# Performance Monitoring Framework

A Selenium 4 automation framework with built-in browser performance monitoring using Chrome DevTools Protocol (CDP), supporting Netskope vs Non-Netskope network comparison testing.

## Features

- **Java 21 LTS** with version-agnostic CDP support
- **Selenium 4.29.0** with ChromiumDriver.executeCdpCommand()
- **Performance Metrics**: Page Load, FCP, LCP, TTI, FID, CLS, TBT
- **Netskope Comparison**: Parallel execution on Netskope vs Non-Netskope machines
- **Jenkins Integration**: Parameterized benchmark thresholds
- **ExtentReports**: Network-type-specific reports
- **OpenSearch**: Optional metrics storage and analysis

## Project Structure

```
performace-monitoring-framework/
├── pom.xml                              # Parent POM
├── Jenkinsfile                          # Parallel Netskope/Non-Netskope execution
│
├── performance-framework-core/          # Core framework
│   └── src/main/java/com/performance/framework/
│       ├── config/                      # Configuration
│       │   ├── ConfigManager.java
│       │   ├── NetworkConfig.java       # Netskope detection
│       │   ├── BenchmarkConfigResolver.java
│       │   └── Application*.java
│       ├── driver/
│       │   ├── DriverFactory.java
│       │   └── CDPManager.java          # Version-agnostic CDP
│       ├── performance/
│       │   ├── PerformanceMetricsCollector.java
│       │   ├── PerformanceMetrics.java
│       │   └── BenchmarkValidator.java
│       ├── comparison/                  # Netskope comparison
│       │   ├── NetworkComparisonResult.java
│       │   └── NetworkPerformanceComparator.java
│       ├── reports/
│       │   ├── ExtentManager.java       # Network-type reports
│       │   └── PerformanceReportLogger.java
│       ├── listeners/
│       │   ├── ExtentReportListener.java
│       │   └── PerformanceMetricsListener.java
│       ├── pages/
│       │   └── BasePage.java
│       ├── tests/
│       │   └── BaseTest.java
│       └── opensearch/
│           └── OpenSearchClientManager.java
│
└── saucedemo-automation/                # Example application
    ├── src/main/java/com/saucedemo/pages/
    │   ├── LoginPage.java
    │   ├── InventoryPage.java
    │   ├── CartPage.java
    │   └── CheckoutPage.java
    ├── src/test/java/com/saucedemo/tests/
    │   ├── LoginTest.java
    │   ├── InventoryTest.java
    │   ├── CheckoutTest.java
    │   └── PerformanceMetricsTest.java
    └── src/test/resources/
        ├── testng.xml
        ├── testng-netskope.xml
        └── testng-non-netskope.xml
```

## Quick Start

### Build

```bash
mvn clean install -DskipTests
```

### Run Tests (Local)

```bash
cd saucedemo-automation
mvn test
```

### Run with Network Type

```bash
# Netskope machine
mvn test -Dnetwork.type=netskope -DsuiteXmlFile=testng-netskope.xml

# Non-Netskope machine
mvn test -Dnetwork.type=non-netskope -DsuiteXmlFile=testng-non-netskope.xml
```

### Run on Selenium Grid

```bash
mvn test -Dbrowser.useGrid=true -Dbrowser.gridUrl=http://localhost:4444
```

## Jenkins Parameters

Override benchmark thresholds via system properties:

```bash
mvn test \
  -Dbenchmark.pageLoad.max=3000 \
  -Dbenchmark.firstContentfulPaint.max=1800 \
  -Dbenchmark.largestContentfulPaint.max=2500
```

**Priority**: Jenkins params > app config.yaml > global application.yaml

## Reports

Reports are generated in `target/extent-reports/`:

- `TestReport_Netskope_<timestamp>.html`
- `TestReport_Non-Netskope_<timestamp>.html`

## Configuration

### application.yaml (Global defaults)

```yaml
browser:
  type: chrome
  headless: false
  useGrid: false

benchmarks:
  pageLoad: { max: 3000, warn: 2000 }
  firstContentfulPaint: { max: 1800, warn: 1200 }
```

### Network Configuration

Set via:

- System property: `-Dnetwork.type=netskope`
- Environment variable: `NETWORK_TYPE=netskope`
- Config file: `network.type: netskope`

## Prerequisites

- Java 21+
- Maven 3.9+
- Chrome browser

## License

MIT
