package com.performance.framework.config;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

// Network config for Netskope vs Non-Netskope comparison testing
// Set via: -Dnetwork.type=netskope or NETWORK_TYPE env var or setThreadNetworkType() for parallel
@Data
@Slf4j
public class NetworkConfig {

    // InheritableThreadLocal for parallel test execution - inherited by child
    // threads
    private static final InheritableThreadLocal<NetworkType> threadNetworkType = new InheritableThreadLocal<>();

    public enum NetworkType {
        NETSKOPE("Netskope", "Traffic via Netskope proxy"),
        NON_NETSKOPE("Non-Netskope", "Direct network access"),
        UNKNOWN("Unknown", "Not specified");

        private final String displayName;
        private final String description;

        NetworkType(String displayName, String description) {
            this.displayName = displayName;
            this.description = description;
        }

        public String getDisplayName() {
            return displayName;
        }

        public String getDescription() {
            return description;
        }

        public static NetworkType fromString(String value) {
            if (value == null || value.trim().isEmpty()) {
                return UNKNOWN;
            }

            String normalized = value.trim().toLowerCase().replace("-", "").replace("_", "");

            if (normalized.contains("netskope") && !normalized.contains("non")) {
                return NETSKOPE;
            } else if (normalized.contains("non") || normalized.contains("direct")) {
                return NON_NETSKOPE;
            }

            // Try exact match
            for (NetworkType type : values()) {
                if (type.name().equalsIgnoreCase(value.trim())) {
                    return type;
                }
            }

            return UNKNOWN;
        }
    }

    private NetworkType type = NetworkType.UNKNOWN;
    private String description;
    private String machineName;
    private String machineId;

    // Priority: ThreadLocal (parallel) > system property > env var > config file
    public static NetworkType getCurrentNetworkType() {
        // Check ThreadLocal first (for parallel execution)
        NetworkType threadType = threadNetworkType.get();
        if (threadType != null) {
            return threadType;
        }

        String sysProp = System.getProperty("network.type");
        if (sysProp != null && !sysProp.isEmpty()) {
            NetworkType type = NetworkType.fromString(sysProp);
            log.debug("Network type from system property: {}", type);
            return type;
        }

        String envVar = System.getenv("NETWORK_TYPE");
        if (envVar != null && !envVar.isEmpty()) {
            NetworkType type = NetworkType.fromString(envVar);
            log.debug("Network type from environment variable: {}", type);
            return type;
        }

        try {
            String configType = ConfigManager.getInstance().getNetworkType();
            if (configType != null && !configType.isEmpty()) {
                NetworkType type = NetworkType.fromString(configType);
                log.debug("Network type from config file: {}", type);
                return type;
            }
        } catch (Exception e) {
            log.warn("Failed to get network type from config: {}", e.getMessage());
        }

        return NetworkType.UNKNOWN;
    }

    public static String getMachineIdentifier() {
        String machineId = System.getProperty("machine.id");
        if (machineId != null && !machineId.isEmpty())
            return machineId;

        machineId = System.getenv("MACHINE_ID");
        if (machineId != null && !machineId.isEmpty())
            return machineId;

        try {
            return java.net.InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            return "unknown-machine";
        }
    }

    public static boolean isNetskope() {
        return getCurrentNetworkType() == NetworkType.NETSKOPE;
    }

    public static boolean isNonNetskope() {
        return getCurrentNetworkType() == NetworkType.NON_NETSKOPE;
    }

    public static String getNetworkTypeForReport() {
        NetworkType type = getCurrentNetworkType();
        String machineId = getMachineIdentifier();
        return String.format("%s (%s)", type.getDisplayName(), machineId);
    }

    // For parallel execution - set network type per thread
    public static void setThreadNetworkType(NetworkType type) {
        threadNetworkType.set(type);
        log.debug("Thread network type set to: {}", type);
    }

    public static void setThreadNetworkType(String type) {
        setThreadNetworkType(NetworkType.fromString(type));
    }

    public static void clearThreadNetworkType() {
        threadNetworkType.remove();
    }
}
