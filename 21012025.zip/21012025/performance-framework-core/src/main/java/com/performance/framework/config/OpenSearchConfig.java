package com.performance.framework.config;

import lombok.Builder;
import lombok.Data;

/**
 * OpenSearch configuration POJO
 */
@Data
@Builder
public class OpenSearchConfig {
    private boolean enabled;
    private String host;
    private int port;
    private String scheme;
    private String indexName;
    private String username;
    private String password;
    private int connectTimeout;
    private int socketTimeout;

    /**
     * Build connection URL
     */
    public String getConnectionUrl() {
        return "%s://%s:%d".formatted(scheme, host, port);
    }

    /**
     * Check if authentication is configured
     */
    public boolean hasCredentials() {
        return username != null && !username.isEmpty()
                && password != null && !password.isEmpty();
    }
}
