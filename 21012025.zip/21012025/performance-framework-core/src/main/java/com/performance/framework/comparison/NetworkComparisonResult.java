package com.performance.framework.comparison;

import com.performance.framework.config.NetworkConfig.NetworkType;
import com.performance.framework.performance.PerformanceMetrics;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

// Compares performance metrics between Netskope and Non-Netskope test runs
@SuppressWarnings("unused")
@Data
@Builder
@Slf4j
public class NetworkComparisonResult {

    private String testName;
    private String pageName;

    // Netskope metrics (proxied network)
    private PerformanceMetrics netskopeMetrics;
    private String netskopeMachineId;

    // Non-Netskope metrics (direct network)
    private PerformanceMetrics nonNetskopeMetrics;
    private String nonNetskopeMachineId;

    // Computed differences
    private MetricDifference pageLoadDiff;
    private MetricDifference fcpDiff;
    private MetricDifference lcpDiff;
    private MetricDifference ttfbDiff;
    private MetricDifference dclDiff;
    private MetricDifference ttiDiff;

    @Data
    @Builder
    public static class MetricDifference {
        private String metricName;
        private long netskopeValue;
        private long nonNetskopeValue;
        private long absoluteDifference;
        private double percentageDifference;
        private String impact; // "Faster", "Slower", "Same"

        public static MetricDifference calculate(String name, long netskopeVal, long nonNetskopeVal) {
            long diff = netskopeVal - nonNetskopeVal;
            double pctDiff = nonNetskopeVal > 0
                    ? ((double) diff / nonNetskopeVal) * 100
                    : 0;

            String impact;
            if (diff > 50) { // More than 50ms slower
                impact = "Slower on Netskope";
            } else if (diff < -50) { // More than 50ms faster
                impact = "Faster on Netskope";
            } else {
                impact = "Similar";
            }

            return MetricDifference.builder()
                    .metricName(name)
                    .netskopeValue(netskopeVal)
                    .nonNetskopeValue(nonNetskopeVal)
                    .absoluteDifference(diff)
                    .percentageDifference(Math.round(pctDiff * 100.0) / 100.0)
                    .impact(impact)
                    .build();
        }

        @Override
        public String toString() {
            return String.format("%s: Netskope=%dms, Non-Netskope=%dms, Diff=%+dms (%.1f%%) - %s",
                    metricName, netskopeValue, nonNetskopeValue, absoluteDifference, percentageDifference, impact);
        }
    }

    /**
     * Calculate all metric differences between networks.
     */
    public void calculateDifferences() {
        if (netskopeMetrics != null && nonNetskopeMetrics != null) {
            pageLoadDiff = MetricDifference.calculate("Page Load",
                    netskopeMetrics.getPageLoadTime(), nonNetskopeMetrics.getPageLoadTime());
            fcpDiff = MetricDifference.calculate("First Contentful Paint",
                    netskopeMetrics.getFirstContentfulPaint(), nonNetskopeMetrics.getFirstContentfulPaint());
            lcpDiff = MetricDifference.calculate("Largest Contentful Paint",
                    netskopeMetrics.getLargestContentfulPaint(), nonNetskopeMetrics.getLargestContentfulPaint());
            ttfbDiff = MetricDifference.calculate("Time to First Byte",
                    netskopeMetrics.getTimeToFirstByte(), nonNetskopeMetrics.getTimeToFirstByte());
            dclDiff = MetricDifference.calculate("DOM Content Loaded",
                    netskopeMetrics.getDomContentLoaded(), nonNetskopeMetrics.getDomContentLoaded());
            ttiDiff = MetricDifference.calculate("Time to Interactive",
                    netskopeMetrics.getTimeToInteractive(), nonNetskopeMetrics.getTimeToInteractive());
        }
    }

    /**
     * Get all computed differences as a list.
     */
    public List<MetricDifference> getAllDifferences() {
        List<MetricDifference> diffs = new ArrayList<>();
        if (pageLoadDiff != null)
            diffs.add(pageLoadDiff);
        if (fcpDiff != null)
            diffs.add(fcpDiff);
        if (lcpDiff != null)
            diffs.add(lcpDiff);
        if (ttfbDiff != null)
            diffs.add(ttfbDiff);
        if (dclDiff != null)
            diffs.add(dclDiff);
        if (ttiDiff != null)
            diffs.add(ttiDiff);
        return diffs;
    }

    /**
     * Get a summary of the comparison.
     */
    public String getSummary() {
        if (netskopeMetrics == null || nonNetskopeMetrics == null) {
            return "Comparison incomplete - missing metrics from one or both networks";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("\n╔══════════════════════════════════════════════════════════════════════════════╗\n");
        sb.append("║              NETSKOPE vs NON-NETSKOPE PERFORMANCE COMPARISON                 ║\n");
        sb.append("╠══════════════════════════════════════════════════════════════════════════════╣\n");
        sb.append(String.format("║  Test: %-70s║\n", testName));
        sb.append(String.format("║  Page: %-70s║\n", pageName));
        sb.append("╠══════════════════════════════════════════════════════════════════════════════╣\n");
        sb.append(String.format("║  Netskope Machine:     %-54s║\n",
                netskopeMachineId != null ? netskopeMachineId : "Unknown"));
        sb.append(String.format("║  Non-Netskope Machine: %-54s║\n",
                nonNetskopeMachineId != null ? nonNetskopeMachineId : "Unknown"));
        sb.append("╠══════════════════════════════════════════════════════════════════════════════╣\n");
        sb.append("║  Metric                    │ Netskope │ Non-Netskope │   Diff   │  Impact   ║\n");
        sb.append("╟────────────────────────────┼──────────┼──────────────┼──────────┼───────────╢\n");

        for (MetricDifference diff : getAllDifferences()) {
            sb.append(String.format("║  %-25s │ %7dms│  %9dms  │ %+7dms│ %-9s ║\n",
                    diff.getMetricName(),
                    diff.getNetskopeValue(),
                    diff.getNonNetskopeValue(),
                    diff.getAbsoluteDifference(),
                    diff.getImpact().replace(" on Netskope", "")));
        }

        sb.append("╚══════════════════════════════════════════════════════════════════════════════╝\n");

        return sb.toString();
    }

    /**
     * Log the comparison summary.
     */
    public void logComparison() {
        log.info(getSummary());
    }

    /**
     * Determine overall network impact.
     */
    public String getOverallImpact() {
        if (pageLoadDiff == null)
            return "Unknown";

        int slowerCount = 0;
        int fasterCount = 0;

        for (MetricDifference diff : getAllDifferences()) {
            if (diff.getImpact().contains("Slower"))
                slowerCount++;
            else if (diff.getImpact().contains("Faster"))
                fasterCount++;
        }

        if (slowerCount > fasterCount + 1) {
            return "Netskope adds noticeable latency";
        } else if (fasterCount > slowerCount + 1) {
            return "Netskope performs better (unusual - verify results)";
        } else {
            return "Network impact is minimal";
        }
    }
}
