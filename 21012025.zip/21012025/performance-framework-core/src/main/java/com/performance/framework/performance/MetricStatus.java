package com.performance.framework.performance;

/**
 * Enum representing the status of a performance metric after benchmark
 * validation.
 */
public enum MetricStatus {

    /**
     * Metric value is within acceptable threshold
     */
    PASS("PASS", "✓", "Within threshold"),

    /**
     * Metric value exceeds threshold but is within warning range
     */
    WARN("WARN", "⚠", "Exceeds threshold but within warning range"),

    /**
     * Metric value exceeds warning threshold - action required
     */
    FAIL("FAIL", "✗", "Exceeds warning threshold"),

    /**
     * Metric could not be collected or validated
     */
    UNKNOWN("UNKNOWN", "?", "Unable to determine status");

    private final String code;
    private final String symbol;
    private final String description;

    MetricStatus(String code, String symbol, String description) {
        this.code = code;
        this.symbol = symbol;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Get CSS class name for Extent Reports styling
     */
    public String getCssClass() {
        switch (this) {
            case PASS:
                return "badge-success";
            case WARN:
                return "badge-warning";
            case FAIL:
                return "badge-danger";
            default:
                return "badge-secondary";
        }
    }

    /**
     * Get HTML color code
     */
    public String getHtmlColor() {
        switch (this) {
            case PASS:
                return "#28a745";
            case WARN:
                return "#ffc107";
            case FAIL:
                return "#dc3545";
            default:
                return "#6c757d";
        }
    }

    @Override
    public String toString() {
        return "%s %s".formatted(symbol, code);
    }
}
