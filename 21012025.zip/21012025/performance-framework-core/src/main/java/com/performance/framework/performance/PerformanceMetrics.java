package com.performance.framework.performance;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * POJO representing performance metrics collected from browser.
 * Contains all core web vitals and navigation timing metrics.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PerformanceMetrics {

    // Identification
    private String testName;
    private String pageName;
    private String url;

    // Context
    private String environment;
    private String browser;
    private String networkType; // Netskope or Non-Netskope
    private String machineId; // Machine identifier for comparison

    // Navigation Timing Metrics (in milliseconds)
    private long pageLoadTime;
    private long domContentLoaded;
    private long domInteractive;
    private long domComplete;

    // Core Web Vitals (in milliseconds)
    private long firstContentfulPaint; // FCP
    private long largestContentfulPaint; // LCP
    private long timeToInteractive; // TTI
    private long firstInputDelay; // FID
    private double cumulativeLayoutShift; // CLS (not in ms)
    private long totalBlockingTime; // TBT

    // Network Metrics
    private long timeToFirstByte; // TTFB
    private long dnsLookupTime;
    private long connectionTime;
    private long tlsTime;
    private long requestTime;
    private long responseTime;

    // Resource Metrics
    private int resourceCount;
    private long totalResourceSize;
    private long totalTransferSize;

    // JavaScript Metrics
    private long jsHeapUsedSize;
    private long jsHeapTotalSize;
    private long scriptDuration;
    private long taskDuration;

    // Timestamp
    private Instant timestamp;

    // Raw metrics map for additional data
    @Builder.Default
    private Map<String, Object> rawMetrics = new HashMap<>();

    // Validation status
    @Builder.Default
    private Map<String, MetricStatus> statusMap = new HashMap<>();

    /**
     * Add a raw metric value
     */
    public void addRawMetric(String name, Object value) {
        if (rawMetrics == null) {
            rawMetrics = new HashMap<>();
        }
        rawMetrics.put(name, value);
    }

    /**
     * Set status for a specific metric
     */
    public void setMetricStatus(String metricName, MetricStatus status) {
        if (statusMap == null) {
            statusMap = new HashMap<>();
        }
        statusMap.put(metricName, status);
    }

    /**
     * Get status for a specific metric
     */
    public MetricStatus getMetricStatus(String metricName) {
        return statusMap != null ? statusMap.get(metricName) : null;
    }

    /**
     * Check if any metric has FAIL status
     */
    public boolean hasFailures() {
        if (statusMap == null) {
            return false;
        }
        return statusMap.values().stream().anyMatch(s -> s == MetricStatus.FAIL);
    }

    /**
     * Check if any metric has WARN status
     */
    public boolean hasWarnings() {
        if (statusMap == null) {
            return false;
        }
        return statusMap.values().stream().anyMatch(s -> s == MetricStatus.WARN);
    }

    /**
     * Get overall status based on all metrics
     */
    public MetricStatus getOverallStatus() {
        if (hasFailures()) {
            return MetricStatus.FAIL;
        }
        if (hasWarnings()) {
            return MetricStatus.WARN;
        }
        return MetricStatus.PASS;
    }

    /**
     * Convert metrics to a flat map for JSON serialization
     */
    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("testName", testName);
        map.put("pageName", pageName);
        map.put("url", url);
        map.put("environment", environment);
        map.put("browser", browser);
        map.put("networkType", networkType);
        map.put("machineId", machineId);
        map.put("pageLoadTime", pageLoadTime);
        map.put("domContentLoaded", domContentLoaded);
        map.put("domInteractive", domInteractive);
        map.put("domComplete", domComplete);
        map.put("firstContentfulPaint", firstContentfulPaint);
        map.put("largestContentfulPaint", largestContentfulPaint);
        map.put("timeToInteractive", timeToInteractive);
        map.put("firstInputDelay", firstInputDelay);
        map.put("cumulativeLayoutShift", cumulativeLayoutShift);
        map.put("totalBlockingTime", totalBlockingTime);
        map.put("timeToFirstByte", timeToFirstByte);
        map.put("dnsLookupTime", dnsLookupTime);
        map.put("connectionTime", connectionTime);
        map.put("tlsTime", tlsTime);
        map.put("requestTime", requestTime);
        map.put("responseTime", responseTime);
        map.put("resourceCount", resourceCount);
        map.put("totalResourceSize", totalResourceSize);
        map.put("totalTransferSize", totalTransferSize);
        map.put("jsHeapUsedSize", jsHeapUsedSize);
        map.put("jsHeapTotalSize", jsHeapTotalSize);
        map.put("scriptDuration", scriptDuration);
        map.put("taskDuration", taskDuration);
        map.put("timestamp", timestamp != null ? timestamp.toString() : null);
        map.put("overallStatus", getOverallStatus().name());
        map.put("statusMap", statusMap);
        return map;
    }

    /**
     * Generate a summary string
     */
    public String getSummary() {
        return "PerformanceMetrics[page=%s, network=%s, load=%dms, FCP=%dms, LCP=%dms, TTI=%dms, status=%s]".formatted(
                pageName, networkType != null ? networkType : "Unknown", pageLoadTime, firstContentfulPaint,
                largestContentfulPaint, timeToInteractive, getOverallStatus());
    }

    /**
     * Generate a detailed summary including network info
     */
    public String getDetailedSummary() {
        return String.format(
                "PerformanceMetrics[page=%s, network=%s, machine=%s, load=%dms, FCP=%dms, LCP=%dms, TTFB=%dms, status=%s]",
                pageName,
                networkType != null ? networkType : "Unknown",
                machineId != null ? machineId : "Unknown",
                pageLoadTime,
                firstContentfulPaint,
                largestContentfulPaint,
                timeToFirstByte,
                getOverallStatus());
    }
}
