package com.performance.framework.config;

import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

// Priority: Jenkins params (-Dbenchmark.x.max) > app config.yaml > global application.yaml
@Slf4j
public class BenchmarkConfigResolver {

    private static final String JENKINS_PARAM_PREFIX = "benchmark.";

    private final ConfigManager configManager;
    private final ApplicationConfigManager appConfigManager;

    // Cache for resolved benchmarks
    private final Map<String, ResolvedBenchmark> resolvedCache = new HashMap<>();

    public BenchmarkConfigResolver() {
        this.configManager = ConfigManager.getInstance();
        this.appConfigManager = ApplicationConfigManager.getInstance();
    }

    public BenchmarkConfigResolver(ConfigManager configManager, ApplicationConfigManager appConfigManager) {
        this.configManager = configManager;
        this.appConfigManager = appConfigManager;
    }

    public long getBenchmark(String metricName, String threshold) {
        String cacheKey = metricName + "." + threshold;

        if (resolvedCache.containsKey(cacheKey)) {
            return resolvedCache.get(cacheKey).value();
        }

        ResolvedBenchmark resolved = resolveBenchmark(metricName, threshold);
        resolvedCache.put(cacheKey, resolved);

        return resolved.value();
    }

    public long getBenchmark(String key) {
        String[] parts = key.split("\\.");
        if (parts.length != 2) {
            log.warn("Invalid benchmark key format: {}. Expected: metricName.threshold", key);
            return Long.MAX_VALUE;
        }
        return getBenchmark(parts[0], parts[1]);
    }

    public BenchmarkSource getBenchmarkSource(String metricName, String threshold) {
        String cacheKey = metricName + "." + threshold;

        if (!resolvedCache.containsKey(cacheKey)) {
            resolveBenchmark(metricName, threshold);
        }

        ResolvedBenchmark resolved = resolvedCache.get(cacheKey);
        return resolved != null ? resolved.source() : BenchmarkSource.DEFAULT;
    }

    private ResolvedBenchmark resolveBenchmark(String metricName, String threshold) {
        // 1. Check Jenkins Parameters (System Properties)
        String jenkinsKey = JENKINS_PARAM_PREFIX + metricName + "." + threshold;
        String jenkinsValue = System.getProperty(jenkinsKey);

        if (jenkinsValue != null && !jenkinsValue.trim().isEmpty()) {
            try {
                long value = Long.parseLong(jenkinsValue.trim());
                if (value > 0) {
                    log.debug("Benchmark {}.{} = {} (SOURCE: Jenkins Parameter)",
                            metricName, threshold, value);
                    return new ResolvedBenchmark(value, BenchmarkSource.JENKINS_PARAMETER);
                } else {
                    log.warn("Invalid Jenkins benchmark value for {}.{}: {} (must be positive)",
                            metricName, threshold, value);
                }
            } catch (NumberFormatException e) {
                log.warn("Invalid Jenkins benchmark value for {}.{}: {} (not a number)",
                        metricName, threshold, jenkinsValue);
            }
        }

        // 2. Check Application-specific config
        ApplicationConfig appConfig = appConfigManager.getCurrentApplicationConfig();
        if (appConfig != null && appConfig.getBenchmarks() != null) {
            Long appValue = getFromMap(appConfig.getBenchmarks(), metricName, threshold);
            if (appValue != null && appValue > 0) {
                log.debug("Benchmark {}.{} = {} (SOURCE: Application Config - {})",
                        metricName, threshold, appValue, appConfig.getName());
                return new ResolvedBenchmark(appValue, BenchmarkSource.APPLICATION_CONFIG);
            }
        }

        // 3. Fall back to Global defaults
        long globalValue = configManager.getBenchmark(metricName + "." + threshold);
        if (globalValue != Long.MAX_VALUE && globalValue > 0) {
            log.debug("Benchmark {}.{} = {} (SOURCE: Global Default)",
                    metricName, threshold, globalValue);
            return new ResolvedBenchmark(globalValue, BenchmarkSource.GLOBAL_DEFAULT);
        }

        // 4. Return MAX_VALUE as ultimate fallback (no threshold)
        log.warn("No benchmark found for {}.{}, using no threshold", metricName, threshold);
        return new ResolvedBenchmark(Long.MAX_VALUE, BenchmarkSource.DEFAULT);
    }

    @SuppressWarnings("unchecked")
    private Long getFromMap(Map<String, Object> map, String metricName, String threshold) {
        if (map == null)
            return null;

        Object metricObj = map.get(metricName);
        if (metricObj instanceof Map) {
            Map<String, Object> metricMap = (Map<String, Object>) metricObj;
            Object value = metricMap.get(threshold);
            if (value != null) {
                return toLong(value);
            }
        }
        return null;
    }

    private Long toLong(Object value) {
        if (value == null)
            return null;
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        try {
            return Long.parseLong(value.toString().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public BenchmarkThresholds getThresholds(String metricName) {
        long max = getBenchmark(metricName, "max");
        long warn = getBenchmark(metricName, "warn");
        BenchmarkSource maxSource = getBenchmarkSource(metricName, "max");
        BenchmarkSource warnSource = getBenchmarkSource(metricName, "warn");

        return new BenchmarkThresholds(metricName, max, warn, maxSource, warnSource);
    }

    public void logBenchmarkSources() {
        log.info("=== Benchmark Configuration Sources ===");

        String[] metrics = {
                "pageLoad", "domContentLoaded", "firstContentfulPaint",
                "largestContentfulPaint", "timeToInteractive", "firstByte",
                "firstInputDelay", "cumulativeLayoutShift", "totalBlockingTime"
        };

        for (String metric : metrics) {
            BenchmarkThresholds thresholds = getThresholds(metric);
            log.info("{}: max={} ({}), warn={} ({})",
                    metric,
                    thresholds.max() == Long.MAX_VALUE ? "N/A" : thresholds.max(),
                    thresholds.maxSource().getDisplayName(),
                    thresholds.warn() == Long.MAX_VALUE ? "N/A" : thresholds.warn(),
                    thresholds.warnSource().getDisplayName());
        }

        log.info("=======================================");
    }

    public boolean hasJenkinsOverrides() {
        return System.getProperties().stringPropertyNames().stream()
                .anyMatch(key -> key.startsWith(JENKINS_PARAM_PREFIX));
    }

    public Map<String, String> getJenkinsOverrides() {
        Map<String, String> overrides = new HashMap<>();
        for (String key : System.getProperties().stringPropertyNames()) {
            if (key.startsWith(JENKINS_PARAM_PREFIX)) {
                overrides.put(key, System.getProperty(key));
            }
        }
        return overrides;
    }

    public void clearCache() {
        resolvedCache.clear();
    }

    // Record classes for structured data
    public record ResolvedBenchmark(long value, BenchmarkSource source) {
    }

    public record BenchmarkThresholds(
            String metricName,
            long max,
            long warn,
            BenchmarkSource maxSource,
            BenchmarkSource warnSource) {
    }

    public enum BenchmarkSource {
        JENKINS_PARAMETER("Jenkins Parameter"),
        APPLICATION_CONFIG("Application Config"),
        GLOBAL_DEFAULT("Global Default"),
        DEFAULT("No Config");

        private final String displayName;

        BenchmarkSource(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }
}
