package com.performance.framework.performance;

import com.performance.framework.config.BenchmarkConfigResolver;
import com.performance.framework.config.BenchmarkConfigResolver.BenchmarkSource;
import lombok.extern.slf4j.Slf4j;

/**
 * Validates performance metrics against benchmarks.
 * Uses BenchmarkConfigResolver for priority-based benchmark resolution:
 * 1. Jenkins Parameters (highest priority)
 * 2. Application-specific config.yaml
 * 3. Global application.yaml defaults (lowest priority)
 */
@Slf4j
public class BenchmarkValidator {

    private final BenchmarkConfigResolver benchmarkResolver;

    public BenchmarkValidator() {
        this.benchmarkResolver = new BenchmarkConfigResolver();
    }

    public BenchmarkValidator(BenchmarkConfigResolver resolver) {
        this.benchmarkResolver = resolver;
    }

    /**
     * Initialize and log benchmark sources (call at test suite start)
     */
    public void initialize() {
        if (benchmarkResolver.hasJenkinsOverrides()) {
            log.info("Jenkins benchmark overrides detected");
        }
        benchmarkResolver.logBenchmarkSources();
    }

    public void validateMetrics(PerformanceMetrics metrics) {
        validateMetric(metrics, "pageLoad", metrics.getPageLoadTime());
        validateMetric(metrics, "domContentLoaded", metrics.getDomContentLoaded());
        validateMetric(metrics, "firstContentfulPaint", metrics.getFirstContentfulPaint());
        validateMetric(metrics, "largestContentfulPaint", metrics.getLargestContentfulPaint());
        validateMetric(metrics, "timeToInteractive", metrics.getTimeToInteractive());
        validateMetric(metrics, "firstByte", metrics.getTimeToFirstByte());
        validateMetric(metrics, "firstInputDelay", metrics.getFirstInputDelay());
        validateMetric(metrics, "totalBlockingTime", metrics.getTotalBlockingTime());

        log.debug("Metrics validation completed. Status: {}", metrics.getOverallStatus());
    }

    public MetricStatus validateMetric(PerformanceMetrics metrics, String metricName, long actualValue) {
        if (actualValue <= 0) {
            metrics.setMetricStatus(metricName, MetricStatus.UNKNOWN);
            return MetricStatus.UNKNOWN;
        }

        BenchmarkThreshold threshold = getThreshold(metricName);

        MetricStatus status;
        if (actualValue <= threshold.getMaxThreshold()) {
            status = MetricStatus.PASS;
        } else if (actualValue <= threshold.getWarnThreshold()) {
            status = MetricStatus.WARN;
        } else {
            status = MetricStatus.FAIL;
        }

        metrics.setMetricStatus(metricName, status);
        return status;
    }

    public MetricStatus validateSingleMetric(String metricName, long actualValue) {
        if (actualValue <= 0)
            return MetricStatus.UNKNOWN;

        BenchmarkThreshold threshold = getThreshold(metricName);

        if (actualValue <= threshold.getMaxThreshold())
            return MetricStatus.PASS;
        if (actualValue <= threshold.getWarnThreshold())
            return MetricStatus.WARN;
        return MetricStatus.FAIL;
    }

    /**
     * Get benchmark threshold for a metric using priority-based resolution.
     */
    public BenchmarkThreshold getThreshold(String metricName) {
        BenchmarkConfigResolver.BenchmarkThresholds resolved = benchmarkResolver.getThresholds(metricName);

        return new BenchmarkThreshold(
                metricName,
                resolved.max(),
                resolved.warn(),
                resolved.maxSource(),
                resolved.warnSource());
    }

    /**
     * Get the benchmark resolver for advanced operations
     */
    public BenchmarkConfigResolver getResolver() {
        return benchmarkResolver;
    }

    /**
     * Represents benchmark thresholds with source tracking
     */
    public static class BenchmarkThreshold {
        private final String metricName;
        private final long maxThreshold;
        private final long warnThreshold;
        private final BenchmarkSource maxSource;
        private final BenchmarkSource warnSource;

        public BenchmarkThreshold(String metricName, long maxThreshold, long warnThreshold) {
            this(metricName, maxThreshold, warnThreshold, BenchmarkSource.DEFAULT, BenchmarkSource.DEFAULT);
        }

        public BenchmarkThreshold(String metricName, long maxThreshold, long warnThreshold,
                BenchmarkSource maxSource, BenchmarkSource warnSource) {
            this.metricName = metricName;
            this.maxThreshold = maxThreshold;
            this.warnThreshold = warnThreshold;
            this.maxSource = maxSource;
            this.warnSource = warnSource;
        }

        public String getMetricName() {
            return metricName;
        }

        public long getMaxThreshold() {
            return maxThreshold;
        }

        public long getWarnThreshold() {
            return warnThreshold;
        }

        public BenchmarkSource getMaxSource() {
            return maxSource;
        }

        public BenchmarkSource getWarnSource() {
            return warnSource;
        }

        @Override
        public String toString() {
            return "BenchmarkThreshold[%s: max=%d (%s), warn=%d (%s)]"
                    .formatted(metricName, maxThreshold, maxSource.getDisplayName(),
                            warnThreshold, warnSource.getDisplayName());
        }
    }
}
