package com.performance.framework.driver;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chromium.ChromiumDriver;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Version-agnostic CDP manager via ChromiumDriver.executeCdpCommand() - works with any Chrome version
@Slf4j
public class CDPManager {

    private final ChromiumDriver driver;
    private boolean devToolsAvailable = false;
    private boolean performanceEnabled = false;
    private boolean networkEnabled = false;
    private boolean pageEnabled = false;

    public CDPManager(WebDriver driver) {
        if (driver instanceof ChromiumDriver chromiumDriver) {
            this.driver = chromiumDriver;
            this.devToolsAvailable = true;
            log.debug("CDPManager initialized with ChromiumDriver (version-agnostic)");
        } else {
            this.driver = null;
            this.devToolsAvailable = false;
            log.debug("CDPManager: Non-Chromium browser, CDP not available");
        }
    }

    public boolean isAvailable() {
        return devToolsAvailable && driver != null;
    }

    public void enablePerformanceDomain() {
        if (!isAvailable() || performanceEnabled)
            return;

        try {
            executeCdpCommand("Performance.enable", new HashMap<>());
            performanceEnabled = true;
            log.debug("CDP Performance domain enabled");
        } catch (Exception e) {
            log.warn("Failed to enable Performance domain: {}", e.getMessage());
        }
    }

    public void enableNetworkDomain() {
        if (!isAvailable() || networkEnabled)
            return;

        try {
            executeCdpCommand("Network.enable", new HashMap<>());
            networkEnabled = true;
            log.debug("CDP Network domain enabled");
        } catch (Exception e) {
            log.warn("Failed to enable Network domain: {}", e.getMessage());
        }
    }

    public void enablePageDomain() {
        if (!isAvailable() || pageEnabled)
            return;

        try {
            executeCdpCommand("Page.enable", new HashMap<>());
            pageEnabled = true;
            log.debug("CDP Page domain enabled");
        } catch (Exception e) {
            log.warn("Failed to enable Page domain: {}", e.getMessage());
        }
    }

    public void enableAllPerformanceDomains() {
        if (!isAvailable()) {
            log.debug("CDP not available, skipping domain enablement");
            return;
        }

        enablePerformanceDomain();
        enableNetworkDomain();
        enablePageDomain();

        log.info("CDP domains enabled: Performance={}, Network={}, Page={}",
                performanceEnabled, networkEnabled, pageEnabled);
    }

    public void disablePerformanceDomain() {
        if (!isAvailable() || !performanceEnabled)
            return;

        try {
            executeCdpCommand("Performance.disable", new HashMap<>());
            performanceEnabled = false;
        } catch (Exception e) {
            log.warn("Failed to disable Performance domain: {}", e.getMessage());
        }
    }

    public void disableNetworkDomain() {
        if (!isAvailable() || !networkEnabled)
            return;

        try {
            executeCdpCommand("Network.disable", new HashMap<>());
            networkEnabled = false;
        } catch (Exception e) {
            log.warn("Failed to disable Network domain: {}", e.getMessage());
        }
    }

    public void disablePageDomain() {
        if (!isAvailable() || !pageEnabled)
            return;

        try {
            executeCdpCommand("Page.disable", new HashMap<>());
            pageEnabled = false;
        } catch (Exception e) {
            log.warn("Failed to disable Page domain: {}", e.getMessage());
        }
    }

    public void disableAllDomains() {
        disablePerformanceDomain();
        disableNetworkDomain();
        disablePageDomain();
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> getPerformanceMetrics() {
        if (!isAvailable()) {
            return new HashMap<>();
        }

        try {
            Map<String, Object> result = executeCdpCommand("Performance.getMetrics", new HashMap<>());

            if (result != null && result.containsKey("metrics")) {
                Map<String, Object> metricsMap = new HashMap<>();
                Object metrics = result.get("metrics");

                if (metrics instanceof List<?> metricsList) {
                    for (Object metric : metricsList) {
                        if (metric instanceof Map<?, ?> m) {
                            String name = (String) m.get("name");
                            Object value = m.get("value");
                            if (name != null && value != null) {
                                metricsMap.put(name, value);
                            }
                        }
                    }
                }
                return metricsMap;
            }
        } catch (Exception e) {
            log.warn("Failed to get CDP performance metrics: {}", e.getMessage());
        }

        return new HashMap<>();
    }

    // Simulate network conditions (offline, latency in ms, throughput in bytes/sec)
    public void emulateNetworkConditions(boolean offline, long latency,
            long downloadThroughput, long uploadThroughput) {
        if (!isAvailable()) {
            log.warn("CDP not available, cannot emulate network conditions");
            return;
        }

        try {
            Map<String, Object> params = new HashMap<>();
            params.put("offline", offline);
            params.put("latency", latency);
            params.put("downloadThroughput", downloadThroughput);
            params.put("uploadThroughput", uploadThroughput);

            executeCdpCommand("Network.emulateNetworkConditions", params);
            log.info("Network conditions emulated: offline={}, latency={}ms", offline, latency);
        } catch (Exception e) {
            log.warn("Failed to emulate network conditions: {}", e.getMessage());
        }
    }

    public void emulateSlowNetwork() {
        // Slow 3G: 400ms latency, 500kb/s
        emulateNetworkConditions(false, 400, 500 * 1024 / 8, 500 * 1024 / 8);
    }

    public void emulateFastNetwork() {
        // Fast 3G: 100ms latency, 1.5Mb/s
        emulateNetworkConditions(false, 100, 1500 * 1024 / 8, 750 * 1024 / 8);
    }

    public void disableNetworkThrottling() {
        emulateNetworkConditions(false, 0, -1, -1);
    }

    public void clearBrowserCache() {
        if (!isAvailable())
            return;

        try {
            executeCdpCommand("Network.clearBrowserCache", new HashMap<>());
            log.debug("Browser cache cleared");
        } catch (Exception e) {
            log.warn("Failed to clear browser cache: {}", e.getMessage());
        }
    }

    public void clearBrowserCookies() {
        if (!isAvailable())
            return;

        try {
            executeCdpCommand("Network.clearBrowserCookies", new HashMap<>());
            log.debug("Browser cookies cleared");
        } catch (Exception e) {
            log.warn("Failed to clear browser cookies: {}", e.getMessage());
        }
    }

    // Rate: 1 = no throttle, 4 = 4x slowdown, 6 = 6x slowdown
    public void setCPUThrottlingRate(int rate) {
        if (!isAvailable())
            return;

        try {
            Map<String, Object> params = new HashMap<>();
            params.put("rate", rate);
            executeCdpCommand("Emulation.setCPUThrottlingRate", params);
            log.info("CPU throttling set to {}x", rate);
        } catch (Exception e) {
            log.warn("Failed to set CPU throttling: {}", e.getMessage());
        }
    }

    // Version-agnostic CDP command execution
    public Map<String, Object> executeCdpCommand(String command, Map<String, Object> params) {
        if (!isAvailable()) {
            log.debug("CDP not available, skipping command: {}", command);
            return new HashMap<>();
        }

        try {
            return driver.executeCdpCommand(command, params);
        } catch (Exception e) {
            log.debug("CDP command failed: {} - {}", command, e.getMessage());
            throw e;
        }
    }

    public void cleanup() {
        if (!isAvailable())
            return;

        try {
            disableAllDomains();
            log.debug("CDP cleanup completed");
        } catch (Exception e) {
            log.debug("Error during CDP cleanup: {}", e.getMessage());
        }
    }

    public ChromiumDriver getDriver() {
        return driver;
    }

    public boolean isPerformanceEnabled() {
        return performanceEnabled;
    }

    public boolean isNetworkEnabled() {
        return networkEnabled;
    }

    public boolean isPageEnabled() {
        return pageEnabled;
    }
}
