package com.performance.framework.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages application-specific configurations for multi-application support.
 * Each application has its own config.yaml and testdata.yaml files.
 * 
 * Usage:
 * ApplicationConfigManager.getInstance().setCurrentApplication("opencart");
 * ApplicationConfig appConfig =
 * ApplicationConfigManager.getInstance().getCurrentApplicationConfig();
 * String email = appConfig.getTestData("users.validUser.email");
 */
@Slf4j
public class ApplicationConfigManager {

    private static ApplicationConfigManager instance;
    private static final String APPLICATIONS_BASE_PATH = "config/applications/";
    private static final String CONFIG_FILE = "config.yaml";
    private static final String TESTDATA_FILE = "testdata.yaml";

    private final Map<String, ApplicationConfig> applicationConfigs = new ConcurrentHashMap<>();
    private final ObjectMapper yamlMapper = new ObjectMapper(new YAMLFactory());

    @Getter
    private String currentApplication;

    @Getter
    private String currentEnvironment;

    private ApplicationConfigManager() {
        // Default application from system property or "saucedemo"
        this.currentApplication = System.getProperty("application", "saucedemo");
        this.currentEnvironment = System.getProperty("environment", "local");
        try {
            loadApplication(currentApplication);
        } catch (RuntimeException e) {
            log.warn("Default application '{}' not found. Will load on first setCurrentApplication() call.",
                    currentApplication);
        }
    }

    public static synchronized ApplicationConfigManager getInstance() {
        if (instance == null) {
            instance = new ApplicationConfigManager();
        }
        return instance;
    }

    /**
     * Set the current application and load its configuration.
     * Always reloads to ensure environment settings are current.
     */
    public void setCurrentApplication(String applicationName) {
        this.currentApplication = applicationName.toLowerCase();
        // Always reload to ensure we have the latest environment settings
        loadApplication(currentApplication);
        log.info("Switched to application: {}", currentApplication);
    }

    /**
     * Set the current environment
     */
    public void setCurrentEnvironment(String environment) {
        this.currentEnvironment = environment.toLowerCase();
        log.info("Switched to environment: {}", currentEnvironment);
    }

    /**
     * Get the current application's configuration
     */
    public ApplicationConfig getCurrentApplicationConfig() {
        if (!applicationConfigs.containsKey(currentApplication)) {
            loadApplication(currentApplication);
        }
        return applicationConfigs.get(currentApplication);
    }

    /**
     * Get configuration for a specific application
     */
    public ApplicationConfig getApplicationConfig(String applicationName) {
        String appKey = applicationName.toLowerCase();
        if (!applicationConfigs.containsKey(appKey)) {
            loadApplication(appKey);
        }
        return applicationConfigs.get(appKey);
    }

    /**
     * Load application configuration and test data
     */
    @SuppressWarnings("unchecked")
    private void loadApplication(String applicationName) {
        String configPath = APPLICATIONS_BASE_PATH + applicationName + "/" + CONFIG_FILE;
        String testDataPath = APPLICATIONS_BASE_PATH + applicationName + "/" + TESTDATA_FILE;

        try {
            // Load config.yaml
            Map<String, Object> configMap = loadYamlFile(configPath);
            if (configMap == null) {
                throw new RuntimeException("Application configuration not found: " + configPath);
            }

            // Load testdata.yaml (optional)
            Map<String, Object> testDataMap = loadYamlFile(testDataPath);
            if (testDataMap == null) {
                log.warn("Test data file not found for application: {}. Proceeding without test data.",
                        applicationName);
                testDataMap = Map.of();
            }

            // Extract application info
            Map<String, Object> appInfo = (Map<String, Object>) configMap.get("application");
            Map<String, Object> environments = (Map<String, Object>) configMap.get("environments");
            Map<String, Object> settings = (Map<String, Object>) configMap.get("settings");
            Map<String, Object> pages = (Map<String, Object>) configMap.get("pages");
            Map<String, Object> benchmarks = (Map<String, Object>) configMap.get("benchmarks");

            // Get base URL for current environment
            String baseUrl = "";
            if (environments != null && environments.containsKey(currentEnvironment)) {
                Map<String, Object> envConfig = (Map<String, Object>) environments.get(currentEnvironment);
                baseUrl = (String) envConfig.get("baseUrl");
            }

            // Build ApplicationConfig
            ApplicationConfig appConfig = ApplicationConfig.builder()
                    .name(appInfo != null ? (String) appInfo.get("name") : applicationName)
                    .description(appInfo != null ? (String) appInfo.get("description") : "")
                    .version(appInfo != null ? (String) appInfo.get("version") : "1.0.0")
                    .currentEnvironment(currentEnvironment)
                    .baseUrl(baseUrl)
                    .settings(settings)
                    .pages(pages)
                    .benchmarks(benchmarks)
                    .testData(testDataMap)
                    .build();

            applicationConfigs.put(applicationName, appConfig);
            log.info("Loaded application configuration: {} (environment: {})", applicationName, currentEnvironment);

        } catch (Exception e) {
            log.error("Failed to load application configuration: {}", applicationName, e);
            throw new RuntimeException("Failed to load application configuration: " + applicationName, e);
        }
    }

    /**
     * Load a YAML file and return as Map
     */
    @SuppressWarnings("unchecked")
    private Map<String, Object> loadYamlFile(String path) {
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(path)) {
            if (inputStream == null) {
                return null;
            }
            return yamlMapper.readValue(inputStream, Map.class);
        } catch (IOException e) {
            log.error("Failed to load YAML file: {}", path, e);
            return null;
        }
    }

    /**
     * Get base URL for current application and environment
     */
    public String getBaseUrl() {
        ApplicationConfig appConfig = getCurrentApplicationConfig();
        return appConfig != null ? appConfig.getBaseUrl() : "";
    }

    /**
     * Get test data from current application
     */
    public <T> T getTestData(String path) {
        ApplicationConfig appConfig = getCurrentApplicationConfig();
        return appConfig != null ? appConfig.getTestData(path) : null;
    }

    /**
     * Get test data with default value
     */
    public <T> T getTestData(String path, T defaultValue) {
        T value = getTestData(path);
        return value != null ? value : defaultValue;
    }

    /**
     * Get page URL from current application
     */
    public String getPageUrl(String pageName) {
        ApplicationConfig appConfig = getCurrentApplicationConfig();
        return appConfig != null ? appConfig.getPageUrl(pageName) : null;
    }

    /**
     * Get full page URL (baseUrl + pageUrl) from current application
     */
    public String getFullPageUrl(String pageName) {
        ApplicationConfig appConfig = getCurrentApplicationConfig();
        return appConfig != null ? appConfig.getFullPageUrl(pageName) : null;
    }

    /**
     * Get benchmark max value from current application
     */
    public long getBenchmarkMax(String metricName) {
        ApplicationConfig appConfig = getCurrentApplicationConfig();
        return appConfig != null ? appConfig.getBenchmarkMax(metricName) : Long.MAX_VALUE;
    }

    /**
     * Get benchmark warning threshold from current application
     */
    public long getBenchmarkWarn(String metricName) {
        ApplicationConfig appConfig = getCurrentApplicationConfig();
        return appConfig != null ? appConfig.getBenchmarkWarn(metricName) : Long.MAX_VALUE;
    }

    /**
     * Reload application configuration
     */
    public void reloadApplication(String applicationName) {
        applicationConfigs.remove(applicationName.toLowerCase());
        loadApplication(applicationName.toLowerCase());
        log.info("Reloaded application configuration: {}", applicationName);
    }

    /**
     * Reload current application configuration
     */
    public void reloadCurrentApplication() {
        reloadApplication(currentApplication);
    }

    /**
     * Check if an application is loaded
     */
    public boolean isApplicationLoaded(String applicationName) {
        return applicationConfigs.containsKey(applicationName.toLowerCase());
    }

    /**
     * Get list of loaded applications
     */
    public java.util.Set<String> getLoadedApplications() {
        return applicationConfigs.keySet();
    }
}
