// Report Computation Engine — rule-based insights, alerts, hygiene checks
// No AI: all logic is deterministic from Neptune data + thresholds

import { OwnerReportData, EnvironmentReportData } from './report-data-collector';

// ── Alert types ──
export interface Alert {
  priority: 'CRITICAL' | 'WARNING' | 'INFO';
  environment: string;
  alert: string;
  detail: string;
}

// ── KPI summary ──
export interface KpiSummary {
  environmentCount: number;
  avgHealthScore: number;
  healthDelta: number;
  changesThisWeek: number;
  changesDelta: number;
  upcomingUpdates: number;
  activeAlerts: number;
  alertsDelta: number;
  connectedEnvCount: number;
  connectedDelta: number;
}

// ── Hygiene check row ──
export interface HygieneCheck {
  check: string;
  results: Record<string, { pass: boolean; detail: string }>;
}

// ── Scheduling conflict ──
export interface ScheduleConflict {
  envA: string;
  envB: string;
  date: string;
  descriptionA: string;
  descriptionB: string;
}

// ── Version drift ──
export interface VersionDrift {
  application: string;
  environments: { name: string; version: string }[];
}

// ── Connectivity diff ──
export interface ConnectivityDiff {
  envName: string;
  newEnvironments: string[];
  removedEnvironments: string[];
  newIntegrationCount: number;
  totalIntegrationCount: number;
}

// ── Full computation result ──
export interface ComputedInsights {
  kpi: KpiSummary;
  alerts: Alert[];
  hygieneChecks: HygieneCheck[];
  scheduleConflicts: ScheduleConflict[];
  versionDrifts: VersionDrift[];
  connectivityDiffs: ConnectivityDiff[];
  narrativeInsights: string[];
}

// ── Thresholds ──
const THRESHOLD = {
  CPU_CRITICAL: 80,
  MEMORY_WARNING: 85,
  STORAGE_WARNING: 90,
  HEALTH_MIN: 70,
  SL_STALE_HOURS: 24,
};

export class ReportComputationEngine {
  /**
   * Run all computations against the collected data
   */
  compute(data: OwnerReportData): ComputedInsights {
    const alerts = this.computeAlerts(data);
    const hygieneChecks = this.computeHygiene(data);
    const connectivityDiffs = this.computeConnectivityDiffs(data);
    const scheduleConflicts = this.detectScheduleConflicts(data);
    const narrativeInsights = this.buildNarrative(data, alerts, connectivityDiffs, scheduleConflicts);

    return {
      kpi: this.computeKpi(data, alerts),
      alerts,
      hygieneChecks,
      scheduleConflicts,
      versionDrifts: this.detectVersionDrifts(data),
      connectivityDiffs,
      narrativeInsights,
    };
  }

  // ── KPI ──
  private computeKpi(data: OwnerReportData, alerts: Alert[]): KpiSummary {
    const scores = data.environments.map(e => parseFloat(e.stats.healthScore || '0')).filter(s => s > 0);
    const avgHealth = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;

    return {
      environmentCount: data.environments.length,
      avgHealthScore: Math.round(avgHealth * 10) / 10,
      healthDelta: 0, // requires previous-week snapshot — set to 0 for now
      changesThisWeek: data.totalChanges,
      changesDelta: 0,
      upcomingUpdates: data.environments.filter(e => e.scheduledUpdates && e.scheduledUpdates.trim().length > 0).length,
      activeAlerts: alerts.filter(a => a.priority === 'CRITICAL' || a.priority === 'WARNING').length,
      alertsDelta: 0,
      connectedEnvCount: data.allConnectedEnvNames.length,
      connectedDelta: 0,
    };
  }

  // ── ALERTS ──
  private computeAlerts(data: OwnerReportData): Alert[] {
    const alerts: Alert[] = [];

    for (const env of data.environments) {
      const cpu = parseFloat(env.stats.cpu || '0');
      const memory = parseFloat(env.stats.memory || '0');
      const storage = parseFloat(env.stats.storage || '0');
      const health = parseFloat(env.stats.healthScore || '100');

      // CPU critical
      if (cpu > THRESHOLD.CPU_CRITICAL) {
        alerts.push({
          priority: 'CRITICAL',
          environment: env.name,
          alert: 'High CPU',
          detail: `CPU at ${cpu}% — threshold ${THRESHOLD.CPU_CRITICAL}%`,
        });
      }

      // Health low
      if (health < THRESHOLD.HEALTH_MIN && health > 0) {
        alerts.push({
          priority: 'CRITICAL',
          environment: env.name,
          alert: 'Health Warning',
          detail: `Health score ${health}, state = ${env.status}`,
        });
      }

      // Memory warning
      if (memory > THRESHOLD.MEMORY_WARNING) {
        alerts.push({
          priority: 'WARNING',
          environment: env.name,
          alert: 'High Memory',
          detail: `Memory at ${memory}% — threshold ${THRESHOLD.MEMORY_WARNING}%`,
        });
      }

      // Storage warning
      if (storage > THRESHOLD.STORAGE_WARNING) {
        alerts.push({
          priority: 'WARNING',
          environment: env.name,
          alert: 'High Storage',
          detail: `Storage at ${storage}% — threshold ${THRESHOLD.STORAGE_WARNING}%`,
        });
      }

      // ScienceLogic freshness
      if (env.stats.lastSyncedAt) {
        const syncAgeHours = (Date.now() - new Date(env.stats.lastSyncedAt).getTime()) / (1000 * 60 * 60);
        if (syncAgeHours > THRESHOLD.SL_STALE_HOURS) {
          alerts.push({
            priority: 'WARNING',
            environment: env.name,
            alert: 'Stale monitoring',
            detail: `ScienceLogic last synced ${Math.round(syncAgeHours)} hours ago`,
          });
        }
      }

      // State = Warning or Critical
      if (env.status === 'Warning' || env.status === 'Critical') {
        alerts.push({
          priority: env.status === 'Critical' ? 'CRITICAL' : 'WARNING',
          environment: env.name,
          alert: `Environment ${env.status}`,
          detail: `State reported as ${env.status}`,
        });
      }
    }

    // Sort: CRITICAL first, then WARNING, then INFO
    const order = { CRITICAL: 0, WARNING: 1, INFO: 2 };
    return alerts.sort((a, b) => order[a.priority] - order[b.priority]);
  }

  // ── HYGIENE CHECKLIST ──
  private computeHygiene(data: OwnerReportData): HygieneCheck[] {
    const checks: HygieneCheck[] = [];
    const envNames = data.environments.map(e => e.name);

    // Collaborators set (warning only)
    const collabCheck: HygieneCheck = { check: 'Collaborators set', results: {} };
    for (const env of data.environments) {
      collabCheck.results[env.name] = {
        pass: !!env.collaborators && env.collaborators.trim().length > 0,
        detail: env.collaborators ? 'PASS' : 'WARN — None',
        warning: !env.collaborators || env.collaborators.trim().length === 0,
      } as any;
    }
    checks.push(collabCheck);

    // Health > 70
    const healthCheck: HygieneCheck = { check: 'Health score > 70', results: {} };
    for (const env of data.environments) {
      const val = parseFloat(env.stats.healthScore || '0');
      healthCheck.results[env.name] = {
        pass: val >= THRESHOLD.HEALTH_MIN,
        detail: val >= THRESHOLD.HEALTH_MIN ? `PASS — ${val}` : `FAIL — ${val}`,
      };
    }
    checks.push(healthCheck);

    // CPU < 80
    const cpuCheck: HygieneCheck = { check: 'CPU < 80%', results: {} };
    for (const env of data.environments) {
      const val = parseFloat(env.stats.cpu || '0');
      cpuCheck.results[env.name] = {
        pass: val < THRESHOLD.CPU_CRITICAL,
        detail: val < THRESHOLD.CPU_CRITICAL ? `PASS — ${val}%` : `FAIL — ${val}%`,
      };
    }
    checks.push(cpuCheck);

    // Memory < 85
    const memCheck: HygieneCheck = { check: 'Memory < 85%', results: {} };
    for (const env of data.environments) {
      const val = parseFloat(env.stats.memory || '0');
      memCheck.results[env.name] = {
        pass: val < THRESHOLD.MEMORY_WARNING,
        detail: val < THRESHOLD.MEMORY_WARNING ? `PASS — ${val}%` : `FAIL — ${val}%`,
      };
    }
    checks.push(memCheck);

    // Storage < 90
    const storCheck: HygieneCheck = { check: 'Storage < 90%', results: {} };
    for (const env of data.environments) {
      const val = parseFloat(env.stats.storage || '0');
      storCheck.results[env.name] = {
        pass: val < THRESHOLD.STORAGE_WARNING,
        detail: val < THRESHOLD.STORAGE_WARNING ? `PASS — ${val}%` : `FAIL — ${val}%`,
      };
    }
    checks.push(storCheck);

    // SL data fresh
    const slCheck: HygieneCheck = { check: 'SL data fresh (< 24h)', results: {} };
    for (const env of data.environments) {
      if (!env.stats.lastSyncedAt) {
        slCheck.results[env.name] = { pass: false, detail: 'FAIL — No sync data' };
      } else {
        const hours = (Date.now() - new Date(env.stats.lastSyncedAt).getTime()) / (1000 * 60 * 60);
        slCheck.results[env.name] = {
          pass: hours <= THRESHOLD.SL_STALE_HOURS,
          detail: hours <= THRESHOLD.SL_STALE_HOURS ? 'PASS' : `FAIL — ${Math.round(hours)}h stale`,
        };
      }
    }
    checks.push(slCheck);

    return checks;
  }

  // ── VERSION DRIFT DETECTION ──
  private detectVersionDrifts(data: OwnerReportData): VersionDrift[] {
    // Group applications by name across environments
    const appVersions = new Map<string, { name: string; version: string }[]>();
    for (const env of data.environments) {
      for (const app of env.applications) {
        const existing = appVersions.get(app.name) || [];
        existing.push({ name: env.name, version: app.version });
        appVersions.set(app.name, existing);
      }
    }

    const drifts: VersionDrift[] = [];
    for (const [appName, envVersions] of appVersions) {
      const uniqueVersions = new Set(envVersions.map(v => v.version));
      if (uniqueVersions.size > 1) {
        drifts.push({ application: appName, environments: envVersions });
      }
    }
    return drifts;
  }

  // ── CONNECTIVITY DIFFS ──
  private computeConnectivityDiffs(data: OwnerReportData): ConnectivityDiff[] {
    return data.environments.map(env => ({
      envName: env.name,
      newEnvironments: env.connectedEnvironments.filter(c => c.isNewConnection).map(c => c.name),
      removedEnvironments: [], // requires previous-week snapshot
      newIntegrationCount: env.integrations.filter(i => i.isNew).length,
      totalIntegrationCount: env.integrations.length,
    }));
  }

  // ── NARRATIVE INSIGHTS (rule-based) ──
  private buildNarrative(
    data: OwnerReportData,
    alerts: Alert[],
    connectivityDiffs: ConnectivityDiff[],
    scheduleConflicts: ScheduleConflict[]
  ): string[] {
    const insights: string[] = [];

    // Critical health drops
    for (const env of data.environments) {
      const health = parseFloat(env.stats.healthScore || '0');
      if (health > 0 && health < THRESHOLD.HEALTH_MIN) {
        const cpu = env.stats.cpu || 'N/A';
        const latency = env.stats.latency || 'N/A';
        const avail = env.stats.availability || 'N/A';
        insights.push(
          `${env.name} health is at ${health}/100 — CPU: ${cpu}%, latency: ${latency}ms, availability: ${avail}%. Investigate before any scheduled testing.`
        );
      }
    }

    // Stale monitoring
    for (const env of data.environments) {
      if (env.stats.lastSyncedAt) {
        const hours = Math.round((Date.now() - new Date(env.stats.lastSyncedAt).getTime()) / (1000 * 60 * 60));
        if (hours > THRESHOLD.SL_STALE_HOURS) {
          insights.push(
            `${env.name}: ScienceLogic data is ${hours} hours stale — re-sync needed for reliable metrics.`
          );
        }
      }
    }

    // Version drift
    const drifts = this.detectVersionDrifts(data);
    for (const drift of drifts) {
      const versions = drift.environments.map(e => `${e.name}(${e.version})`).join(', ');
      insights.push(
        `Version drift detected for ${drift.application}: ${versions}.`
      );
    }

    // High change volume
    if (data.totalChanges > 10) {
      insights.push(
        `High change volume: ${data.totalChanges} changes across ${data.environments.length} environment(s) this ${data.reportType === 'weekly' ? 'week' : 'day'}.`
      );
    }

    // Schedule conflicts
    if (scheduleConflicts.length > 0) {
      insights.push(
        `${scheduleConflicts.length} scheduling conflict(s) detected — overlapping maintenance windows may cause cascading outages.`
      );
    }

    return insights;
  }

  // ── SCHEDULE CONFLICT DETECTION ──
  private detectScheduleConflicts(data: OwnerReportData): ScheduleConflict[] {
    const conflicts: ScheduleConflict[] = [];

    // Parse schedule strings like "Apr 12 02:00-04:00 UTC — TLS cert rotation"
    interface ParsedSchedule {
      envName: string;
      raw: string;
      dateStr: string;
      startHour: number;
      startMin: number;
      endHour: number;
      endMin: number;
      description: string;
    }

    const schedules: ParsedSchedule[] = [];
    const schedulePattern = /^(\w+ \d+)\s+(\d{2}):(\d{2})-(\d{2}):(\d{2})\s+UTC\s*[—–-]\s*(.+)$/;

    for (const env of data.environments) {
      if (!env.scheduledUpdates || env.scheduledUpdates.trim().length === 0) continue;
      const match = schedulePattern.exec(env.scheduledUpdates.trim());
      if (match) {
        schedules.push({
          envName: env.name,
          raw: env.scheduledUpdates,
          dateStr: match[1],
          startHour: parseInt(match[2], 10),
          startMin: parseInt(match[3], 10),
          endHour: parseInt(match[4], 10),
          endMin: parseInt(match[5], 10),
          description: match[6].trim(),
        });
      }
    }

    // Also check connected environments' schedules (from properties if available)
    for (const env of data.environments) {
      for (const conn of env.connectedEnvironments) {
        // Connected envs don't have schedule data in this view, skip
      }
    }

    // Compare all pairs for overlapping windows on the same date
    for (let i = 0; i < schedules.length; i++) {
      for (let j = i + 1; j < schedules.length; j++) {
        const a = schedules[i];
        const b = schedules[j];
        if (a.dateStr !== b.dateStr) continue;
        // Check time overlap: A starts before B ends AND B starts before A ends
        const aStart = a.startHour * 60 + a.startMin;
        const aEnd = a.endHour * 60 + a.endMin;
        const bStart = b.startHour * 60 + b.startMin;
        const bEnd = b.endHour * 60 + b.endMin;
        if (aStart < bEnd && bStart < aEnd) {
          conflicts.push({
            envA: a.envName,
            envB: b.envName,
            date: a.dateStr,
            descriptionA: a.description,
            descriptionB: b.description,
          });
        }
      }
    }

    return conflicts;
  }
}
