package com.saucedemo.tests;

import com.performance.framework.config.BenchmarkConfigResolver;
import com.performance.framework.performance.PerformanceMetrics;
import com.performance.framework.tests.BaseTest;
import com.saucedemo.pages.CartPage;
import com.saucedemo.pages.InventoryPage;
import com.saucedemo.pages.LoginPage;
import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Performance Metrics Test Examples.
 * Demonstrates how to collect and validate performance metrics
 * using the Performance Monitoring Framework.
 * 
 * Benchmarks are loaded dynamically from configuration with priority:
 * 1. Jenkins Parameters (highest) - e.g., -Dbenchmark.pageLoad.max=2000
 * 2. Application Config (config.yaml)
 * 3. Global Config (application.yaml)
 */
@Slf4j
public class PerformanceMetricsTest extends BaseTest {

    private LoginPage loginPage;
    private BenchmarkConfigResolver benchmarkResolver;

    // Dynamic performance thresholds (loaded from config)
    private long maxPageLoadTime;
    private long maxFcp;
    private long maxLcp;
    private long maxTtfb;

    @Override
    protected String getApplicationName() {
        return "saucedemo";
    }

    @BeforeClass
    public void initBenchmarks() {
        benchmarkResolver = new BenchmarkConfigResolver();

        // Load benchmarks dynamically from configuration
        maxPageLoadTime = benchmarkResolver.getBenchmark("pageLoad", "max");
        maxFcp = benchmarkResolver.getBenchmark("firstContentfulPaint", "max");
        maxLcp = benchmarkResolver.getBenchmark("largestContentfulPaint", "max");
        maxTtfb = benchmarkResolver.getBenchmark("firstByte", "max");

        log.info("=== Loaded Performance Benchmarks ===");
        log.info("Page Load Time Max: {}ms (Source: {})", maxPageLoadTime,
                benchmarkResolver.getBenchmarkSource("pageLoad", "max"));
        log.info("FCP Max: {}ms (Source: {})", maxFcp,
                benchmarkResolver.getBenchmarkSource("firstContentfulPaint", "max"));
        log.info("LCP Max: {}ms (Source: {})", maxLcp,
                benchmarkResolver.getBenchmarkSource("largestContentfulPaint", "max"));
        log.info("TTFB Max: {}ms (Source: {})", maxTtfb,
                benchmarkResolver.getBenchmarkSource("firstByte", "max"));
    }

    @BeforeMethod
    public void setUpPage() {
        loginPage = new LoginPage(driver);
    }

    @Test(description = "Collect and log performance metrics for Login page")
    public void testLoginPagePerformanceMetrics() {
        log.info("Starting Login Page Performance Metrics test");

        // Navigate to login page
        loginPage.open();
        Assert.assertTrue(loginPage.isLoaded(), "Login page should be loaded");

        // Collect performance metrics
        PerformanceMetrics metrics = collectPerformanceMetrics("LoginPage");

        // Log all collected metrics
        logPerformanceMetrics(metrics);

        // Validate Core Web Vitals
        Assert.assertTrue(metrics.getPageLoadTime() > 0,
                "Page load time should be captured");

        log.info("Login Page Performance Metrics test completed");
    }

    @Test(description = "Validate Login page meets performance thresholds")
    public void testLoginPagePerformanceThresholds() {
        log.info("Starting Login Page Performance Thresholds test");

        loginPage.open();
        PerformanceMetrics metrics = collectPerformanceMetrics("LoginPage");

        // Validate against dynamically loaded thresholds
        assertPerformanceThreshold("Page Load Time", metrics.getPageLoadTime(), maxPageLoadTime);
        assertPerformanceThreshold("First Contentful Paint", metrics.getFirstContentfulPaint(), maxFcp);
        assertPerformanceThreshold("Time to First Byte", metrics.getTimeToFirstByte(), maxTtfb);

        log.info("Login Page Performance Thresholds test completed");
    }

    @Test(description = "Compare performance metrics across user login flow")
    public void testLoginFlowPerformanceMetrics() {
        log.info("Starting Login Flow Performance Metrics test");

        // Step 1: Collect Login Page metrics
        loginPage.open();
        PerformanceMetrics loginPageMetrics = collectPerformanceMetrics("LoginPage");
        log.info("Login Page - Load Time: {}ms, FCP: {}ms",
                loginPageMetrics.getPageLoadTime(),
                loginPageMetrics.getFirstContentfulPaint());

        // Step 2: Login and collect Inventory Page metrics
        InventoryPage inventoryPage = loginPage.loginAsStandardUser();
        Assert.assertTrue(inventoryPage.isLoaded(), "Inventory page should be loaded");

        PerformanceMetrics inventoryPageMetrics = collectPerformanceMetrics("InventoryPage");
        log.info("Inventory Page - Load Time: {}ms, FCP: {}ms",
                inventoryPageMetrics.getPageLoadTime(),
                inventoryPageMetrics.getFirstContentfulPaint());

        // Compare metrics
        log.info("=== Performance Comparison ===");
        log.info("Login Page Load Time: {}ms", loginPageMetrics.getPageLoadTime());
        log.info("Inventory Page Load Time: {}ms", inventoryPageMetrics.getPageLoadTime());
        log.info("Difference: {}ms",
                inventoryPageMetrics.getPageLoadTime() - loginPageMetrics.getPageLoadTime());

        log.info("Login Flow Performance Metrics test completed");
    }

    @Test(description = "Measure performance glitch user impact")
    public void testPerformanceGlitchUserMetrics() {
        log.info("Starting Performance Glitch User Metrics test");

        // First, measure standard user login time
        loginPage.open();
        loginPage.loginAsStandardUser();
        PerformanceMetrics standardUserMetrics = collectPerformanceMetrics("InventoryPage-StandardUser");
        long standardLoadTime = standardUserMetrics.getPageLoadTime();
        log.info("Standard User - Inventory Page Load Time: {}ms", standardLoadTime);

        // Navigate back to login page for performance glitch user test
        driver.get("https://www.saucedemo.com");
        loginPage = new LoginPage(driver);

        // Now measure performance glitch user login time
        loginPage.open();
        loginPage.loginWithTestData("performanceGlitchUser");

        InventoryPage inventoryPage = new InventoryPage(driver);
        if (inventoryPage.isLoaded()) {
            PerformanceMetrics glitchUserMetrics = collectPerformanceMetrics("InventoryPage-GlitchUser");
            long glitchLoadTime = glitchUserMetrics.getPageLoadTime();
            log.info("Performance Glitch User - Inventory Page Load Time: {}ms", glitchLoadTime);

            // Compare the two
            long difference = glitchLoadTime - standardLoadTime;
            log.info("Performance Impact (Glitch vs Standard): {}ms slower", difference);
        }

        log.info("Performance Glitch User Metrics test completed");
    }

    @Test(description = "Collect comprehensive Core Web Vitals")
    public void testCoreWebVitals() {
        log.info("Starting Core Web Vitals test");

        loginPage.open();
        InventoryPage inventoryPage = loginPage.loginAsStandardUser();
        Assert.assertTrue(inventoryPage.isLoaded(), "Inventory page should be loaded");

        PerformanceMetrics metrics = collectPerformanceMetrics("InventoryPage");

        log.info("=== Core Web Vitals Report ===");
        log.info("First Contentful Paint (FCP): {}ms (Good < 1800ms)",
                metrics.getFirstContentfulPaint());
        log.info("Largest Contentful Paint (LCP): {}ms (Good < 2500ms)",
                metrics.getLargestContentfulPaint());
        log.info("Time to Interactive (TTI): {}ms",
                metrics.getTimeToInteractive());
        log.info("Cumulative Layout Shift (CLS): {} (Good < 0.1)",
                metrics.getCumulativeLayoutShift());
        log.info("Total Blocking Time (TBT): {}ms (Good < 200ms)",
                metrics.getTotalBlockingTime());

        log.info("=== Navigation Timing ===");
        log.info("Page Load Time: {}ms", metrics.getPageLoadTime());
        log.info("DOM Content Loaded: {}ms", metrics.getDomContentLoaded());
        log.info("DOM Interactive: {}ms", metrics.getDomInteractive());
        log.info("DOM Complete: {}ms", metrics.getDomComplete());

        log.info("=== Network Timing ===");
        log.info("Time to First Byte (TTFB): {}ms", metrics.getTimeToFirstByte());
        log.info("DNS Lookup: {}ms", metrics.getDnsLookupTime());
        log.info("Connection Time: {}ms", metrics.getConnectionTime());
        log.info("TLS Time: {}ms", metrics.getTlsTime());

        log.info("=== Resource Metrics ===");
        log.info("Resource Count: {}", metrics.getResourceCount());
        log.info("Total Resource Size: {} bytes", metrics.getTotalResourceSize());
        log.info("Total Transfer Size: {} bytes", metrics.getTotalTransferSize());

        log.info("=== JavaScript Metrics ===");
        log.info("JS Heap Used: {} bytes", metrics.getJsHeapUsedSize());
        log.info("JS Heap Total: {} bytes", metrics.getJsHeapTotalSize());

        log.info("Core Web Vitals test completed");
    }

    @Test(description = "Test multi-page navigation performance")
    public void testMultiPageNavigationPerformance() {
        log.info("Starting Multi-Page Navigation Performance test");

        // Login
        loginPage.open();
        InventoryPage inventoryPage = loginPage.loginAsStandardUser();

        // Add item to cart
        inventoryPage.addProductFromTestData("backpack");

        // Navigate to cart
        CartPage cartPage = inventoryPage.goToCart();
        Assert.assertTrue(cartPage.isLoaded(), "Cart page should be loaded");

        PerformanceMetrics cartMetrics = collectPerformanceMetrics("CartPage");
        log.info("Cart Page - Load Time: {}ms, FCP: {}ms, LCP: {}ms",
                cartMetrics.getPageLoadTime(),
                cartMetrics.getFirstContentfulPaint(),
                cartMetrics.getLargestContentfulPaint());

        log.info("Multi-Page Navigation Performance test completed");
    }

    @Test(description = "Measure First Input Delay with simulated user interaction")
    public void testFirstInputDelayMeasurement() {
        log.info("Starting First Input Delay Measurement test");

        loginPage.open();
        InventoryPage inventoryPage = loginPage.loginAsStandardUser();
        Assert.assertTrue(inventoryPage.isLoaded(), "Inventory page should be loaded");

        // Measure FID by simulating a user click interaction
        // This triggers the browser's first-input measurement
        long fid = metricsCollector.measureFirstInputDelay();

        log.info("=== First Input Delay (FID) Results ===");
        log.info("FID: {}ms", fid);
        log.info("FID Rating: {}", getFIDRating(fid));
        log.info("");
        log.info("Note: FID measures the delay between user interaction and browser response.");
        log.info("In automated tests, we simulate a click to trigger this measurement.");
        log.info("A value of 0 typically means the browser was immediately responsive.");

        // Estimate TBT using CDP metrics as a fallback
        long estimatedTbt = metricsCollector.estimateTotalBlockingTime();
        log.info("");
        log.info("=== Total Blocking Time (TBT) Estimate ===");
        log.info("Estimated TBT: {}ms", estimatedTbt);
        log.info("TBT Rating: {}", getTBTRating(estimatedTbt));
        log.info("");
        log.info("Note: TBT is the sum of blocking time (>50ms) for all long tasks.");
        log.info("Lower TBT means better interactivity during page load.");

        log.info("First Input Delay Measurement test completed");
    }

    // Helper method to rate FID
    private String getFIDRating(long fid) {
        if (fid <= 100)
            return "Good (≤100ms)";
        if (fid <= 300)
            return "Needs Improvement (100-300ms)";
        return "Poor (>300ms)";
    }

    // Helper method to rate TBT
    private String getTBTRating(long tbt) {
        if (tbt <= 200)
            return "Good (≤200ms)";
        if (tbt <= 600)
            return "Needs Improvement (200-600ms)";
        return "Poor (>600ms)";
    }

    // Helper method to log all performance metrics
    private void logPerformanceMetrics(PerformanceMetrics metrics) {
        log.info("========================================");
        log.info("Performance Metrics for: {}", metrics.getPageName());
        log.info("========================================");
        log.info("URL: {}", metrics.getUrl());
        log.info("Environment: {}", metrics.getEnvironment());
        log.info("Browser: {}", metrics.getBrowser());
        log.info("Timestamp: {}", metrics.getTimestamp());
        log.info("----------------------------------------");
        log.info("Page Load Time: {}ms", metrics.getPageLoadTime());
        log.info("First Contentful Paint: {}ms", metrics.getFirstContentfulPaint());
        log.info("Largest Contentful Paint: {}ms", metrics.getLargestContentfulPaint());
        log.info("Time to First Byte: {}ms", metrics.getTimeToFirstByte());
        log.info("DOM Content Loaded: {}ms", metrics.getDomContentLoaded());
        log.info("DOM Interactive: {}ms", metrics.getDomInteractive());
        log.info("Time to Interactive: {}ms", metrics.getTimeToInteractive());
        log.info("========================================");
    }

    // Helper method to assert performance threshold with detailed logging
    private void assertPerformanceThreshold(String metricName, long actualValue, long threshold) {
        boolean passed = actualValue <= threshold;
        String status = passed ? "PASS" : "FAIL";
        log.info("[{}] {} - Actual: {}ms, Threshold: {}ms",
                status, metricName, actualValue, threshold);

        if (passed) {
            logPass(String.format("%s: %dms (threshold: %dms)", metricName, actualValue, threshold));
        } else {
            logWarning(String.format("%s exceeded threshold: %dms > %dms",
                    metricName, actualValue, threshold));
        }

        // Soft assertion - log warning instead of failing test
        // Change to Assert.assertTrue() for hard assertion
        if (!passed) {
            log.warn("Performance threshold exceeded for {}: {}ms > {}ms",
                    metricName, actualValue, threshold);
        }
    }
}
