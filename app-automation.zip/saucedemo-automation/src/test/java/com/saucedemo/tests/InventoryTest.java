package com.saucedemo.tests;

import com.performance.framework.tests.BaseTest;
import com.saucedemo.pages.CartPage;
import com.saucedemo.pages.InventoryPage;
import com.saucedemo.pages.LoginPage;
import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * SauceDemo Inventory/Product Tests.
 */
@Slf4j
public class InventoryTest extends BaseTest {

    private LoginPage loginPage;
    private InventoryPage inventoryPage;

    @Override
    protected String getApplicationName() {
        return "saucedemo";
    }

    @BeforeMethod
    public void setUpPage() {
        loginPage = new LoginPage(driver);
        inventoryPage = loginPage.open().loginAsStandardUser();
    }

    @Test(description = "Verify products are displayed on inventory page")
    public void testProductsDisplayed() {
        log.info("Starting products display test");

        Assert.assertTrue(inventoryPage.isLoaded(), "Inventory page should be loaded");
        Assert.assertTrue(inventoryPage.getProductCount() > 0, "Products should be displayed");
        Assert.assertEquals(inventoryPage.getProductCount(), 6, "Should display 6 products");

        log.info("Products display test completed");
    }

    @Test(description = "Verify add product to cart")
    public void testAddProductToCart() {
        log.info("Starting add to cart test");

        String productName = "Sauce Labs Backpack";
        inventoryPage.addProductToCart(productName);

        Assert.assertEquals(inventoryPage.getCartItemCount(), 1, "Cart should have 1 item");

        log.info("Add to cart test completed");
    }

    @Test(description = "Verify add product from test data")
    public void testAddProductFromTestData() {
        log.info("Starting add product from test data test");

        inventoryPage.addProductFromTestData("backpack");

        Assert.assertEquals(inventoryPage.getCartItemCount(), 1, "Cart should have 1 item");

        log.info("Add product from test data test completed");
    }

    @Test(description = "Verify add multiple products to cart")
    public void testAddMultipleProducts() {
        log.info("Starting add multiple products test");

        inventoryPage
                .addProductFromTestData("backpack")
                .addProductFromTestData("bikeLight")
                .addProductFromTestData("boltTShirt");

        Assert.assertEquals(inventoryPage.getCartItemCount(), 3, "Cart should have 3 items");

        log.info("Add multiple products test completed");
    }

    @Test(description = "Verify remove product from cart")
    public void testRemoveProductFromCart() {
        log.info("Starting remove from cart test");

        String productName = "Sauce Labs Backpack";
        inventoryPage.addProductToCart(productName);
        Assert.assertEquals(inventoryPage.getCartItemCount(), 1, "Cart should have 1 item");

        inventoryPage.removeProductFromCart(productName);
        Assert.assertEquals(inventoryPage.getCartItemCount(), 0, "Cart should be empty");

        log.info("Remove from cart test completed");
    }

    @Test(description = "Verify sort products by price low to high")
    public void testSortByPriceLowToHigh() {
        log.info("Starting sort by price test");

        inventoryPage.sortProducts("lohi");

        // Verify sort was applied (page should still be loaded)
        Assert.assertTrue(inventoryPage.isLoaded(), "Inventory page should be loaded after sort");

        log.info("Sort by price test completed");
    }

    @Test(description = "Verify sort products by price high to low")
    public void testSortByPriceHighToLow() {
        log.info("Starting sort by price high to low test");

        inventoryPage.sortProducts("hilo");

        Assert.assertTrue(inventoryPage.isLoaded(), "Inventory page should be loaded after sort");

        log.info("Sort by price high to low test completed");
    }

    @Test(description = "Verify sort products by name A to Z")
    public void testSortByNameAtoZ() {
        log.info("Starting sort by name A-Z test");

        inventoryPage.sortProducts("az");

        Assert.assertTrue(inventoryPage.isLoaded(), "Inventory page should be loaded after sort");

        log.info("Sort by name A-Z test completed");
    }

    @Test(description = "Verify sort products by name Z to A")
    public void testSortByNameZtoA() {
        log.info("Starting sort by name Z-A test");

        inventoryPage.sortProducts("za");

        Assert.assertTrue(inventoryPage.isLoaded(), "Inventory page should be loaded after sort");

        log.info("Sort by name Z-A test completed");
    }

    @Test(description = "Verify navigate to cart")
    public void testNavigateToCart() {
        log.info("Starting navigate to cart test");

        inventoryPage.addProductFromTestData("backpack");
        CartPage cartPage = inventoryPage.goToCart();

        Assert.assertTrue(cartPage.isLoaded(), "Cart page should be loaded");
        Assert.assertEquals(cartPage.getCartItemCount(), 1, "Cart should have 1 item");

        log.info("Navigate to cart test completed");
    }

    @Test(description = "Verify logout functionality")
    public void testLogout() {
        log.info("Starting logout test");

        LoginPage logoutPage = inventoryPage.logout();

        Assert.assertTrue(logoutPage.isLoaded(), "Login page should be displayed after logout");

        log.info("Logout test completed");
    }

    @Test(description = "Verify product price is displayed")
    public void testProductPriceDisplayed() {
        log.info("Starting product price test");

        String price = inventoryPage.getProductPrice("Sauce Labs Backpack");

        Assert.assertFalse(price.isEmpty(), "Product price should be displayed");
        Assert.assertTrue(price.contains("$"), "Price should contain $ symbol");

        log.info("Product price test completed");
    }
}
