package com.saucedemo.tests;

import com.performance.framework.tests.BaseTest;
import com.saucedemo.pages.CartPage;
import com.saucedemo.pages.CheckoutPage;
import com.saucedemo.pages.InventoryPage;
import com.saucedemo.pages.LoginPage;
import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * SauceDemo End-to-End Checkout Tests.
 */
@Slf4j
public class CheckoutTest extends BaseTest {

    private LoginPage loginPage;
    private InventoryPage inventoryPage;

    @Override
    protected String getApplicationName() {
        return "saucedemo";
    }

    @BeforeMethod
    public void setUpPage() {
        loginPage = new LoginPage(driver);
        inventoryPage = loginPage.open().loginAsStandardUser();
    }

    @Test(description = "Complete end-to-end checkout flow")
    public void testCompleteCheckoutFlow() {
        log.info("Starting complete checkout flow test");

        // Add products to cart
        inventoryPage
                .addProductFromTestData("backpack")
                .addProductFromTestData("bikeLight");

        Assert.assertEquals(inventoryPage.getCartItemCount(), 2, "Cart should have 2 items");

        // Go to cart
        CartPage cartPage = inventoryPage.goToCart();
        Assert.assertTrue(cartPage.isLoaded(), "Cart page should be loaded");
        Assert.assertEquals(cartPage.getCartItemCount(), 2, "Cart should have 2 items");

        // Proceed to checkout
        CheckoutPage checkoutPage = cartPage.proceedToCheckout();
        Assert.assertTrue(checkoutPage.isLoaded(), "Checkout page should be loaded");
        Assert.assertEquals(checkoutPage.getPageTitleText(), "Checkout: Your Information");

        // Enter customer info from test data
        checkoutPage.enterCustomerInfoFromTestData();
        checkoutPage.continueToStepTwo();

        Assert.assertEquals(checkoutPage.getPageTitleText(), "Checkout: Overview");

        // Finish checkout
        checkoutPage.finishCheckout();

        Assert.assertTrue(checkoutPage.isCheckoutComplete(), "Checkout should be complete");
        Assert.assertTrue(checkoutPage.getCompletionHeader().contains("Thank you"),
                "Completion header should show thank you message");

        log.info("Complete checkout flow test completed");
    }

    @Test(description = "Verify cart shows correct items")
    public void testCartItemsDisplay() {
        log.info("Starting cart items display test");

        // Add specific products
        inventoryPage.addProductToCart("Sauce Labs Backpack");
        inventoryPage.addProductToCart("Sauce Labs Bike Light");

        CartPage cartPage = inventoryPage.goToCart();

        Assert.assertTrue(cartPage.isProductInCart("Sauce Labs Backpack"),
                "Backpack should be in cart");
        Assert.assertTrue(cartPage.isProductInCart("Sauce Labs Bike Light"),
                "Bike Light should be in cart");

        log.info("Cart items display test completed");
    }

    @Test(description = "Verify remove item from cart during checkout")
    public void testRemoveItemFromCart() {
        log.info("Starting remove item from cart test");

        inventoryPage.addProductToCart("Sauce Labs Backpack");
        inventoryPage.addProductToCart("Sauce Labs Bike Light");

        CartPage cartPage = inventoryPage.goToCart();
        Assert.assertEquals(cartPage.getCartItemCount(), 2, "Cart should have 2 items");

        cartPage.removeItem("Sauce Labs Backpack");
        Assert.assertEquals(cartPage.getCartItemCount(), 1, "Cart should have 1 item");
        Assert.assertFalse(cartPage.isProductInCart("Sauce Labs Backpack"),
                "Backpack should be removed");

        log.info("Remove item from cart test completed");
    }

    @Test(description = "Verify continue shopping returns to products")
    public void testContinueShopping() {
        log.info("Starting continue shopping test");

        inventoryPage.addProductFromTestData("backpack");
        CartPage cartPage = inventoryPage.goToCart();

        InventoryPage returnedInventoryPage = cartPage.continueShopping();
        Assert.assertTrue(returnedInventoryPage.isLoaded(),
                "Should return to inventory page");

        log.info("Continue shopping test completed");
    }

    @Test(description = "Verify checkout without customer info shows error")
    public void testCheckoutWithoutInfo() {
        log.info("Starting checkout without info test");

        inventoryPage.addProductFromTestData("backpack");
        CartPage cartPage = inventoryPage.goToCart();
        CheckoutPage checkoutPage = cartPage.proceedToCheckout();

        // Try to continue without entering info
        checkoutPage.continueToStepTwo();

        Assert.assertTrue(checkoutPage.isErrorDisplayed(),
                "Error should be displayed when no info entered");
        Assert.assertTrue(checkoutPage.getErrorMessage().contains("First Name is required"),
                "Error should mention first name is required");

        log.info("Checkout without info test completed");
    }

    @Test(description = "Verify cancel checkout returns to cart")
    public void testCancelCheckout() {
        log.info("Starting cancel checkout test");

        inventoryPage.addProductFromTestData("backpack");
        CartPage cartPage = inventoryPage.goToCart();
        CheckoutPage checkoutPage = cartPage.proceedToCheckout();

        CartPage returnedCartPage = checkoutPage.cancelCheckout();
        Assert.assertTrue(returnedCartPage.isLoaded(), "Should return to cart page");

        log.info("Cancel checkout test completed");
    }

    @Test(description = "Verify back to products after checkout")
    public void testBackToProductsAfterCheckout() {
        log.info("Starting back to products after checkout test");

        // Complete checkout
        inventoryPage.addProductFromTestData("backpack");
        CartPage cartPage = inventoryPage.goToCart();
        CheckoutPage checkoutPage = cartPage.proceedToCheckout();
        checkoutPage.completeCheckoutWithTestData();

        Assert.assertTrue(checkoutPage.isCheckoutComplete(), "Checkout should be complete");

        // Go back to products
        InventoryPage returnedInventoryPage = checkoutPage.backToProducts();
        Assert.assertTrue(returnedInventoryPage.isLoaded(),
                "Should return to inventory page");
        Assert.assertEquals(returnedInventoryPage.getCartItemCount(), 0,
                "Cart should be empty after checkout");

        log.info("Back to products after checkout test completed");
    }

    @Test(description = "Verify checkout totals are displayed")
    public void testCheckoutTotals() {
        log.info("Starting checkout totals test");

        inventoryPage.addProductFromTestData("backpack");
        CartPage cartPage = inventoryPage.goToCart();
        CheckoutPage checkoutPage = cartPage.proceedToCheckout();

        checkoutPage.enterCustomerInfoFromTestData();
        checkoutPage.continueToStepTwo();

        String subtotal = checkoutPage.getSubtotal();
        String tax = checkoutPage.getTax();
        String total = checkoutPage.getTotal();

        Assert.assertFalse(subtotal.isEmpty(), "Subtotal should be displayed");
        Assert.assertFalse(tax.isEmpty(), "Tax should be displayed");
        Assert.assertFalse(total.isEmpty(), "Total should be displayed");

        log.info("Checkout totals test completed");
    }
}
