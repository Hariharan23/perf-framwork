package com.performance.framework.config;

import lombok.Builder;
import lombok.Data;

/**
 * Reporting configuration POJO
 */
@Data
@Builder
public class ReportingConfig {
    // Extent Report settings
    private boolean extentEnabled;
    private String reportPath;
    private String reportName;
    private String documentTitle;
    private String theme;
    private boolean screenshotOnFailure;
    private boolean screenshotOnPass;

    // Performance reporting settings
    private boolean performanceEnabled;
    private boolean logToConsole;
    private boolean logToReport;
    private boolean pushToOpenSearch;
}
