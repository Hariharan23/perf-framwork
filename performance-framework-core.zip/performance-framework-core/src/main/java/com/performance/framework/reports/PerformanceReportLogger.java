package com.performance.framework.reports;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.performance.framework.performance.BenchmarkValidator;
import com.performance.framework.performance.MetricStatus;
import com.performance.framework.performance.PerformanceMetrics;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class PerformanceReportLogger {

    private final BenchmarkValidator benchmarkValidator;

    public PerformanceReportLogger() {
        this.benchmarkValidator = new BenchmarkValidator();
    }

    public void logMetricsToReport(PerformanceMetrics metrics) {
        ExtentTest test = ExtentManager.getTest();
        if (test == null) {
            log.warn("No active test found for logging metrics");
            return;
        }

        logSummary(test, metrics);
        logMetricsTable(test, metrics);
        logMetricDetails(test, metrics);
    }

    private void logSummary(ExtentTest test, PerformanceMetrics metrics) {
        MetricStatus overallStatus = metrics.getOverallStatus();
        String summaryClass = getSummaryCssClass(overallStatus);

        String summaryHtml = String.format(
                "<div class='performance-summary %s'>" +
                        "<h4>Performance Summary - %s</h4>" +
                        "<p><strong>Page:</strong> %s</p>" +
                        "<p><strong>URL:</strong> %s</p>" +
                        "<p><strong>Network Type:</strong> %s</p>" +
                        "<p><strong>Overall Status:</strong> <span class='metric-%s'>%s</span></p>" +
                        "</div>",
                summaryClass,
                metrics.getTestName(),
                metrics.getPageName(),
                metrics.getUrl(),
                metrics.getNetworkType(),
                overallStatus.name().toLowerCase(),
                overallStatus.toString());

        test.info(createMarkup(summaryHtml));
    }

    private void logMetricsTable(ExtentTest test, PerformanceMetrics metrics) {
        List<String[]> tableData = new ArrayList<>();

        addMetricRow(tableData, "Page Load Time", metrics.getPageLoadTime(), "pageLoad", metrics);
        addMetricRow(tableData, "DOM Content Loaded", metrics.getDomContentLoaded(), "domContentLoaded", metrics);
        addMetricRow(tableData, "First Contentful Paint (FCP)", metrics.getFirstContentfulPaint(),
                "firstContentfulPaint", metrics);
        addMetricRow(tableData, "Largest Contentful Paint (LCP)", metrics.getLargestContentfulPaint(),
                "largestContentfulPaint", metrics);
        addMetricRow(tableData, "Time to Interactive (TTI)", metrics.getTimeToInteractive(), "timeToInteractive",
                metrics);
        addMetricRow(tableData, "Time to First Byte (TTFB)", metrics.getTimeToFirstByte(), "firstByte", metrics);
        addMetricRow(tableData, "First Input Delay (FID)", metrics.getFirstInputDelay(), "firstInputDelay", metrics);
        addMetricRow(tableData, "Total Blocking Time (TBT)", metrics.getTotalBlockingTime(), "totalBlockingTime",
                metrics);

        StringBuilder tableHtml = new StringBuilder();
        tableHtml.append("<table class='performance-table'>");
        tableHtml.append(
                "<tr><th>Metric</th><th>Actual (ms)</th><th>Threshold (ms)</th><th>Warning (ms)</th><th>Status</th></tr>");

        for (String[] row : tableData) {
            tableHtml.append("<tr>");
            for (int i = 0; i < row.length; i++) {
                if (i == row.length - 1) {
                    String statusClass = getStatusCssClass(row[i]);
                    tableHtml.append("<td class='%s'>%s</td>".formatted(statusClass, row[i]));
                } else {
                    tableHtml.append("<td>%s</td>".formatted(row[i]));
                }
            }
            tableHtml.append("</tr>");
        }
        tableHtml.append("</table>");

        test.info(createMarkup(tableHtml.toString()));
    }

    private void addMetricRow(List<String[]> tableData, String metricName, long actualValue,
            String benchmarkKey, PerformanceMetrics metrics) {
        BenchmarkValidator.BenchmarkThreshold threshold = benchmarkValidator.getThreshold(benchmarkKey);
        MetricStatus status = metrics.getMetricStatus(benchmarkKey);
        if (status == null)
            status = MetricStatus.UNKNOWN;

        tableData.add(new String[] {
                metricName,
                actualValue > 0 ? String.valueOf(actualValue) : "N/A",
                String.valueOf(threshold.getMaxThreshold()),
                String.valueOf(threshold.getWarnThreshold()),
                status.toString()
        });
    }

    private void logMetricDetails(ExtentTest test, PerformanceMetrics metrics) {
        test.info("<b>Core Web Vitals:</b>");
        logSingleMetric(test, "FCP", metrics.getFirstContentfulPaint(), "firstContentfulPaint", metrics);
        logSingleMetric(test, "LCP", metrics.getLargestContentfulPaint(), "largestContentfulPaint", metrics);
        logSingleMetric(test, "TTI", metrics.getTimeToInteractive(), "timeToInteractive", metrics);

        if (metrics.getResourceCount() > 0) {
            test.info(String.format("<b>Resources:</b> %d total, Size: %s, Transfer: %s",
                    metrics.getResourceCount(),
                    formatBytes(metrics.getTotalResourceSize()),
                    formatBytes(metrics.getTotalTransferSize())));
        }

        if (metrics.getJsHeapUsedSize() > 0) {
            test.info(String.format("<b>JS Heap:</b> Used: %s / Total: %s",
                    formatBytes(metrics.getJsHeapUsedSize()),
                    formatBytes(metrics.getJsHeapTotalSize())));
        }
    }

    private void logSingleMetric(ExtentTest test, String name, long value, String benchmarkKey,
            PerformanceMetrics metrics) {
        MetricStatus status = metrics.getMetricStatus(benchmarkKey);
        if (status == null)
            status = MetricStatus.UNKNOWN;

        BenchmarkValidator.BenchmarkThreshold threshold = benchmarkValidator.getThreshold(benchmarkKey);
        Status logStatus = mapToExtentStatus(status);
        String message = "%s: %dms (threshold: %dms) - %s".formatted(
                name, value, threshold.getMaxThreshold(), status.toString());

        test.log(logStatus, message);
    }

    private Status mapToExtentStatus(MetricStatus status) {
        switch (status) {
            case PASS:
                return Status.PASS;
            case WARN:
                return Status.WARNING;
            case FAIL:
                return Status.FAIL;
            default:
                return Status.INFO;
        }
    }

    private String getSummaryCssClass(MetricStatus status) {
        switch (status) {
            case PASS:
                return "summary-pass";
            case WARN:
                return "summary-warn";
            case FAIL:
                return "summary-fail";
            default:
                return "";
        }
    }

    private String getStatusCssClass(String status) {
        if (status.contains("PASS"))
            return "metric-pass";
        if (status.contains("WARN"))
            return "metric-warn";
        if (status.contains("FAIL"))
            return "metric-fail";
        return "metric-unknown";
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024)
            return bytes + " B";
        if (bytes < 1024 * 1024)
            return "%.2f KB".formatted(bytes / 1024.0);
        return "%.2f MB".formatted(bytes / (1024.0 * 1024.0));
    }

    private Markup createMarkup(String html) {
        return MarkupHelper.createLabel(html, null);
    }

    public void logNetworkComparison(PerformanceMetrics netScopeMetrics, PerformanceMetrics nonNetScopeMetrics) {
        ExtentTest test = ExtentManager.getTest();
        if (test == null)
            return;

        StringBuilder comparisonHtml = new StringBuilder();
        comparisonHtml.append("<div class='performance-summary'>");
        comparisonHtml.append("<h4>Network Latency Comparison</h4>");
        comparisonHtml.append("<table class='performance-table'>");
        comparisonHtml
                .append("<tr><th>Metric</th><th>NetScope (ms)</th><th>Non-NetScope (ms)</th><th>Difference</th></tr>");

        addComparisonRow(comparisonHtml, "Page Load", netScopeMetrics.getPageLoadTime(),
                nonNetScopeMetrics.getPageLoadTime());
        addComparisonRow(comparisonHtml, "FCP", netScopeMetrics.getFirstContentfulPaint(),
                nonNetScopeMetrics.getFirstContentfulPaint());
        addComparisonRow(comparisonHtml, "LCP", netScopeMetrics.getLargestContentfulPaint(),
                nonNetScopeMetrics.getLargestContentfulPaint());
        addComparisonRow(comparisonHtml, "TTI", netScopeMetrics.getTimeToInteractive(),
                nonNetScopeMetrics.getTimeToInteractive());
        addComparisonRow(comparisonHtml, "TTFB", netScopeMetrics.getTimeToFirstByte(),
                nonNetScopeMetrics.getTimeToFirstByte());

        comparisonHtml.append("</table></div>");
        test.info(createMarkup(comparisonHtml.toString()));
    }

    private void addComparisonRow(StringBuilder html, String metric, long netScope, long nonNetScope) {
        long diff = nonNetScope - netScope;
        String diffStr = (diff >= 0 ? "+" : "") + diff;
        String diffClass = diff > 0 ? "metric-fail" : (diff < 0 ? "metric-pass" : "");

        html.append("<tr><td>%s</td><td>%d</td><td>%d</td><td class='%s'>%s</td></tr>".formatted(
                metric, netScope, nonNetScope, diffClass, diffStr));
    }
}
