package com.performance.framework.tests;

import com.performance.framework.config.ApplicationConfig;
import com.performance.framework.config.ApplicationConfigManager;
import com.performance.framework.config.BenchmarkConfigResolver;
import com.performance.framework.config.ConfigManager;
import com.performance.framework.config.EnvironmentConfig;
import com.performance.framework.driver.CDPManager;
import com.performance.framework.driver.DriverFactory;
import com.performance.framework.listeners.ExtentReportListener;
import com.performance.framework.listeners.PerformanceMetricsListener;
import com.performance.framework.opensearch.OpenSearchClientManager;
import com.performance.framework.performance.PerformanceMetrics;
import com.performance.framework.performance.PerformanceMetricsCollector;
import com.performance.framework.reports.ExtentManager;
import com.performance.framework.reports.PerformanceReportLogger;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.lang.reflect.Method;
import java.util.Base64;

/**
 * Base test class for performance monitoring framework.
 * All test classes should extend this class to get access to:
 * - WebDriver initialization and cleanup
 * - DevTools/CDP support (version-agnostic - works with ANY Chrome version!)
 * - Performance metrics collection
 * - ExtentReports integration
 * - Multi-application configuration support
 * - Jenkins-parameterized benchmark thresholds
 */
@Slf4j
@Listeners({ ExtentReportListener.class, PerformanceMetricsListener.class })
public abstract class BaseTest {

    protected WebDriver driver;
    protected CDPManager cdpManager;
    protected PerformanceMetricsCollector metricsCollector;
    protected PerformanceReportLogger reportLogger;
    protected ConfigManager configManager = ConfigManager.getInstance();
    protected ApplicationConfigManager appConfigManager = ApplicationConfigManager.getInstance();
    protected BenchmarkConfigResolver benchmarkResolver = new BenchmarkConfigResolver();
    protected ApplicationConfig appConfig;
    protected EnvironmentConfig environmentConfig;

    /**
     * Override this method to specify the application name for your tests.
     * The application configuration will be loaded from:
     * config/applications/{applicationName}/config.yaml
     * config/applications/{applicationName}/testdata.yaml
     */
    protected abstract String getApplicationName();

    @BeforeSuite(alwaysRun = true)
    public void beforeSuite() {
        log.info("Starting Test Suite");
        initializeOpenSearch();
        logBenchmarkConfiguration();
    }

    @AfterSuite(alwaysRun = true)
    public void afterSuite() {
        log.info("Test Suite Completed");
        OpenSearchClientManager.getInstance().close();
        ExtentManager.flush();
    }

    @BeforeClass(alwaysRun = true)
    public void beforeClass() {
        log.info("Setting up: {}", this.getClass().getSimpleName());
        // Set application for this test class
        appConfigManager.setCurrentApplication(getApplicationName());
        appConfig = appConfigManager.getCurrentApplicationConfig();
    }

    @AfterClass(alwaysRun = true)
    public void afterClass() {
        log.info("Cleaning up: {}", this.getClass().getSimpleName());
    }

    @BeforeMethod(alwaysRun = true)
    public void setUp(Method method) {
        log.info("Starting test: {}", method.getName());

        driver = DriverFactory.initDriver();

        // Version-agnostic CDP - works with ANY Chrome version!
        cdpManager = new CDPManager(driver);
        if (cdpManager.isAvailable()) {
            cdpManager.enableAllPerformanceDomains();
        }

        metricsCollector = new PerformanceMetricsCollector(driver);
        metricsCollector.initialize();

        reportLogger = new PerformanceReportLogger();
        environmentConfig = configManager.getEnvironmentConfig(null);
        appConfig = appConfigManager.getCurrentApplicationConfig();

        log.info("Setup completed for: {} (Application: {}, Environment: {})",
                method.getName(), appConfig.getName(), appConfig.getCurrentEnvironment());
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        String testName = result.getMethod().getMethodName();

        if (result.getStatus() == ITestResult.FAILURE) {
            captureScreenshot(testName);
        }

        if (metricsCollector != null) {
            metricsCollector.cleanup();
        }

        DriverFactory.quitDriver();
        log.info("Teardown completed for: {} - {}", testName, getStatusString(result.getStatus()));
    }

    private void initializeOpenSearch() {
        try {
            if (configManager.getReportingConfig().isPushToOpenSearch()) {
                OpenSearchClientManager.getInstance().initialize();
            }
        } catch (Exception e) {
            log.warn("Failed to initialize OpenSearch", e);
        }
    }

    /**
     * Log benchmark configuration sources at suite start.
     * Shows which benchmarks come from Jenkins parameters vs config files.
     */
    private void logBenchmarkConfiguration() {
        try {
            if (benchmarkResolver.hasJenkinsOverrides()) {
                log.info("=== Jenkins Benchmark Overrides Detected ===");
                benchmarkResolver.getJenkinsOverrides().forEach((key, value) -> log.info("  {} = {}", key, value));
            }
            benchmarkResolver.logBenchmarkSources();
        } catch (Exception e) {
            log.warn("Failed to log benchmark configuration", e);
        }
    }

    /**
     * Navigate to base URL of the current application
     */
    protected void navigateToBaseUrl() {
        String baseUrl = appConfigManager.getBaseUrl();
        log.info("Navigating to: {}", baseUrl);
        driver.get(baseUrl);
    }

    /**
     * Navigate to a specific page defined in the application config
     */
    protected void navigateToPage(String pageName) {
        String fullUrl = appConfigManager.getFullPageUrl(pageName);
        log.info("Navigating to page '{}': {}", pageName, fullUrl);
        driver.get(fullUrl);
    }

    /**
     * Collect performance metrics for the current page
     */
    protected PerformanceMetrics collectPerformanceMetrics(String pageName) {
        String testName = Thread.currentThread().getStackTrace()[2].getMethodName();
        metricsCollector.waitForPageLoad(30);
        PerformanceMetrics metrics = metricsCollector.collectMetrics(testName, pageName);
        PerformanceMetricsListener.registerMetrics(testName, metrics);
        return metrics;
    }

    /**
     * Get test data from the current application's testdata.yaml
     */
    protected <T> T getTestData(String path) {
        return appConfigManager.getTestData(path);
    }

    /**
     * Get test data with default value
     */
    protected <T> T getTestData(String path, T defaultValue) {
        return appConfigManager.getTestData(path, defaultValue);
    }

    /**
     * Set the environment for this test
     */
    protected void setEnvironment(String environment) {
        appConfigManager.setCurrentEnvironment(environment);
        appConfigManager.reloadCurrentApplication();
        appConfig = appConfigManager.getCurrentApplicationConfig();
        log.info("Switched to environment: {}", environment);
    }

    /**
     * Capture screenshot and attach to report
     */
    protected void captureScreenshot(String name) {
        try {
            if (driver != null) {
                byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                String base64Screenshot = Base64.getEncoder().encodeToString(screenshot);
                ExtentManager.attachScreenshot(base64Screenshot, name);
            }
        } catch (Exception e) {
            log.warn("Failed to capture screenshot", e);
        }
    }

    protected String getBaseUrl() {
        return appConfigManager.getBaseUrl();
    }

    protected String getEnvironment() {
        return appConfig.getCurrentEnvironment();
    }

    protected String getNetworkType() {
        return configManager.getNetworkType();
    }

    protected void logInfo(String message) {
        log.info(message);
        ExtentManager.logInfo(message);
    }

    protected void logPass(String message) {
        log.info("PASS: {}", message);
        ExtentManager.logPass(message);
    }

    protected void logFail(String message) {
        log.error("FAIL: {}", message);
        ExtentManager.logFail(message);
    }

    protected void logWarning(String message) {
        log.warn("WARN: {}", message);
        ExtentManager.logWarning(message);
    }

    private String getStatusString(int status) {
        return switch (status) {
            case ITestResult.SUCCESS -> "PASSED";
            case ITestResult.FAILURE -> "FAILED";
            case ITestResult.SKIP -> "SKIPPED";
            default -> "UNKNOWN";
        };
    }
}
