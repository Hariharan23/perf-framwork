package com.performance.framework.utils;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Utility class for JavaScript execution in browser.
 */
@Slf4j
public class JavaScriptUtils {

    private final WebDriver driver;
    private final JavascriptExecutor jsExecutor;

    public JavaScriptUtils(WebDriver driver) {
        this.driver = driver;
        this.jsExecutor = (JavascriptExecutor) driver;
    }

    /**
     * Execute JavaScript and return result
     */
    @SuppressWarnings("unchecked")
    public <T> T executeScript(String script, Object... args) {
        try {
            return (T) jsExecutor.executeScript(script, args);
        } catch (Exception e) {
            log.error("Failed to execute JavaScript: {}", script, e);
            return null;
        }
    }

    /**
     * Execute async JavaScript with timeout
     */
    @SuppressWarnings("unchecked")
    public <T> T executeAsyncScript(String script, long timeoutSeconds, Object... args) {
        try {
            driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(timeoutSeconds));
            return (T) jsExecutor.executeAsyncScript(script, args);
        } catch (Exception e) {
            log.error("Failed to execute async JavaScript", e);
            return null;
        }
    }

    /**
     * Wait for document ready state
     */
    public void waitForDocumentReady(int timeoutSeconds) {
        new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds))
                .until(d -> jsExecutor.executeScript("return document.readyState").equals("complete"));
    }

    /**
     * Scroll to top of page
     */
    public void scrollToTop() {
        jsExecutor.executeScript("window.scrollTo(0, 0)");
    }

    /**
     * Scroll to bottom of page
     */
    public void scrollToBottom() {
        jsExecutor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }

    /**
     * Scroll by pixels
     */
    public void scrollBy(int x, int y) {
        jsExecutor.executeScript("window.scrollBy(arguments[0], arguments[1])", x, y);
    }

    /**
     * Get page height
     */
    public Long getPageHeight() {
        return (Long) jsExecutor.executeScript("return document.body.scrollHeight");
    }

    /**
     * Clear browser cache
     */
    public void clearCache() {
        jsExecutor.executeScript("window.localStorage.clear();");
        jsExecutor.executeScript("window.sessionStorage.clear();");
    }

    /**
     * Get performance timing data as JSON string
     */
    public String getPerformanceTimingJson() {
        return (String) jsExecutor.executeScript(
                "return JSON.stringify(performance.timing)");
    }

    /**
     * Get all resource entries as JSON
     */
    public String getResourceEntriesJson() {
        return (String) jsExecutor.executeScript(
                "return JSON.stringify(performance.getEntriesByType('resource'))");
    }

    /**
     * Mark performance entry
     */
    public void performanceMark(String markName) {
        jsExecutor.executeScript("performance.mark(arguments[0])", markName);
    }

    /**
     * Measure between two marks
     */
    public void performanceMeasure(String measureName, String startMark, String endMark) {
        jsExecutor.executeScript(
                "performance.measure(arguments[0], arguments[1], arguments[2])",
                measureName, startMark, endMark);
    }
}
