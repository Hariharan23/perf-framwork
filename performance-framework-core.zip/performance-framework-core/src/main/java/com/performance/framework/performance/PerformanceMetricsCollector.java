package com.performance.framework.performance;

import com.performance.framework.config.ConfigManager;
import com.performance.framework.driver.CDPManager;
import com.performance.framework.driver.DriverFactory;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * Collects browser performance metrics using:
 * 1. JavaScript Performance API (primary - works on all browsers)
 * 2. Chrome DevTools Protocol via CDPManager (enhanced metrics - version-agnostic)
 * 
 * This implementation is VERSION-AGNOSTIC - works with any Chrome version!
 */
@Slf4j
public class PerformanceMetricsCollector {

    private final WebDriver driver;
    private final CDPManager cdpManager;
    private final BenchmarkValidator benchmarkValidator;
    private final ConfigManager configManager;

    public PerformanceMetricsCollector() {
        this.driver = DriverFactory.getDriver();
        this.cdpManager = new CDPManager(driver);  // Version-agnostic CDP
        this.benchmarkValidator = new BenchmarkValidator();
        this.configManager = ConfigManager.getInstance();
    }

    public PerformanceMetricsCollector(WebDriver driver) {
        this.driver = driver;
        this.cdpManager = new CDPManager(driver);  // Version-agnostic CDP
        this.benchmarkValidator = new BenchmarkValidator();
        this.configManager = ConfigManager.getInstance();
    }

    public void initialize() {
        cdpManager.enableAllPerformanceDomains();
        log.info("PerformanceMetricsCollector initialized");
    }

    public PerformanceMetrics collectMetrics(String testName, String pageName) {
        log.info("Collecting performance metrics for page: {}", pageName);

        PerformanceMetrics.PerformanceMetricsBuilder builder = PerformanceMetrics.builder()
                .testName(testName)
                .pageName(pageName)
                .url(driver.getCurrentUrl())
                .environment(getEnvironment())
                .browser(getBrowser())
                .networkType(configManager.getNetworkType())
                .timestamp(Instant.now());

        collectNavigationTimingMetrics(builder);
        collectCoreWebVitals(builder);
        collectCDPMetrics(builder);
        collectResourceMetrics(builder);
        collectJSHeapMetrics(builder);

        PerformanceMetrics metrics = builder.build();
        benchmarkValidator.validateMetrics(metrics);

        log.info("Performance metrics collected: {}", metrics.getSummary());
        return metrics;
    }

    @SuppressWarnings("unchecked")
    private void collectNavigationTimingMetrics(PerformanceMetrics.PerformanceMetricsBuilder builder) {
        try {
            String script = "var timing = performance.getEntriesByType('navigation')[0] || performance.timing;" +
                    "var navigationStart = timing.startTime || timing.navigationStart || 0;" +
                    "return {" +
                    "  pageLoadTime: timing.loadEventEnd - navigationStart," +
                    "  domContentLoaded: timing.domContentLoadedEventEnd - navigationStart," +
                    "  domInteractive: timing.domInteractive - navigationStart," +
                    "  domComplete: timing.domComplete - navigationStart," +
                    "  responseStart: timing.responseStart - navigationStart," +
                    "  dnsLookup: (timing.domainLookupEnd || 0) - (timing.domainLookupStart || 0)," +
                    "  connection: (timing.connectEnd || 0) - (timing.connectStart || 0)," +
                    "  tls: (timing.secureConnectionStart > 0) ? (timing.connectEnd - timing.secureConnectionStart) : 0,"
                    +
                    "  request: (timing.responseStart || 0) - (timing.requestStart || 0)," +
                    "  response: (timing.responseEnd || 0) - (timing.responseStart || 0)" +
                    "};";

            Map<String, Object> timing = (Map<String, Object>) ((JavascriptExecutor) driver).executeScript(script);

            if (timing != null) {
                builder.pageLoadTime(toLong(timing.get("pageLoadTime")));
                builder.domContentLoaded(toLong(timing.get("domContentLoaded")));
                builder.domInteractive(toLong(timing.get("domInteractive")));
                builder.domComplete(toLong(timing.get("domComplete")));
                builder.timeToFirstByte(toLong(timing.get("responseStart")));
                builder.dnsLookupTime(toLong(timing.get("dnsLookup")));
                builder.connectionTime(toLong(timing.get("connection")));
                builder.tlsTime(toLong(timing.get("tls")));
                builder.requestTime(toLong(timing.get("request")));
                builder.responseTime(toLong(timing.get("response")));

                log.debug("Navigation timing collected: pageLoad={}ms, domContentLoaded={}ms",
                        timing.get("pageLoadTime"), timing.get("domContentLoaded"));
            }
        } catch (Exception e) {
            log.warn("Failed to collect navigation timing metrics", e);
        }
    }

    /**
     * Collect Core Web Vitals using Performance Observer and Paint Timing APIs
     */
    private void collectCoreWebVitals(PerformanceMetrics.PerformanceMetricsBuilder builder) {
        try {
            // Collect First Contentful Paint (FCP)
            String fcpScript = "var fcp = performance.getEntriesByName('first-contentful-paint')[0];" +
                    "return fcp ? fcp.startTime : 0;";
            Object fcpValue = ((JavascriptExecutor) driver).executeScript(fcpScript);
            builder.firstContentfulPaint(toLong(fcpValue));

            // Collect Largest Contentful Paint (LCP)
            try {
                Object lcpValue = ((JavascriptExecutor) driver).executeAsyncScript(
                        "var callback = arguments[arguments.length - 1];" +
                                "try {" +
                                "  new PerformanceObserver((entryList) => {" +
                                "    var entries = entryList.getEntries();" +
                                "    var lastEntry = entries[entries.length - 1];" +
                                "    callback(lastEntry ? lastEntry.startTime : 0);" +
                                "  }).observe({type: 'largest-contentful-paint', buffered: true});" +
                                "} catch(e) { callback(0); }" +
                                "setTimeout(() => callback(0), 3000);");
                builder.largestContentfulPaint(toLong(lcpValue));
            } catch (Exception e) {
                log.debug("LCP collection via PerformanceObserver failed, using fallback");
                builder.largestContentfulPaint(0);
            }

            // Collect Time to Interactive (TTI) - approximation
            String ttiScript = "var timing = performance.getEntriesByType('navigation')[0] || performance.timing;" +
                    "var interactive = timing.domInteractive - (timing.startTime || timing.navigationStart || 0);" +
                    "return interactive > 0 ? interactive : 0;";
            Object ttiValue = ((JavascriptExecutor) driver).executeScript(ttiScript);
            builder.timeToInteractive(toLong(ttiValue));

            // Collect First Input Delay (FID) - if available
            // Note: FID requires actual user interaction. In automated tests, this will
            // often be 0
            // unless we simulate a click event to trigger measurement
            try {
                String fidScript = "var fid = performance.getEntriesByType('first-input')[0];" +
                        "return fid ? Math.round(fid.processingStart - fid.startTime) : -1;";
                Object fidValue = ((JavascriptExecutor) driver).executeScript(fidScript);
                long fidMs = toLong(fidValue);
                // -1 indicates no user interaction occurred (expected in automation)
                builder.firstInputDelay(fidMs >= 0 ? fidMs : 0);
                if (fidMs < 0) {
                    log.debug("FID not available - no user interaction detected (normal in automated tests)");
                }
            } catch (Exception e) {
                log.debug("FID collection failed: {}", e.getMessage());
                builder.firstInputDelay(0);
            }

            // Collect Total Blocking Time (TBT) using Long Tasks API
            // TBT = sum of (long task duration - 50ms) for all tasks > 50ms between FCP and
            // TTI
            try {
                Object tbtValue = ((JavascriptExecutor) driver).executeAsyncScript(
                        "var callback = arguments[arguments.length - 1];" +
                                "var tbt = 0;" +
                                "try {" +
                                "  var entries = performance.getEntriesByType('longtask');" +
                                "  if (entries && entries.length > 0) {" +
                                "    entries.forEach(function(entry) {" +
                                "      var blockingTime = entry.duration - 50;" +
                                "      if (blockingTime > 0) tbt += blockingTime;" +
                                "    });" +
                                "    callback(Math.round(tbt));" +
                                "  } else {" +
                                "    // Fallback: estimate from TaskDuration CDP metric if available" +
                                "    callback(-1);" +
                                "  }" +
                                "} catch(e) { callback(-1); }" +
                                "setTimeout(function() { callback(tbt > 0 ? Math.round(tbt) : -1); }, 500);");
                long tbtMs = toLong(tbtValue);
                // -1 indicates Long Tasks API not available or no long tasks
                builder.totalBlockingTime(tbtMs >= 0 ? tbtMs : 0);
                if (tbtMs < 0) {
                    log.debug("TBT not available via Long Tasks API - using 0 (may indicate good performance)");
                }
            } catch (Exception e) {
                log.debug("TBT collection failed: {}", e.getMessage());
                builder.totalBlockingTime(0);
            }

            // Collect Cumulative Layout Shift (CLS) - approximation
            try {
                Object clsValue = ((JavascriptExecutor) driver).executeAsyncScript(
                        "var callback = arguments[arguments.length - 1];" +
                                "var cls = 0;" +
                                "try {" +
                                "  new PerformanceObserver((entryList) => {" +
                                "    for (var entry of entryList.getEntries()) {" +
                                "      if (!entry.hadRecentInput) cls += entry.value;" +
                                "    }" +
                                "    callback(cls);" +
                                "  }).observe({type: 'layout-shift', buffered: true});" +
                                "} catch(e) { callback(0); }" +
                                "setTimeout(() => callback(cls), 1000);");
                builder.cumulativeLayoutShift(toDouble(clsValue));
            } catch (Exception e) {
                builder.cumulativeLayoutShift(0.0);
            }

            log.debug("Core Web Vitals collected: FCP={}ms", fcpValue);
        } catch (Exception e) {
            log.warn("Failed to collect Core Web Vitals", e);
        }
    }

    /**
     * Collect CDP Performance.getMetrics() data using VERSION-AGNOSTIC approach
     */
    private void collectCDPMetrics(PerformanceMetrics.PerformanceMetricsBuilder builder) {
        if (!cdpManager.isAvailable()) {
            log.debug("CDP not available, skipping CDP metrics");
            return;
        }

        try {
            Map<String, Object> metrics = cdpManager.getPerformanceMetrics();
            
            if (metrics.isEmpty()) {
                log.debug("No CDP metrics available");
                return;
            }

            Map<String, Object> rawMetrics = new HashMap<>(metrics);

            // Extract specific metrics
            if (metrics.containsKey("ScriptDuration")) {
                double value = toDouble(metrics.get("ScriptDuration"));
                builder.scriptDuration((long) (value * 1000)); // Convert to ms
            }
            if (metrics.containsKey("TaskDuration")) {
                double value = toDouble(metrics.get("TaskDuration"));
                builder.taskDuration((long) (value * 1000));
            }
            if (metrics.containsKey("JSHeapUsedSize")) {
                builder.jsHeapUsedSize(toLong(metrics.get("JSHeapUsedSize")));
            }
            if (metrics.containsKey("JSHeapTotalSize")) {
                builder.jsHeapTotalSize(toLong(metrics.get("JSHeapTotalSize")));
            }

            builder.rawMetrics(rawMetrics);
            log.debug("CDP metrics collected: {} metrics", metrics.size());
        } catch (Exception e) {
            log.warn("Failed to collect CDP metrics: {}", e.getMessage());
        }
    }

    /**
     * Collect resource loading metrics
     */
    @SuppressWarnings("unchecked")
    private void collectResourceMetrics(PerformanceMetrics.PerformanceMetricsBuilder builder) {
        try {
            String script = "var resources = performance.getEntriesByType('resource');" +
                    "var totalSize = 0, transferSize = 0;" +
                    "resources.forEach(r => {" +
                    "  totalSize += r.decodedBodySize || 0;" +
                    "  transferSize += r.transferSize || 0;" +
                    "});" +
                    "return {count: resources.length, totalSize: totalSize, transferSize: transferSize};";

            Map<String, Object> resourceData = (Map<String, Object>) ((JavascriptExecutor) driver)
                    .executeScript(script);

            if (resourceData != null) {
                builder.resourceCount(toInt(resourceData.get("count")));
                builder.totalResourceSize(toLong(resourceData.get("totalSize")));
                builder.totalTransferSize(toLong(resourceData.get("transferSize")));
                log.debug("Resource metrics collected: {} resources", resourceData.get("count"));
            }
        } catch (Exception e) {
            log.warn("Failed to collect resource metrics", e);
        }
    }

    /**
     * Collect JavaScript heap memory metrics
     */
    @SuppressWarnings("unchecked")
    private void collectJSHeapMetrics(PerformanceMetrics.PerformanceMetricsBuilder builder) {
        try {
            String script = "if (performance.memory) {" +
                    "  return {" +
                    "    usedJSHeapSize: performance.memory.usedJSHeapSize," +
                    "    totalJSHeapSize: performance.memory.totalJSHeapSize" +
                    "  };" +
                    "}" +
                    "return null;";

            Map<String, Object> memoryData = (Map<String, Object>) ((JavascriptExecutor) driver).executeScript(script);

            if (memoryData != null) {
                builder.jsHeapUsedSize(toLong(memoryData.get("usedJSHeapSize")));
                builder.jsHeapTotalSize(toLong(memoryData.get("totalJSHeapSize")));
            }
        } catch (Exception e) {
            log.debug("JS heap metrics not available (non-Chrome browser)");
        }
    }

    /**
     * Clear performance entries buffer
     */
    public void clearPerformanceBuffer() {
        try {
            ((JavascriptExecutor) driver).executeScript("performance.clearResourceTimings();");
            log.debug("Performance buffer cleared");
        } catch (Exception e) {
            log.warn("Failed to clear performance buffer", e);
        }
    }

    /**
     * Wait for page to be fully loaded
     */
    public void waitForPageLoad(int timeoutSeconds) {
        try {
            long startTime = System.currentTimeMillis();
            long timeout = timeoutSeconds * 1000L;

            while ((System.currentTimeMillis() - startTime) < timeout) {
                String readyState = (String) ((JavascriptExecutor) driver)
                        .executeScript("return document.readyState");
                if ("complete".equals(readyState)) {
                    log.debug("Page load complete");
                    return;
                }
                Thread.sleep(100);
            }
            log.warn("Page load timeout after {} seconds", timeoutSeconds);
        } catch (Exception e) {
            log.warn("Error waiting for page load", e);
        }
    }

    /**
     * Get current environment
     */
    private String getEnvironment() {
        String env = System.getProperty("environment");
        return env != null ? env : configManager.getEnvironmentConfig(null).getKey();
    }

    /**
     * Get current browser
     */
    private String getBrowser() {
        String browser = System.getProperty("browser");
        return browser != null ? browser : configManager.getBrowserConfig().getType();
    }

    /**
     * Safely convert to long
     */
    private long toLong(Object value) {
        if (value == null)
            return 0;
        if (value instanceof Number number) {
            return number.longValue();
        }
        try {
            return Long.parseLong(value.toString());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /**
     * Safely convert to double
     */
    private double toDouble(Object value) {
        if (value == null)
            return 0.0;
        if (value instanceof Number number) {
            return number.doubleValue();
        }
        try {
            return Double.parseDouble(value.toString());
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    /**
     * Safely convert to int
     */
    private int toInt(Object value) {
        if (value == null)
            return 0;
        if (value instanceof Number number) {
            return number.intValue();
        }
        try {
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /**
     * Cleanup resources
     */
    public void cleanup() {
        cdpManager.disableAllDomains();
        log.debug("PerformanceMetricsCollector cleanup complete");
    }

    /**
     * Collect First Input Delay by simulating a user interaction.
     * This method performs a click on the document body to trigger FID measurement.
     * Call this AFTER the page loads but BEFORE collecting metrics if you want FID
     * data.
     * 
     * @return the First Input Delay in milliseconds, or 0 if not measurable
     */
    public long measureFirstInputDelay() {
        try {
            // First, set up a PerformanceObserver to capture FID
            String setupScript = "window.__fidValue = -1;" +
                    "try {" +
                    "  new PerformanceObserver(function(entryList) {" +
                    "    var entries = entryList.getEntries();" +
                    "    if (entries.length > 0) {" +
                    "      var entry = entries[0];" +
                    "      window.__fidValue = Math.round(entry.processingStart - entry.startTime);" +
                    "    }" +
                    "  }).observe({type: 'first-input', buffered: true});" +
                    "} catch(e) { console.log('FID observer setup failed:', e); }";
            ((JavascriptExecutor) driver).executeScript(setupScript);

            // Simulate a click event on the body to trigger first input
            String clickScript = "var event = new MouseEvent('click', {" +
                    "  view: window," +
                    "  bubbles: true," +
                    "  cancelable: true" +
                    "});" +
                    "document.body.dispatchEvent(event);";
            ((JavascriptExecutor) driver).executeScript(clickScript);

            // Small delay to allow the observer to process
            Thread.sleep(100);

            // Retrieve the FID value
            Object fidValue = ((JavascriptExecutor) driver).executeScript("return window.__fidValue;");
            long fid = toLong(fidValue);

            if (fid >= 0) {
                log.debug("FID measured via simulated interaction: {}ms", fid);
                return fid;
            } else {
                log.debug("FID could not be measured (no first-input entry captured)");
                return 0;
            }
        } catch (Exception e) {
            log.warn("Failed to measure FID with simulated interaction: {}", e.getMessage());
            return 0;
        }
    }

    /**
     * Estimate Total Blocking Time using CDP TaskDuration metric.
     * This is an approximation since true TBT requires Long Tasks API observation
     * from page load start.
     * 
     * Uses VERSION-AGNOSTIC CDP approach.
     * 
     * @return estimated TBT in milliseconds
     */
    public long estimateTotalBlockingTime() {
        if (!cdpManager.isAvailable()) {
            return 0;
        }

        try {
            Map<String, Object> metrics = cdpManager.getPerformanceMetrics();
            
            double taskDuration = toDouble(metrics.get("TaskDuration"));
            double scriptDuration = toDouble(metrics.get("ScriptDuration"));

            // Estimate TBT as script duration that exceeds threshold
            // This is a rough approximation: tasks > 50ms contribute to TBT
            // We estimate based on script duration patterns
            double estimatedTbt = Math.max(0, (scriptDuration * 1000) - 50);

            log.debug("Estimated TBT from CDP metrics: {}ms (TaskDuration: {}s, ScriptDuration: {}s)",
                    (long) estimatedTbt, taskDuration, scriptDuration);

            return (long) estimatedTbt;
        } catch (Exception e) {
            log.warn("Failed to estimate TBT from CDP metrics: {}", e.getMessage());
            return 0;
        }
    }
}
