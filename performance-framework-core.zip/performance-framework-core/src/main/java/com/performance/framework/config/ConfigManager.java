package com.performance.framework.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

@Slf4j
public class ConfigManager {

    private static ConfigManager instance;
    private static final String CONFIG_FILE = "config/application.yaml";

    @Getter
    private Map<String, Object> config;

    @Getter
    private Map<String, Object> benchmarks;

    private ConfigManager() {
        loadConfiguration();
        loadBenchmarks();
    }

    public static synchronized ConfigManager getInstance() {
        if (instance == null) {
            instance = new ConfigManager();
        }
        return instance;
    }

    @SuppressWarnings("unchecked")
    private void loadConfiguration() {
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (inputStream == null) {
                throw new RuntimeException("Configuration file not found: " + CONFIG_FILE);
            }
            ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
            config = mapper.readValue(inputStream, Map.class);
            log.info("Configuration loaded from {}", CONFIG_FILE);
        } catch (IOException e) {
            log.error("Failed to load configuration: {}", CONFIG_FILE, e);
            throw new RuntimeException("Failed to load configuration", e);
        }
    }

    @SuppressWarnings("unchecked")
    private void loadBenchmarks() {
        // Load benchmarks from YAML configuration
        benchmarks = getConfigValue("benchmarks");
        if (benchmarks == null) {
            log.warn("No benchmarks found in configuration, using empty map");
            benchmarks = Map.of();
        } else {
            log.info("Benchmarks loaded from {} ({} metrics configured)", CONFIG_FILE, benchmarks.size());
        }
    }

    @SuppressWarnings("unchecked")
    public <T> T getConfigValue(String path) {
        String[] keys = path.split("\\.");
        Object current = config;

        for (String key : keys) {
            if (current instanceof Map) {
                current = ((Map<String, Object>) current).get(key);
            } else {
                return null;
            }
        }
        return (T) current;
    }

    public <T> T getConfigValue(String path, T defaultValue) {
        T value = getConfigValue(path);
        return value != null ? value : defaultValue;
    }

    /**
     * Get a benchmark value from the YAML configuration.
     * Supports keys like "pageLoad.max" or "firstContentfulPaint.warn"
     * 
     * @param key the benchmark key in format "metricName.threshold" (e.g.,
     *            "pageLoad.max")
     * @return the benchmark value, or Long.MAX_VALUE if not found
     */
    @SuppressWarnings("unchecked")
    public long getBenchmark(String key) {
        if (benchmarks == null) {
            log.warn("Benchmarks not loaded");
            return Long.MAX_VALUE;
        }

        // Parse key like "pageLoad.max" into metricName and threshold
        String[] parts = key.split("\\.");
        if (parts.length != 2) {
            log.warn("Invalid benchmark key format: {}. Expected format: metricName.threshold", key);
            return Long.MAX_VALUE;
        }

        String metricName = parts[0];
        String threshold = parts[1];

        Object metricConfig = benchmarks.get(metricName);
        if (metricConfig instanceof Map) {
            Map<String, Object> metricMap = (Map<String, Object>) metricConfig;
            Object value = metricMap.get(threshold);
            if (value != null) {
                return toLong(value);
            }
        }

        log.warn("Benchmark not found: {}", key);
        return Long.MAX_VALUE;
    }

    /**
     * Safely convert Object to long
     */
    private long toLong(Object value) {
        if (value == null)
            return Long.MAX_VALUE;
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        try {
            return Long.parseLong(value.toString());
        } catch (NumberFormatException e) {
            return Long.MAX_VALUE;
        }
    }

    public BrowserConfig getBrowserConfig() {
        return BrowserConfig.builder()
                .type(getConfigValue("browser.type", "chrome"))
                .headless(getConfigValue("browser.headless", false))
                .maximizeWindow(getConfigValue("browser.maximizeWindow", true))
                .implicitWait(getConfigValue("browser.implicitWait", 10))
                .pageLoadTimeout(getConfigValue("browser.pageLoadTimeout", 60))
                .scriptTimeout(getConfigValue("browser.scriptTimeout", 30))
                .useGrid(getConfigValue("browser.useGrid", false))
                .gridUrl(getConfigValue("browser.gridUrl", "http://localhost:4444/wd/hub"))
                .platformName(getConfigValue("browser.platformName", ""))
                .browserVersion(getConfigValue("browser.browserVersion", ""))
                .build();
    }

    public EnvironmentConfig getEnvironmentConfig(String env) {
        String envKey = env != null ? env : System.getProperty("environment", "local");
        String baseUrl = getConfigValue("environments." + envKey + ".baseUrl", "");
        String name = getConfigValue("environments." + envKey + ".name", envKey);
        return new EnvironmentConfig(envKey, name, baseUrl);
    }

    public OpenSearchConfig getOpenSearchConfig() {
        return OpenSearchConfig.builder()
                .enabled(getConfigValue("opensearch.enabled", true))
                .host(getConfigValue("opensearch.host", "localhost"))
                .port(getConfigValue("opensearch.port", 9200))
                .scheme(getConfigValue("opensearch.scheme", "http"))
                .indexName(getConfigValue("opensearch.indexName", "performance-metrics"))
                .username(getConfigValue("opensearch.username", ""))
                .password(getConfigValue("opensearch.password", ""))
                .connectTimeout(getConfigValue("opensearch.connectTimeout", 5000))
                .socketTimeout(getConfigValue("opensearch.socketTimeout", 60000))
                .build();
    }

    public ReportingConfig getReportingConfig() {
        return ReportingConfig.builder()
                .extentEnabled(getConfigValue("reporting.extent.enabled", true))
                .reportPath(getConfigValue("reporting.extent.reportPath", "target/extent-reports"))
                .reportName(getConfigValue("reporting.extent.reportName", "Performance Test Report"))
                .documentTitle(getConfigValue("reporting.extent.documentTitle", "Test Report"))
                .theme(getConfigValue("reporting.extent.theme", "DARK"))
                .screenshotOnFailure(getConfigValue("reporting.extent.screenshots.onFailure", true))
                .screenshotOnPass(getConfigValue("reporting.extent.screenshots.onPass", false))
                .performanceEnabled(getConfigValue("reporting.performance.enabled", true))
                .logToConsole(getConfigValue("reporting.performance.logToConsole", true))
                .logToReport(getConfigValue("reporting.performance.logToReport", true))
                .pushToOpenSearch(getConfigValue("reporting.performance.pushToOpenSearch", true))
                .build();
    }

    public String getNetworkType() {
        String networkType = System.getProperty("networkType");
        if (networkType != null && !networkType.isEmpty()) {
            return networkType;
        }
        return getConfigValue("network.type", "Non-NetScope");
    }

    public void reload() {
        loadConfiguration();
        loadBenchmarks();
        log.info("Configuration reloaded");
    }
}
