package com.performance.framework.config;

import lombok.Builder;
import lombok.Data;

import java.util.Map;

/**
 * Configuration class for application-specific settings.
 * Each application (OpenCart, SauceDemo, etc.) has its own config and test
 * data.
 */
@Data
@Builder
public class ApplicationConfig {

    private String name;
    private String description;
    private String version;
    private String currentEnvironment;
    private String baseUrl;
    private Map<String, Object> settings;
    private Map<String, Object> pages;
    private Map<String, Object> benchmarks;
    private Map<String, Object> testData;

    /**
     * Get a page configuration by page name
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> getPageConfig(String pageName) {
        if (pages != null && pages.containsKey(pageName)) {
            return (Map<String, Object>) pages.get(pageName);
        }
        return null;
    }

    /**
     * Get page URL by page name
     */
    public String getPageUrl(String pageName) {
        Map<String, Object> pageConfig = getPageConfig(pageName);
        if (pageConfig != null) {
            return (String) pageConfig.get("url");
        }
        return null;
    }

    /**
     * Get page title by page name
     */
    public String getPageTitle(String pageName) {
        Map<String, Object> pageConfig = getPageConfig(pageName);
        if (pageConfig != null) {
            return (String) pageConfig.get("title");
        }
        return null;
    }

    /**
     * Get full URL for a page (baseUrl + page url)
     */
    public String getFullPageUrl(String pageName) {
        String pageUrl = getPageUrl(pageName);
        if (pageUrl != null && baseUrl != null) {
            return baseUrl + pageUrl;
        }
        return baseUrl;
    }

    /**
     * Get application setting by key
     */
    @SuppressWarnings("unchecked")
    public <T> T getSetting(String key) {
        if (settings != null && settings.containsKey(key)) {
            return (T) settings.get(key);
        }
        return null;
    }

    /**
     * Get application setting with default value
     */
    public <T> T getSetting(String key, T defaultValue) {
        T value = getSetting(key);
        return value != null ? value : defaultValue;
    }

    /**
     * Get benchmark value for a specific metric
     */
    @SuppressWarnings("unchecked")
    public long getBenchmarkMax(String metricName) {
        if (benchmarks != null && benchmarks.containsKey(metricName)) {
            Map<String, Object> metric = (Map<String, Object>) benchmarks.get(metricName);
            if (metric != null && metric.containsKey("max")) {
                return ((Number) metric.get("max")).longValue();
            }
        }
        return Long.MAX_VALUE;
    }

    /**
     * Get warning threshold for a specific metric
     */
    @SuppressWarnings("unchecked")
    public long getBenchmarkWarn(String metricName) {
        if (benchmarks != null && benchmarks.containsKey(metricName)) {
            Map<String, Object> metric = (Map<String, Object>) benchmarks.get(metricName);
            if (metric != null && metric.containsKey("warn")) {
                return ((Number) metric.get("warn")).longValue();
            }
        }
        return Long.MAX_VALUE;
    }

    /**
     * Get test data by path (dot-separated)
     */
    @SuppressWarnings("unchecked")
    public <T> T getTestData(String path) {
        if (testData == null) {
            return null;
        }

        String[] keys = path.split("\\.");
        Object current = testData;

        for (String key : keys) {
            if (current instanceof Map) {
                current = ((Map<String, Object>) current).get(key);
            } else {
                return null;
            }
        }
        return (T) current;
    }

    /**
     * Get test data with default value
     */
    public <T> T getTestData(String path, T defaultValue) {
        T value = getTestData(path);
        return value != null ? value : defaultValue;
    }
}
