package com.performance.framework.opensearch;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.performance.framework.config.ConfigManager;
import com.performance.framework.config.OpenSearchConfig;
import com.performance.framework.performance.PerformanceMetrics;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Slf4j
public class OpenSearchClientManager {

    private static OpenSearchClientManager instance;
    private CloseableHttpClient httpClient;
    private final OpenSearchConfig config;
    private final ObjectMapper objectMapper;
    private boolean initialized = false;
    private String baseUrl;

    private OpenSearchClientManager() {
        this.config = ConfigManager.getInstance().getOpenSearchConfig();
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    public static synchronized OpenSearchClientManager getInstance() {
        if (instance == null) {
            instance = new OpenSearchClientManager();
        }
        return instance;
    }

    public void initialize() {
        if (!config.isEnabled()) {
            log.info("OpenSearch integration is disabled");
            return;
        }

        if (initialized) {
            log.debug("OpenSearch client already initialized");
            return;
        }

        try {
            this.baseUrl = config.getConnectionUrl();

            HttpClientBuilder builder = HttpClients.custom();

            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(config.getConnectTimeout())
                    .setSocketTimeout(config.getSocketTimeout())
                    .setConnectionRequestTimeout(config.getConnectTimeout())
                    .build();
            builder.setDefaultRequestConfig(requestConfig);

            if (config.hasCredentials()) {
                CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
                credentialsProvider.setCredentials(
                        AuthScope.ANY,
                        new UsernamePasswordCredentials(config.getUsername(), config.getPassword()));
                builder.setDefaultCredentialsProvider(credentialsProvider);
            }

            httpClient = builder.build();
            initialized = true;

            // Ensure index exists
            ensureIndexExists();

            log.info("OpenSearch client initialized successfully: {}", baseUrl);
        } catch (Exception e) {
            log.error("Failed to initialize OpenSearch client", e);
            initialized = false;
        }
    }

    private void ensureIndexExists() {
        try {
            String indexUrl = baseUrl + "/" + config.getIndexName();
            HttpHead headRequest = new HttpHead(indexUrl);
            HttpResponse response = httpClient.execute(headRequest);
            int statusCode = response.getStatusLine().getStatusCode();
            EntityUtils.consumeQuietly(response.getEntity());

            if (statusCode == 404) {
                createIndex();
            } else if (statusCode == 200) {
                log.debug("Index {} already exists", config.getIndexName());
            }
        } catch (IOException e) {
            log.error("Failed to check index existence", e);
        }
    }

    private void createIndex() {
        try {
            String indexUrl = baseUrl + "/" + config.getIndexName();
            HttpPut putRequest = new HttpPut(indexUrl);

            Map<String, Object> indexBody = new HashMap<>();

            Map<String, Object> settings = new HashMap<>();
            settings.put("number_of_shards", 1);
            settings.put("number_of_replicas", 1);
            indexBody.put("settings", settings);

            Map<String, Object> mappings = new HashMap<>();
            mappings.put("properties", createMappingProperties());
            indexBody.put("mappings", mappings);

            String jsonBody = objectMapper.writeValueAsString(indexBody);
            putRequest.setEntity(new StringEntity(jsonBody, ContentType.APPLICATION_JSON));

            HttpResponse response = httpClient.execute(putRequest);
            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = EntityUtils.toString(response.getEntity());

            if (statusCode == 200 || statusCode == 201) {
                log.info("Created OpenSearch index: {}", config.getIndexName());
            } else {
                log.warn("Failed to create index, status: {}, response: {}", statusCode, responseBody);
            }
        } catch (IOException e) {
            log.error("Failed to create index", e);
        }
    }

    private Map<String, Object> createMappingProperties() {
        Map<String, Object> properties = new HashMap<>();

        addFieldMapping(properties, "testName", "keyword");
        addFieldMapping(properties, "pageName", "keyword");
        addFieldMapping(properties, "url", "text");
        addFieldMapping(properties, "environment", "keyword");
        addFieldMapping(properties, "browser", "keyword");
        addFieldMapping(properties, "networkType", "keyword");
        addFieldMapping(properties, "overallStatus", "keyword");

        addFieldMapping(properties, "pageLoadTime", "long");
        addFieldMapping(properties, "domContentLoaded", "long");
        addFieldMapping(properties, "domInteractive", "long");
        addFieldMapping(properties, "domComplete", "long");
        addFieldMapping(properties, "firstContentfulPaint", "long");
        addFieldMapping(properties, "largestContentfulPaint", "long");
        addFieldMapping(properties, "timeToInteractive", "long");
        addFieldMapping(properties, "firstInputDelay", "long");
        addFieldMapping(properties, "totalBlockingTime", "long");
        addFieldMapping(properties, "timeToFirstByte", "long");
        addFieldMapping(properties, "dnsLookupTime", "long");
        addFieldMapping(properties, "connectionTime", "long");
        addFieldMapping(properties, "tlsTime", "long");
        addFieldMapping(properties, "requestTime", "long");
        addFieldMapping(properties, "responseTime", "long");
        addFieldMapping(properties, "resourceCount", "integer");
        addFieldMapping(properties, "totalResourceSize", "long");
        addFieldMapping(properties, "totalTransferSize", "long");
        addFieldMapping(properties, "jsHeapUsedSize", "long");
        addFieldMapping(properties, "jsHeapTotalSize", "long");
        addFieldMapping(properties, "scriptDuration", "long");
        addFieldMapping(properties, "taskDuration", "long");
        addFieldMapping(properties, "cumulativeLayoutShift", "double");
        addFieldMapping(properties, "timestamp", "date");

        return properties;
    }

    private void addFieldMapping(Map<String, Object> properties, String fieldName, String fieldType) {
        Map<String, Object> field = new HashMap<>();
        field.put("type", fieldType);
        properties.put(fieldName, field);
    }

    public boolean pushMetrics(PerformanceMetrics metrics) {
        if (!config.isEnabled() || !initialized) {
            log.debug("OpenSearch is disabled or not initialized, skipping metrics push");
            return false;
        }

        try {
            // Convert metrics to document
            Map<String, Object> document = createDocument(metrics);
            String documentId = generateDocumentId(metrics);

            // Index the document using REST API
            String indexUrl = baseUrl + "/" + config.getIndexName() + "/_doc/" + documentId;
            HttpPut putRequest = new HttpPut(indexUrl);

            String jsonBody = objectMapper.writeValueAsString(document);
            putRequest.setEntity(new StringEntity(jsonBody, ContentType.APPLICATION_JSON));

            HttpResponse response = httpClient.execute(putRequest);
            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = EntityUtils.toString(response.getEntity());

            if (statusCode == 200 || statusCode == 201) {
                log.info("Pushed performance metrics to OpenSearch. Index: {}, ID: {}, Status: {}",
                        config.getIndexName(), documentId, statusCode);
                return true;
            } else {
                log.warn("Failed to push metrics, status: {}, response: {}", statusCode, responseBody);
                return false;
            }
        } catch (Exception e) {
            log.error("Failed to push metrics to OpenSearch", e);
            return false;
        }
    }

    /**
     * Create document from metrics
     */
    private Map<String, Object> createDocument(PerformanceMetrics metrics) {
        Map<String, Object> document = new HashMap<>();

        // Basic info
        document.put("testName", metrics.getTestName());
        document.put("pageName", metrics.getPageName());
        document.put("url", metrics.getUrl());
        document.put("environment", metrics.getEnvironment());
        document.put("browser", metrics.getBrowser());
        document.put("networkType", metrics.getNetworkType());

        // Navigation timing
        document.put("pageLoadTime", metrics.getPageLoadTime());
        document.put("domContentLoaded", metrics.getDomContentLoaded());
        document.put("domInteractive", metrics.getDomInteractive());
        document.put("domComplete", metrics.getDomComplete());

        // Core Web Vitals
        document.put("firstContentfulPaint", metrics.getFirstContentfulPaint());
        document.put("largestContentfulPaint", metrics.getLargestContentfulPaint());
        document.put("timeToInteractive", metrics.getTimeToInteractive());
        document.put("firstInputDelay", metrics.getFirstInputDelay());
        document.put("cumulativeLayoutShift", metrics.getCumulativeLayoutShift());
        document.put("totalBlockingTime", metrics.getTotalBlockingTime());

        // Network timing
        document.put("timeToFirstByte", metrics.getTimeToFirstByte());
        document.put("dnsLookupTime", metrics.getDnsLookupTime());
        document.put("connectionTime", metrics.getConnectionTime());
        document.put("tlsTime", metrics.getTlsTime());
        document.put("requestTime", metrics.getRequestTime());
        document.put("responseTime", metrics.getResponseTime());

        // Resource metrics
        document.put("resourceCount", metrics.getResourceCount());
        document.put("totalResourceSize", metrics.getTotalResourceSize());
        document.put("totalTransferSize", metrics.getTotalTransferSize());

        // JS metrics
        document.put("jsHeapUsedSize", metrics.getJsHeapUsedSize());
        document.put("jsHeapTotalSize", metrics.getJsHeapTotalSize());
        document.put("scriptDuration", metrics.getScriptDuration());
        document.put("taskDuration", metrics.getTaskDuration());

        // Status
        document.put("overallStatus", metrics.getOverallStatus().name());

        // Timestamp
        document.put("timestamp",
                metrics.getTimestamp() != null ? metrics.getTimestamp().toString() : Instant.now().toString());

        return document;
    }

    /**
     * Generate unique document ID
     */
    private String generateDocumentId(PerformanceMetrics metrics) {
        return String.format("%s_%s_%s_%s",
                metrics.getTestName(),
                metrics.getEnvironment(),
                metrics.getNetworkType(),
                UUID.randomUUID().toString().substring(0, 8));
    }

    /**
     * Push metrics with additional metadata
     */
    public boolean pushMetricsWithMetadata(PerformanceMetrics metrics, Map<String, Object> additionalData) {
        if (!config.isEnabled() || !initialized) {
            return false;
        }

        try {
            Map<String, Object> document = createDocument(metrics);
            document.putAll(additionalData);

            String documentId = generateDocumentId(metrics);
            String indexUrl = baseUrl + "/" + config.getIndexName() + "/_doc/" + documentId;
            HttpPut putRequest = new HttpPut(indexUrl);

            String jsonBody = objectMapper.writeValueAsString(document);
            putRequest.setEntity(new StringEntity(jsonBody, ContentType.APPLICATION_JSON));

            HttpResponse response = httpClient.execute(putRequest);
            int statusCode = response.getStatusLine().getStatusCode();
            EntityUtils.consumeQuietly(response.getEntity());

            return statusCode == 200 || statusCode == 201;
        } catch (Exception e) {
            log.error("Failed to push metrics with metadata", e);
            return false;
        }
    }

    /**
     * Check if OpenSearch is connected and available
     */
    public boolean isAvailable() {
        if (!config.isEnabled() || !initialized || httpClient == null) {
            return false;
        }

        try {
            HttpGet getRequest = new HttpGet(baseUrl);
            HttpResponse response = httpClient.execute(getRequest);
            int statusCode = response.getStatusLine().getStatusCode();
            EntityUtils.consumeQuietly(response.getEntity());
            return statusCode == 200;
        } catch (IOException e) {
            log.warn("OpenSearch ping failed", e);
            return false;
        }
    }

    /**
     * Close the OpenSearch client connection
     */
    public void close() {
        if (httpClient != null) {
            try {
                httpClient.close();
                log.info("OpenSearch client closed");
            } catch (IOException e) {
                log.error("Error closing OpenSearch client", e);
            }
        }
        initialized = false;
    }

    /**
     * Get the index name
     */
    public String getIndexName() {
        return config.getIndexName();
    }

    /**
     * Convert metrics to JSON string
     */
    public String metricsToJson(PerformanceMetrics metrics) {
        try {
            return objectMapper.writerWithDefaultPrettyPrinter()
                    .writeValueAsString(createDocument(metrics));
        } catch (Exception e) {
            log.error("Failed to convert metrics to JSON", e);
            return "{}";
        }
    }
}
