package com.performance.framework.driver;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chromium.ChromiumDriver;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Chrome DevTools Protocol (CDP) Manager.
 * 
 * Uses VERSION-AGNOSTIC CDP commands via ChromiumDriver.executeCdpCommand().
 * This approach works with ANY Chrome version without needing version-specific dependencies.
 * 
 * No more updating selenium-devtools-vXXX dependencies when Chrome updates!
 * 
 * Supported browsers: Chrome, Edge (Chromium-based)
 */
@Slf4j
public class CDPManager {

    private final ChromiumDriver driver;
    private boolean devToolsAvailable = false;
    private boolean performanceEnabled = false;
    private boolean networkEnabled = false;
    private boolean pageEnabled = false;

    /**
     * Create CDPManager with a WebDriver instance.
     * 
     * @param driver WebDriver instance (must be ChromiumDriver for CDP support)
     */
    public CDPManager(WebDriver driver) {
        if (driver instanceof ChromiumDriver chromiumDriver) {
            this.driver = chromiumDriver;
            this.devToolsAvailable = true;
            log.debug("CDPManager initialized with ChromiumDriver (version-agnostic)");
        } else {
            this.driver = null;
            this.devToolsAvailable = false;
            log.debug("CDPManager: Non-Chromium browser, CDP not available");
        }
    }

    /**
     * Check if DevTools/CDP is available.
     */
    public boolean isAvailable() {
        return devToolsAvailable && driver != null;
    }

    /**
     * Enable Performance domain via CDP.
     */
    public void enablePerformanceDomain() {
        if (!isAvailable() || performanceEnabled) return;

        try {
            executeCdpCommand("Performance.enable", new HashMap<>());
            performanceEnabled = true;
            log.debug("CDP Performance domain enabled");
        } catch (Exception e) {
            log.warn("Failed to enable Performance domain: {}", e.getMessage());
        }
    }

    /**
     * Enable Network domain via CDP.
     */
    public void enableNetworkDomain() {
        if (!isAvailable() || networkEnabled) return;

        try {
            executeCdpCommand("Network.enable", new HashMap<>());
            networkEnabled = true;
            log.debug("CDP Network domain enabled");
        } catch (Exception e) {
            log.warn("Failed to enable Network domain: {}", e.getMessage());
        }
    }

    /**
     * Enable Page domain via CDP.
     */
    public void enablePageDomain() {
        if (!isAvailable() || pageEnabled) return;

        try {
            executeCdpCommand("Page.enable", new HashMap<>());
            pageEnabled = true;
            log.debug("CDP Page domain enabled");
        } catch (Exception e) {
            log.warn("Failed to enable Page domain: {}", e.getMessage());
        }
    }

    /**
     * Enable all performance-related CDP domains.
     */
    public void enableAllPerformanceDomains() {
        if (!isAvailable()) {
            log.debug("CDP not available, skipping domain enablement");
            return;
        }

        enablePerformanceDomain();
        enableNetworkDomain();
        enablePageDomain();
        
        log.info("CDP domains enabled: Performance={}, Network={}, Page={}", 
                performanceEnabled, networkEnabled, pageEnabled);
    }

    /**
     * Disable Performance domain.
     */
    public void disablePerformanceDomain() {
        if (!isAvailable() || !performanceEnabled) return;

        try {
            executeCdpCommand("Performance.disable", new HashMap<>());
            performanceEnabled = false;
        } catch (Exception e) {
            log.warn("Failed to disable Performance domain: {}", e.getMessage());
        }
    }

    /**
     * Disable Network domain.
     */
    public void disableNetworkDomain() {
        if (!isAvailable() || !networkEnabled) return;

        try {
            executeCdpCommand("Network.disable", new HashMap<>());
            networkEnabled = false;
        } catch (Exception e) {
            log.warn("Failed to disable Network domain: {}", e.getMessage());
        }
    }

    /**
     * Disable Page domain.
     */
    public void disablePageDomain() {
        if (!isAvailable() || !pageEnabled) return;

        try {
            executeCdpCommand("Page.disable", new HashMap<>());
            pageEnabled = false;
        } catch (Exception e) {
            log.warn("Failed to disable Page domain: {}", e.getMessage());
        }
    }

    /**
     * Disable all CDP domains.
     */
    public void disableAllDomains() {
        disablePerformanceDomain();
        disableNetworkDomain();
        disablePageDomain();
    }

    /**
     * Get performance metrics via CDP.
     * 
     * @return Map of metric name to value
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> getPerformanceMetrics() {
        if (!isAvailable()) {
            return new HashMap<>();
        }

        try {
            Map<String, Object> result = executeCdpCommand("Performance.getMetrics", new HashMap<>());
            
            if (result != null && result.containsKey("metrics")) {
                Map<String, Object> metricsMap = new HashMap<>();
                Object metrics = result.get("metrics");
                
                if (metrics instanceof List<?> metricsList) {
                    for (Object metric : metricsList) {
                        if (metric instanceof Map<?, ?> m) {
                            String name = (String) m.get("name");
                            Object value = m.get("value");
                            if (name != null && value != null) {
                                metricsMap.put(name, value);
                            }
                        }
                    }
                }
                return metricsMap;
            }
        } catch (Exception e) {
            log.warn("Failed to get CDP performance metrics: {}", e.getMessage());
        }
        
        return new HashMap<>();
    }

    /**
     * Simulate network conditions.
     * 
     * @param offline Whether to simulate offline mode
     * @param latency Latency in milliseconds
     * @param downloadThroughput Download speed in bytes/second (-1 for no throttling)
     * @param uploadThroughput Upload speed in bytes/second (-1 for no throttling)
     */
    public void emulateNetworkConditions(boolean offline, long latency, 
                                          long downloadThroughput, long uploadThroughput) {
        if (!isAvailable()) {
            log.warn("CDP not available, cannot emulate network conditions");
            return;
        }

        try {
            Map<String, Object> params = new HashMap<>();
            params.put("offline", offline);
            params.put("latency", latency);
            params.put("downloadThroughput", downloadThroughput);
            params.put("uploadThroughput", uploadThroughput);
            
            executeCdpCommand("Network.emulateNetworkConditions", params);
            log.info("Network conditions emulated: offline={}, latency={}ms", offline, latency);
        } catch (Exception e) {
            log.warn("Failed to emulate network conditions: {}", e.getMessage());
        }
    }

    /**
     * Simulate slow 3G network.
     */
    public void emulateSlowNetwork() {
        // Slow 3G: 400ms latency, 500kb/s download, 500kb/s upload
        emulateNetworkConditions(false, 400, 500 * 1024 / 8, 500 * 1024 / 8);
    }

    /**
     * Simulate fast 3G network.
     */
    public void emulateFastNetwork() {
        // Fast 3G: 100ms latency, 1.5Mb/s download, 750kb/s upload
        emulateNetworkConditions(false, 100, 1500 * 1024 / 8, 750 * 1024 / 8);
    }

    /**
     * Disable network throttling.
     */
    public void disableNetworkThrottling() {
        emulateNetworkConditions(false, 0, -1, -1);
    }

    /**
     * Clear browser cache via CDP.
     */
    public void clearBrowserCache() {
        if (!isAvailable()) return;

        try {
            executeCdpCommand("Network.clearBrowserCache", new HashMap<>());
            log.debug("Browser cache cleared");
        } catch (Exception e) {
            log.warn("Failed to clear browser cache: {}", e.getMessage());
        }
    }

    /**
     * Clear browser cookies via CDP.
     */
    public void clearBrowserCookies() {
        if (!isAvailable()) return;

        try {
            executeCdpCommand("Network.clearBrowserCookies", new HashMap<>());
            log.debug("Browser cookies cleared");
        } catch (Exception e) {
            log.warn("Failed to clear browser cookies: {}", e.getMessage());
        }
    }

    /**
     * Set CPU throttling rate.
     * 
     * @param rate Throttling rate (1 = no throttle, 4 = 4x slowdown, 6 = 6x slowdown)
     */
    public void setCPUThrottlingRate(int rate) {
        if (!isAvailable()) return;

        try {
            Map<String, Object> params = new HashMap<>();
            params.put("rate", rate);
            executeCdpCommand("Emulation.setCPUThrottlingRate", params);
            log.info("CPU throttling set to {}x", rate);
        } catch (Exception e) {
            log.warn("Failed to set CPU throttling: {}", e.getMessage());
        }
    }

    /**
     * Execute a CDP command with parameters.
     * This is the VERSION-AGNOSTIC way to interact with Chrome DevTools.
     * 
     * @param command CDP command (e.g., "Performance.getMetrics", "Network.enable")
     * @param params Command parameters
     * @return Command result as a Map
     */
    public Map<String, Object> executeCdpCommand(String command, Map<String, Object> params) {
        if (!isAvailable()) {
            log.debug("CDP not available, skipping command: {}", command);
            return new HashMap<>();
        }

        try {
            return driver.executeCdpCommand(command, params);
        } catch (Exception e) {
            log.debug("CDP command failed: {} - {}", command, e.getMessage());
            throw e;
        }
    }

    /**
     * Cleanup and disable all CDP domains.
     */
    public void cleanup() {
        if (!isAvailable()) return;

        try {
            disableAllDomains();
            log.debug("CDP cleanup completed");
        } catch (Exception e) {
            log.debug("Error during CDP cleanup: {}", e.getMessage());
        }
    }

    /**
     * Get the ChromiumDriver instance.
     */
    public ChromiumDriver getDriver() {
        return driver;
    }

    public boolean isPerformanceEnabled() {
        return performanceEnabled;
    }

    public boolean isNetworkEnabled() {
        return networkEnabled;
    }

    public boolean isPageEnabled() {
        return pageEnabled;
    }
}
