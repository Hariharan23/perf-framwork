package com.performance.framework.listeners;

import com.performance.framework.reports.ExtentManager;
import lombok.extern.slf4j.Slf4j;
import org.testng.*;

@Slf4j
public class ExtentReportListener implements ITestListener, ISuiteListener {

    @Override
    public void onStart(ISuite suite) {
        log.info("Suite Started: {}", suite.getName());
        ExtentManager.getInstance();
    }

    @Override
    public void onFinish(ISuite suite) {
        log.info("Suite Finished: {}", suite.getName());
        ExtentManager.flush();
    }

    @Override
    public void onTestStart(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        String description = result.getMethod().getDescription();

        log.info("Test Started: {}", testName);

        if (description != null && !description.isEmpty()) {
            ExtentManager.createTest(testName, description);
        } else {
            ExtentManager.createTest(testName);
        }
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        log.info("Test Passed: {}", result.getMethod().getMethodName());
        ExtentManager.logPass("Test passed");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        Throwable throwable = result.getThrowable();

        log.error("Test Failed: {}", testName, throwable);

        if (throwable != null) {
            ExtentManager.logFail("Test failed: " + throwable.getMessage());
            ExtentManager.getTest().fail(throwable);
        } else {
            ExtentManager.logFail("Test failed");
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        log.warn("Test Skipped: {}", result.getMethod().getMethodName());
        Throwable throwable = result.getThrowable();
        ExtentManager.logSkip(throwable != null ? "Skipped: " + throwable.getMessage() : "Test skipped");
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        log.info("Test Failed But Within Success Percentage: {}", result.getMethod().getMethodName());
    }

    @Override
    public void onTestFailedWithTimeout(ITestResult result) {
        log.error("Test Timed Out: {}", result.getMethod().getMethodName());
        ExtentManager.logFail("Test failed due to timeout");
    }
}
