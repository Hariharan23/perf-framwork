package com.performance.framework.utils;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Utility class for common wait operations.
 */
@Slf4j
public class WaitUtils {

    private final WebDriver driver;
    private final WebDriverWait wait;

    public WaitUtils(WebDriver driver) {
        this(driver, 10);
    }

    public WaitUtils(WebDriver driver, int defaultTimeout) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(defaultTimeout));
    }

    /**
     * Wait for element to be visible
     */
    public WebElement waitForVisible(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    /**
     * Wait for element to be clickable
     */
    public WebElement waitForClickable(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    /**
     * Wait for element to be present in DOM
     */
    public WebElement waitForPresence(By locator) {
        return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    /**
     * Wait for element to be invisible
     */
    public boolean waitForInvisible(By locator) {
        return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    /**
     * Wait for element to contain text
     */
    public boolean waitForTextPresent(By locator, String text) {
        return wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
    }

    /**
     * Wait for URL to contain
     */
    public boolean waitForUrlContains(String urlFragment) {
        return wait.until(ExpectedConditions.urlContains(urlFragment));
    }

    /**
     * Wait for title to contain
     */
    public boolean waitForTitleContains(String titleFragment) {
        return wait.until(ExpectedConditions.titleContains(titleFragment));
    }

    /**
     * Wait for page load complete
     */
    public void waitForPageLoad() {
        wait.until((ExpectedCondition<Boolean>) d -> {
            JavascriptExecutor js = (JavascriptExecutor) d;
            return js.executeScript("return document.readyState").equals("complete");
        });
    }

    /**
     * Wait for AJAX calls to complete
     */
    public void waitForAjaxComplete() {
        wait.until((ExpectedCondition<Boolean>) d -> {
            JavascriptExecutor js = (JavascriptExecutor) d;
            return (Boolean) js.executeScript("return jQuery.active == 0");
        });
    }

    /**
     * Wait for Angular to complete (if applicable)
     */
    public void waitForAngular() {
        try {
            wait.until((ExpectedCondition<Boolean>) d -> {
                JavascriptExecutor js = (JavascriptExecutor) d;
                return (Boolean) js.executeScript(
                        "return window.getAllAngularTestabilities ? " +
                                "window.getAllAngularTestabilities().every(t => t.isStable()) : true");
            });
        } catch (Exception e) {
            log.debug("Angular wait skipped - not an Angular app");
        }
    }

    /**
     * Wait with custom timeout
     */
    public WebElement waitForVisible(By locator, int timeoutSeconds) {
        WebDriverWait customWait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return customWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    /**
     * Wait for staleness of element (useful after page navigation)
     */
    public boolean waitForStaleness(WebElement element) {
        return wait.until(ExpectedConditions.stalenessOf(element));
    }

    /**
     * Wait for number of windows
     */
    public boolean waitForNumberOfWindows(int numberOfWindows) {
        return wait.until(ExpectedConditions.numberOfWindowsToBe(numberOfWindows));
    }

    /**
     * Fluent wait with polling
     */
    public WebElement fluentWait(By locator, int timeout, int pollingInterval) {
        return new WebDriverWait(driver, Duration.ofSeconds(timeout))
                .pollingEvery(Duration.ofMillis(pollingInterval))
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    /**
     * Simple sleep (use sparingly)
     */
    public void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.warn("Sleep interrupted", e);
        }
    }
}
