package com.performance.framework.config;

import lombok.Builder;
import lombok.Data;

/**
 * Browser configuration POJO
 */
@Data
@Builder
public class BrowserConfig {
    private String type;
    private boolean headless;
    private boolean maximizeWindow;
    private int implicitWait;
    private int pageLoadTimeout;
    private int scriptTimeout;

    // Selenium Grid Configuration
    private boolean useGrid;
    private String gridUrl;
    private String platformName;
    private String browserVersion;
}
