package com.performance.framework.driver;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v131.network.Network;
import org.openqa.selenium.devtools.v131.page.Page;
import org.openqa.selenium.devtools.v131.performance.Performance;

import java.util.Optional;

@Slf4j
public class CDPManager {

    private final DevTools devTools;
    private boolean performanceEnabled = false;
    private boolean networkEnabled = false;
    private boolean pageEnabled = false;

    public CDPManager(DevTools devTools) {
        this.devTools = devTools;
        if (devTools == null) {
            log.warn("DevTools is null - CDP features will be unavailable");
        }
    }

    public void enablePerformanceDomain() {
        if (devTools == null || performanceEnabled)
            return;

        try {
            devTools.send(Performance.enable(Optional.empty()));
            performanceEnabled = true;
            log.info("CDP Performance domain enabled");
        } catch (Exception e) {
            log.error("Failed to enable Performance domain", e);
        }
    }

    public void enableNetworkDomain() {
        if (devTools == null || networkEnabled)
            return;

        try {
            devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));
            networkEnabled = true;
            log.info("CDP Network domain enabled");
        } catch (Exception e) {
            log.error("Failed to enable Network domain", e);
        }
    }

    public void enablePageDomain() {
        if (devTools == null || pageEnabled)
            return;

        try {
            devTools.send(Page.enable());
            pageEnabled = true;
            log.info("CDP Page domain enabled");
        } catch (Exception e) {
            log.error("Failed to enable Page domain", e);
        }
    }

    public void enableAllPerformanceDomains() {
        enablePerformanceDomain();
        enableNetworkDomain();
        enablePageDomain();
        log.info("All CDP performance domains enabled");
    }

    public void disablePerformanceDomain() {
        if (devTools == null || !performanceEnabled)
            return;

        try {
            devTools.send(Performance.disable());
            performanceEnabled = false;
        } catch (Exception e) {
            log.warn("Failed to disable Performance domain", e);
        }
    }

    public void disableNetworkDomain() {
        if (devTools == null || !networkEnabled)
            return;

        try {
            devTools.send(Network.disable());
            networkEnabled = false;
        } catch (Exception e) {
            log.warn("Failed to disable Network domain", e);
        }
    }

    public void disablePageDomain() {
        if (devTools == null || !pageEnabled)
            return;

        try {
            devTools.send(Page.disable());
            pageEnabled = false;
        } catch (Exception e) {
            log.warn("Failed to disable Page domain", e);
        }
    }

    public void disableAllDomains() {
        disablePerformanceDomain();
        disableNetworkDomain();
        disablePageDomain();
    }

    public void addPageLoadEventListener(Runnable callback) {
        if (devTools == null)
            return;

        try {
            devTools.addListener(Page.loadEventFired(), loadEvent -> {
                log.debug("Page load event fired");
                if (callback != null)
                    callback.run();
            });
        } catch (Exception e) {
            log.error("Failed to add page load event listener", e);
        }
    }

    public void addDOMContentLoadedListener(Runnable callback) {
        if (devTools == null)
            return;

        try {
            devTools.addListener(Page.domContentEventFired(), domEvent -> {
                log.debug("DOM content loaded");
                if (callback != null)
                    callback.run();
            });
        } catch (Exception e) {
            log.error("Failed to add DOM content loaded listener", e);
        }
    }

    public DevTools getDevTools() {
        return devTools;
    }

    public boolean isAvailable() {
        return devTools != null;
    }

    public boolean isPerformanceEnabled() {
        return performanceEnabled;
    }

    public boolean isNetworkEnabled() {
        return networkEnabled;
    }

    public boolean isPageEnabled() {
        return pageEnabled;
    }
}
