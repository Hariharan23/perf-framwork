package com.performance.framework.listeners;

import com.performance.framework.config.ConfigManager;
import com.performance.framework.config.ReportingConfig;
import com.performance.framework.opensearch.OpenSearchClientManager;
import com.performance.framework.performance.PerformanceMetrics;
import com.performance.framework.reports.ExtentManager;
import com.performance.framework.reports.PerformanceReportLogger;
import lombok.extern.slf4j.Slf4j;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public class PerformanceMetricsListener implements IInvokedMethodListener {

    private static final ThreadLocal<Map<String, PerformanceMetrics>> testMetricsMap = ThreadLocal
            .withInitial(HashMap::new);

    private final PerformanceReportLogger reportLogger;
    private final ReportingConfig reportingConfig;

    public PerformanceMetricsListener() {
        this.reportLogger = new PerformanceReportLogger();
        this.reportingConfig = ConfigManager.getInstance().getReportingConfig();
    }

    @Override
    public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
        if (method.isTestMethod()) {
            String testName = method.getTestMethod().getMethodName();
            testMetricsMap.get().remove(testName);
        }
    }

    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
        if (method.isTestMethod()) {
            String testName = method.getTestMethod().getMethodName();
            PerformanceMetrics metrics = testMetricsMap.get().get(testName);

            if (metrics != null) {
                processMetrics(metrics);
            }
        }
    }

    private void processMetrics(PerformanceMetrics metrics) {
        if (reportingConfig.isLogToReport()) {
            reportLogger.logMetricsToReport(metrics);
        }

        if (reportingConfig.isLogToConsole()) {
            logMetricsToConsole(metrics);
        }

        if (reportingConfig.isPushToOpenSearch()) {
            pushMetricsToOpenSearch(metrics);
        }
    }

    private void logMetricsToConsole(PerformanceMetrics metrics) {
        log.info("Performance Metrics: {}", metrics.getPageName());
        log.info("  Page Load: {}ms | FCP: {}ms | LCP: {}ms | TTI: {}ms | TTFB: {}ms | Status: {}",
                metrics.getPageLoadTime(),
                metrics.getFirstContentfulPaint(),
                metrics.getLargestContentfulPaint(),
                metrics.getTimeToInteractive(),
                metrics.getTimeToFirstByte(),
                metrics.getOverallStatus());
    }

    private void pushMetricsToOpenSearch(PerformanceMetrics metrics) {
        try {
            OpenSearchClientManager openSearchManager = OpenSearchClientManager.getInstance();
            if (openSearchManager.isAvailable()) {
                boolean success = openSearchManager.pushMetrics(metrics);
                if (success) {
                    ExtentManager.logInfo("Metrics pushed to OpenSearch");
                } else {
                    ExtentManager.logWarning("Failed to push metrics to OpenSearch");
                }
            }
        } catch (Exception e) {
            log.warn("Error pushing metrics to OpenSearch", e);
        }
    }

    public static void registerMetrics(String testName, PerformanceMetrics metrics) {
        testMetricsMap.get().put(testName, metrics);
    }

    public static PerformanceMetrics getMetrics(String testName) {
        return testMetricsMap.get().get(testName);
    }

    public static void clearMetrics() {
        testMetricsMap.get().clear();
    }
}
