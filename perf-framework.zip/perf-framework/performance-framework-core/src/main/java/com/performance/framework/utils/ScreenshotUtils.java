package com.performance.framework.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

/**
 * Utility class for screenshot operations.
 */
@Slf4j
public class ScreenshotUtils {

    private final WebDriver driver;
    private static final String SCREENSHOT_DIR = "target/screenshots/";

    public ScreenshotUtils(WebDriver driver) {
        this.driver = driver;
        createScreenshotDirectory();
    }

    /**
     * Create screenshot directory if not exists
     */
    private void createScreenshotDirectory() {
        File dir = new File(SCREENSHOT_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    /**
     * Take screenshot and save to file
     */
    public String takeScreenshot(String name) {
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);

            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String fileName = name + "_" + timestamp + ".png";
            String filePath = SCREENSHOT_DIR + fileName;

            FileUtils.copyFile(source, new File(filePath));
            log.info("Screenshot saved: {}", filePath);

            return filePath;
        } catch (IOException e) {
            log.error("Failed to save screenshot", e);
            return null;
        }
    }

    /**
     * Get screenshot as Base64 string
     */
    public String getScreenshotAsBase64() {
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            byte[] screenshot = ts.getScreenshotAs(OutputType.BYTES);
            return Base64.getEncoder().encodeToString(screenshot);
        } catch (Exception e) {
            log.error("Failed to capture screenshot as Base64", e);
            return null;
        }
    }

    /**
     * Get screenshot as bytes
     */
    public byte[] getScreenshotAsBytes() {
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            return ts.getScreenshotAs(OutputType.BYTES);
        } catch (Exception e) {
            log.error("Failed to capture screenshot as bytes", e);
            return new byte[0];
        }
    }

    /**
     * Take full page screenshot (using scrolling)
     */
    public String takeFullPageScreenshot(String name) {
        // For Chrome, we can use CDP for full page screenshot
        // This is a basic implementation
        return takeScreenshot(name + "_fullpage");
    }

    /**
     * Get screenshot directory
     */
    public static String getScreenshotDirectory() {
        return SCREENSHOT_DIR;
    }
}
