package com.performance.framework.pages;

import com.performance.framework.config.ApplicationConfigManager;
import com.performance.framework.config.ConfigManager;
import com.performance.framework.driver.DriverFactory;
import com.performance.framework.performance.PerformanceMetrics;
import com.performance.framework.performance.PerformanceMetricsCollector;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

@Slf4j
public abstract class BasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected PerformanceMetricsCollector metricsCollector;
    protected ConfigManager configManager;
    protected ApplicationConfigManager appConfigManager;

    private static final int DEFAULT_WAIT_TIMEOUT = 10;

    public BasePage() {
        this.driver = DriverFactory.getDriver();
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(DEFAULT_WAIT_TIMEOUT));
        this.metricsCollector = new PerformanceMetricsCollector();
        this.configManager = ConfigManager.getInstance();
        this.appConfigManager = ApplicationConfigManager.getInstance();
        PageFactory.initElements(driver, this);
    }

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(DEFAULT_WAIT_TIMEOUT));
        this.metricsCollector = new PerformanceMetricsCollector();
        this.configManager = ConfigManager.getInstance();
        this.appConfigManager = ApplicationConfigManager.getInstance();
        PageFactory.initElements(driver, this);
    }

    public abstract String getPageName();

    public abstract boolean isLoaded();

    public void navigateTo(String url) {
        log.info("Navigating to: {}", url);
        driver.get(url);
        waitForPageLoad();
    }

    public void waitForPageLoad() {
        wait.until(webDriver -> ((JavascriptExecutor) webDriver)
                .executeScript("return document.readyState").equals("complete"));
    }

    protected WebElement waitForVisibility(WebElement element) {
        return wait.until(ExpectedConditions.visibilityOf(element));
    }

    protected WebElement waitForVisibility(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    protected WebElement waitForClickable(WebElement element) {
        return wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    protected WebElement waitForClickable(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    protected void click(WebElement element) {
        waitForClickable(element).click();
    }

    protected void type(WebElement element, String text) {
        WebElement el = waitForVisibility(element);
        el.clear();
        el.sendKeys(text);
    }

    protected String getText(WebElement element) {
        return waitForVisibility(element).getText();
    }

    protected boolean isDisplayed(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (NoSuchElementException | StaleElementReferenceException e) {
            return false;
        }
    }

    protected void scrollToElement(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    protected void jsClick(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }

    public PerformanceMetrics collectPerformanceMetrics(String testName) {
        metricsCollector.waitForPageLoad(30);
        return metricsCollector.collectMetrics(testName, getPageName());
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    public byte[] takeScreenshot() {
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }

    public void refresh() {
        driver.navigate().refresh();
        waitForPageLoad();
    }

    public void goBack() {
        driver.navigate().back();
        waitForPageLoad();
    }

    protected void setWaitTimeout(int seconds) {
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
    }
}
