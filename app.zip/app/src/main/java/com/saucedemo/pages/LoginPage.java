package com.saucedemo.pages;

import com.performance.framework.pages.BasePage;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * SauceDemo Login Page Object.
 */
@Slf4j
public class LoginPage extends BasePage {

    private static final String PAGE_NAME = "Login Page";

    @FindBy(id = "user-name")
    private WebElement usernameInput;

    @FindBy(id = "password")
    private WebElement passwordInput;

    @FindBy(id = "login-button")
    private WebElement loginButton;

    @FindBy(css = "[data-test='error']")
    private WebElement errorMessage;

    @FindBy(css = ".login_logo")
    private WebElement loginLogo;

    public LoginPage() {
        super();
    }

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public String getPageName() {
        return PAGE_NAME;
    }

    @Override
    public boolean isLoaded() {
        try {
            return usernameInput.isDisplayed() && passwordInput.isDisplayed() && loginButton.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Navigate to login page
     */
    public LoginPage open() {
        String loginUrl = appConfigManager.getFullPageUrl("login");
        navigateTo(loginUrl);
        log.info("Navigated to login page: {}", loginUrl);
        return this;
    }

    /**
     * Enter username
     */
    public LoginPage enterUsername(String username) {
        type(usernameInput, username);
        log.debug("Entered username: {}", username);
        return this;
    }

    /**
     * Enter password
     */
    public LoginPage enterPassword(String password) {
        type(passwordInput, password);
        log.debug("Entered password");
        return this;
    }

    /**
     * Click login button
     */
    public LoginPage clickLogin() {
        click(loginButton);
        log.info("Clicked login button");
        return this;
    }

    /**
     * Perform login with credentials
     */
    public InventoryPage login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLogin();
        log.info("Logged in with username: {}", username);
        return new InventoryPage(driver);
    }

    /**
     * Login using test data
     */
    public InventoryPage loginWithTestData(String userType) {
        String username = appConfigManager.getTestData("users." + userType + ".username");
        String password = appConfigManager.getTestData("users." + userType + ".password");
        return login(username, password);
    }

    /**
     * Login as standard user
     */
    public InventoryPage loginAsStandardUser() {
        return loginWithTestData("standardUser");
    }

    /**
     * Login as performance glitch user
     */
    public InventoryPage loginAsPerformanceGlitchUser() {
        return loginWithTestData("performanceGlitchUser");
    }

    /**
     * Attempt login as locked out user
     */
    public LoginPage attemptLoginAsLockedOutUser() {
        String username = appConfigManager.getTestData("users.lockedOutUser.username");
        String password = appConfigManager.getTestData("users.lockedOutUser.password");
        enterUsername(username);
        enterPassword(password);
        clickLogin();
        log.info("Attempted login as locked out user");
        return this;
    }

    /**
     * Check if error is displayed
     */
    public boolean isErrorDisplayed() {
        try {
            return errorMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Get error message text
     */
    public String getErrorMessage() {
        if (isErrorDisplayed()) {
            return getText(errorMessage);
        }
        return "";
    }

    /**
     * Verify error matches expected
     */
    public boolean verifyErrorMessage(String errorKey) {
        String expectedError = appConfigManager.getTestData("errorMessages." + errorKey);
        String actualError = getErrorMessage();
        return actualError.equals(expectedError);
    }

    /**
     * Check if logo is displayed
     */
    public boolean isLogoDisplayed() {
        return isDisplayed(loginLogo);
    }
}
