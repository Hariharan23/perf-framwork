package com.saucedemo.tests;

import com.performance.framework.tests.BaseTest;
import com.saucedemo.pages.InventoryPage;
import com.saucedemo.pages.LoginPage;
import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * SauceDemo Login Tests.
 */
@Slf4j
public class LoginTest extends BaseTest {

    private LoginPage loginPage;

    @Override
    protected String getApplicationName() {
        return "saucedemo";
    }

    @BeforeMethod
    public void setUpPage() {
        loginPage = new LoginPage(driver);
    }

    @Test(description = "Verify successful login with standard user")
    public void testSuccessfulLogin() {
        log.info("Starting successful login test");

        loginPage.open();
        Assert.assertTrue(loginPage.isLoaded(), "Login page should be loaded");

        InventoryPage inventoryPage = loginPage.loginAsStandardUser();

        Assert.assertTrue(inventoryPage.isLoaded(), "Inventory page should be loaded after login");
        Assert.assertEquals(inventoryPage.getPageTitleText(), "Products", "Page title should be 'Products'");

        log.info("Successful login test completed");
    }

    @Test(description = "Verify login with invalid credentials shows error")
    public void testInvalidLogin() {
        log.info("Starting invalid login test");

        loginPage.open();
        loginPage.login("invalid_user", "invalid_password");

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Error message should be displayed");
        Assert.assertTrue(loginPage.getErrorMessage().contains("Username and password do not match"),
                "Error message should indicate invalid credentials");

        log.info("Invalid login test completed");
    }

    @Test(description = "Verify login with locked out user shows error")
    public void testLockedOutUser() {
        log.info("Starting locked out user test");

        loginPage.open();
        loginPage.loginWithTestData("lockedOutUser");

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Error message should be displayed");
        Assert.assertTrue(loginPage.getErrorMessage().contains("locked out"),
                "Error message should indicate user is locked out");

        log.info("Locked out user test completed");
    }

    @Test(description = "Verify login with problem user")
    public void testProblemUser() {
        log.info("Starting problem user test");

        loginPage.open();
        loginPage.loginWithTestData("problemUser");

        // Problem user can login but experiences issues in the app
        InventoryPage inventoryPage = new InventoryPage(driver);
        Assert.assertTrue(inventoryPage.isLoaded(), "Problem user should be able to login");

        log.info("Problem user test completed");
    }

    @Test(description = "Verify performance glitch user login")
    public void testPerformanceGlitchUser() {
        log.info("Starting performance glitch user test");

        loginPage.open();
        loginPage.loginWithTestData("performanceGlitchUser");

        // Performance glitch user can login but with delays
        InventoryPage inventoryPage = new InventoryPage(driver);
        Assert.assertTrue(inventoryPage.isLoaded(), "Performance glitch user should be able to login");

        log.info("Performance glitch user test completed");
    }

    @Test(description = "Verify empty username shows error")
    public void testEmptyUsername() {
        log.info("Starting empty username test");

        loginPage.open();
        loginPage.login("", "secret_sauce");

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Error message should be displayed");
        Assert.assertTrue(loginPage.getErrorMessage().contains("Username is required"),
                "Error message should indicate username is required");

        log.info("Empty username test completed");
    }

    @Test(description = "Verify empty password shows error")
    public void testEmptyPassword() {
        log.info("Starting empty password test");

        loginPage.open();
        loginPage.login("standard_user", "");

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Error message should be displayed");
        Assert.assertTrue(loginPage.getErrorMessage().contains("Password is required"),
                "Error message should indicate password is required");

        log.info("Empty password test completed");
    }
}
