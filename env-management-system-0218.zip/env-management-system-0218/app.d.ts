#!/usr/bin/env node
import 'source-map-support/register';
