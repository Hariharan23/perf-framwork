import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * AWS Lambda handler for Neptune database cleanup operations
 * Provides functionality to delete all data or specific entity types
 */
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
