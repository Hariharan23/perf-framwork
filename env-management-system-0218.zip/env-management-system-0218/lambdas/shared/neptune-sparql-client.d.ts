export interface Entity {
    id: string;
    name: string;
    type: string;
    uniqueIdentifier?: string;
    owner?: string;
    description?: string;
    createdAt?: string;
    status?: string;
}
export interface Environment extends Entity {
    type: 'Environment';
}
export interface Application extends Entity {
    type: 'Application';
}
export interface Integration extends Entity {
    type: 'Integration';
}
export interface Configuration {
    id: string;
    type: string;
    configurationMap?: string;
    createdAt?: string;
}
export interface EnvironmentConfiguration extends Configuration {
    type: 'EnvironmentConfiguration';
}
export interface ApplicationConfiguration extends Configuration {
    type: 'ApplicationConfiguration';
}
export interface IntegrationConfiguration extends Configuration {
    type: 'IntegrationConfiguration';
    sourceService?: string;
    targetService?: string;
}
export interface ConfigurationEntry {
    id: string;
    configurationKey: string;
    configurationValue: string;
    configurationType?: string;
}
export interface NetworkNode {
    id: string;
    label: string;
    type: string;
    properties: Record<string, any>;
    configurations?: Record<string, string>;
}
export interface NetworkEdge {
    id: string;
    source: string;
    target: string;
    type: string;
    label?: string;
    properties: Record<string, any>;
}
export interface NetworkData {
    nodes: NetworkNode[];
    edges: NetworkEdge[];
}
export declare class NeptuneSparqlClient {
    private neptuneEndpoint;
    private region;
    private credentials;
    private signer;
    private readonly ontologyPrefix;
    /**
     * Extract UUID from full URI or return as-is if already a UUID
     */
    private extractEntityId;
    constructor(neptuneEndpoint?: string, region?: string);
    /**
     * Execute SPARQL query against Neptune with IAM authentication
     */
    executeSparqlQuery(query: string): Promise<any>;
    /**
     * Execute SPARQL update against Neptune with IAM authentication
     */
    executeSparqlUpdate(update: string): Promise<any>;
    /**
     * Health check for Neptune cluster
     */
    healthCheck(): Promise<boolean>;
    /**
     * Create Environment using SPARQL following ontology
     */
    createEnvironment(environment: Omit<Environment, 'id'>): Promise<Environment>;
    /**
     * Create Application using SPARQL following ontology
     */
    createApplication(application: Omit<Application, 'id'>): Promise<Application>;
    /**
     * Create Integration using SPARQL following ontology
     */
    createIntegration(integration: Omit<Integration, 'id'>): Promise<Integration>;
    /**
     * Create Environment Configuration using SPARQL
     */
    createEnvironmentConfiguration(config: Omit<EnvironmentConfiguration, 'id'>, environmentId: string): Promise<EnvironmentConfiguration>;
    /**
     * Create Application Configuration using SPARQL
     */
    createApplicationConfiguration(config: Omit<ApplicationConfiguration, 'id'>, applicationId: string): Promise<ApplicationConfiguration>;
    /**
     * Create Integration Configuration using SPARQL
     */
    createIntegrationConfiguration(config: Omit<IntegrationConfiguration, 'id'>, integrationId: string): Promise<IntegrationConfiguration>;
    /**
     * Create Configuration Entry using SPARQL
     */
    createConfigurationEntry(entry: Omit<ConfigurationEntry, 'id'>, configurationId: string): Promise<ConfigurationEntry>;
    /**
     * Get all entities by type following ontology
     */
    getEntitiesByType(entityType: string): Promise<Entity[]>;
    /**
     * Get network data for visualization following ontology
     */
    getNetworkData(): Promise<NetworkData>;
    /**
     * Get entity by ID following ontology
     */
    getEntityById(id: string): Promise<Entity | null>;
    /**
     * Get configurations for an entity
     */
    getEntityConfigurations(entityId: string): Promise<Configuration[]>;
    /**
     * Get configuration entries for a configuration
     */
    getConfigurationEntries(configurationId: string): Promise<ConfigurationEntry[]>;
    /**
     * Delete entity by ID
     */
    deleteEntity(id: string): Promise<boolean>;
    /**
     * Initialize ontology following the complete schema
     */
    initializeOntology(): Promise<void>;
    /**
     * Create deployment relationship
     */
    createDeployment(applicationId: string, environmentId: string): Promise<void>;
    /**
     * Get deployments for an environment
     */
    getEnvironmentDeployments(environmentId: string): Promise<Entity[]>;
    /**
     * Create relationships between entities
     */
    createRelationship(sourceEntityName: string, relationshipType: string, targetEntityName: string): Promise<void>;
    /**
     * Add configuration properties directly to an entity
     */
    addConfigurationProperties(entityId: string, configurations: Record<string, any>): Promise<void>;
}
