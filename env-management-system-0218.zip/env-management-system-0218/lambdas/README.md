# Neptune Environment Management System - Lambda Functions# Environment Management Lambda Functions

SPARQL-only implementation following the complete ontology with consolidated dependencies.This directory contains the modernized AWS Lambda functions for the Environment Management System, updated to use utility files instead of layers for better maintainability and deployment simplicity.

## Structure## Architecture Overview

````### New Architecture (Utility-Based)

lambdas/

├── package.json                          # Consolidated dependencies- **Query Lambda** (`query/index.js`): Handles all data retrieval operations

├── tsconfig.json                         # TypeScript configuration- **Ingestion Lambda** (`ingestion/index.js`): Handles all data creation/modification operations

├── node_modules/                         # Shared dependencies- **Neptune Utilities** (`utils/neptune-utils.js`): Shared Neptune client and helper functions

├── shared/

│   └── neptune-sparql-client.ts         # SPARQL-only Neptune client### Benefits of New Architecture

├── src/

│   ├── ingestion.ts                     # Ingestion Lambda handler
│   └── query.ts                         # Query Lambda handler
└── dist/                                # Compiled output for deployment
    ├── package.json                     # Dependencies for Lambda
    ├── node_modules/                    # Runtime dependencies
    ├── shared/                          # Compiled shared utilities

    └── src/                             # Compiled Lambda handlers

```## Lambda Functions



## Development### Query Lambda (`query/index.js`)



### Build**Purpose**: Retrieve data from Neptune database in various formats

```bash

npm run build**Supported Operations**:

````

- `get-topology` - Get all entities and relationships

### Clean- `get-graph` - Get data in vis.js graph format

```bash- `get-entity` - Get specific entity details

npm run clean- `get-changes` - Get configuration change history

```- `health` - Service health check

## Ontology Support**Example Request**:

Follows the complete ontology from `../ontology.ttl`:```json

{

### Core Entities "operation": "get-topology",

- **Environment** - Deployment environments "includeConfigurations": true

- **Application** - Software applications }

- **Integration** - Service integrations```

### Configuration Classes**Example Response**:

- **EnvironmentConfiguration** - Environment settings

- **ApplicationConfiguration** - Application settings```json

- **IntegrationConfiguration** - Integration settings{

- **ConfigurationEntry** - Key-value configuration pairs "success": true,

  "data": {

### Relationships "entities": [...],

- `env:deployedIn` - Application deployed in Environment "relations": [...]

- `env:integratesWith` - Service integration relationships },

- `env:hasConfiguration` - Entity-to-Configuration links "message": "Topology data retrieved successfully",

- `env:hasConfigurationEntry` - Configuration-to-Entry links "source": "neptune",

  "timestamp": "2024-01-15T10:30:00.000Z"

## Operations}

````

### Ingestion Lambda

- `create-environment`, `create-application`, `create-integration`### Ingestion Lambda (`ingestion/index.js`)

- `create-environment-config`, `create-application-config`, `create-integration-config`

- `create-config-entry`, `create-deployment`**Purpose**: Create, update, and delete entities in Neptune database

- `initialize-ontology`, `health`

**Supported Operations**:

### Query Lambda

- `get-network`, `get-entities`, `get-entity`- `create-entity` - Generic entity creation

- `get-configurations`, `get-config-entries`, `get-deployments`- `create-environment` - Create environment with config

- `get-environments`, `get-applications`, `get-integrations`- `create-application` - Create application with config

- `health`- `create-integration` - Create integration with config

- `update-entity` - Update entity properties

All operations use pure SPARQL queries and updates against Neptune RDF store.- `update-configuration` - Update entity configuration
- `delete-entity` - Delete entity and related data
- `bulk-insert` - Create multiple entities
- `health` - Service health check

**Example Request** (Create Environment):

```json
{
  "operation": "create-environment",
  "id": "prod-env-001",
  "name": "Production Environment",
  "owner": "devops-team",
  "description": "Main production environment",
  "type": "production",
  "region": "us-east-1",
  "configurations": {
    "database_url": "jdbc:postgresql://prod-db:5432/app",
    "api_endpoint": "https://api.prod.example.com"
  },
  "changedBy": "admin-user"
}
````

## Neptune Utilities (`utils/neptune-utils.js`)

### Key Components

1. **NeptuneClient**: SPARQL query execution and health monitoring
2. **DataTransformer**: Convert SPARQL results to application formats
3. **ChangeTracker**: Record and retrieve configuration changes
4. **Utils**: Helper functions for responses, JSON parsing, etc.
5. **SPARQL_QUERIES**: Template queries for common operations

### Usage Example

```javascript
const { NeptuneClient, Utils } = require("../utils/neptune-utils");

const client = new NeptuneClient({
  endpoint: process.env.NEPTUNE_ENDPOINT,
  port: 8182,
  region: "us-east-1",
  useIAM: true,
});

const result = await client.executeSPARQLQuery(
  "SELECT * WHERE { ?s ?p ?o } LIMIT 10"
);
```

## Environment Variables

Required environment variables for Lambda deployment:

```bash
# Neptune Configuration
NEPTUNE_ENDPOINT=your-neptune-cluster.cluster-xyz.us-east-1.neptune.amazonaws.com
NEPTUNE_PORT=8182
AWS_REGION=us-east-1
USE_IAM=true

# Optional Lambda Configuration
LAMBDA_TIMEOUT=300
MEMORY_SIZE=512
```

## Deployment Instructions

### 1. Package Functions

```bash
# Package individual functions
npm run package-query      # Creates query-function.zip
npm run package-ingestion  # Creates ingestion-function.zip

# Package all functions
npm run package-all
```

### 2. Deploy via AWS CLI

```bash
# Update query function
aws lambda update-function-code \
  --function-name environment-management-query \
  --zip-file fileb://query-function.zip

# Update ingestion function
aws lambda update-function-code \
  --function-name environment-management-ingestion \
  --zip-file fileb://ingestion-function.zip
```

### 3. Deploy via AWS Console

1. Navigate to AWS Lambda console
2. Select your function
3. Upload the appropriate `.zip` file
4. Update environment variables if needed
5. Test the function

### 4. Deploy via Infrastructure as Code

Use the deployment package with your preferred IaC tool:

- **Terraform**: Use `aws_lambda_function` resource
- **CloudFormation**: Use `AWS::Lambda::Function` resource
- **CDK**: Use `Function` construct
- **Serverless Framework**: Reference zip file in function config

## Testing

### Local Testing

```bash
# Run comprehensive test suite
npm run test

# Or run specific tests
node test-lambdas.js
```

### Integration Testing

1. Deploy functions to AWS
2. Configure Neptune endpoint and IAM permissions
3. Test via AWS Console, API Gateway, or direct invocation
4. Monitor CloudWatch logs for errors

## Migration from Layer-Based Architecture

### What Changed

- **Removed**: Layer dependencies (`layers/` directory)
- **Added**: Utility functions embedded in each deployment package
- **Updated**: Import statements to use relative paths
- **Enhanced**: Error handling and health monitoring

### Migration Steps

1. **Utilities Created**: Comprehensive Neptune utilities in TypeScript
2. **Query Lambda Updated**: Modernized with operation-based routing
3. **Ingestion Lambda Updated**: Full CRUD operations with change tracking
4. **Testing Added**: Comprehensive test suite for validation
5. **Deployment**: Ready for AWS deployment

### Backward Compatibility

The new Lambda functions maintain backward compatibility with existing server integrations through exported compatibility functions:

- `getRawEntityData()`
- `queryNeptuneData()`
- `convertToGraph()`

## Troubleshooting

### Common Issues

**1. Neptune Connection Errors**

- Verify Neptune endpoint and port configuration
- Check VPC settings and security groups
- Ensure IAM role has Neptune access permissions

**2. SPARQL Query Errors**

- Enable debug logging in Neptune utilities
- Validate SPARQL syntax using Neptune workbench
- Check for proper URI escaping in queries

**3. Lambda Timeout Issues**

- Increase Lambda timeout for large datasets
- Consider pagination for large result sets
- Optimize SPARQL queries for performance

**4. Permission Errors**

- Verify Lambda execution role has Neptune permissions
- Check VPC configuration if Lambda is in VPC
- Ensure proper IAM policies are attached

### Debug Mode

Enable detailed logging by setting environment variable:

```bash
DEBUG_MODE=true
```

## Performance Considerations

### Query Optimization

- Use LIMIT clauses for large datasets
- Implement pagination for UI components
- Cache frequently accessed data
- Use Neptune query hints for complex queries

### Lambda Optimization

- Right-size memory allocation based on workload
- Use provisioned concurrency for consistent performance
- Monitor cold start times and optimize initialization
- Consider connection pooling for high-throughput scenarios

## Security Best Practices

### IAM Permissions

- Use least-privilege access for Lambda execution roles
- Restrict Neptune access to specific databases/endpoints
- Enable VPC for network isolation
- Use IAM database authentication when possible

### Data Protection

- Encrypt sensitive configuration values
- Use AWS Secrets Manager for credentials
- Implement proper input validation
- Log security events for monitoring

## Monitoring and Alerting

### CloudWatch Metrics

- Monitor Lambda duration, errors, and invocations
- Track Neptune query performance and errors
- Set up alarms for high error rates or latency
- Monitor memory and timeout issues

### Logging Strategy

- Use structured logging (JSON format)
- Include correlation IDs for request tracking
- Log business events (entity creation, updates)
- Maintain audit trail for configuration changes

---

## Next Steps

1. **Deploy Functions**: Package and deploy to AWS environment
2. **Configure Monitoring**: Set up CloudWatch dashboards and alarms
3. **Performance Testing**: Load test with realistic data volumes
4. **Documentation**: Update API documentation with new operations
5. **Training**: Update team on new architecture and capabilities

For questions or support, refer to the team documentation or contact the development team.
