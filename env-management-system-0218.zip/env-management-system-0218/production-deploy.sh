#!/bin/bash

# Production Deployment Script for Environment Management System

set -e  # Exit on any error

echo "Environment Management System - Production Deployment"

# Configuration
APP_NAME="env-management-system"
APP_DIR="/opt/${APP_NAME}"
SERVICE_NAME="${APP_NAME}"
USER="www-data"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   log_error "This script must be run as root for production deployment"
   exit 1
fi

# Install Node.js if not present
if ! command -v node &> /dev/null; then
    log_info "Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    apt-get install -y nodejs
fi

# Create application directory
log_info "Setting up application directory..."
mkdir -p $APP_DIR
chown $USER:$USER $APP_DIR

# Copy application files
log_info "Copying application files..."
cp server.js $APP_DIR/
cp environment-management-app.html $APP_DIR/
cp package.json $APP_DIR/
cp .env.production $APP_DIR/.env || cp .env $APP_DIR/.env

# Install dependencies
log_info "Installing Node.js dependencies..."
cd $APP_DIR
sudo -u $USER npm install --production

# Create systemd service
log_info "Creating systemd service..."
cat > /etc/systemd/system/${SERVICE_NAME}.service << EOF
[Unit]
Description=Environment Management System
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production
Environment=PORT=3000

# Security settings
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=$APP_DIR

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd and start service
log_info "Starting service..."
systemctl daemon-reload
systemctl enable $SERVICE_NAME
systemctl restart $SERVICE_NAME

# Check service status
if systemctl is-active --quiet $SERVICE_NAME; then
    log_info "Service started successfully"
    systemctl status $SERVICE_NAME --no-pager
else
    log_error "Service failed to start"
    systemctl status $SERVICE_NAME --no-pager
    exit 1
fi

log_info "Deployment completed successfully!"
log_info "Application is running on port 3000"