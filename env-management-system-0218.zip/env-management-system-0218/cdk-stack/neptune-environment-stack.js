"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NeptuneEnvironmentStack = void 0;
const cdk = require("aws-cdk-lib");
const ec2 = require("aws-cdk-lib/aws-ec2");
const neptune = require("aws-cdk-lib/aws-neptune");
const lambda = require("aws-cdk-lib/aws-lambda");
const iam = require("aws-cdk-lib/aws-iam");
const s3 = require("aws-cdk-lib/aws-s3");
const logs = require("aws-cdk-lib/aws-logs");
const apigateway = require("aws-cdk-lib/aws-apigateway");
class NeptuneEnvironmentStack extends cdk.Stack {
    constructor(scope, id, props) {
        super(scope, id, props);
        // Create cost-optimized VPC for Neptune cluster
        this.vpc = new ec2.Vpc(this, 'SRE-POC-NeptuneVpc', {
            maxAzs: 2,
            natGateways: 1,
            subnetConfiguration: [
                {
                    cidrMask: 26,
                    name: 'private-subnet',
                    subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
                },
                {
                    cidrMask: 28,
                    name: 'public-subnet',
                    subnetType: ec2.SubnetType.PUBLIC,
                },
            ],
        });
        // Create security group for Neptune
        const neptuneSecurityGroup = new ec2.SecurityGroup(this, 'SRE-POC-NeptuneSecurityGroup', {
            vpc: this.vpc,
            description: 'Security group for SRE POC Neptune cluster',
            allowAllOutbound: true,
        });
        // Allow inbound connections on Neptune port from Lambda security group
        neptuneSecurityGroup.addIngressRule(neptuneSecurityGroup, ec2.Port.tcp(8182), 'Allow Neptune connections from Lambda functions');
        // Create Neptune subnet group
        const subnetGroup = new neptune.CfnDBSubnetGroup(this, 'SRE-POC-NeptuneSubnetGroup', {
            dbSubnetGroupDescription: 'Subnet group for SRE POC Neptune cluster',
            subnetIds: this.vpc.privateSubnets.map((subnet) => subnet.subnetId),
            dbSubnetGroupName: 'sre-poc-neptune-subnet-group',
        });
        // Create Neptune cluster (cost-optimized)
        this.neptuneCluster = new neptune.CfnDBCluster(this, 'SRE-POC-NeptuneCluster', {
            dbClusterIdentifier: 'sre-poc-neptune-environment-cluster',
            dbSubnetGroupName: subnetGroup.ref,
            vpcSecurityGroupIds: [neptuneSecurityGroup.securityGroupId],
            backupRetentionPeriod: 1,
            preferredBackupWindow: '03:00-04:00',
            preferredMaintenanceWindow: 'sun:04:00-sun:05:00',
            storageEncrypted: false,
            deletionProtection: false,
            iamAuthEnabled: true, // Enable IAM database authentication
        });
        // Create Neptune instance (smallest instance type)
        const neptuneInstance = new neptune.CfnDBInstance(this, 'SRE-POC-NeptuneInstance', {
            dbInstanceClass: 'db.t3.medium',
            dbClusterIdentifier: this.neptuneCluster.ref,
            dbInstanceIdentifier: 'sre-poc-neptune-instance-1',
        });
        neptuneInstance.addDependency(this.neptuneCluster);
        // Create cost-optimized S3 bucket for data exports and backups
        const dataBucket = new s3.Bucket(this, 'SRE-POC-EnvironmentDataBucket', {
            encryption: s3.BucketEncryption.S3_MANAGED,
            blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
            versioned: false,
            lifecycleRules: [
                {
                    id: 'transition-to-ia',
                    enabled: true,
                    transitions: [
                        {
                            storageClass: s3.StorageClass.INFREQUENT_ACCESS,
                            transitionAfter: cdk.Duration.days(30), // Move to IA after 30 days
                        },
                        {
                            storageClass: s3.StorageClass.GLACIER,
                            transitionAfter: cdk.Duration.days(90), // Move to Glacier after 90 days
                        },
                    ],
                    expiration: cdk.Duration.days(365), // Delete after 1 year
                },
            ],
            removalPolicy: cdk.RemovalPolicy.DESTROY, // For development
        });
        // Create IAM role for Lambda functions
        const lambdaRole = new iam.Role(this, 'SRE-POC-NeptuneLambdaRole', {
            assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
            managedPolicies: [
                iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaVPCAccessExecutionRole'),
            ],
            inlinePolicies: {
                NeptuneFullAccess: new iam.PolicyDocument({
                    statements: [
                        new iam.PolicyStatement({
                            effect: iam.Effect.ALLOW,
                            actions: [
                                'neptune-db:*',
                            ],
                            resources: ['*'],
                        }),
                        new iam.PolicyStatement({
                            effect: iam.Effect.ALLOW,
                            actions: [
                                'neptune:*',
                            ],
                            resources: ['*'],
                        }),
                        new iam.PolicyStatement({
                            effect: iam.Effect.ALLOW,
                            actions: ['s3:GetObject', 's3:PutObject', 's3:DeleteObject', 's3:ListBucket'],
                            resources: [dataBucket.bucketArn, `${dataBucket.bucketArn}/*`],
                        }),
                    ],
                }),
            },
        });
        // Create Lambda Layer for shared utilities (using consolidated structure)
        const neptuneUtilsLayer = new lambda.LayerVersion(this, 'SRE-POC-NeptuneUtilsLayer', {
            code: lambda.Code.fromAsset('./lambdas/dist/shared'),
            compatibleRuntimes: [lambda.Runtime.NODEJS_20_X],
            description: 'Shared SPARQL-only utilities for SRE POC Neptune operations',
        });
        // Create security group for Lambda functions
        const lambdaSecurityGroup = new ec2.SecurityGroup(this, 'SRE-POC-LambdaSecurityGroup', {
            vpc: this.vpc,
            description: 'Security group for SRE POC Lambda functions',
            allowAllOutbound: true,
        });
        // Allow Lambda to connect to Neptune
        neptuneSecurityGroup.addIngressRule(lambdaSecurityGroup, ec2.Port.tcp(8182), 'Allow Lambda connections to Neptune');
        // Create ingestion Lambda function with consolidated SPARQL-only structure  
        this.ingestionLambda = new lambda.Function(this, 'SRE-POC-IngestionLambda', {
            runtime: lambda.Runtime.NODEJS_20_X,
            handler: 'src/ingestion.handler',
            code: lambda.Code.fromAsset('./lambdas/dist'),
            layers: [neptuneUtilsLayer],
            role: lambdaRole,
            timeout: cdk.Duration.seconds(30),
            memorySize: 256,
            vpc: this.vpc,
            securityGroups: [lambdaSecurityGroup],
            vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
            environment: {
                NEPTUNE_ENDPOINT: this.neptuneCluster.attrEndpoint,
                NEPTUNE_PORT: '8182',
                S3_BUCKET: dataBucket.bucketName,
                AWS_NODEJS_CONNECTION_REUSE_ENABLED: '1',
                USE_IAM: 'true', // Enable IAM authentication for Neptune
            },
            logGroup: new logs.LogGroup(this, 'SRE-POC-IngestionLambdaLogGroup', {
                retention: logs.RetentionDays.ONE_WEEK,
                removalPolicy: cdk.RemovalPolicy.DESTROY,
            }),
        });
        // Create query Lambda function with consolidated SPARQL-only structure
        this.queryLambda = new lambda.Function(this, 'SRE-POC-QueryLambda', {
            runtime: lambda.Runtime.NODEJS_20_X,
            handler: 'src/query.handler',
            code: lambda.Code.fromAsset('./lambdas/dist'),
            layers: [neptuneUtilsLayer],
            role: lambdaRole,
            timeout: cdk.Duration.seconds(60),
            memorySize: 512,
            vpc: this.vpc,
            securityGroups: [lambdaSecurityGroup],
            vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
            environment: {
                NEPTUNE_ENDPOINT: this.neptuneCluster.attrEndpoint,
                NEPTUNE_PORT: '8182',
                S3_BUCKET: dataBucket.bucketName,
                AWS_NODEJS_CONNECTION_REUSE_ENABLED: '1',
                USE_IAM: 'true', // Enable IAM authentication for Neptune
            },
            logGroup: new logs.LogGroup(this, 'SRE-POC-QueryLambdaLogGroup', {
                retention: logs.RetentionDays.ONE_WEEK,
                removalPolicy: cdk.RemovalPolicy.DESTROY,
            }),
        });
        // Create cleanup Lambda function for database maintenance
        this.cleanupLambda = new lambda.Function(this, 'SRE-POC-CleanupLambda', {
            runtime: lambda.Runtime.NODEJS_20_X,
            handler: 'src/cleanup.handler',
            code: lambda.Code.fromAsset('./lambdas/dist'),
            layers: [neptuneUtilsLayer],
            role: lambdaRole,
            timeout: cdk.Duration.minutes(5),
            memorySize: 512,
            vpc: this.vpc,
            securityGroups: [lambdaSecurityGroup],
            vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
            environment: {
                NEPTUNE_ENDPOINT: this.neptuneCluster.attrEndpoint,
                NEPTUNE_PORT: '8182',
                S3_BUCKET: dataBucket.bucketName,
                AWS_NODEJS_CONNECTION_REUSE_ENABLED: '1',
                USE_IAM: 'true',
            },
            logGroup: new logs.LogGroup(this, 'SRE-POC-CleanupLambdaLogGroup', {
                retention: logs.RetentionDays.ONE_WEEK,
                removalPolicy: cdk.RemovalPolicy.DESTROY,
            }),
        });
        // Output important values
        new cdk.CfnOutput(this, 'SRE-POC-NeptuneClusterEndpoint', {
            value: this.neptuneCluster.attrEndpoint,
            description: 'SRE POC Neptune cluster endpoint',
        });
        new cdk.CfnOutput(this, 'SRE-POC-NeptuneClusterReadEndpoint', {
            value: this.neptuneCluster.attrReadEndpoint,
            description: 'SRE POC Neptune cluster read endpoint',
        });
        new cdk.CfnOutput(this, 'SRE-POC-DataBucketName', {
            value: dataBucket.bucketName,
            description: 'S3 bucket for SRE POC environment data',
        });
        new cdk.CfnOutput(this, 'SRE-POC-IngestionLambdaArn', {
            value: this.ingestionLambda.functionArn,
            description: 'ARN of the SRE POC data ingestion Lambda function',
        });
        // Create API Gateway with CORS configuration
        const api = new apigateway.RestApi(this, 'SRE-POC-NeptuneEnvironmentApi', {
            restApiName: 'SRE POC Neptune Environment Management API',
            description: 'API for managing SRE POC Neptune environment data',
            defaultCorsPreflightOptions: {
                allowOrigins: ['http://localhost:3000'],
                allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
                allowHeaders: ['Content-Type', 'Authorization', 'Accept', 'Origin', 'X-Requested-With'],
                allowCredentials: false,
            },
            deployOptions: {
                stageName: 'prod',
                loggingLevel: apigateway.MethodLoggingLevel.INFO,
                dataTraceEnabled: true,
                metricsEnabled: true,
            },
        });
        // Create Lambda integrations
        const queryIntegration = new apigateway.LambdaIntegration(this.queryLambda, {
            requestTemplates: { 'application/json': '{ "statusCode": "200" }' },
            proxy: true,
        });
        const ingestionIntegration = new apigateway.LambdaIntegration(this.ingestionLambda, {
            requestTemplates: { 'application/json': '{ "statusCode": "200" }' },
            proxy: true,
        });
        const cleanupIntegration = new apigateway.LambdaIntegration(this.cleanupLambda, {
            requestTemplates: { 'application/json': '{ "statusCode": "200" }' },
            proxy: true,
        });
        // Create API resources and methods
        const queryResource = api.root.addResource('query');
        queryResource.addMethod('POST', queryIntegration, {
            authorizationType: apigateway.AuthorizationType.NONE,
        });
        queryResource.addMethod('GET', queryIntegration, {
            authorizationType: apigateway.AuthorizationType.NONE,
        });
        const ingestionResource = api.root.addResource('ingest');
        ingestionResource.addMethod('POST', ingestionIntegration, {
            authorizationType: apigateway.AuthorizationType.NONE,
        });
        const cleanupResource = api.root.addResource('cleanup');
        cleanupResource.addMethod('POST', cleanupIntegration, {
            authorizationType: apigateway.AuthorizationType.NONE,
        });
        cleanupResource.addMethod('DELETE', cleanupIntegration, {
            authorizationType: apigateway.AuthorizationType.NONE,
        });
        // Keep Function URLs as backup (comment out if not needed)
        const ingestionFunctionUrl = this.ingestionLambda.addFunctionUrl({
            authType: lambda.FunctionUrlAuthType.NONE,
        });
        const queryFunctionUrl = this.queryLambda.addFunctionUrl({
            authType: lambda.FunctionUrlAuthType.NONE,
        });
        const cleanupFunctionUrl = this.cleanupLambda.addFunctionUrl({
            authType: lambda.FunctionUrlAuthType.NONE,
        });
        // Output API Gateway URLs
        new cdk.CfnOutput(this, 'SRE-POC-ApiGatewayUrl', {
            value: api.url,
            description: 'SRE POC API Gateway base URL',
        });
        new cdk.CfnOutput(this, 'SRE-POC-QueryApiUrl', {
            value: `${api.url}query`,
            description: 'SRE POC Query API endpoint URL',
        });
        new cdk.CfnOutput(this, 'SRE-POC-IngestionApiUrl', {
            value: `${api.url}ingest`,
            description: 'SRE POC Ingestion API endpoint URL',
        });
        new cdk.CfnOutput(this, 'SRE-POC-CleanupApiUrl', {
            value: `${api.url}cleanup`,
            description: 'SRE POC Cleanup API endpoint URL',
        });
        new cdk.CfnOutput(this, 'SRE-POC-QueryLambdaArn', {
            value: this.queryLambda.functionArn,
            description: 'ARN of the SRE POC query Lambda function',
        });
        new cdk.CfnOutput(this, 'SRE-POC-IngestionFunctionUrl', {
            value: ingestionFunctionUrl.url,
            description: 'URL for the SRE POC ingestion Lambda function (backup)',
        });
        new cdk.CfnOutput(this, 'SRE-POC-QueryFunctionUrl', {
            value: queryFunctionUrl.url,
            description: 'URL for the SRE POC query Lambda function (backup)',
        });
        new cdk.CfnOutput(this, 'SRE-POC-CleanupLambdaArn', {
            value: this.cleanupLambda.functionArn,
            description: 'ARN of the SRE POC cleanup Lambda function',
        });
        new cdk.CfnOutput(this, 'SRE-POC-CleanupFunctionUrl', {
            value: cleanupFunctionUrl.url,
            description: 'URL for the SRE POC cleanup Lambda function (backup)',
        });
        new cdk.CfnOutput(this, 'SRE-POC-VpcId', {
            value: this.vpc.vpcId,
            description: 'VPC ID for the SRE POC Neptune environment',
        });
    }
}
exports.NeptuneEnvironmentStack = NeptuneEnvironmentStack;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVwdHVuZS1lbnZpcm9ubWVudC1zdGFjay5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIm5lcHR1bmUtZW52aXJvbm1lbnQtc3RhY2sudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsbUNBQW1DO0FBQ25DLDJDQUEyQztBQUMzQyxtREFBbUQ7QUFDbkQsaURBQWlEO0FBQ2pELDJDQUEyQztBQUMzQyx5Q0FBeUM7QUFDekMsNkNBQTZDO0FBQzdDLHlEQUF5RDtBQUd6RCxNQUFhLHVCQUF3QixTQUFRLEdBQUcsQ0FBQyxLQUFLO0lBT3BELFlBQVksS0FBZ0IsRUFBRSxFQUFVLEVBQUUsS0FBc0I7UUFDOUQsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFeEIsZ0RBQWdEO1FBQ2hELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUNqRCxNQUFNLEVBQUUsQ0FBQztZQUNULFdBQVcsRUFBRSxDQUFDO1lBQ2QsbUJBQW1CLEVBQUU7Z0JBQ25CO29CQUNFLFFBQVEsRUFBRSxFQUFFO29CQUNaLElBQUksRUFBRSxnQkFBZ0I7b0JBQ3RCLFVBQVUsRUFBRSxHQUFHLENBQUMsVUFBVSxDQUFDLG1CQUFtQjtpQkFDL0M7Z0JBQ0Q7b0JBQ0UsUUFBUSxFQUFFLEVBQUU7b0JBQ1osSUFBSSxFQUFFLGVBQWU7b0JBQ3JCLFVBQVUsRUFBRSxHQUFHLENBQUMsVUFBVSxDQUFDLE1BQU07aUJBQ2xDO2FBQ0Y7U0FDRixDQUFDLENBQUM7UUFFSCxvQ0FBb0M7UUFDcEMsTUFBTSxvQkFBb0IsR0FBRyxJQUFJLEdBQUcsQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLDhCQUE4QixFQUFFO1lBQ3ZGLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRztZQUNiLFdBQVcsRUFBRSw0Q0FBNEM7WUFDekQsZ0JBQWdCLEVBQUUsSUFBSTtTQUN2QixDQUFDLENBQUM7UUFFSCx1RUFBdUU7UUFDdkUsb0JBQW9CLENBQUMsY0FBYyxDQUNqQyxvQkFBb0IsRUFDcEIsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQ2xCLGlEQUFpRCxDQUNsRCxDQUFDO1FBRUYsOEJBQThCO1FBQzlCLE1BQU0sV0FBVyxHQUFHLElBQUksT0FBTyxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRSw0QkFBNEIsRUFBRTtZQUNuRix3QkFBd0IsRUFBRSwwQ0FBMEM7WUFDcEUsU0FBUyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNuRSxpQkFBaUIsRUFBRSw4QkFBOEI7U0FDbEQsQ0FBQyxDQUFDO1FBRUgsMENBQTBDO1FBQzFDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSx3QkFBd0IsRUFBRTtZQUM3RSxtQkFBbUIsRUFBRSxxQ0FBcUM7WUFDMUQsaUJBQWlCLEVBQUUsV0FBVyxDQUFDLEdBQUc7WUFDbEMsbUJBQW1CLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLENBQUM7WUFDM0QscUJBQXFCLEVBQUUsQ0FBQztZQUN4QixxQkFBcUIsRUFBRSxhQUFhO1lBQ3BDLDBCQUEwQixFQUFFLHFCQUFxQjtZQUNqRCxnQkFBZ0IsRUFBRSxLQUFLO1lBQ3ZCLGtCQUFrQixFQUFFLEtBQUs7WUFDekIsY0FBYyxFQUFFLElBQUksRUFBRSxxQ0FBcUM7U0FDNUQsQ0FBQyxDQUFDO1FBRUgsbURBQW1EO1FBQ25ELE1BQU0sZUFBZSxHQUFHLElBQUksT0FBTyxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUseUJBQXlCLEVBQUU7WUFDakYsZUFBZSxFQUFFLGNBQWM7WUFDL0IsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHO1lBQzVDLG9CQUFvQixFQUFFLDRCQUE0QjtTQUNuRCxDQUFDLENBQUM7UUFFSCxlQUFlLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUVuRCwrREFBK0Q7UUFDL0QsTUFBTSxVQUFVLEdBQUcsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSwrQkFBK0IsRUFBRTtZQUN0RSxVQUFVLEVBQUUsRUFBRSxDQUFDLGdCQUFnQixDQUFDLFVBQVU7WUFDMUMsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLGlCQUFpQixDQUFDLFNBQVM7WUFDakQsU0FBUyxFQUFFLEtBQUs7WUFDaEIsY0FBYyxFQUFFO2dCQUNkO29CQUNFLEVBQUUsRUFBRSxrQkFBa0I7b0JBQ3RCLE9BQU8sRUFBRSxJQUFJO29CQUNiLFdBQVcsRUFBRTt3QkFDWDs0QkFDRSxZQUFZLEVBQUUsRUFBRSxDQUFDLFlBQVksQ0FBQyxpQkFBaUI7NEJBQy9DLGVBQWUsRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSwyQkFBMkI7eUJBQ3BFO3dCQUNEOzRCQUNFLFlBQVksRUFBRSxFQUFFLENBQUMsWUFBWSxDQUFDLE9BQU87NEJBQ3JDLGVBQWUsRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxnQ0FBZ0M7eUJBQ3pFO3FCQUNGO29CQUNELFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxzQkFBc0I7aUJBQzNEO2FBQ0Y7WUFDRCxhQUFhLEVBQUUsR0FBRyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsa0JBQWtCO1NBQzdELENBQUMsQ0FBQztRQUVILHVDQUF1QztRQUN2QyxNQUFNLFVBQVUsR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLDJCQUEyQixFQUFFO1lBQ2pFLFNBQVMsRUFBRSxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxzQkFBc0IsQ0FBQztZQUMzRCxlQUFlLEVBQUU7Z0JBQ2YsR0FBRyxDQUFDLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQyw4Q0FBOEMsQ0FBQzthQUMzRjtZQUNELGNBQWMsRUFBRTtnQkFDZCxpQkFBaUIsRUFBRSxJQUFJLEdBQUcsQ0FBQyxjQUFjLENBQUM7b0JBQ3hDLFVBQVUsRUFBRTt3QkFDVixJQUFJLEdBQUcsQ0FBQyxlQUFlLENBQUM7NEJBQ3RCLE1BQU0sRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUs7NEJBQ3hCLE9BQU8sRUFBRTtnQ0FDUCxjQUFjOzZCQUNmOzRCQUNELFNBQVMsRUFBRSxDQUFDLEdBQUcsQ0FBQzt5QkFDakIsQ0FBQzt3QkFDRixJQUFJLEdBQUcsQ0FBQyxlQUFlLENBQUM7NEJBQ3RCLE1BQU0sRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUs7NEJBQ3hCLE9BQU8sRUFBRTtnQ0FDUCxXQUFXOzZCQUNaOzRCQUNELFNBQVMsRUFBRSxDQUFDLEdBQUcsQ0FBQzt5QkFDakIsQ0FBQzt3QkFDRixJQUFJLEdBQUcsQ0FBQyxlQUFlLENBQUM7NEJBQ3RCLE1BQU0sRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUs7NEJBQ3hCLE9BQU8sRUFBRSxDQUFDLGNBQWMsRUFBRSxjQUFjLEVBQUUsaUJBQWlCLEVBQUUsZUFBZSxDQUFDOzRCQUM3RSxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEdBQUcsVUFBVSxDQUFDLFNBQVMsSUFBSSxDQUFDO3lCQUMvRCxDQUFDO3FCQUNIO2lCQUNGLENBQUM7YUFDSDtTQUNGLENBQUMsQ0FBQztRQUVILDBFQUEwRTtRQUMxRSxNQUFNLGlCQUFpQixHQUFHLElBQUksTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsMkJBQTJCLEVBQUU7WUFDbkYsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixDQUFDO1lBQ3BELGtCQUFrQixFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7WUFDaEQsV0FBVyxFQUFFLDZEQUE2RDtTQUMzRSxDQUFDLENBQUM7UUFFSCw2Q0FBNkM7UUFDN0MsTUFBTSxtQkFBbUIsR0FBRyxJQUFJLEdBQUcsQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLDZCQUE2QixFQUFFO1lBQ3JGLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRztZQUNiLFdBQVcsRUFBRSw2Q0FBNkM7WUFDMUQsZ0JBQWdCLEVBQUUsSUFBSTtTQUN2QixDQUFDLENBQUM7UUFFSCxxQ0FBcUM7UUFDckMsb0JBQW9CLENBQUMsY0FBYyxDQUNqQyxtQkFBbUIsRUFDbkIsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQ2xCLHFDQUFxQyxDQUN0QyxDQUFDO1FBRUYsNkVBQTZFO1FBQzdFLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSx5QkFBeUIsRUFBRTtZQUMxRSxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1lBQ25DLE9BQU8sRUFBRSx1QkFBdUI7WUFDaEMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDO1lBQzdDLE1BQU0sRUFBRSxDQUFDLGlCQUFpQixDQUFDO1lBQzNCLElBQUksRUFBRSxVQUFVO1lBQ2hCLE9BQU8sRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDakMsVUFBVSxFQUFFLEdBQUc7WUFDZixHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUc7WUFDYixjQUFjLEVBQUUsQ0FBQyxtQkFBbUIsQ0FBQztZQUNyQyxVQUFVLEVBQUUsRUFBRSxVQUFVLEVBQUUsR0FBRyxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRTtZQUM5RCxXQUFXLEVBQUU7Z0JBQ1gsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZO2dCQUNsRCxZQUFZLEVBQUUsTUFBTTtnQkFDcEIsU0FBUyxFQUFFLFVBQVUsQ0FBQyxVQUFVO2dCQUNoQyxtQ0FBbUMsRUFBRSxHQUFHO2dCQUN4QyxPQUFPLEVBQUUsTUFBTSxFQUFFLHdDQUF3QzthQUMxRDtZQUNELFFBQVEsRUFBRSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLGlDQUFpQyxFQUFFO2dCQUNuRSxTQUFTLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRO2dCQUN0QyxhQUFhLEVBQUUsR0FBRyxDQUFDLGFBQWEsQ0FBQyxPQUFPO2FBQ3pDLENBQUM7U0FDSCxDQUFDLENBQUM7UUFFSCx1RUFBdUU7UUFDdkUsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQ2xFLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVc7WUFDbkMsT0FBTyxFQUFFLG1CQUFtQjtZQUM1QixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUM7WUFDN0MsTUFBTSxFQUFFLENBQUMsaUJBQWlCLENBQUM7WUFDM0IsSUFBSSxFQUFFLFVBQVU7WUFDaEIsT0FBTyxFQUFFLEdBQUcsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUNqQyxVQUFVLEVBQUUsR0FBRztZQUNmLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRztZQUNiLGNBQWMsRUFBRSxDQUFDLG1CQUFtQixDQUFDO1lBQ3JDLFVBQVUsRUFBRSxFQUFFLFVBQVUsRUFBRSxHQUFHLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFO1lBQzlELFdBQVcsRUFBRTtnQkFDWCxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVk7Z0JBQ2xELFlBQVksRUFBRSxNQUFNO2dCQUNwQixTQUFTLEVBQUUsVUFBVSxDQUFDLFVBQVU7Z0JBQ2hDLG1DQUFtQyxFQUFFLEdBQUc7Z0JBQ3hDLE9BQU8sRUFBRSxNQUFNLEVBQUUsd0NBQXdDO2FBQzFEO1lBQ0QsUUFBUSxFQUFFLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsNkJBQTZCLEVBQUU7Z0JBQy9ELFNBQVMsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVE7Z0JBQ3RDLGFBQWEsRUFBRSxHQUFHLENBQUMsYUFBYSxDQUFDLE9BQU87YUFDekMsQ0FBQztTQUNILENBQUMsQ0FBQztRQUVILDBEQUEwRDtRQUMxRCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsdUJBQXVCLEVBQUU7WUFDdEUsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsV0FBVztZQUNuQyxPQUFPLEVBQUUscUJBQXFCO1lBQzlCLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQztZQUM3QyxNQUFNLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQztZQUMzQixJQUFJLEVBQUUsVUFBVTtZQUNoQixPQUFPLEVBQUUsR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQ2hDLFVBQVUsRUFBRSxHQUFHO1lBQ2YsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHO1lBQ2IsY0FBYyxFQUFFLENBQUMsbUJBQW1CLENBQUM7WUFDckMsVUFBVSxFQUFFLEVBQUUsVUFBVSxFQUFFLEdBQUcsQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUU7WUFDOUQsV0FBVyxFQUFFO2dCQUNYLGdCQUFnQixFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWTtnQkFDbEQsWUFBWSxFQUFFLE1BQU07Z0JBQ3BCLFNBQVMsRUFBRSxVQUFVLENBQUMsVUFBVTtnQkFDaEMsbUNBQW1DLEVBQUUsR0FBRztnQkFDeEMsT0FBTyxFQUFFLE1BQU07YUFDaEI7WUFDRCxRQUFRLEVBQUUsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSwrQkFBK0IsRUFBRTtnQkFDakUsU0FBUyxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUTtnQkFDdEMsYUFBYSxFQUFFLEdBQUcsQ0FBQyxhQUFhLENBQUMsT0FBTzthQUN6QyxDQUFDO1NBQ0gsQ0FBQyxDQUFDO1FBRUgsMEJBQTBCO1FBQzFCLElBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsZ0NBQWdDLEVBQUU7WUFDeEQsS0FBSyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWTtZQUN2QyxXQUFXLEVBQUUsa0NBQWtDO1NBQ2hELENBQUMsQ0FBQztRQUVILElBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsb0NBQW9DLEVBQUU7WUFDNUQsS0FBSyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCO1lBQzNDLFdBQVcsRUFBRSx1Q0FBdUM7U0FDckQsQ0FBQyxDQUFDO1FBRUgsSUFBSSxHQUFHLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSx3QkFBd0IsRUFBRTtZQUNoRCxLQUFLLEVBQUUsVUFBVSxDQUFDLFVBQVU7WUFDNUIsV0FBVyxFQUFFLHdDQUF3QztTQUN0RCxDQUFDLENBQUM7UUFFSCxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLDRCQUE0QixFQUFFO1lBQ3BELEtBQUssRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVc7WUFDdkMsV0FBVyxFQUFFLG1EQUFtRDtTQUNqRSxDQUFDLENBQUM7UUFFSCw2Q0FBNkM7UUFDN0MsTUFBTSxHQUFHLEdBQUcsSUFBSSxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSwrQkFBK0IsRUFBRTtZQUN4RSxXQUFXLEVBQUUsNENBQTRDO1lBQ3pELFdBQVcsRUFBRSxtREFBbUQ7WUFDaEUsMkJBQTJCLEVBQUU7Z0JBQzNCLFlBQVksRUFBRSxDQUFDLHVCQUF1QixDQUFDO2dCQUN2QyxZQUFZLEVBQUUsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDO2dCQUN6RCxZQUFZLEVBQUUsQ0FBQyxjQUFjLEVBQUUsZUFBZSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsa0JBQWtCLENBQUM7Z0JBQ3ZGLGdCQUFnQixFQUFFLEtBQUs7YUFDeEI7WUFDRCxhQUFhLEVBQUU7Z0JBQ2IsU0FBUyxFQUFFLE1BQU07Z0JBQ2pCLFlBQVksRUFBRSxVQUFVLENBQUMsa0JBQWtCLENBQUMsSUFBSTtnQkFDaEQsZ0JBQWdCLEVBQUUsSUFBSTtnQkFDdEIsY0FBYyxFQUFFLElBQUk7YUFDckI7U0FDRixDQUFDLENBQUM7UUFFSCw2QkFBNkI7UUFDN0IsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQzFFLGdCQUFnQixFQUFFLEVBQUUsa0JBQWtCLEVBQUUseUJBQXlCLEVBQUU7WUFDbkUsS0FBSyxFQUFFLElBQUk7U0FDWixDQUFDLENBQUM7UUFFSCxNQUFNLG9CQUFvQixHQUFHLElBQUksVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDbEYsZ0JBQWdCLEVBQUUsRUFBRSxrQkFBa0IsRUFBRSx5QkFBeUIsRUFBRTtZQUNuRSxLQUFLLEVBQUUsSUFBSTtTQUNaLENBQUMsQ0FBQztRQUVILE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTtZQUM5RSxnQkFBZ0IsRUFBRSxFQUFFLGtCQUFrQixFQUFFLHlCQUF5QixFQUFFO1lBQ25FLEtBQUssRUFBRSxJQUFJO1NBQ1osQ0FBQyxDQUFDO1FBRUgsbUNBQW1DO1FBQ25DLE1BQU0sYUFBYSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3BELGFBQWEsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLGdCQUFnQixFQUFFO1lBQ2hELGlCQUFpQixFQUFFLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJO1NBQ3JELENBQUMsQ0FBQztRQUNILGFBQWEsQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLGdCQUFnQixFQUFFO1lBQy9DLGlCQUFpQixFQUFFLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJO1NBQ3JELENBQUMsQ0FBQztRQUVILE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDekQsaUJBQWlCLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxvQkFBb0IsRUFBRTtZQUN4RCxpQkFBaUIsRUFBRSxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSTtTQUNyRCxDQUFDLENBQUM7UUFFSCxNQUFNLGVBQWUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN4RCxlQUFlLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxrQkFBa0IsRUFBRTtZQUNwRCxpQkFBaUIsRUFBRSxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSTtTQUNyRCxDQUFDLENBQUM7UUFDSCxlQUFlLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxrQkFBa0IsRUFBRTtZQUN0RCxpQkFBaUIsRUFBRSxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSTtTQUNyRCxDQUFDLENBQUM7UUFFSCwyREFBMkQ7UUFDM0QsTUFBTSxvQkFBb0IsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQztZQUMvRCxRQUFRLEVBQUUsTUFBTSxDQUFDLG1CQUFtQixDQUFDLElBQUk7U0FDMUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQztZQUN2RCxRQUFRLEVBQUUsTUFBTSxDQUFDLG1CQUFtQixDQUFDLElBQUk7U0FDMUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQztZQUMzRCxRQUFRLEVBQUUsTUFBTSxDQUFDLG1CQUFtQixDQUFDLElBQUk7U0FDMUMsQ0FBQyxDQUFDO1FBRUgsMEJBQTBCO1FBQzFCLElBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsdUJBQXVCLEVBQUU7WUFDL0MsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1lBQ2QsV0FBVyxFQUFFLDhCQUE4QjtTQUM1QyxDQUFDLENBQUM7UUFFSCxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQzdDLEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLE9BQU87WUFDeEIsV0FBVyxFQUFFLGdDQUFnQztTQUM5QyxDQUFDLENBQUM7UUFFSCxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLHlCQUF5QixFQUFFO1lBQ2pELEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLFFBQVE7WUFDekIsV0FBVyxFQUFFLG9DQUFvQztTQUNsRCxDQUFDLENBQUM7UUFFSCxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLHVCQUF1QixFQUFFO1lBQy9DLEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLFNBQVM7WUFDMUIsV0FBVyxFQUFFLGtDQUFrQztTQUNoRCxDQUFDLENBQUM7UUFFSCxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLHdCQUF3QixFQUFFO1lBQ2hELEtBQUssRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVc7WUFDbkMsV0FBVyxFQUFFLDBDQUEwQztTQUN4RCxDQUFDLENBQUM7UUFFSCxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLDhCQUE4QixFQUFFO1lBQ3RELEtBQUssRUFBRSxvQkFBb0IsQ0FBQyxHQUFHO1lBQy9CLFdBQVcsRUFBRSx3REFBd0Q7U0FDdEUsQ0FBQyxDQUFDO1FBRUgsSUFBSSxHQUFHLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSwwQkFBMEIsRUFBRTtZQUNsRCxLQUFLLEVBQUUsZ0JBQWdCLENBQUMsR0FBRztZQUMzQixXQUFXLEVBQUUsb0RBQW9EO1NBQ2xFLENBQUMsQ0FBQztRQUVILElBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsMEJBQTBCLEVBQUU7WUFDbEQsS0FBSyxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVztZQUNyQyxXQUFXLEVBQUUsNENBQTRDO1NBQzFELENBQUMsQ0FBQztRQUVILElBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsNEJBQTRCLEVBQUU7WUFDcEQsS0FBSyxFQUFFLGtCQUFrQixDQUFDLEdBQUc7WUFDN0IsV0FBVyxFQUFFLHNEQUFzRDtTQUNwRSxDQUFDLENBQUM7UUFFSCxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN2QyxLQUFLLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLO1lBQ3JCLFdBQVcsRUFBRSw0Q0FBNEM7U0FDMUQsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBOVdELDBEQThXQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGNkayBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgKiBhcyBlYzIgZnJvbSAnYXdzLWNkay1saWIvYXdzLWVjMic7XG5pbXBvcnQgKiBhcyBuZXB0dW5lIGZyb20gJ2F3cy1jZGstbGliL2F3cy1uZXB0dW5lJztcbmltcG9ydCAqIGFzIGxhbWJkYSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtbGFtYmRhJztcbmltcG9ydCAqIGFzIGlhbSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCAqIGFzIHMzIGZyb20gJ2F3cy1jZGstbGliL2F3cy1zMyc7XG5pbXBvcnQgKiBhcyBsb2dzIGZyb20gJ2F3cy1jZGstbGliL2F3cy1sb2dzJztcbmltcG9ydCAqIGFzIGFwaWdhdGV3YXkgZnJvbSAnYXdzLWNkay1saWIvYXdzLWFwaWdhdGV3YXknO1xuaW1wb3J0IHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5cbmV4cG9ydCBjbGFzcyBOZXB0dW5lRW52aXJvbm1lbnRTdGFjayBleHRlbmRzIGNkay5TdGFjayB7XG4gIHB1YmxpYyByZWFkb25seSBuZXB0dW5lQ2x1c3RlcjogbmVwdHVuZS5DZm5EQkNsdXN0ZXI7XG4gIHB1YmxpYyByZWFkb25seSB2cGM6IGVjMi5WcGM7XG4gIHB1YmxpYyByZWFkb25seSBpbmdlc3Rpb25MYW1iZGE6IGxhbWJkYS5GdW5jdGlvbjtcbiAgcHVibGljIHJlYWRvbmx5IHF1ZXJ5TGFtYmRhOiBsYW1iZGEuRnVuY3Rpb247XG4gIHB1YmxpYyByZWFkb25seSBjbGVhbnVwTGFtYmRhOiBsYW1iZGEuRnVuY3Rpb247XG5cbiAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM/OiBjZGsuU3RhY2tQcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwgcHJvcHMpO1xuXG4gICAgLy8gQ3JlYXRlIGNvc3Qtb3B0aW1pemVkIFZQQyBmb3IgTmVwdHVuZSBjbHVzdGVyXG4gICAgdGhpcy52cGMgPSBuZXcgZWMyLlZwYyh0aGlzLCAnU1JFLVBPQy1OZXB0dW5lVnBjJywge1xuICAgICAgbWF4QXpzOiAyLCAvLyBLZWVwIDIgQVpzIGZvciBOZXB0dW5lIHJlcXVpcmVtZW50IChtaW5pbXVtIGZvciBzdWJuZXQgZ3JvdXApXG4gICAgICBuYXRHYXRld2F5czogMSwgLy8gVXNlIG9ubHkgMSBOQVQgR2F0ZXdheSB0byByZWR1Y2UgY29zdHNcbiAgICAgIHN1Ym5ldENvbmZpZ3VyYXRpb246IFtcbiAgICAgICAge1xuICAgICAgICAgIGNpZHJNYXNrOiAyNiwgLy8gU21hbGxlciBzdWJuZXRzIHRvIHNhdmUgSVAgc3BhY2VcbiAgICAgICAgICBuYW1lOiAncHJpdmF0ZS1zdWJuZXQnLFxuICAgICAgICAgIHN1Ym5ldFR5cGU6IGVjMi5TdWJuZXRUeXBlLlBSSVZBVEVfV0lUSF9FR1JFU1MsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBjaWRyTWFzazogMjgsIC8vIFZlcnkgc21hbGwgcHVibGljIHN1Ym5ldCAob25seSBmb3IgTkFUKVxuICAgICAgICAgIG5hbWU6ICdwdWJsaWMtc3VibmV0JyxcbiAgICAgICAgICBzdWJuZXRUeXBlOiBlYzIuU3VibmV0VHlwZS5QVUJMSUMsXG4gICAgICAgIH0sXG4gICAgICBdLFxuICAgIH0pO1xuXG4gICAgLy8gQ3JlYXRlIHNlY3VyaXR5IGdyb3VwIGZvciBOZXB0dW5lXG4gICAgY29uc3QgbmVwdHVuZVNlY3VyaXR5R3JvdXAgPSBuZXcgZWMyLlNlY3VyaXR5R3JvdXAodGhpcywgJ1NSRS1QT0MtTmVwdHVuZVNlY3VyaXR5R3JvdXAnLCB7XG4gICAgICB2cGM6IHRoaXMudnBjLFxuICAgICAgZGVzY3JpcHRpb246ICdTZWN1cml0eSBncm91cCBmb3IgU1JFIFBPQyBOZXB0dW5lIGNsdXN0ZXInLFxuICAgICAgYWxsb3dBbGxPdXRib3VuZDogdHJ1ZSxcbiAgICB9KTtcblxuICAgIC8vIEFsbG93IGluYm91bmQgY29ubmVjdGlvbnMgb24gTmVwdHVuZSBwb3J0IGZyb20gTGFtYmRhIHNlY3VyaXR5IGdyb3VwXG4gICAgbmVwdHVuZVNlY3VyaXR5R3JvdXAuYWRkSW5ncmVzc1J1bGUoXG4gICAgICBuZXB0dW5lU2VjdXJpdHlHcm91cCxcbiAgICAgIGVjMi5Qb3J0LnRjcCg4MTgyKSxcbiAgICAgICdBbGxvdyBOZXB0dW5lIGNvbm5lY3Rpb25zIGZyb20gTGFtYmRhIGZ1bmN0aW9ucydcbiAgICApO1xuXG4gICAgLy8gQ3JlYXRlIE5lcHR1bmUgc3VibmV0IGdyb3VwXG4gICAgY29uc3Qgc3VibmV0R3JvdXAgPSBuZXcgbmVwdHVuZS5DZm5EQlN1Ym5ldEdyb3VwKHRoaXMsICdTUkUtUE9DLU5lcHR1bmVTdWJuZXRHcm91cCcsIHtcbiAgICAgIGRiU3VibmV0R3JvdXBEZXNjcmlwdGlvbjogJ1N1Ym5ldCBncm91cCBmb3IgU1JFIFBPQyBOZXB0dW5lIGNsdXN0ZXInLFxuICAgICAgc3VibmV0SWRzOiB0aGlzLnZwYy5wcml2YXRlU3VibmV0cy5tYXAoKHN1Ym5ldCkgPT4gc3VibmV0LnN1Ym5ldElkKSxcbiAgICAgIGRiU3VibmV0R3JvdXBOYW1lOiAnc3JlLXBvYy1uZXB0dW5lLXN1Ym5ldC1ncm91cCcsXG4gICAgfSk7XG5cbiAgICAvLyBDcmVhdGUgTmVwdHVuZSBjbHVzdGVyIChjb3N0LW9wdGltaXplZClcbiAgICB0aGlzLm5lcHR1bmVDbHVzdGVyID0gbmV3IG5lcHR1bmUuQ2ZuREJDbHVzdGVyKHRoaXMsICdTUkUtUE9DLU5lcHR1bmVDbHVzdGVyJywge1xuICAgICAgZGJDbHVzdGVySWRlbnRpZmllcjogJ3NyZS1wb2MtbmVwdHVuZS1lbnZpcm9ubWVudC1jbHVzdGVyJyxcbiAgICAgIGRiU3VibmV0R3JvdXBOYW1lOiBzdWJuZXRHcm91cC5yZWYsXG4gICAgICB2cGNTZWN1cml0eUdyb3VwSWRzOiBbbmVwdHVuZVNlY3VyaXR5R3JvdXAuc2VjdXJpdHlHcm91cElkXSxcbiAgICAgIGJhY2t1cFJldGVudGlvblBlcmlvZDogMSwgLy8gTWluaW11bSBiYWNrdXAgcmV0ZW50aW9uICgxIGRheSlcbiAgICAgIHByZWZlcnJlZEJhY2t1cFdpbmRvdzogJzAzOjAwLTA0OjAwJyxcbiAgICAgIHByZWZlcnJlZE1haW50ZW5hbmNlV2luZG93OiAnc3VuOjA0OjAwLXN1bjowNTowMCcsXG4gICAgICBzdG9yYWdlRW5jcnlwdGVkOiBmYWxzZSwgLy8gRGlzYWJsZSBlbmNyeXB0aW9uIHRvIHJlZHVjZSBjb3N0XG4gICAgICBkZWxldGlvblByb3RlY3Rpb246IGZhbHNlLCAvLyBGb3IgZGV2ZWxvcG1lbnQgLSBzZXQgdG8gdHJ1ZSBmb3IgcHJvZHVjdGlvblxuICAgICAgaWFtQXV0aEVuYWJsZWQ6IHRydWUsIC8vIEVuYWJsZSBJQU0gZGF0YWJhc2UgYXV0aGVudGljYXRpb25cbiAgICB9KTtcblxuICAgIC8vIENyZWF0ZSBOZXB0dW5lIGluc3RhbmNlIChzbWFsbGVzdCBpbnN0YW5jZSB0eXBlKVxuICAgIGNvbnN0IG5lcHR1bmVJbnN0YW5jZSA9IG5ldyBuZXB0dW5lLkNmbkRCSW5zdGFuY2UodGhpcywgJ1NSRS1QT0MtTmVwdHVuZUluc3RhbmNlJywge1xuICAgICAgZGJJbnN0YW5jZUNsYXNzOiAnZGIudDMubWVkaXVtJywgLy8gU21hbGxlc3QgTmVwdHVuZSBpbnN0YW5jZSB0eXBlXG4gICAgICBkYkNsdXN0ZXJJZGVudGlmaWVyOiB0aGlzLm5lcHR1bmVDbHVzdGVyLnJlZixcbiAgICAgIGRiSW5zdGFuY2VJZGVudGlmaWVyOiAnc3JlLXBvYy1uZXB0dW5lLWluc3RhbmNlLTEnLFxuICAgIH0pO1xuXG4gICAgbmVwdHVuZUluc3RhbmNlLmFkZERlcGVuZGVuY3kodGhpcy5uZXB0dW5lQ2x1c3Rlcik7XG5cbiAgICAvLyBDcmVhdGUgY29zdC1vcHRpbWl6ZWQgUzMgYnVja2V0IGZvciBkYXRhIGV4cG9ydHMgYW5kIGJhY2t1cHNcbiAgICBjb25zdCBkYXRhQnVja2V0ID0gbmV3IHMzLkJ1Y2tldCh0aGlzLCAnU1JFLVBPQy1FbnZpcm9ubWVudERhdGFCdWNrZXQnLCB7XG4gICAgICBlbmNyeXB0aW9uOiBzMy5CdWNrZXRFbmNyeXB0aW9uLlMzX01BTkFHRUQsXG4gICAgICBibG9ja1B1YmxpY0FjY2VzczogczMuQmxvY2tQdWJsaWNBY2Nlc3MuQkxPQ0tfQUxMLFxuICAgICAgdmVyc2lvbmVkOiBmYWxzZSwgLy8gRGlzYWJsZSB2ZXJzaW9uaW5nIHRvIHNhdmUgc3RvcmFnZSBjb3N0c1xuICAgICAgbGlmZWN5Y2xlUnVsZXM6IFtcbiAgICAgICAge1xuICAgICAgICAgIGlkOiAndHJhbnNpdGlvbi10by1pYScsXG4gICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICB0cmFuc2l0aW9uczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzdG9yYWdlQ2xhc3M6IHMzLlN0b3JhZ2VDbGFzcy5JTkZSRVFVRU5UX0FDQ0VTUyxcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbkFmdGVyOiBjZGsuRHVyYXRpb24uZGF5cygzMCksIC8vIE1vdmUgdG8gSUEgYWZ0ZXIgMzAgZGF5c1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc3RvcmFnZUNsYXNzOiBzMy5TdG9yYWdlQ2xhc3MuR0xBQ0lFUixcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbkFmdGVyOiBjZGsuRHVyYXRpb24uZGF5cyg5MCksIC8vIE1vdmUgdG8gR2xhY2llciBhZnRlciA5MCBkYXlzXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgZXhwaXJhdGlvbjogY2RrLkR1cmF0aW9uLmRheXMoMzY1KSwgLy8gRGVsZXRlIGFmdGVyIDEgeWVhclxuICAgICAgICB9LFxuICAgICAgXSxcbiAgICAgIHJlbW92YWxQb2xpY3k6IGNkay5SZW1vdmFsUG9saWN5LkRFU1RST1ksIC8vIEZvciBkZXZlbG9wbWVudFxuICAgIH0pO1xuXG4gICAgLy8gQ3JlYXRlIElBTSByb2xlIGZvciBMYW1iZGEgZnVuY3Rpb25zXG4gICAgY29uc3QgbGFtYmRhUm9sZSA9IG5ldyBpYW0uUm9sZSh0aGlzLCAnU1JFLVBPQy1OZXB0dW5lTGFtYmRhUm9sZScsIHtcbiAgICAgIGFzc3VtZWRCeTogbmV3IGlhbS5TZXJ2aWNlUHJpbmNpcGFsKCdsYW1iZGEuYW1hem9uYXdzLmNvbScpLFxuICAgICAgbWFuYWdlZFBvbGljaWVzOiBbXG4gICAgICAgIGlhbS5NYW5hZ2VkUG9saWN5LmZyb21Bd3NNYW5hZ2VkUG9saWN5TmFtZSgnc2VydmljZS1yb2xlL0FXU0xhbWJkYVZQQ0FjY2Vzc0V4ZWN1dGlvblJvbGUnKSxcbiAgICAgIF0sXG4gICAgICBpbmxpbmVQb2xpY2llczoge1xuICAgICAgICBOZXB0dW5lRnVsbEFjY2VzczogbmV3IGlhbS5Qb2xpY3lEb2N1bWVudCh7XG4gICAgICAgICAgc3RhdGVtZW50czogW1xuICAgICAgICAgICAgbmV3IGlhbS5Qb2xpY3lTdGF0ZW1lbnQoe1xuICAgICAgICAgICAgICBlZmZlY3Q6IGlhbS5FZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgIGFjdGlvbnM6IFtcbiAgICAgICAgICAgICAgICAnbmVwdHVuZS1kYjoqJyxcbiAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgcmVzb3VyY2VzOiBbJyonXSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbmV3IGlhbS5Qb2xpY3lTdGF0ZW1lbnQoe1xuICAgICAgICAgICAgICBlZmZlY3Q6IGlhbS5FZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgIGFjdGlvbnM6IFtcbiAgICAgICAgICAgICAgICAnbmVwdHVuZToqJyxcbiAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgcmVzb3VyY2VzOiBbJyonXSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbmV3IGlhbS5Qb2xpY3lTdGF0ZW1lbnQoe1xuICAgICAgICAgICAgICBlZmZlY3Q6IGlhbS5FZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgIGFjdGlvbnM6IFsnczM6R2V0T2JqZWN0JywgJ3MzOlB1dE9iamVjdCcsICdzMzpEZWxldGVPYmplY3QnLCAnczM6TGlzdEJ1Y2tldCddLFxuICAgICAgICAgICAgICByZXNvdXJjZXM6IFtkYXRhQnVja2V0LmJ1Y2tldEFybiwgYCR7ZGF0YUJ1Y2tldC5idWNrZXRBcm59LypgXSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIF0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9KTtcblxuICAgIC8vIENyZWF0ZSBMYW1iZGEgTGF5ZXIgZm9yIHNoYXJlZCB1dGlsaXRpZXMgKHVzaW5nIGNvbnNvbGlkYXRlZCBzdHJ1Y3R1cmUpXG4gICAgY29uc3QgbmVwdHVuZVV0aWxzTGF5ZXIgPSBuZXcgbGFtYmRhLkxheWVyVmVyc2lvbih0aGlzLCAnU1JFLVBPQy1OZXB0dW5lVXRpbHNMYXllcicsIHtcbiAgICAgIGNvZGU6IGxhbWJkYS5Db2RlLmZyb21Bc3NldCgnLi9sYW1iZGFzL2Rpc3Qvc2hhcmVkJyksXG4gICAgICBjb21wYXRpYmxlUnVudGltZXM6IFtsYW1iZGEuUnVudGltZS5OT0RFSlNfMjBfWF0sXG4gICAgICBkZXNjcmlwdGlvbjogJ1NoYXJlZCBTUEFSUUwtb25seSB1dGlsaXRpZXMgZm9yIFNSRSBQT0MgTmVwdHVuZSBvcGVyYXRpb25zJyxcbiAgICB9KTtcblxuICAgIC8vIENyZWF0ZSBzZWN1cml0eSBncm91cCBmb3IgTGFtYmRhIGZ1bmN0aW9uc1xuICAgIGNvbnN0IGxhbWJkYVNlY3VyaXR5R3JvdXAgPSBuZXcgZWMyLlNlY3VyaXR5R3JvdXAodGhpcywgJ1NSRS1QT0MtTGFtYmRhU2VjdXJpdHlHcm91cCcsIHtcbiAgICAgIHZwYzogdGhpcy52cGMsXG4gICAgICBkZXNjcmlwdGlvbjogJ1NlY3VyaXR5IGdyb3VwIGZvciBTUkUgUE9DIExhbWJkYSBmdW5jdGlvbnMnLFxuICAgICAgYWxsb3dBbGxPdXRib3VuZDogdHJ1ZSxcbiAgICB9KTtcblxuICAgIC8vIEFsbG93IExhbWJkYSB0byBjb25uZWN0IHRvIE5lcHR1bmVcbiAgICBuZXB0dW5lU2VjdXJpdHlHcm91cC5hZGRJbmdyZXNzUnVsZShcbiAgICAgIGxhbWJkYVNlY3VyaXR5R3JvdXAsXG4gICAgICBlYzIuUG9ydC50Y3AoODE4MiksXG4gICAgICAnQWxsb3cgTGFtYmRhIGNvbm5lY3Rpb25zIHRvIE5lcHR1bmUnXG4gICAgKTtcblxuICAgIC8vIENyZWF0ZSBpbmdlc3Rpb24gTGFtYmRhIGZ1bmN0aW9uIHdpdGggY29uc29saWRhdGVkIFNQQVJRTC1vbmx5IHN0cnVjdHVyZSAgXG4gICAgdGhpcy5pbmdlc3Rpb25MYW1iZGEgPSBuZXcgbGFtYmRhLkZ1bmN0aW9uKHRoaXMsICdTUkUtUE9DLUluZ2VzdGlvbkxhbWJkYScsIHtcbiAgICAgIHJ1bnRpbWU6IGxhbWJkYS5SdW50aW1lLk5PREVKU18yMF9YLFxuICAgICAgaGFuZGxlcjogJ3NyYy9pbmdlc3Rpb24uaGFuZGxlcicsXG4gICAgICBjb2RlOiBsYW1iZGEuQ29kZS5mcm9tQXNzZXQoJy4vbGFtYmRhcy9kaXN0JyksXG4gICAgICBsYXllcnM6IFtuZXB0dW5lVXRpbHNMYXllcl0sXG4gICAgICByb2xlOiBsYW1iZGFSb2xlLFxuICAgICAgdGltZW91dDogY2RrLkR1cmF0aW9uLnNlY29uZHMoMzApLCAvLyBSZWR1Y2UgdGltZW91dCB0byBtaW5pbWl6ZSBjb3N0c1xuICAgICAgbWVtb3J5U2l6ZTogMjU2LCAvLyBNaW5pbXVtIG1lbW9yeSBmb3IgY29zdCBvcHRpbWl6YXRpb25cbiAgICAgIHZwYzogdGhpcy52cGMsXG4gICAgICBzZWN1cml0eUdyb3VwczogW2xhbWJkYVNlY3VyaXR5R3JvdXBdLFxuICAgICAgdnBjU3VibmV0czogeyBzdWJuZXRUeXBlOiBlYzIuU3VibmV0VHlwZS5QUklWQVRFX1dJVEhfRUdSRVNTIH0sXG4gICAgICBlbnZpcm9ubWVudDoge1xuICAgICAgICBORVBUVU5FX0VORFBPSU5UOiB0aGlzLm5lcHR1bmVDbHVzdGVyLmF0dHJFbmRwb2ludCxcbiAgICAgICAgTkVQVFVORV9QT1JUOiAnODE4MicsXG4gICAgICAgIFMzX0JVQ0tFVDogZGF0YUJ1Y2tldC5idWNrZXROYW1lLFxuICAgICAgICBBV1NfTk9ERUpTX0NPTk5FQ1RJT05fUkVVU0VfRU5BQkxFRDogJzEnLFxuICAgICAgICBVU0VfSUFNOiAndHJ1ZScsIC8vIEVuYWJsZSBJQU0gYXV0aGVudGljYXRpb24gZm9yIE5lcHR1bmVcbiAgICAgIH0sXG4gICAgICBsb2dHcm91cDogbmV3IGxvZ3MuTG9nR3JvdXAodGhpcywgJ1NSRS1QT0MtSW5nZXN0aW9uTGFtYmRhTG9nR3JvdXAnLCB7XG4gICAgICAgIHJldGVudGlvbjogbG9ncy5SZXRlbnRpb25EYXlzLk9ORV9XRUVLLFxuICAgICAgICByZW1vdmFsUG9saWN5OiBjZGsuUmVtb3ZhbFBvbGljeS5ERVNUUk9ZLFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICAvLyBDcmVhdGUgcXVlcnkgTGFtYmRhIGZ1bmN0aW9uIHdpdGggY29uc29saWRhdGVkIFNQQVJRTC1vbmx5IHN0cnVjdHVyZVxuICAgIHRoaXMucXVlcnlMYW1iZGEgPSBuZXcgbGFtYmRhLkZ1bmN0aW9uKHRoaXMsICdTUkUtUE9DLVF1ZXJ5TGFtYmRhJywge1xuICAgICAgcnVudGltZTogbGFtYmRhLlJ1bnRpbWUuTk9ERUpTXzIwX1gsXG4gICAgICBoYW5kbGVyOiAnc3JjL3F1ZXJ5LmhhbmRsZXInLFxuICAgICAgY29kZTogbGFtYmRhLkNvZGUuZnJvbUFzc2V0KCcuL2xhbWJkYXMvZGlzdCcpLFxuICAgICAgbGF5ZXJzOiBbbmVwdHVuZVV0aWxzTGF5ZXJdLFxuICAgICAgcm9sZTogbGFtYmRhUm9sZSxcbiAgICAgIHRpbWVvdXQ6IGNkay5EdXJhdGlvbi5zZWNvbmRzKDYwKSwgLy8gUmVkdWNlIHRpbWVvdXQgZm9yIHF1ZXJpZXNcbiAgICAgIG1lbW9yeVNpemU6IDUxMiwgLy8gUmVkdWNlIG1lbW9yeSBmb3IgY29zdCBvcHRpbWl6YXRpb25cbiAgICAgIHZwYzogdGhpcy52cGMsXG4gICAgICBzZWN1cml0eUdyb3VwczogW2xhbWJkYVNlY3VyaXR5R3JvdXBdLFxuICAgICAgdnBjU3VibmV0czogeyBzdWJuZXRUeXBlOiBlYzIuU3VibmV0VHlwZS5QUklWQVRFX1dJVEhfRUdSRVNTIH0sXG4gICAgICBlbnZpcm9ubWVudDoge1xuICAgICAgICBORVBUVU5FX0VORFBPSU5UOiB0aGlzLm5lcHR1bmVDbHVzdGVyLmF0dHJFbmRwb2ludCxcbiAgICAgICAgTkVQVFVORV9QT1JUOiAnODE4MicsXG4gICAgICAgIFMzX0JVQ0tFVDogZGF0YUJ1Y2tldC5idWNrZXROYW1lLFxuICAgICAgICBBV1NfTk9ERUpTX0NPTk5FQ1RJT05fUkVVU0VfRU5BQkxFRDogJzEnLFxuICAgICAgICBVU0VfSUFNOiAndHJ1ZScsIC8vIEVuYWJsZSBJQU0gYXV0aGVudGljYXRpb24gZm9yIE5lcHR1bmVcbiAgICAgIH0sXG4gICAgICBsb2dHcm91cDogbmV3IGxvZ3MuTG9nR3JvdXAodGhpcywgJ1NSRS1QT0MtUXVlcnlMYW1iZGFMb2dHcm91cCcsIHtcbiAgICAgICAgcmV0ZW50aW9uOiBsb2dzLlJldGVudGlvbkRheXMuT05FX1dFRUssXG4gICAgICAgIHJlbW92YWxQb2xpY3k6IGNkay5SZW1vdmFsUG9saWN5LkRFU1RST1ksXG4gICAgICB9KSxcbiAgICB9KTtcblxuICAgIC8vIENyZWF0ZSBjbGVhbnVwIExhbWJkYSBmdW5jdGlvbiBmb3IgZGF0YWJhc2UgbWFpbnRlbmFuY2VcbiAgICB0aGlzLmNsZWFudXBMYW1iZGEgPSBuZXcgbGFtYmRhLkZ1bmN0aW9uKHRoaXMsICdTUkUtUE9DLUNsZWFudXBMYW1iZGEnLCB7XG4gICAgICBydW50aW1lOiBsYW1iZGEuUnVudGltZS5OT0RFSlNfMjBfWCxcbiAgICAgIGhhbmRsZXI6ICdzcmMvY2xlYW51cC5oYW5kbGVyJyxcbiAgICAgIGNvZGU6IGxhbWJkYS5Db2RlLmZyb21Bc3NldCgnLi9sYW1iZGFzL2Rpc3QnKSxcbiAgICAgIGxheWVyczogW25lcHR1bmVVdGlsc0xheWVyXSxcbiAgICAgIHJvbGU6IGxhbWJkYVJvbGUsXG4gICAgICB0aW1lb3V0OiBjZGsuRHVyYXRpb24ubWludXRlcyg1KSwgLy8gTG9uZ2VyIHRpbWVvdXQgZm9yIGNsZWFudXAgb3BlcmF0aW9uc1xuICAgICAgbWVtb3J5U2l6ZTogNTEyLFxuICAgICAgdnBjOiB0aGlzLnZwYyxcbiAgICAgIHNlY3VyaXR5R3JvdXBzOiBbbGFtYmRhU2VjdXJpdHlHcm91cF0sXG4gICAgICB2cGNTdWJuZXRzOiB7IHN1Ym5ldFR5cGU6IGVjMi5TdWJuZXRUeXBlLlBSSVZBVEVfV0lUSF9FR1JFU1MgfSxcbiAgICAgIGVudmlyb25tZW50OiB7XG4gICAgICAgIE5FUFRVTkVfRU5EUE9JTlQ6IHRoaXMubmVwdHVuZUNsdXN0ZXIuYXR0ckVuZHBvaW50LFxuICAgICAgICBORVBUVU5FX1BPUlQ6ICc4MTgyJyxcbiAgICAgICAgUzNfQlVDS0VUOiBkYXRhQnVja2V0LmJ1Y2tldE5hbWUsXG4gICAgICAgIEFXU19OT0RFSlNfQ09OTkVDVElPTl9SRVVTRV9FTkFCTEVEOiAnMScsXG4gICAgICAgIFVTRV9JQU06ICd0cnVlJyxcbiAgICAgIH0sXG4gICAgICBsb2dHcm91cDogbmV3IGxvZ3MuTG9nR3JvdXAodGhpcywgJ1NSRS1QT0MtQ2xlYW51cExhbWJkYUxvZ0dyb3VwJywge1xuICAgICAgICByZXRlbnRpb246IGxvZ3MuUmV0ZW50aW9uRGF5cy5PTkVfV0VFSyxcbiAgICAgICAgcmVtb3ZhbFBvbGljeTogY2RrLlJlbW92YWxQb2xpY3kuREVTVFJPWSxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgLy8gT3V0cHV0IGltcG9ydGFudCB2YWx1ZXNcbiAgICBuZXcgY2RrLkNmbk91dHB1dCh0aGlzLCAnU1JFLVBPQy1OZXB0dW5lQ2x1c3RlckVuZHBvaW50Jywge1xuICAgICAgdmFsdWU6IHRoaXMubmVwdHVuZUNsdXN0ZXIuYXR0ckVuZHBvaW50LFxuICAgICAgZGVzY3JpcHRpb246ICdTUkUgUE9DIE5lcHR1bmUgY2x1c3RlciBlbmRwb2ludCcsXG4gICAgfSk7XG5cbiAgICBuZXcgY2RrLkNmbk91dHB1dCh0aGlzLCAnU1JFLVBPQy1OZXB0dW5lQ2x1c3RlclJlYWRFbmRwb2ludCcsIHtcbiAgICAgIHZhbHVlOiB0aGlzLm5lcHR1bmVDbHVzdGVyLmF0dHJSZWFkRW5kcG9pbnQsXG4gICAgICBkZXNjcmlwdGlvbjogJ1NSRSBQT0MgTmVwdHVuZSBjbHVzdGVyIHJlYWQgZW5kcG9pbnQnLFxuICAgIH0pO1xuXG4gICAgbmV3IGNkay5DZm5PdXRwdXQodGhpcywgJ1NSRS1QT0MtRGF0YUJ1Y2tldE5hbWUnLCB7XG4gICAgICB2YWx1ZTogZGF0YUJ1Y2tldC5idWNrZXROYW1lLFxuICAgICAgZGVzY3JpcHRpb246ICdTMyBidWNrZXQgZm9yIFNSRSBQT0MgZW52aXJvbm1lbnQgZGF0YScsXG4gICAgfSk7XG5cbiAgICBuZXcgY2RrLkNmbk91dHB1dCh0aGlzLCAnU1JFLVBPQy1Jbmdlc3Rpb25MYW1iZGFBcm4nLCB7XG4gICAgICB2YWx1ZTogdGhpcy5pbmdlc3Rpb25MYW1iZGEuZnVuY3Rpb25Bcm4sXG4gICAgICBkZXNjcmlwdGlvbjogJ0FSTiBvZiB0aGUgU1JFIFBPQyBkYXRhIGluZ2VzdGlvbiBMYW1iZGEgZnVuY3Rpb24nLFxuICAgIH0pO1xuXG4gICAgLy8gQ3JlYXRlIEFQSSBHYXRld2F5IHdpdGggQ09SUyBjb25maWd1cmF0aW9uXG4gICAgY29uc3QgYXBpID0gbmV3IGFwaWdhdGV3YXkuUmVzdEFwaSh0aGlzLCAnU1JFLVBPQy1OZXB0dW5lRW52aXJvbm1lbnRBcGknLCB7XG4gICAgICByZXN0QXBpTmFtZTogJ1NSRSBQT0MgTmVwdHVuZSBFbnZpcm9ubWVudCBNYW5hZ2VtZW50IEFQSScsXG4gICAgICBkZXNjcmlwdGlvbjogJ0FQSSBmb3IgbWFuYWdpbmcgU1JFIFBPQyBOZXB0dW5lIGVudmlyb25tZW50IGRhdGEnLFxuICAgICAgZGVmYXVsdENvcnNQcmVmbGlnaHRPcHRpb25zOiB7XG4gICAgICAgIGFsbG93T3JpZ2luczogWydodHRwOi8vbG9jYWxob3N0OjMwMDAnXSxcbiAgICAgICAgYWxsb3dNZXRob2RzOiBbJ0dFVCcsICdQT1NUJywgJ1BVVCcsICdERUxFVEUnLCAnT1BUSU9OUyddLFxuICAgICAgICBhbGxvd0hlYWRlcnM6IFsnQ29udGVudC1UeXBlJywgJ0F1dGhvcml6YXRpb24nLCAnQWNjZXB0JywgJ09yaWdpbicsICdYLVJlcXVlc3RlZC1XaXRoJ10sXG4gICAgICAgIGFsbG93Q3JlZGVudGlhbHM6IGZhbHNlLFxuICAgICAgfSxcbiAgICAgIGRlcGxveU9wdGlvbnM6IHtcbiAgICAgICAgc3RhZ2VOYW1lOiAncHJvZCcsXG4gICAgICAgIGxvZ2dpbmdMZXZlbDogYXBpZ2F0ZXdheS5NZXRob2RMb2dnaW5nTGV2ZWwuSU5GTyxcbiAgICAgICAgZGF0YVRyYWNlRW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgbWV0cmljc0VuYWJsZWQ6IHRydWUsXG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgLy8gQ3JlYXRlIExhbWJkYSBpbnRlZ3JhdGlvbnNcbiAgICBjb25zdCBxdWVyeUludGVncmF0aW9uID0gbmV3IGFwaWdhdGV3YXkuTGFtYmRhSW50ZWdyYXRpb24odGhpcy5xdWVyeUxhbWJkYSwge1xuICAgICAgcmVxdWVzdFRlbXBsYXRlczogeyAnYXBwbGljYXRpb24vanNvbic6ICd7IFwic3RhdHVzQ29kZVwiOiBcIjIwMFwiIH0nIH0sXG4gICAgICBwcm94eTogdHJ1ZSxcbiAgICB9KTtcblxuICAgIGNvbnN0IGluZ2VzdGlvbkludGVncmF0aW9uID0gbmV3IGFwaWdhdGV3YXkuTGFtYmRhSW50ZWdyYXRpb24odGhpcy5pbmdlc3Rpb25MYW1iZGEsIHtcbiAgICAgIHJlcXVlc3RUZW1wbGF0ZXM6IHsgJ2FwcGxpY2F0aW9uL2pzb24nOiAneyBcInN0YXR1c0NvZGVcIjogXCIyMDBcIiB9JyB9LFxuICAgICAgcHJveHk6IHRydWUsXG4gICAgfSk7XG5cbiAgICBjb25zdCBjbGVhbnVwSW50ZWdyYXRpb24gPSBuZXcgYXBpZ2F0ZXdheS5MYW1iZGFJbnRlZ3JhdGlvbih0aGlzLmNsZWFudXBMYW1iZGEsIHtcbiAgICAgIHJlcXVlc3RUZW1wbGF0ZXM6IHsgJ2FwcGxpY2F0aW9uL2pzb24nOiAneyBcInN0YXR1c0NvZGVcIjogXCIyMDBcIiB9JyB9LFxuICAgICAgcHJveHk6IHRydWUsXG4gICAgfSk7XG5cbiAgICAvLyBDcmVhdGUgQVBJIHJlc291cmNlcyBhbmQgbWV0aG9kc1xuICAgIGNvbnN0IHF1ZXJ5UmVzb3VyY2UgPSBhcGkucm9vdC5hZGRSZXNvdXJjZSgncXVlcnknKTtcbiAgICBxdWVyeVJlc291cmNlLmFkZE1ldGhvZCgnUE9TVCcsIHF1ZXJ5SW50ZWdyYXRpb24sIHtcbiAgICAgIGF1dGhvcml6YXRpb25UeXBlOiBhcGlnYXRld2F5LkF1dGhvcml6YXRpb25UeXBlLk5PTkUsXG4gICAgfSk7XG4gICAgcXVlcnlSZXNvdXJjZS5hZGRNZXRob2QoJ0dFVCcsIHF1ZXJ5SW50ZWdyYXRpb24sIHtcbiAgICAgIGF1dGhvcml6YXRpb25UeXBlOiBhcGlnYXRld2F5LkF1dGhvcml6YXRpb25UeXBlLk5PTkUsXG4gICAgfSk7XG5cbiAgICBjb25zdCBpbmdlc3Rpb25SZXNvdXJjZSA9IGFwaS5yb290LmFkZFJlc291cmNlKCdpbmdlc3QnKTtcbiAgICBpbmdlc3Rpb25SZXNvdXJjZS5hZGRNZXRob2QoJ1BPU1QnLCBpbmdlc3Rpb25JbnRlZ3JhdGlvbiwge1xuICAgICAgYXV0aG9yaXphdGlvblR5cGU6IGFwaWdhdGV3YXkuQXV0aG9yaXphdGlvblR5cGUuTk9ORSxcbiAgICB9KTtcblxuICAgIGNvbnN0IGNsZWFudXBSZXNvdXJjZSA9IGFwaS5yb290LmFkZFJlc291cmNlKCdjbGVhbnVwJyk7XG4gICAgY2xlYW51cFJlc291cmNlLmFkZE1ldGhvZCgnUE9TVCcsIGNsZWFudXBJbnRlZ3JhdGlvbiwge1xuICAgICAgYXV0aG9yaXphdGlvblR5cGU6IGFwaWdhdGV3YXkuQXV0aG9yaXphdGlvblR5cGUuTk9ORSxcbiAgICB9KTtcbiAgICBjbGVhbnVwUmVzb3VyY2UuYWRkTWV0aG9kKCdERUxFVEUnLCBjbGVhbnVwSW50ZWdyYXRpb24sIHtcbiAgICAgIGF1dGhvcml6YXRpb25UeXBlOiBhcGlnYXRld2F5LkF1dGhvcml6YXRpb25UeXBlLk5PTkUsXG4gICAgfSk7XG5cbiAgICAvLyBLZWVwIEZ1bmN0aW9uIFVSTHMgYXMgYmFja3VwIChjb21tZW50IG91dCBpZiBub3QgbmVlZGVkKVxuICAgIGNvbnN0IGluZ2VzdGlvbkZ1bmN0aW9uVXJsID0gdGhpcy5pbmdlc3Rpb25MYW1iZGEuYWRkRnVuY3Rpb25Vcmwoe1xuICAgICAgYXV0aFR5cGU6IGxhbWJkYS5GdW5jdGlvblVybEF1dGhUeXBlLk5PTkUsXG4gICAgfSk7XG5cbiAgICBjb25zdCBxdWVyeUZ1bmN0aW9uVXJsID0gdGhpcy5xdWVyeUxhbWJkYS5hZGRGdW5jdGlvblVybCh7XG4gICAgICBhdXRoVHlwZTogbGFtYmRhLkZ1bmN0aW9uVXJsQXV0aFR5cGUuTk9ORSxcbiAgICB9KTtcblxuICAgIGNvbnN0IGNsZWFudXBGdW5jdGlvblVybCA9IHRoaXMuY2xlYW51cExhbWJkYS5hZGRGdW5jdGlvblVybCh7XG4gICAgICBhdXRoVHlwZTogbGFtYmRhLkZ1bmN0aW9uVXJsQXV0aFR5cGUuTk9ORSxcbiAgICB9KTtcblxuICAgIC8vIE91dHB1dCBBUEkgR2F0ZXdheSBVUkxzXG4gICAgbmV3IGNkay5DZm5PdXRwdXQodGhpcywgJ1NSRS1QT0MtQXBpR2F0ZXdheVVybCcsIHtcbiAgICAgIHZhbHVlOiBhcGkudXJsLFxuICAgICAgZGVzY3JpcHRpb246ICdTUkUgUE9DIEFQSSBHYXRld2F5IGJhc2UgVVJMJyxcbiAgICB9KTtcblxuICAgIG5ldyBjZGsuQ2ZuT3V0cHV0KHRoaXMsICdTUkUtUE9DLVF1ZXJ5QXBpVXJsJywge1xuICAgICAgdmFsdWU6IGAke2FwaS51cmx9cXVlcnlgLFxuICAgICAgZGVzY3JpcHRpb246ICdTUkUgUE9DIFF1ZXJ5IEFQSSBlbmRwb2ludCBVUkwnLFxuICAgIH0pO1xuXG4gICAgbmV3IGNkay5DZm5PdXRwdXQodGhpcywgJ1NSRS1QT0MtSW5nZXN0aW9uQXBpVXJsJywge1xuICAgICAgdmFsdWU6IGAke2FwaS51cmx9aW5nZXN0YCxcbiAgICAgIGRlc2NyaXB0aW9uOiAnU1JFIFBPQyBJbmdlc3Rpb24gQVBJIGVuZHBvaW50IFVSTCcsXG4gICAgfSk7XG5cbiAgICBuZXcgY2RrLkNmbk91dHB1dCh0aGlzLCAnU1JFLVBPQy1DbGVhbnVwQXBpVXJsJywge1xuICAgICAgdmFsdWU6IGAke2FwaS51cmx9Y2xlYW51cGAsXG4gICAgICBkZXNjcmlwdGlvbjogJ1NSRSBQT0MgQ2xlYW51cCBBUEkgZW5kcG9pbnQgVVJMJyxcbiAgICB9KTtcblxuICAgIG5ldyBjZGsuQ2ZuT3V0cHV0KHRoaXMsICdTUkUtUE9DLVF1ZXJ5TGFtYmRhQXJuJywge1xuICAgICAgdmFsdWU6IHRoaXMucXVlcnlMYW1iZGEuZnVuY3Rpb25Bcm4sXG4gICAgICBkZXNjcmlwdGlvbjogJ0FSTiBvZiB0aGUgU1JFIFBPQyBxdWVyeSBMYW1iZGEgZnVuY3Rpb24nLFxuICAgIH0pO1xuXG4gICAgbmV3IGNkay5DZm5PdXRwdXQodGhpcywgJ1NSRS1QT0MtSW5nZXN0aW9uRnVuY3Rpb25VcmwnLCB7XG4gICAgICB2YWx1ZTogaW5nZXN0aW9uRnVuY3Rpb25VcmwudXJsLFxuICAgICAgZGVzY3JpcHRpb246ICdVUkwgZm9yIHRoZSBTUkUgUE9DIGluZ2VzdGlvbiBMYW1iZGEgZnVuY3Rpb24gKGJhY2t1cCknLFxuICAgIH0pO1xuXG4gICAgbmV3IGNkay5DZm5PdXRwdXQodGhpcywgJ1NSRS1QT0MtUXVlcnlGdW5jdGlvblVybCcsIHtcbiAgICAgIHZhbHVlOiBxdWVyeUZ1bmN0aW9uVXJsLnVybCxcbiAgICAgIGRlc2NyaXB0aW9uOiAnVVJMIGZvciB0aGUgU1JFIFBPQyBxdWVyeSBMYW1iZGEgZnVuY3Rpb24gKGJhY2t1cCknLFxuICAgIH0pO1xuXG4gICAgbmV3IGNkay5DZm5PdXRwdXQodGhpcywgJ1NSRS1QT0MtQ2xlYW51cExhbWJkYUFybicsIHtcbiAgICAgIHZhbHVlOiB0aGlzLmNsZWFudXBMYW1iZGEuZnVuY3Rpb25Bcm4sXG4gICAgICBkZXNjcmlwdGlvbjogJ0FSTiBvZiB0aGUgU1JFIFBPQyBjbGVhbnVwIExhbWJkYSBmdW5jdGlvbicsXG4gICAgfSk7XG5cbiAgICBuZXcgY2RrLkNmbk91dHB1dCh0aGlzLCAnU1JFLVBPQy1DbGVhbnVwRnVuY3Rpb25VcmwnLCB7XG4gICAgICB2YWx1ZTogY2xlYW51cEZ1bmN0aW9uVXJsLnVybCxcbiAgICAgIGRlc2NyaXB0aW9uOiAnVVJMIGZvciB0aGUgU1JFIFBPQyBjbGVhbnVwIExhbWJkYSBmdW5jdGlvbiAoYmFja3VwKScsXG4gICAgfSk7XG5cbiAgICBuZXcgY2RrLkNmbk91dHB1dCh0aGlzLCAnU1JFLVBPQy1WcGNJZCcsIHtcbiAgICAgIHZhbHVlOiB0aGlzLnZwYy52cGNJZCxcbiAgICAgIGRlc2NyaXB0aW9uOiAnVlBDIElEIGZvciB0aGUgU1JFIFBPQyBOZXB0dW5lIGVudmlyb25tZW50JyxcbiAgICB9KTtcbiAgfVxufVxuIl19