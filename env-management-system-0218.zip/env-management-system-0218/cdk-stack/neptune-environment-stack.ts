import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as neptune from 'aws-cdk-lib/aws-neptune';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as logs from 'aws-cdk-lib/aws-logs';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import { Construct } from 'constructs';

export class NeptuneEnvironmentStack extends cdk.Stack {
  public readonly neptuneCluster: neptune.CfnDBCluster;
  public readonly vpc: ec2.Vpc;
  public readonly ingestionLambda: lambda.Function;
  public readonly queryLambda: lambda.Function;
  public readonly cleanupLambda: lambda.Function;

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Create cost-optimized VPC for Neptune cluster
    this.vpc = new ec2.Vpc(this, 'SRE-POC-NeptuneVpc', {
      maxAzs: 2, // Keep 2 AZs for Neptune requirement (minimum for subnet group)
      natGateways: 1, // Use only 1 NAT Gateway to reduce costs
      subnetConfiguration: [
        {
          cidrMask: 26, // Smaller subnets to save IP space
          name: 'private-subnet',
          subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
        },
        {
          cidrMask: 28, // Very small public subnet (only for NAT)
          name: 'public-subnet',
          subnetType: ec2.SubnetType.PUBLIC,
        },
      ],
    });

    // Create security group for Neptune
    const neptuneSecurityGroup = new ec2.SecurityGroup(this, 'SRE-POC-NeptuneSecurityGroup', {
      vpc: this.vpc,
      description: 'Security group for SRE POC Neptune cluster',
      allowAllOutbound: true,
    });

    // Allow inbound connections on Neptune port from Lambda security group
    neptuneSecurityGroup.addIngressRule(
      neptuneSecurityGroup,
      ec2.Port.tcp(8182),
      'Allow Neptune connections from Lambda functions'
    );

    // Create Neptune subnet group
    const subnetGroup = new neptune.CfnDBSubnetGroup(this, 'SRE-POC-NeptuneSubnetGroup', {
      dbSubnetGroupDescription: 'Subnet group for SRE POC Neptune cluster',
      subnetIds: this.vpc.privateSubnets.map((subnet) => subnet.subnetId),
      dbSubnetGroupName: 'sre-poc-neptune-subnet-group',
    });

    // Create Neptune cluster (cost-optimized)
    this.neptuneCluster = new neptune.CfnDBCluster(this, 'SRE-POC-NeptuneCluster', {
      dbClusterIdentifier: 'sre-poc-neptune-environment-cluster',
      dbSubnetGroupName: subnetGroup.ref,
      vpcSecurityGroupIds: [neptuneSecurityGroup.securityGroupId],
      backupRetentionPeriod: 1, // Minimum backup retention (1 day)
      preferredBackupWindow: '03:00-04:00',
      preferredMaintenanceWindow: 'sun:04:00-sun:05:00',
      storageEncrypted: false, // Disable encryption to reduce cost
      deletionProtection: false, // For development - set to true for production
      iamAuthEnabled: true, // Enable IAM database authentication
    });

    // Create Neptune instance (smallest instance type)
    const neptuneInstance = new neptune.CfnDBInstance(this, 'SRE-POC-NeptuneInstance', {
      dbInstanceClass: 'db.t3.medium', // Smallest Neptune instance type
      dbClusterIdentifier: this.neptuneCluster.ref,
      dbInstanceIdentifier: 'sre-poc-neptune-instance-1',
    });

    neptuneInstance.addDependency(this.neptuneCluster);

    // Create cost-optimized S3 bucket for data exports and backups
    const dataBucket = new s3.Bucket(this, 'SRE-POC-EnvironmentDataBucket', {
      encryption: s3.BucketEncryption.S3_MANAGED,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      versioned: false, // Disable versioning to save storage costs
      lifecycleRules: [
        {
          id: 'transition-to-ia',
          enabled: true,
          transitions: [
            {
              storageClass: s3.StorageClass.INFREQUENT_ACCESS,
              transitionAfter: cdk.Duration.days(30), // Move to IA after 30 days
            },
            {
              storageClass: s3.StorageClass.GLACIER,
              transitionAfter: cdk.Duration.days(90), // Move to Glacier after 90 days
            },
          ],
          expiration: cdk.Duration.days(365), // Delete after 1 year
        },
      ],
      removalPolicy: cdk.RemovalPolicy.DESTROY, // For development
    });

    // Create IAM role for Lambda functions
    const lambdaRole = new iam.Role(this, 'SRE-POC-NeptuneLambdaRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaVPCAccessExecutionRole'),
      ],
      inlinePolicies: {
        NeptuneFullAccess: new iam.PolicyDocument({
          statements: [
            new iam.PolicyStatement({
              effect: iam.Effect.ALLOW,
              actions: [
                'neptune-db:*',
              ],
              resources: ['*'],
            }),
            new iam.PolicyStatement({
              effect: iam.Effect.ALLOW,
              actions: [
                'neptune:*',
              ],
              resources: ['*'],
            }),
            new iam.PolicyStatement({
              effect: iam.Effect.ALLOW,
              actions: ['s3:GetObject', 's3:PutObject', 's3:DeleteObject', 's3:ListBucket'],
              resources: [dataBucket.bucketArn, `${dataBucket.bucketArn}/*`],
            }),
          ],
        }),
      },
    });

    // Create Lambda Layer for shared utilities (using consolidated structure)
    const neptuneUtilsLayer = new lambda.LayerVersion(this, 'SRE-POC-NeptuneUtilsLayer', {
      code: lambda.Code.fromAsset('./lambdas', {
        bundling: {
          image: lambda.Runtime.NODEJS_20_X.bundlingImage,
          command: [
            'bash', '-c',
            'cp -r /asset-input/node_modules /asset-output/nodejs/ && ' +
            'mkdir -p /asset-output/nodejs/node_modules && ' +
            'cp -r /asset-input/node_modules/* /asset-output/nodejs/node_modules/'
          ],
        },
      }),
      compatibleRuntimes: [lambda.Runtime.NODEJS_20_X],
      description: 'Shared SPARQL-only utilities for SRE POC Neptune operations with dependencies',
    });

    // Create security group for Lambda functions
    const lambdaSecurityGroup = new ec2.SecurityGroup(this, 'SRE-POC-LambdaSecurityGroup', {
      vpc: this.vpc,
      description: 'Security group for SRE POC Lambda functions',
      allowAllOutbound: true,
    });

    // Allow Lambda to connect to Neptune
    neptuneSecurityGroup.addIngressRule(
      lambdaSecurityGroup,
      ec2.Port.tcp(8182),
      'Allow Lambda connections to Neptune'
    );

    // Create ingestion Lambda function with all dependencies bundled  
    this.ingestionLambda = new lambda.Function(this, 'SRE-POC-IngestionLambda', {
      runtime: lambda.Runtime.NODEJS_20_X,
      handler: 'src/ingestion.handler',
      code: lambda.Code.fromAsset('./lambdas', {
        bundling: {
          image: lambda.Runtime.NODEJS_20_X.bundlingImage,
          command: [
            'bash', '-c',
            'cp -r /asset-input/dist/* /asset-output/ && ' +
            'cp -r /asset-input/node_modules /asset-output/'
          ],
        },
      }),
      role: lambdaRole,
      timeout: cdk.Duration.seconds(30), // Reduce timeout to minimize costs
      memorySize: 256, // Minimum memory for cost optimization
      vpc: this.vpc,
      securityGroups: [lambdaSecurityGroup],
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      environment: {
        NEPTUNE_ENDPOINT: this.neptuneCluster.attrEndpoint,
        NEPTUNE_PORT: '8182',
        S3_BUCKET: dataBucket.bucketName,
        AWS_NODEJS_CONNECTION_REUSE_ENABLED: '1',
        USE_IAM: 'true', // Enable IAM authentication for Neptune
      },
      logGroup: new logs.LogGroup(this, 'SRE-POC-IngestionLambdaLogGroup', {
        retention: logs.RetentionDays.ONE_WEEK,
        removalPolicy: cdk.RemovalPolicy.DESTROY,
      }),
    });

    // Create query Lambda function with all dependencies bundled
    this.queryLambda = new lambda.Function(this, 'SRE-POC-QueryLambda', {
      runtime: lambda.Runtime.NODEJS_20_X,
      handler: 'src/query.handler',
      code: lambda.Code.fromAsset('./lambdas', {
        bundling: {
          image: lambda.Runtime.NODEJS_20_X.bundlingImage,
          command: [
            'bash', '-c',
            'cp -r /asset-input/dist/* /asset-output/ && ' +
            'cp -r /asset-input/node_modules /asset-output/'
          ],
        },
      }),
      role: lambdaRole,
      timeout: cdk.Duration.seconds(60), // Reduce timeout for queries
      memorySize: 512, // Reduce memory for cost optimization
      vpc: this.vpc,
      securityGroups: [lambdaSecurityGroup],
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      environment: {
        NEPTUNE_ENDPOINT: this.neptuneCluster.attrEndpoint,
        NEPTUNE_PORT: '8182',
        S3_BUCKET: dataBucket.bucketName,
        AWS_NODEJS_CONNECTION_REUSE_ENABLED: '1',
        USE_IAM: 'true', // Enable IAM authentication for Neptune
      },
      logGroup: new logs.LogGroup(this, 'SRE-POC-QueryLambdaLogGroup', {
        retention: logs.RetentionDays.ONE_WEEK,
        removalPolicy: cdk.RemovalPolicy.DESTROY,
      }),
    });

    // Create cleanup Lambda function for database maintenance
    this.cleanupLambda = new lambda.Function(this, 'SRE-POC-CleanupLambda', {
      runtime: lambda.Runtime.NODEJS_20_X,
      handler: 'src/cleanup.handler',
      code: lambda.Code.fromAsset('./lambdas', {
        bundling: {
          image: lambda.Runtime.NODEJS_20_X.bundlingImage,
          command: [
            'bash', '-c',
            'cp -r /asset-input/dist/* /asset-output/ && ' +
            'cp -r /asset-input/node_modules /asset-output/'
          ],
        },
      }),
      role: lambdaRole,
      timeout: cdk.Duration.minutes(5), // Longer timeout for cleanup operations
      memorySize: 512,
      vpc: this.vpc,
      securityGroups: [lambdaSecurityGroup],
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      environment: {
        NEPTUNE_ENDPOINT: this.neptuneCluster.attrEndpoint,
        NEPTUNE_PORT: '8182',
        S3_BUCKET: dataBucket.bucketName,
        AWS_NODEJS_CONNECTION_REUSE_ENABLED: '1',
        USE_IAM: 'true',
      },
      logGroup: new logs.LogGroup(this, 'SRE-POC-CleanupLambdaLogGroup', {
        retention: logs.RetentionDays.ONE_WEEK,
        removalPolicy: cdk.RemovalPolicy.DESTROY,
      }),
    });

    // Output important values
    new cdk.CfnOutput(this, 'SRE-POC-NeptuneClusterEndpoint', {
      value: this.neptuneCluster.attrEndpoint,
      description: 'SRE POC Neptune cluster endpoint',
    });

    new cdk.CfnOutput(this, 'SRE-POC-NeptuneClusterReadEndpoint', {
      value: this.neptuneCluster.attrReadEndpoint,
      description: 'SRE POC Neptune cluster read endpoint',
    });

    new cdk.CfnOutput(this, 'SRE-POC-DataBucketName', {
      value: dataBucket.bucketName,
      description: 'S3 bucket for SRE POC environment data',
    });

    new cdk.CfnOutput(this, 'SRE-POC-IngestionLambdaArn', {
      value: this.ingestionLambda.functionArn,
      description: 'ARN of the SRE POC data ingestion Lambda function',
    });

    // Create API Gateway with CORS configuration
    const api = new apigateway.RestApi(this, 'SRE-POC-NeptuneEnvironmentApi', {
      restApiName: 'SRE POC Neptune Environment Management API',
      description: 'API for managing SRE POC Neptune environment data',
      defaultCorsPreflightOptions: {
        allowOrigins: apigateway.Cors.ALL_ORIGINS,
        allowMethods: apigateway.Cors.ALL_METHODS,
        allowHeaders: ['Content-Type', 'Authorization', 'Accept', 'Origin', 'X-Requested-With'],
        allowCredentials: false,
      },
      deployOptions: {
        stageName: 'prod',
        loggingLevel: apigateway.MethodLoggingLevel.INFO,
        dataTraceEnabled: true,
        metricsEnabled: true,
      },
    });

    // Create Lambda integrations
    const queryIntegration = new apigateway.LambdaIntegration(this.queryLambda, {
      requestTemplates: { 'application/json': '{ "statusCode": "200" }' },
      proxy: true,
    });

    const ingestionIntegration = new apigateway.LambdaIntegration(this.ingestionLambda, {
      requestTemplates: { 'application/json': '{ "statusCode": "200" }' },
      proxy: true,
    });

    const cleanupIntegration = new apigateway.LambdaIntegration(this.cleanupLambda, {
      requestTemplates: { 'application/json': '{ "statusCode": "200" }' },
      proxy: true,
    });

    // Create API resources and methods
    const queryResource = api.root.addResource('query');
    queryResource.addMethod('POST', queryIntegration, {
      authorizationType: apigateway.AuthorizationType.NONE,
    });
    queryResource.addMethod('GET', queryIntegration, {
      authorizationType: apigateway.AuthorizationType.NONE,
    });

    const ingestionResource = api.root.addResource('ingest');
    ingestionResource.addMethod('POST', ingestionIntegration, {
      authorizationType: apigateway.AuthorizationType.NONE,
    });

    const cleanupResource = api.root.addResource('cleanup');
    cleanupResource.addMethod('POST', cleanupIntegration, {
      authorizationType: apigateway.AuthorizationType.NONE,
    });
    cleanupResource.addMethod('DELETE', cleanupIntegration, {
      authorizationType: apigateway.AuthorizationType.NONE,
    });

    // Keep Function URLs as backup (comment out if not needed)
    const ingestionFunctionUrl = this.ingestionLambda.addFunctionUrl({
      authType: lambda.FunctionUrlAuthType.NONE,
    });

    const queryFunctionUrl = this.queryLambda.addFunctionUrl({
      authType: lambda.FunctionUrlAuthType.NONE,
    });

    const cleanupFunctionUrl = this.cleanupLambda.addFunctionUrl({
      authType: lambda.FunctionUrlAuthType.NONE,
    });

    // Output API Gateway URLs
    new cdk.CfnOutput(this, 'SRE-POC-ApiGatewayUrl', {
      value: api.url,
      description: 'SRE POC API Gateway base URL',
    });

    new cdk.CfnOutput(this, 'SRE-POC-QueryApiUrl', {
      value: `${api.url}query`,
      description: 'SRE POC Query API endpoint URL',
    });

    new cdk.CfnOutput(this, 'SRE-POC-IngestionApiUrl', {
      value: `${api.url}ingest`,
      description: 'SRE POC Ingestion API endpoint URL',
    });

    new cdk.CfnOutput(this, 'SRE-POC-CleanupApiUrl', {
      value: `${api.url}cleanup`,
      description: 'SRE POC Cleanup API endpoint URL',
    });

    new cdk.CfnOutput(this, 'SRE-POC-QueryLambdaArn', {
      value: this.queryLambda.functionArn,
      description: 'ARN of the SRE POC query Lambda function',
    });

    new cdk.CfnOutput(this, 'SRE-POC-IngestionFunctionUrl', {
      value: ingestionFunctionUrl.url,
      description: 'URL for the SRE POC ingestion Lambda function (backup)',
    });

    new cdk.CfnOutput(this, 'SRE-POC-QueryFunctionUrl', {
      value: queryFunctionUrl.url,
      description: 'URL for the SRE POC query Lambda function (backup)',
    });

    new cdk.CfnOutput(this, 'SRE-POC-CleanupLambdaArn', {
      value: this.cleanupLambda.functionArn,
      description: 'ARN of the SRE POC cleanup Lambda function',
    });

    new cdk.CfnOutput(this, 'SRE-POC-CleanupFunctionUrl', {
      value: cleanupFunctionUrl.url,
      description: 'URL for the SRE POC cleanup Lambda function (backup)',
    });

    new cdk.CfnOutput(this, 'SRE-POC-VpcId', {
      value: this.vpc.vpcId,
      description: 'VPC ID for the SRE POC Neptune environment',
    });
  }
}
