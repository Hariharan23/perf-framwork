"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_bedrock_runtime_1 = require("@aws-sdk/client-bedrock-runtime");
const credential_provider_node_1 = require("@aws-sdk/credential-provider-node");
const protocol_http_1 = require("@smithy/protocol-http");
const sha256_js_1 = require("@aws-crypto/sha256-js");
const signature_v4_1 = require("@smithy/signature-v4");
const axios_1 = __importDefault(require("axios"));
// Initialize Bedrock client
const bedrockClient = new client_bedrock_runtime_1.BedrockRuntimeClient({
    region: process.env.AWS_REGION || 'us-east-1',
    credentials: (0, credential_provider_node_1.defaultProvider)(),
});
// Initialize IAM signer for Neptune
const credentials = (0, credential_provider_node_1.defaultProvider)();
const region = process.env.AWS_REGION || 'us-east-1';
const signer = new signature_v4_1.SignatureV4({
    credentials,
    region,
    service: 'neptune-db',
    sha256: sha256_js_1.Sha256,
});
// Neptune SPARQL endpoint from environment
const NEPTUNE_ENDPOINT = process.env.NEPTUNE_ENDPOINT || '';
const NEPTUNE_PORT = '8182';
// Bedrock model configuration (Amazon Nova Micro - cost-effective and no approval required)
const BEDROCK_MODEL_ID = 'amazon.nova-micro-v1:0';
const MAX_TOKENS = 2000;
const TEMPERATURE = 0.1; // Low temperature for deterministic query generation
/**
 * System prompt with Neptune ontology schema
 */
const SYSTEM_PROMPT = `You are a SPARQL query generator for a Neptune graph database.

DATABASE ONTOLOGY:
- Namespace: http://neptune.aws.com/envmgmt/ontology/
- Prefix: env

ENTITY TYPES:
1. Environment - Infrastructure environments (QA, Prod, etc.)
   Properties: id, name, type, description, owner, status, createdAt
   Config Properties: region, endpoint, config_*
   ScienceLogic Meta: deviceName, deviceDescription, ipAddress, deviceClass, organization, collectionMode, deviceHostname, managedType, category, subClass, uptime, collectionTime, collectorGroup, sourceId, sourceSystem, lastSyncedAt
   ScienceLogic Stats: availability, latency, cpu, memory, swap, currentState, storage, healthScore
   
2. Application - Software applications
   Properties: id, name, type, description, owner, status, createdAt
   Config Properties: version, config_*
   ScienceLogic Meta: deviceName, deviceDescription, ipAddress, deviceClass, organization, collectionMode, deviceHostname, managedType, category, subClass, uptime, collectionTime, collectorGroup, sourceId, sourceSystem, lastSyncedAt
   ScienceLogic Stats: availability, latency, cpu, memory, swap, currentState, storage, healthScore
   
3. Integration - Service integrations
   Properties: id, name, type, description, owner, status, createdAt
   Config Properties: protocol, sourceService, targetService, config_*
   ScienceLogic Meta: deviceName, deviceDescription, ipAddress, deviceClass, organization, collectionMode, deviceHostname, managedType, category, subClass, uptime, collectionTime, collectorGroup, sourceId, sourceSystem, lastSyncedAt
   ScienceLogic Stats: availability, latency, cpu, memory, swap, currentState, storage, healthScore

4. Relationship - Connections between entities
   Properties: id, name, type, relationshipType, sourceEntity, targetEntity, sourceEntityId, targetEntityId
   Common relationshipType values:
   - "hasIntegration": Source Environment → Integration entity (created by PCE discovery)
   - "integratesWith": Integration entity → Target Environment (resolved connection)
   - "stubs": Integration entity → Target Environment (unresolved/placeholder connection)
   - "calls", "depends_on", "feeds_into", "syncs_with", "authenticates", "publishes_to", "reads_from" (manual relationships)

SCIENCELOGIC META PROPERTIES (device metadata):
- deviceName: Device name as shown in ScienceLogic dashboard
- deviceDescription: Device description from ScienceLogic
- ipAddress: IP address or device ID
- deviceClass: Device classification (e.g. server, switch, router)
- organization: Organization the device belongs to
- collectionMode: Data collection mode (e.g. SNMP, Agent, API)
- deviceHostname: Hostname of the device
- managedType: Managed type (e.g. Managed, Unmanaged)
- category: Device category (e.g. Server, Network, Storage)
- subClass: Device sub-class
- uptime: Device uptime
- collectionTime: Last data collection timestamp
- collectorGroup: Collector group or data collector name
- sourceId: External source system identifier
- sourceSystem: External monitoring system name (e.g. ScienceLogic)
- lastSyncedAt: Last sync timestamp

SCIENCELOGIC STATS PROPERTIES (monitoring/health):
- availability: Uptime/availability percentage
- latency: Network latency in milliseconds
- cpu: CPU usage percentage
- memory: Memory usage percentage
- swap: Swap memory usage percentage
- currentState: Current operational state (e.g. Healthy, Warning, Critical, Notice, Major)
- storage: Storage usage percentage
- healthScore: Overall health score (0-100)

CRITICAL REQUIREMENT:
EVERY query MUST start with:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>

SPARQL RULES:
1. Entity types: env:Environment, env:Application, env:Integration
2. Properties are directly on entities (flat structure)
3. Configuration properties start with env:config_
4. Always add LIMIT clause (default: LIMIT 100)
5. Use FILTER for text matching with CONTAINS or regex
6. Escape special characters in string literals
7. For counts, use SELECT (COUNT(?var) AS ?count)
8. Return only valid SPARQL 1.1 queries

COMMON QUERY PATTERNS:

List all entities of a type:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?id ?name ?status ?owner WHERE {
  ?entity rdf:type env:Environment ;
          env:id ?id ;
          env:name ?name .
  OPTIONAL { ?entity env:status ?status }
  OPTIONAL { ?entity env:owner ?owner }
} LIMIT 100

Find entity by name:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?id ?type ?description ?owner ?status WHERE {
  ?entity env:name "CAS_QA" ;
          env:id ?id ;
          env:type ?type .
  OPTIONAL { ?entity env:description ?description }
  OPTIONAL { ?entity env:owner ?owner }
  OPTIONAL { ?entity env:status ?status }
}

Get entity configurations:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?key ?value WHERE {
  ?entity env:name "CAS_QA" ;
          ?configProp ?value .
  FILTER(CONTAINS(STR(?configProp), "config_"))
  BIND(REPLACE(STR(?configProp), ".*config_", "") AS ?key)
}

Find relationships:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?source ?relType ?target WHERE {
  ?rel env:type "Relationship" ;
       env:sourceEntity ?source ;
       env:relationshipType ?relType ;
       env:targetEntity ?target .
}

Count entities:
SELECT (COUNT(?entity) AS ?count) WHERE {
  ?entity rdf:type env:Application .
}

Filter by property:
SELECT ?name ?status WHERE {
  ?entity rdf:type env:Environment ;
          env:name ?name ;
          env:status ?status .
  FILTER(?status = "active")
}

Get entity stats/health:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type ?currentState ?availability ?latency ?cpu ?memory ?swap ?ipAddress ?deviceClass WHERE {
  ?entity env:name ?name ;
          env:type ?type .
  OPTIONAL { ?entity env:currentState ?currentState }
  OPTIONAL { ?entity env:availability ?availability }
  OPTIONAL { ?entity env:latency ?latency }
  OPTIONAL { ?entity env:cpu ?cpu }
  OPTIONAL { ?entity env:memory ?memory }
  OPTIONAL { ?entity env:swap ?swap }
  OPTIONAL { ?entity env:ipAddress ?ipAddress }
  OPTIONAL { ?entity env:deviceClass ?deviceClass }
  FILTER(?type IN ("Environment", "Application", "Integration"))
} LIMIT 100

Get full ScienceLogic details for a specific entity:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type ?currentState ?availability ?latency ?cpu ?memory ?swap ?ipAddress ?deviceClass ?organization ?collectionMode ?deviceHostname ?managedType ?category ?subClass ?uptime ?collectionTime ?collectorGroup ?sourceSystem ?lastSyncedAt WHERE {
  ?entity env:name "CAS_QA" ;
          env:name ?name ;
          env:type ?type .
  OPTIONAL { ?entity env:currentState ?currentState }
  OPTIONAL { ?entity env:availability ?availability }
  OPTIONAL { ?entity env:latency ?latency }
  OPTIONAL { ?entity env:cpu ?cpu }
  OPTIONAL { ?entity env:memory ?memory }
  OPTIONAL { ?entity env:swap ?swap }
  OPTIONAL { ?entity env:ipAddress ?ipAddress }
  OPTIONAL { ?entity env:deviceClass ?deviceClass }
  OPTIONAL { ?entity env:organization ?organization }
  OPTIONAL { ?entity env:collectionMode ?collectionMode }
  OPTIONAL { ?entity env:deviceHostname ?deviceHostname }
  OPTIONAL { ?entity env:managedType ?managedType }
  OPTIONAL { ?entity env:category ?category }
  OPTIONAL { ?entity env:subClass ?subClass }
  OPTIONAL { ?entity env:uptime ?uptime }
  OPTIONAL { ?entity env:collectionTime ?collectionTime }
  OPTIONAL { ?entity env:collectorGroup ?collectorGroup }
  OPTIONAL { ?entity env:sourceSystem ?sourceSystem }
  OPTIONAL { ?entity env:lastSyncedAt ?lastSyncedAt }
}

Find unhealthy entities (Critical or Warning state):
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type ?currentState ?availability ?cpu ?memory ?latency WHERE {
  ?entity env:name ?name ;
          env:type ?type ;
          env:currentState ?currentState .
  FILTER(?currentState IN ("Critical", "Warning", "Major"))
} ORDER BY ?currentState LIMIT 100

Find entities by organization:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type ?organization ?currentState ?ipAddress WHERE {
  ?entity env:name ?name ;
          env:type ?type ;
          env:organization ?organization .
  OPTIONAL { ?entity env:currentState ?currentState }
  OPTIONAL { ?entity env:ipAddress ?ipAddress }
  FILTER(CONTAINS(?organization, "OrgName"))
} LIMIT 100

Find entities with high latency:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type ?latency ?availability ?currentState WHERE {
  ?entity env:name ?name ;
          env:type ?type ;
          env:latency ?latency .
  FILTER(xsd:float(?latency) > 100)
} ORDER BY DESC(xsd:float(?latency)) LIMIT 100

BLAST RADIUS / IMPACT ANALYSIS:

Find all entities directly connected to a specific entity (1-hop blast radius):
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?impactedName ?impactedType ?direction ?relationType WHERE {
  {
    ?rel env:type "Relationship" ;
         env:sourceEntityId ?srcId ;
         env:targetEntityId ?tgtId ;
         env:relationshipType ?relationType .
    ?src env:id ?srcId ; env:name "ENTITY_NAME" .
    ?tgt env:id ?tgtId ; env:name ?impactedName ; env:type ?impactedType .
    BIND("downstream" AS ?direction)
  }
  UNION
  {
    ?rel env:type "Relationship" ;
         env:sourceEntityId ?srcId ;
         env:targetEntityId ?tgtId ;
         env:relationshipType ?relationType .
    ?tgt env:id ?tgtId ; env:name "ENTITY_NAME" .
    ?src env:id ?srcId ; env:name ?impactedName ; env:type ?impactedType .
    BIND("upstream" AS ?direction)
  }
}

Find entities that depend on a given entity (who calls this entity):
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?dependentName ?dependentType ?relationType WHERE {
  ?rel env:type "Relationship" ;
       env:sourceEntityId ?srcId ;
       env:targetEntityId ?tgtId ;
       env:relationshipType ?relationType .
  ?tgt env:id ?tgtId ; env:name "ENTITY_NAME" .
  ?src env:id ?srcId ; env:name ?dependentName ; env:type ?dependentType .
}

Find what a given entity depends on (what this entity calls):
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?dependencyName ?dependencyType ?relationType WHERE {
  ?rel env:type "Relationship" ;
       env:sourceEntityId ?srcId ;
       env:targetEntityId ?tgtId ;
       env:relationshipType ?relationType .
  ?src env:id ?srcId ; env:name "ENTITY_NAME" .
  ?tgt env:id ?tgtId ; env:name ?dependencyName ; env:type ?dependencyType .
}

Find single points of failure (entities with the most inbound connections):
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type (COUNT(DISTINCT ?rel) AS ?inboundCount) WHERE {
  ?rel env:type "Relationship" ;
       env:targetEntityId ?tgtId .
  ?entity env:id ?tgtId ;
          env:name ?name ;
          env:type ?type .
} GROUP BY ?name ?type ORDER BY DESC(?inboundCount) LIMIT 20

Find most connected entities (highest total connections):
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type (COUNT(DISTINCT ?rel) AS ?totalConnections) WHERE {
  {
    ?rel env:type "Relationship" ; env:sourceEntityId ?eid .
    ?entity env:id ?eid ; env:name ?name ; env:type ?type .
  } UNION {
    ?rel env:type "Relationship" ; env:targetEntityId ?eid .
    ?entity env:id ?eid ; env:name ?name ; env:type ?type .
  }
} GROUP BY ?name ?type ORDER BY DESC(?totalConnections) LIMIT 20

Find isolated entities (no connections):
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type WHERE {
  ?entity env:name ?name ; env:type ?type ; env:id ?id .
  FILTER(?type IN ("Environment", "Application"))
  FILTER NOT EXISTS {
    { ?rel env:type "Relationship" ; env:sourceEntityId ?id }
    UNION
    { ?rel env:type "Relationship" ; env:targetEntityId ?id }
  }
}

Find shared dependencies between two entities:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?sharedName ?sharedType WHERE {
  ?rel1 env:type "Relationship" ; env:sourceEntityId ?src1 ; env:targetEntityId ?shared .
  ?rel2 env:type "Relationship" ; env:sourceEntityId ?src2 ; env:targetEntityId ?shared .
  ?e1 env:id ?src1 ; env:name "ENTITY_1" .
  ?e2 env:id ?src2 ; env:name "ENTITY_2" .
  ?sharedEntity env:id ?shared ; env:name ?sharedName ; env:type ?sharedType .
}

IMPORTANT: Return ONLY the SPARQL query, no explanations or markdown formatting.`;
/**
 * Execute SPARQL query on Neptune with IAM authentication
 */
async function executeSparqlQuery(query) {
    const body = `query=${encodeURIComponent(query)}`;
    // Create the request for signing
    const request = new protocol_http_1.HttpRequest({
        method: 'POST',
        protocol: 'https:',
        hostname: NEPTUNE_ENDPOINT,
        port: 8182,
        path: '/sparql',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/sparql-results+json',
            'Host': `${NEPTUNE_ENDPOINT}:8182`,
        },
        body,
    });
    try {
        // Sign the request with IAM credentials
        const signedRequest = await signer.sign(request);
        // Construct the full URL
        const endpoint = `https://${NEPTUNE_ENDPOINT}:${NEPTUNE_PORT}/sparql`;
        console.log(`Executing SPARQL query to: ${endpoint}`);
        console.log(`Query: ${query.substring(0, 200)}...`);
        const response = await (0, axios_1.default)({
            method: 'POST',
            url: endpoint,
            headers: {
                ...signedRequest.headers,
                'Content-Length': body.length.toString(),
            },
            data: body,
            timeout: 30000,
        });
        return response.data;
    }
    catch (error) {
        console.error('SPARQL execution error:', error.response?.data || error.message);
        throw new Error(`Neptune query failed: ${error.response?.data?.message || error.message}`);
    }
}
/**
 * Call Bedrock to generate SPARQL from natural language
 */
async function generateSparqlWithBedrock(userQuery) {
    // Amazon Nova uses messages format similar to Claude
    const prompt = {
        schemaVersion: "messages-v1",
        messages: [
            {
                role: "user",
                content: [
                    {
                        text: `${SYSTEM_PROMPT}\n\nConvert this natural language query to SPARQL:\n\n${userQuery}\n\nReturn only the SPARQL query, nothing else.`
                    }
                ]
            }
        ],
        inferenceConfig: {
            max_new_tokens: MAX_TOKENS,
            temperature: TEMPERATURE
        }
    };
    const command = new client_bedrock_runtime_1.InvokeModelCommand({
        modelId: BEDROCK_MODEL_ID,
        contentType: 'application/json',
        accept: 'application/json',
        body: JSON.stringify(prompt),
    });
    try {
        const response = await bedrockClient.send(command);
        const responseBody = JSON.parse(new TextDecoder().decode(response.body));
        console.log('Bedrock response:', JSON.stringify(responseBody, null, 2));
        // Extract SPARQL from Nova response format
        let sparqlQuery = responseBody.output?.message?.content?.[0]?.text || responseBody.results?.[0]?.outputText || '';
        sparqlQuery = sparqlQuery.trim();
        // Remove markdown code blocks if present
        sparqlQuery = sparqlQuery.replace(/```sparql\n?/g, '').replace(/```\n?/g, '').trim();
        // Ensure PREFIX is present - add if missing
        if (!sparqlQuery.toLowerCase().includes('prefix env:')) {
            sparqlQuery = 'PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>\n\n' + sparqlQuery;
        }
        console.log('Generated SPARQL:', sparqlQuery);
        return sparqlQuery;
    }
    catch (error) {
        console.error('Bedrock invocation error:', error);
        throw new Error(`Failed to generate SPARQL: ${error.message}`);
    }
}
/**
 * All ScienceLogic property names (meta + stats) for detection
 */
const STAT_PROPERTIES = [
    // Meta
    'deviceName', 'deviceDescription',
    'ipAddress', 'deviceClass', 'organization', 'collectionMode',
    'deviceHostname', 'managedType', 'category', 'subClass',
    'uptime', 'collectionTime', 'collectorGroup',
    'sourceId', 'sourceSystem', 'lastSyncedAt',
    // Stats
    'availability', 'latency', 'cpu', 'memory', 'swap', 'currentState',
    // Derived/Internal
    'storage', 'healthScore',
];
/**
 * Execute blast radius analysis — find all entities impacted if a given entity goes down
 * Performs multi-hop traversal: direct connections + transitive downstream dependencies
 */
async function getBlastRadius(entityName, maxDepth = 3) {
    // Step 1: Find entity ID
    const idQuery = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    SELECT ?id ?name ?type WHERE {
      ?entity env:name ?name ; env:id ?id ; env:type ?type .
      FILTER(?name = "${entityName}")
    } LIMIT 1
  `;
    const idResult = await executeSparqlQuery(idQuery);
    const rootBinding = idResult.results?.bindings?.[0];
    if (!rootBinding)
        return { found: false, entityName };
    const rootId = rootBinding.id.value;
    // Step 2: Find all directly connected entities (both directions)
    const directQuery = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    SELECT ?impactedId ?impactedName ?impactedType ?direction ?relationType ?integrationName WHERE {
      {
        ?rel env:type "Relationship" ;
             env:sourceEntityId "${rootId}" ;
             env:targetEntityId ?impactedId ;
             env:relationshipType ?relationType .
        OPTIONAL {
          ?rel env:name ?integrationName .
        }
        ?tgt env:id ?impactedId ; env:name ?impactedName ; env:type ?impactedType .
        BIND("downstream" AS ?direction)
      }
      UNION
      {
        ?rel env:type "Relationship" ;
             env:targetEntityId "${rootId}" ;
             env:sourceEntityId ?impactedId ;
             env:relationshipType ?relationType .
        OPTIONAL {
          ?rel env:name ?integrationName .
        }
        ?src env:id ?impactedId ; env:name ?impactedName ; env:type ?impactedType .
        BIND("upstream" AS ?direction)
      }
    }
  `;
    const directResult = await executeSparqlQuery(directQuery);
    const directBindings = directResult.results?.bindings || [];
    // Step 3: For each downstream entity, find THEIR downstream (2nd hop)
    const downstreamIds = directBindings
        .filter((b) => b.direction.value === 'downstream')
        .map((b) => b.impactedId.value);
    let transitiveBindings = [];
    if (maxDepth >= 2 && downstreamIds.length > 0) {
        const idValues = downstreamIds.map((id) => `"${id}"`).join(' ');
        const transitiveQuery = `
      PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
      SELECT ?hopSourceName ?impactedId ?impactedName ?impactedType ?relationType WHERE {
        VALUES ?hopSourceId { ${idValues} }
        ?rel env:type "Relationship" ;
             env:sourceEntityId ?hopSourceId ;
             env:targetEntityId ?impactedId ;
             env:relationshipType ?relationType .
        ?tgt env:id ?impactedId ; env:name ?impactedName ; env:type ?impactedType .
        ?hopSrc env:id ?hopSourceId ; env:name ?hopSourceName .
        FILTER(?impactedId != "${rootId}")
      }
    `;
        const transitiveResult = await executeSparqlQuery(transitiveQuery);
        transitiveBindings = transitiveResult.results?.bindings || [];
    }
    // Step 4: Get stats for impacted entities
    const allImpactedIds = new Set();
    directBindings.forEach((b) => allImpactedIds.add(b.impactedId.value));
    transitiveBindings.forEach((b) => allImpactedIds.add(b.impactedId.value));
    let impactedStats = [];
    if (allImpactedIds.size > 0) {
        const statsIdValues = Array.from(allImpactedIds).map(id => `"${id}"`).join(' ');
        const statsQuery = `
      PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
      SELECT ?id ?name ?currentState ?availability ?healthScore WHERE {
        VALUES ?id { ${statsIdValues} }
        ?entity env:id ?id ; env:name ?name .
        OPTIONAL { ?entity env:currentState ?currentState }
        OPTIONAL { ?entity env:availability ?availability }
        OPTIONAL { ?entity env:healthScore ?healthScore }
      }
    `;
        const statsResult = await executeSparqlQuery(statsQuery);
        impactedStats = statsResult.results?.bindings || [];
    }
    const statsMap = new Map();
    impactedStats.forEach((b) => {
        statsMap.set(b.id.value, {
            currentState: b.currentState?.value,
            availability: b.availability?.value,
            healthScore: b.healthScore?.value,
        });
    });
    return {
        found: true,
        root: {
            id: rootId,
            name: rootBinding.name.value,
            type: rootBinding.type.value,
        },
        directImpact: directBindings.map((b) => ({
            id: b.impactedId.value,
            name: b.impactedName.value,
            type: b.impactedType.value,
            direction: b.direction.value,
            relationType: b.relationType.value,
            integrationName: b.integrationName?.value || null,
            stats: statsMap.get(b.impactedId.value) || {},
        })),
        transitiveImpact: transitiveBindings.map((b) => ({
            id: b.impactedId.value,
            name: b.impactedName.value,
            type: b.impactedType.value,
            via: b.hopSourceName.value,
            relationType: b.relationType.value,
            stats: statsMap.get(b.impactedId.value) || {},
        })),
        totalImpacted: allImpactedIds.size,
    };
}
/**
 * Find single points of failure — entities with the most inbound dependencies
 */
async function getSinglePointsOfFailure(limit = 20) {
    const query = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    SELECT ?id ?name ?type (COUNT(DISTINCT ?rel) AS ?inboundCount) WHERE {
      ?rel env:type "Relationship" ;
           env:targetEntityId ?id .
      ?entity env:id ?id ;
              env:name ?name ;
              env:type ?type .
      FILTER(?type IN ("Environment", "Application", "Integration"))
    }
    GROUP BY ?id ?name ?type
    ORDER BY DESC(?inboundCount)
    LIMIT ${limit}
  `;
    return executeSparqlQuery(query);
}
/**
 * Find dependency chain — what does entity X depend on (full downstream tree)
 */
async function getDependencyChain(entityName) {
    // Get entity ID
    const idQuery = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    SELECT ?id WHERE {
      ?entity env:name "${entityName}" ; env:id ?id .
    } LIMIT 1
  `;
    const idResult = await executeSparqlQuery(idQuery);
    const rootId = idResult.results?.bindings?.[0]?.id?.value;
    if (!rootId)
        return { found: false, entityName };
    // Find outbound dependencies (what this entity calls)
    const depsQuery = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    SELECT ?depName ?depType ?relationType ?integrationName WHERE {
      ?rel env:type "Relationship" ;
           env:sourceEntityId "${rootId}" ;
           env:targetEntityId ?depId ;
           env:relationshipType ?relationType .
      OPTIONAL { ?rel env:name ?integrationName }
      ?dep env:id ?depId ; env:name ?depName ; env:type ?depType .
    }
  `;
    // Find inbound dependents (who calls this entity)
    const dependentsQuery = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    SELECT ?depName ?depType ?relationType ?integrationName WHERE {
      ?rel env:type "Relationship" ;
           env:targetEntityId "${rootId}" ;
           env:sourceEntityId ?depId ;
           env:relationshipType ?relationType .
      OPTIONAL { ?rel env:name ?integrationName }
      ?dep env:id ?depId ; env:name ?depName ; env:type ?depType .
    }
  `;
    const [depsResult, dependentsResult] = await Promise.all([
        executeSparqlQuery(depsQuery),
        executeSparqlQuery(dependentsQuery),
    ]);
    return {
        found: true,
        entityName,
        dependsOn: (depsResult.results?.bindings || []).map((b) => ({
            name: b.depName.value,
            type: b.depType.value,
            relationType: b.relationType.value,
            integrationName: b.integrationName?.value || null,
        })),
        dependedOnBy: (dependentsResult.results?.bindings || []).map((b) => ({
            name: b.depName.value,
            type: b.depType.value,
            relationType: b.relationType.value,
            integrationName: b.integrationName?.value || null,
        })),
    };
}
/**
 * Find isolated entities — no connections at all
 */
async function getIsolatedEntities() {
    const query = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    SELECT ?id ?name ?type ?owner WHERE {
      ?entity env:name ?name ; env:type ?type ; env:id ?id .
      FILTER(?type IN ("Environment", "Application"))
      FILTER NOT EXISTS {
        { ?rel env:type "Relationship" ; env:sourceEntityId ?id }
        UNION
        { ?rel env:type "Relationship" ; env:targetEntityId ?id }
      }
      OPTIONAL { ?entity env:owner ?owner }
    }
  `;
    return executeSparqlQuery(query);
}
/**
 * Find shared dependencies between two entities
 */
async function getSharedDependencies(entity1, entity2) {
    const query = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    SELECT ?sharedName ?sharedType ?rel1Type ?rel2Type WHERE {
      ?e1 env:name "${entity1}" ; env:id ?id1 .
      ?e2 env:name "${entity2}" ; env:id ?id2 .
      ?rel1 env:type "Relationship" ; env:sourceEntityId ?id1 ; env:targetEntityId ?sharedId ; env:relationshipType ?rel1Type .
      ?rel2 env:type "Relationship" ; env:sourceEntityId ?id2 ; env:targetEntityId ?sharedId ; env:relationshipType ?rel2Type .
      ?shared env:id ?sharedId ; env:name ?sharedName ; env:type ?sharedType .
    }
  `;
    return executeSparqlQuery(query);
}
/**
 * Get environment-level connectivity summary
 */
async function getConnectivitySummary() {
    const query = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    SELECT ?name ?type
           (COUNT(DISTINCT ?outRel) AS ?outbound)
           (COUNT(DISTINCT ?inRel) AS ?inbound)
    WHERE {
      ?entity env:name ?name ; env:type ?type ; env:id ?id .
      FILTER(?type IN ("Environment", "Application"))
      OPTIONAL {
        ?outRel env:type "Relationship" ; env:sourceEntityId ?id .
      }
      OPTIONAL {
        ?inRel env:type "Relationship" ; env:targetEntityId ?id .
      }
    }
    GROUP BY ?name ?type
    ORDER BY DESC(?outbound)
    LIMIT 50
  `;
    return executeSparqlQuery(query);
}
/**
 * Execute a direct SPARQL query to get stats/health for a specific entity
 */
async function getEntityStats(entityIdentifier) {
    // Try to find entity by name or ID
    const query = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>

    SELECT ?id ?name ?type ?status
           ?deviceName ?deviceDescription
           ?ipAddress ?deviceClass ?organization ?collectionMode
           ?deviceHostname ?managedType ?category ?subClass
           ?uptime ?collectionTime ?collectorGroup
           ?sourceId ?sourceSystem ?lastSyncedAt
           ?availability ?latency ?cpu ?memory ?swap ?currentState
           ?storage ?healthScore
    WHERE {
      ?entity env:name ?name ;
              env:id ?id ;
              env:type ?type .
      FILTER(?name = "${entityIdentifier}" || ?id = "${entityIdentifier}")
      OPTIONAL { ?entity env:status ?status }
      OPTIONAL { ?entity env:deviceName ?deviceName }
      OPTIONAL { ?entity env:deviceDescription ?deviceDescription }
      OPTIONAL { ?entity env:ipAddress ?ipAddress }
      OPTIONAL { ?entity env:deviceClass ?deviceClass }
      OPTIONAL { ?entity env:organization ?organization }
      OPTIONAL { ?entity env:collectionMode ?collectionMode }
      OPTIONAL { ?entity env:deviceHostname ?deviceHostname }
      OPTIONAL { ?entity env:managedType ?managedType }
      OPTIONAL { ?entity env:category ?category }
      OPTIONAL { ?entity env:subClass ?subClass }
      OPTIONAL { ?entity env:uptime ?uptime }
      OPTIONAL { ?entity env:collectionTime ?collectionTime }
      OPTIONAL { ?entity env:collectorGroup ?collectorGroup }
      OPTIONAL { ?entity env:sourceId ?sourceId }
      OPTIONAL { ?entity env:sourceSystem ?sourceSystem }
      OPTIONAL { ?entity env:lastSyncedAt ?lastSyncedAt }
      OPTIONAL { ?entity env:availability ?availability }
      OPTIONAL { ?entity env:latency ?latency }
      OPTIONAL { ?entity env:cpu ?cpu }
      OPTIONAL { ?entity env:memory ?memory }
      OPTIONAL { ?entity env:swap ?swap }
      OPTIONAL { ?entity env:currentState ?currentState }
      OPTIONAL { ?entity env:storage ?storage }
      OPTIONAL { ?entity env:healthScore ?healthScore }
    }
    LIMIT 1
  `;
    return executeSparqlQuery(query);
}
/**
 * Execute a direct SPARQL query to get health dashboard (all entities with stats)
 */
async function getHealthDashboard(entityType) {
    const typeFilter = entityType
        ? `FILTER(?type = "${entityType}")`
        : 'FILTER(?type IN ("Environment", "Application", "Integration"))';
    const query = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>

    SELECT ?id ?name ?type ?status
           ?deviceName ?deviceDescription
           ?currentState ?availability ?latency ?cpu ?memory ?swap
           ?ipAddress ?deviceClass ?organization ?category
           ?uptime ?collectorGroup ?sourceSystem ?lastSyncedAt
           ?storage ?healthScore
    WHERE {
      ?entity env:name ?name ;
              env:id ?id ;
              env:type ?type .
      ${typeFilter}
      OPTIONAL { ?entity env:status ?status }
      OPTIONAL { ?entity env:deviceName ?deviceName }
      OPTIONAL { ?entity env:deviceDescription ?deviceDescription }
      OPTIONAL { ?entity env:currentState ?currentState }
      OPTIONAL { ?entity env:availability ?availability }
      OPTIONAL { ?entity env:latency ?latency }
      OPTIONAL { ?entity env:cpu ?cpu }
      OPTIONAL { ?entity env:memory ?memory }
      OPTIONAL { ?entity env:swap ?swap }
      OPTIONAL { ?entity env:ipAddress ?ipAddress }
      OPTIONAL { ?entity env:deviceClass ?deviceClass }
      OPTIONAL { ?entity env:organization ?organization }
      OPTIONAL { ?entity env:category ?category }
      OPTIONAL { ?entity env:uptime ?uptime }
      OPTIONAL { ?entity env:collectorGroup ?collectorGroup }
      OPTIONAL { ?entity env:sourceSystem ?sourceSystem }
      OPTIONAL { ?entity env:lastSyncedAt ?lastSyncedAt }
      OPTIONAL { ?entity env:storage ?storage }
      OPTIONAL { ?entity env:healthScore ?healthScore }
    }
    ORDER BY DESC(?healthScore)
    LIMIT 200
  `;
    return executeSparqlQuery(query);
}
/**
 * Parse stats from a SPARQL result binding into a structured stats object
 */
function parseStatsFromBinding(binding) {
    const stats = {};
    for (const prop of STAT_PROPERTIES) {
        if (binding[prop]?.value) {
            stats[prop] = binding[prop].value;
        }
    }
    return stats;
}
/**
 * Format entity stats into a human-readable summary
 */
function formatEntityStats(binding) {
    const name = binding.name?.value || 'Unknown';
    const type = binding.type?.value || 'Unknown';
    const status = binding.status?.value || 'unknown';
    const stats = parseStatsFromBinding(binding);
    let formatted = `Entity: ${name} (${type}) [${status}]\n`;
    if (Object.keys(stats).length === 0) {
        formatted += '  No ScienceLogic data available.\n';
        return formatted;
    }
    // Current state / health
    if (stats.currentState)
        formatted += `  Current State: ${stats.currentState}\n`;
    if (stats.healthScore)
        formatted += `  Health Score: ${stats.healthScore}\n`;
    // Performance stats
    if (stats.availability)
        formatted += `  Availability: ${stats.availability}%\n`;
    if (stats.latency)
        formatted += `  Latency: ${stats.latency}ms\n`;
    if (stats.cpu)
        formatted += `  CPU: ${stats.cpu}%\n`;
    if (stats.memory)
        formatted += `  Memory: ${stats.memory}%\n`;
    if (stats.swap)
        formatted += `  Swap: ${stats.swap}%\n`;
    if (stats.storage)
        formatted += `  Storage: ${stats.storage}%\n`;
    // Device meta
    if (stats.deviceName)
        formatted += `  Device Name: ${stats.deviceName}\n`;
    if (stats.deviceDescription)
        formatted += `  Description: ${stats.deviceDescription}\n`;
    if (stats.ipAddress)
        formatted += `  IP Address: ${stats.ipAddress}\n`;
    if (stats.deviceHostname)
        formatted += `  Hostname: ${stats.deviceHostname}\n`;
    if (stats.deviceClass)
        formatted += `  Device Class: ${stats.deviceClass}\n`;
    if (stats.subClass)
        formatted += `  Sub-Class: ${stats.subClass}\n`;
    if (stats.category)
        formatted += `  Category: ${stats.category}\n`;
    if (stats.organization)
        formatted += `  Organization: ${stats.organization}\n`;
    if (stats.managedType)
        formatted += `  Managed Type: ${stats.managedType}\n`;
    if (stats.collectionMode)
        formatted += `  Collection Mode: ${stats.collectionMode}\n`;
    if (stats.uptime)
        formatted += `  Uptime: ${stats.uptime}\n`;
    if (stats.collectionTime)
        formatted += `  Collection Time: ${stats.collectionTime}\n`;
    if (stats.collectorGroup)
        formatted += `  Collector Group: ${stats.collectorGroup}\n`;
    if (stats.sourceSystem)
        formatted += `  Source System: ${stats.sourceSystem}\n`;
    if (stats.lastSyncedAt)
        formatted += `  Last Synced: ${stats.lastSyncedAt}\n`;
    return formatted;
}
/**
 * Format Neptune results into human-readable response
 */
function formatResults(results, userQuery) {
    if (!results.results?.bindings?.length) {
        return 'No results found.';
    }
    const bindings = results.results.bindings;
    const count = bindings.length;
    // For count queries
    if (bindings[0].count) {
        return `Found ${bindings[0].count.value} results.`;
    }
    // Detect if this is a stats/health query by checking for stats fields
    const hasStatsFields = bindings.some((b) => STAT_PROPERTIES.some(prop => b[prop]?.value));
    if (hasStatsFields) {
        let formatted = `Health/Stats Report (${count} entit${count > 1 ? 'ies' : 'y'}):\n\n`;
        bindings.slice(0, 30).forEach((binding) => {
            formatted += formatEntityStats(binding) + '\n';
        });
        if (count > 30) {
            formatted += `\n... and ${count - 30} more entities.`;
        }
        return formatted.trim();
    }
    // For entity lists
    let formatted = `Found ${count} result${count > 1 ? 's' : ''}:\n\n`;
    bindings.slice(0, 20).forEach((binding, index) => {
        formatted += `${index + 1}. `;
        // Extract key fields
        const fields = [];
        if (binding.name)
            fields.push(binding.name.value);
        if (binding.type)
            fields.push(`(${binding.type.value})`);
        if (binding.status)
            fields.push(`[${binding.status.value}]`);
        if (binding.owner)
            fields.push(`Owner: ${binding.owner.value}`);
        if (binding.description)
            fields.push(binding.description.value);
        // For relationship queries
        if (binding.source && binding.target) {
            fields.push(`${binding.source.value} → ${binding.relType?.value || 'relates to'} → ${binding.target.value}`);
        }
        // For config queries
        if (binding.key && binding.value) {
            fields.push(`${binding.key.value}: ${binding.value.value}`);
        }
        formatted += fields.join(' | ') + '\n';
    });
    if (count > 20) {
        formatted += `\n... and ${count - 20} more results.`;
    }
    return formatted.trim();
}
/**
 * Main Lambda handler
 */
const handler = async (event) => {
    console.log('Event:', JSON.stringify(event, null, 2));
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, Accept, Origin, X-Requested-With, x-api-key',
    };
    try {
        // Handle CORS preflight
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ message: 'CORS preflight successful' }),
            };
        }
        // Parse request body
        let body = {};
        if (event.body) {
            body = JSON.parse(event.body);
        }
        // Determine the operation type from path or body/query params
        const path = event.path || event.resource || '';
        let operation;
        if (path.includes('/stats')) {
            operation = 'entity-stats';
        }
        else if (path.includes('/health-dashboard')) {
            operation = 'health-dashboard';
        }
        else {
            operation = body.operation || event.queryStringParameters?.operation || 'query';
        }
        const userQuery = body.query || event.queryStringParameters?.query;
        const entityId = body.entityId || event.queryStringParameters?.entityId;
        const entityName = body.entityName || event.queryStringParameters?.entityName;
        const entityType = body.entityType || event.queryStringParameters?.entityType;
        console.log(`Operation: ${operation}`);
        // Handle different operations
        switch (operation.toLowerCase()) {
            // --- Direct entity stats/health endpoint ---
            case 'entity-stats': {
                const identifier = entityName || entityId;
                if (!identifier) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing required parameter: entityName or entityId',
                            example: { operation: 'entity-stats', entityName: 'CAS_QA' },
                        }),
                    };
                }
                console.log(`Fetching stats for entity: ${identifier}`);
                const statsResults = await getEntityStats(identifier);
                const bindings = statsResults.results?.bindings || [];
                if (bindings.length === 0) {
                    return {
                        statusCode: 404,
                        headers,
                        body: JSON.stringify({
                            success: false,
                            error: `Entity not found: ${identifier}`,
                        }),
                    };
                }
                const binding = bindings[0];
                const stats = parseStatsFromBinding(binding);
                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        success: true,
                        operation: 'entity-stats',
                        entity: {
                            id: binding.id?.value,
                            name: binding.name?.value,
                            type: binding.type?.value,
                            status: binding.status?.value,
                        },
                        stats,
                        hasStats: Object.keys(stats).length > 0,
                        formatted: formatEntityStats(binding),
                        timestamp: new Date().toISOString(),
                    }),
                };
            }
            // --- Health dashboard endpoint ---
            case 'health-dashboard': {
                console.log(`Fetching health dashboard${entityType ? ` for type: ${entityType}` : ''}`);
                const dashResults = await getHealthDashboard(entityType);
                const dashBindings = dashResults.results?.bindings || [];
                const entities = dashBindings.map((binding) => ({
                    id: binding.id?.value,
                    name: binding.name?.value,
                    type: binding.type?.value,
                    status: binding.status?.value,
                    stats: parseStatsFromBinding(binding),
                }));
                const withStats = entities.filter((e) => Object.keys(e.stats).length > 0);
                const unhealthy = entities.filter((e) => {
                    const score = parseFloat(e.stats.healthScore);
                    return !isNaN(score) && score < 80;
                });
                // Compute aggregate summary
                const avgHealthScore = withStats.length > 0
                    ? withStats.reduce((sum, e) => {
                        const score = parseFloat(e.stats.healthScore);
                        return sum + (isNaN(score) ? 0 : score);
                    }, 0) / withStats.filter((e) => e.stats.healthScore).length || 0
                    : null;
                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        success: true,
                        operation: 'health-dashboard',
                        summary: {
                            totalEntities: entities.length,
                            entitiesWithStats: withStats.length,
                            unhealthyEntities: unhealthy.length,
                            averageHealthScore: avgHealthScore ? Math.round(avgHealthScore * 100) / 100 : null,
                        },
                        entities,
                        unhealthy,
                        timestamp: new Date().toISOString(),
                    }),
                };
            }
            // --- Blast radius / impact analysis ---
            case 'blast-radius': {
                const target = entityName || body.entity || userQuery;
                if (!target) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({ error: 'Missing required parameter: entityName', example: { operation: 'blast-radius', entityName: 'payment-gateway-prod' } }),
                    };
                }
                console.log(`Blast radius analysis for: ${target}`);
                const blastResult = await getBlastRadius(target, body.maxDepth || 3);
                if (!blastResult.found) {
                    return { statusCode: 404, headers, body: JSON.stringify({ success: false, error: `Entity not found: ${target}` }) };
                }
                const downstream = blastResult.directImpact.filter((e) => e.direction === 'downstream');
                const upstream = blastResult.directImpact.filter((e) => e.direction === 'upstream');
                let formatted = `BLAST RADIUS ANALYSIS: ${blastResult.root.name} (${blastResult.root.type})\n`;
                formatted += `${'='.repeat(60)}\n\n`;
                formatted += `If "${blastResult.root.name}" goes down:\n\n`;
                formatted += `DIRECT DOWNSTREAM IMPACT (${downstream.length} entities affected):\n`;
                downstream.forEach((e) => {
                    formatted += `  → ${e.name} (${e.type}) via ${e.relationType}`;
                    if (e.stats?.currentState)
                        formatted += ` [${e.stats.currentState}]`;
                    formatted += '\n';
                });
                formatted += `\nUPSTREAM DEPENDENTS (${upstream.length} entities that call this):\n`;
                upstream.forEach((e) => {
                    formatted += `  ← ${e.name} (${e.type}) via ${e.relationType}`;
                    if (e.stats?.currentState)
                        formatted += ` [${e.stats.currentState}]`;
                    formatted += '\n';
                });
                if (blastResult.transitiveImpact.length > 0) {
                    formatted += `\nTRANSITIVE IMPACT (${blastResult.transitiveImpact.length} 2nd-hop entities):\n`;
                    blastResult.transitiveImpact.forEach((e) => {
                        formatted += `  →→ ${e.name} (${e.type}) via ${e.via}\n`;
                    });
                }
                formatted += `\nTOTAL BLAST RADIUS: ${blastResult.totalImpacted} entities impacted`;
                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        success: true,
                        operation: 'blast-radius',
                        root: blastResult.root,
                        directImpact: blastResult.directImpact,
                        transitiveImpact: blastResult.transitiveImpact,
                        summary: {
                            totalImpacted: blastResult.totalImpacted,
                            downstreamCount: downstream.length,
                            upstreamCount: upstream.length,
                            transitiveCount: blastResult.transitiveImpact.length,
                        },
                        formatted,
                        timestamp: new Date().toISOString(),
                    }),
                };
            }
            // --- Dependency chain ---
            case 'dependency-chain': {
                const target = entityName || body.entity || userQuery;
                if (!target) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({ error: 'Missing required parameter: entityName', example: { operation: 'dependency-chain', entityName: 'web-portal-prod' } }),
                    };
                }
                console.log(`Dependency chain for: ${target}`);
                const chainResult = await getDependencyChain(target);
                if (!chainResult.found) {
                    return { statusCode: 404, headers, body: JSON.stringify({ success: false, error: `Entity not found: ${target}` }) };
                }
                let formatted = `DEPENDENCY CHAIN: ${target}\n${'='.repeat(50)}\n\n`;
                formatted += `DEPENDS ON (${chainResult.dependsOn.length} outbound):\n`;
                chainResult.dependsOn.forEach((d) => {
                    formatted += `  → ${d.name} (${d.type}) [${d.relationType}]`;
                    if (d.integrationName)
                        formatted += ` via ${d.integrationName}`;
                    formatted += '\n';
                });
                formatted += `\nDEPENDED ON BY (${chainResult.dependedOnBy.length} inbound):\n`;
                chainResult.dependedOnBy.forEach((d) => {
                    formatted += `  ← ${d.name} (${d.type}) [${d.relationType}]`;
                    if (d.integrationName)
                        formatted += ` via ${d.integrationName}`;
                    formatted += '\n';
                });
                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        success: true,
                        operation: 'dependency-chain',
                        entityName: target,
                        dependsOn: chainResult.dependsOn,
                        dependedOnBy: chainResult.dependedOnBy,
                        formatted,
                        timestamp: new Date().toISOString(),
                    }),
                };
            }
            // --- Single points of failure ---
            case 'single-points-of-failure':
            case 'spof': {
                console.log('Finding single points of failure');
                const spofResult = await getSinglePointsOfFailure(body.limit || 20);
                const bindings = spofResult.results?.bindings || [];
                let formatted = `SINGLE POINTS OF FAILURE (Top ${bindings.length})\n${'='.repeat(50)}\n\n`;
                formatted += 'Entities with the most inbound dependencies (highest risk):\n\n';
                bindings.forEach((b, i) => {
                    formatted += `${i + 1}. ${b.name.value} (${b.type.value}) — ${b.inboundCount.value} dependents\n`;
                });
                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        success: true,
                        operation: 'single-points-of-failure',
                        entities: bindings.map((b) => ({
                            id: b.id.value,
                            name: b.name.value,
                            type: b.type.value,
                            inboundCount: parseInt(b.inboundCount.value),
                        })),
                        formatted,
                        timestamp: new Date().toISOString(),
                    }),
                };
            }
            // --- Isolated entities ---
            case 'isolated-entities': {
                console.log('Finding isolated entities');
                const isoResult = await getIsolatedEntities();
                const bindings = isoResult.results?.bindings || [];
                let formatted = `ISOLATED ENTITIES (${bindings.length} with no connections)\n${'='.repeat(50)}\n\n`;
                bindings.forEach((b, i) => {
                    formatted += `${i + 1}. ${b.name.value} (${b.type.value})`;
                    if (b.owner?.value)
                        formatted += ` — Owner: ${b.owner.value}`;
                    formatted += '\n';
                });
                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        success: true,
                        operation: 'isolated-entities',
                        entities: bindings.map((b) => ({
                            id: b.id.value,
                            name: b.name.value,
                            type: b.type.value,
                            owner: b.owner?.value || null,
                        })),
                        count: bindings.length,
                        formatted,
                        timestamp: new Date().toISOString(),
                    }),
                };
            }
            // --- Shared dependencies ---
            case 'shared-dependencies': {
                const entity1 = entityName || body.entity1;
                const entity2 = body.entity2Name || body.entity2;
                if (!entity1 || !entity2) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({ error: 'Missing parameters: entityName and entity2Name', example: { operation: 'shared-dependencies', entityName: 'web-portal-prod', entity2Name: 'order-mgmt-prod' } }),
                    };
                }
                console.log(`Shared dependencies between: ${entity1} and ${entity2}`);
                const sharedResult = await getSharedDependencies(entity1, entity2);
                const bindings = sharedResult.results?.bindings || [];
                let formatted = `SHARED DEPENDENCIES: ${entity1} ↔ ${entity2}\n${'='.repeat(50)}\n\n`;
                if (bindings.length === 0) {
                    formatted += 'No shared dependencies found.';
                }
                else {
                    formatted += `Found ${bindings.length} shared dependencie(s):\n\n`;
                    bindings.forEach((b, i) => {
                        formatted += `${i + 1}. ${b.sharedName.value} (${b.sharedType.value})\n`;
                        formatted += `   ${entity1} → [${b.rel1Type.value}] → ${b.sharedName.value}\n`;
                        formatted += `   ${entity2} → [${b.rel2Type.value}] → ${b.sharedName.value}\n\n`;
                    });
                }
                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        success: true,
                        operation: 'shared-dependencies',
                        entity1,
                        entity2,
                        sharedDependencies: bindings.map((b) => ({
                            name: b.sharedName.value,
                            type: b.sharedType.value,
                            relation1Type: b.rel1Type.value,
                            relation2Type: b.rel2Type.value,
                        })),
                        count: bindings.length,
                        formatted,
                        timestamp: new Date().toISOString(),
                    }),
                };
            }
            // --- Connectivity summary ---
            case 'connectivity-summary': {
                console.log('Getting connectivity summary');
                const connResult = await getConnectivitySummary();
                const bindings = connResult.results?.bindings || [];
                let formatted = `CONNECTIVITY SUMMARY\n${'='.repeat(50)}\n\n`;
                formatted += 'Entity                          | Type        | Out | In\n';
                formatted += '-'.repeat(65) + '\n';
                bindings.forEach((b) => {
                    const name = b.name.value.padEnd(32);
                    const type = b.type.value.padEnd(12);
                    formatted += `${name}| ${type}| ${b.outbound.value.padStart(3)} | ${b.inbound.value.padStart(3)}\n`;
                });
                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        success: true,
                        operation: 'connectivity-summary',
                        entities: bindings.map((b) => ({
                            name: b.name.value,
                            type: b.type.value,
                            outbound: parseInt(b.outbound.value),
                            inbound: parseInt(b.inbound.value),
                            total: parseInt(b.outbound.value) + parseInt(b.inbound.value),
                        })),
                        count: bindings.length,
                        formatted,
                        timestamp: new Date().toISOString(),
                    }),
                };
            }
            // --- Default: natural language query via Bedrock ---
            case 'query':
            default: {
                if (!userQuery) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing required parameter: query',
                            availableOperations: [
                                { operation: 'query', description: 'Natural language query via Bedrock AI', params: ['query'] },
                                { operation: 'entity-stats', description: 'Get stats/health for a specific entity', params: ['entityName or entityId'] },
                                { operation: 'health-dashboard', description: 'Get health overview of all entities', params: ['entityType (optional)'] },
                                { operation: 'blast-radius', description: 'Impact analysis if an entity goes down', params: ['entityName'] },
                                { operation: 'dependency-chain', description: 'Show what depends on / is depended on by an entity', params: ['entityName'] },
                                { operation: 'single-points-of-failure', description: 'Find entities with the most inbound dependencies (risky)', params: [] },
                                { operation: 'isolated-entities', description: 'Find entities with no connections', params: [] },
                                { operation: 'shared-dependencies', description: 'Find common dependencies between two entities', params: ['entityName', 'entity2Name'] },
                                { operation: 'connectivity-summary', description: 'Overview of connection counts per entity', params: [] },
                            ],
                            example: { query: 'Show all active environments' },
                        }),
                    };
                }
                console.log(`User query: ${userQuery}`);
                // Step 1: Generate SPARQL using Bedrock
                const sparqlQuery = await generateSparqlWithBedrock(userQuery);
                // Step 2: Execute SPARQL on Neptune
                const results = await executeSparqlQuery(sparqlQuery);
                // Step 3: Format results
                const formattedResponse = formatResults(results, userQuery);
                // Return response
                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        success: true,
                        operation: 'query',
                        query: userQuery,
                        sparql: sparqlQuery,
                        resultCount: results.results?.bindings?.length || 0,
                        results: results.results?.bindings || [],
                        formatted: formattedResponse,
                        timestamp: new Date().toISOString(),
                    }),
                };
            }
        }
    }
    catch (error) {
        console.error('Handler error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                success: false,
                error: error.message,
                timestamp: new Date().toISOString(),
            }),
        };
    }
};
exports.handler = handler;
