import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as s3n from 'aws-cdk-lib/aws-s3-notifications';
import * as logs from 'aws-cdk-lib/aws-logs';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as events from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
import { Construct } from 'constructs';
import { execSync } from 'child_process';
import * as path from 'path';

export interface PceDiscoveryStackProps extends cdk.StackProps {
  neptuneClusterEndpoint: string;
  neptuneVpc: ec2.IVpc;
  neptuneSecurityGroup: ec2.ISecurityGroup;
  neptuneSubnets: ec2.ISubnet[];
  /** Cron schedule for PCE database polling (default: every 6 hours) */
  scheduleExpression?: string;
  /** PostgreSQL connection config — stored in env vars (use Secrets Manager in production) */
  pceDbHost?: string;
  pceDbPort?: string;
  pceDbName?: string;
  pceDbUser?: string;
  pceDbPassword?: string;
  pceDbTable?: string;
}

export class PceDiscoveryStack extends cdk.Stack {
  public readonly discoveryLambda: lambda.Function;
  public readonly csvBucket: s3.Bucket;
  public readonly aliasTable: dynamodb.Table;
  public readonly discoveryApi: apigateway.RestApi;

  constructor(scope: Construct, id: string, props: PceDiscoveryStackProps) {
    super(scope, id, props);

    // --- DynamoDB: Hostname → Environment alias map ---
    this.aliasTable = new dynamodb.Table(this, 'HostnameAliasTable', {
      tableName: `${this.stackName}-hostname-aliases`,
      partitionKey: { name: 'hostname', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
    });

    // --- S3: CSV upload bucket ---
    this.csvBucket = new s3.Bucket(this, 'PceCsvBucket', {
      bucketName: `${this.stackName.toLowerCase()}-pce-csv-uploads`,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
      autoDeleteObjects: true,
      lifecycleRules: [
        {
          prefix: 'processed/',
          expiration: cdk.Duration.days(30),
        },
      ],
    });

    // --- IAM Role ---
    const lambdaRole = new iam.Role(this, 'PceDiscoveryLambdaRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaVPCAccessExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
      ],
    });

    // Neptune permissions
    lambdaRole.addToPolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'neptune-db:ReadDataViaQuery',
        'neptune-db:WriteDataViaQuery',
        'neptune-db:DeleteDataViaQuery',
        'neptune-db:connect',
      ],
      resources: [`arn:aws:neptune-db:${this.region}:${this.account}:*/*`],
    }));

    // S3 permissions
    this.csvBucket.grantReadWrite(lambdaRole);

    // DynamoDB permissions
    this.aliasTable.grantReadData(lambdaRole);

    // --- Lambda Function ---
    // Reuse Neptune security group directly (same pattern as Bedrock stack)
    // to avoid cross-stack dependency cycles
    this.discoveryLambda = new lambda.Function(this, 'PceDiscoveryLambda', {
      functionName: 'PCE-Discovery-Pipeline',
      runtime: lambda.Runtime.NODEJS_20_X,
      handler: 'src/pce-discovery.handler',
      code: lambda.Code.fromAsset('./lambdas', {
        bundling: {
          image: lambda.Runtime.NODEJS_20_X.bundlingImage,
          command: [
            'bash', '-c',
            'cp -r /asset-input/dist/* /asset-output/ && ' +
            'cp -r /asset-input/node_modules /asset-output/',
          ],
          local: {
            tryBundle(outputDir: string) {
              try {
                execSync(`cp -r ${path.resolve('./lambdas/dist')}/* ${outputDir}/`);
                execSync(`cp -r ${path.resolve('./lambdas/node_modules')} ${outputDir}/`);
                return true;
              } catch { return false; }
            },
          },
        },
      }),
      role: lambdaRole,
      timeout: cdk.Duration.minutes(5),
      memorySize: 512,
      vpc: props.neptuneVpc,
      securityGroups: [props.neptuneSecurityGroup],
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      environment: {
        NEPTUNE_ENDPOINT: props.neptuneClusterEndpoint,
        NEPTUNE_PORT: '8182',
        ALIAS_TABLE_NAME: this.aliasTable.tableName,
        AUTO_CREATE_ENVIRONMENTS: 'true',
        AWS_NODEJS_CONNECTION_REUSE_ENABLED: '1',
        USE_IAM: 'true',
        // PCE DB connection — set these when you have database access
        PCE_DB_HOST: props.pceDbHost || '',
        PCE_DB_PORT: props.pceDbPort || '5432',
        PCE_DB_NAME: props.pceDbName || 'pce',
        PCE_DB_USER: props.pceDbUser || 'pce_reader',
        PCE_DB_PASSWORD: props.pceDbPassword || '',
        PCE_DB_TABLE: props.pceDbTable || 'pce_properties',
        PCE_DB_SSL: 'true',
      },
      logGroup: new logs.LogGroup(this, 'PceDiscoveryLogGroup', {
        retention: logs.RetentionDays.ONE_WEEK,
        removalPolicy: cdk.RemovalPolicy.DESTROY,
      }),
    });

    // --- S3 Notification: trigger Lambda on CSV upload ---
    this.csvBucket.addEventNotification(
      s3.EventType.OBJECT_CREATED,
      new s3n.LambdaDestination(this.discoveryLambda),
      { prefix: 'uploads/', suffix: '.csv' }
    );

    // --- EventBridge: scheduled PCE database polling ---
    const schedule = props.scheduleExpression || 'rate(6 hours)';
    new events.Rule(this, 'PceScheduleRule', {
      ruleName: `${this.stackName}-pce-schedule`,
      schedule: events.Schedule.expression(schedule),
      targets: [new targets.LambdaFunction(this.discoveryLambda)],
      enabled: !!props.pceDbHost, // Only enable if DB host is configured
    });

    // --- API Gateway: CSV upload endpoint ---
    this.discoveryApi = new apigateway.RestApi(this, 'PceDiscoveryApi', {
      restApiName: 'PCE Discovery API',
      description: 'Upload CSV for PCE environment discovery',
      defaultCorsPreflightOptions: {
        allowOrigins: apigateway.Cors.ALL_ORIGINS,
        allowMethods: ['POST', 'OPTIONS'],
        allowHeaders: ['Content-Type'],
      },
    });

    const discoveryResource = this.discoveryApi.root.addResource('pce-discovery');
    const uploadResource = discoveryResource.addResource('upload-csv');
    uploadResource.addMethod('POST', new apigateway.LambdaIntegration(this.discoveryLambda), {
      authorizationType: apigateway.AuthorizationType.NONE,
    });

    // --- Outputs ---
    new cdk.CfnOutput(this, 'CsvBucketName', {
      value: this.csvBucket.bucketName,
      description: 'S3 bucket for CSV uploads (put files in uploads/ prefix)',
    });

    new cdk.CfnOutput(this, 'UploadApiEndpoint', {
      value: `${this.discoveryApi.url}pce-discovery/upload-csv`,
      description: 'API endpoint for CSV upload',
    });

    new cdk.CfnOutput(this, 'AliasTableName', {
      value: this.aliasTable.tableName,
      description: 'DynamoDB table for hostname → environment aliases',
    });
  }
}
