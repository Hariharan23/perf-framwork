import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as s3n from 'aws-cdk-lib/aws-s3-notifications';
import * as logs from 'aws-cdk-lib/aws-logs';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import { Construct } from 'constructs';
import { execSync } from 'child_process';
import * as path from 'path';

export interface PceDiscoveryStackProps extends cdk.StackProps {
  neptuneClusterEndpoint: string;
  neptuneVpc: ec2.IVpc;
  neptuneSecurityGroup: ec2.ISecurityGroup;
  neptuneSubnets: ec2.ISubnet[];
}

export class PceDiscoveryStack extends cdk.Stack {
  public readonly discoveryLambda: lambda.Function;
  public readonly csvBucket: s3.Bucket;
  public readonly aliasTable: dynamodb.Table;
  public readonly discoveryApi: apigateway.RestApi;

  constructor(scope: Construct, id: string, props: PceDiscoveryStackProps) {
    super(scope, id, props);

    // --- DynamoDB: Hostname → Environment alias map ---
    this.aliasTable = new dynamodb.Table(this, 'HostnameAliasTable', {
      tableName: `${this.stackName}-hostname-aliases`,
      partitionKey: { name: 'hostname', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
    });

    // --- S3: CSV upload bucket ---
    this.csvBucket = new s3.Bucket(this, 'PceCsvBucket', {
      bucketName: `${this.stackName.toLowerCase()}-pce-csv-uploads`,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
      autoDeleteObjects: true,
      lifecycleRules: [
        {
          prefix: 'processed/',
          expiration: cdk.Duration.days(30),
        },
      ],
    });

    // --- IAM Role ---
    const lambdaRole = new iam.Role(this, 'PceDiscoveryLambdaRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaVPCAccessExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
      ],
    });

    // Neptune permissions
    lambdaRole.addToPolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'neptune-db:ReadDataViaQuery',
        'neptune-db:WriteDataViaQuery',
        'neptune-db:DeleteDataViaQuery',
        'neptune-db:connect',
      ],
      resources: [`arn:aws:neptune-db:${this.region}:${this.account}:*/*`],
    }));

    // S3 permissions
    this.csvBucket.grantReadWrite(lambdaRole);

    // DynamoDB permissions
    this.aliasTable.grantReadData(lambdaRole);

    // --- Lambda Function ---
    // Reuse Neptune security group directly (same pattern as Bedrock stack)
    // to avoid cross-stack dependency cycles
    this.discoveryLambda = new lambda.Function(this, 'PceDiscoveryLambda', {
      functionName: 'PCE-Discovery-Pipeline',
      runtime: lambda.Runtime.NODEJS_20_X,
      handler: 'src/pce-discovery.handler',
      code: lambda.Code.fromAsset('./lambdas', {
        bundling: {
          image: lambda.Runtime.NODEJS_20_X.bundlingImage,
          command: [
            'bash', '-c',
            'cp -r /asset-input/dist/* /asset-output/ && ' +
            'cp -r /asset-input/node_modules /asset-output/',
          ],
          local: {
            tryBundle(outputDir: string) {
              try {
                execSync(`cp -r ${path.resolve('./lambdas/dist')}/* ${outputDir}/`);
                execSync(`cp -r ${path.resolve('./lambdas/node_modules')} ${outputDir}/`);
                return true;
              } catch { return false; }
            },
          },
        },
      }),
      role: lambdaRole,
      timeout: cdk.Duration.minutes(5),
      memorySize: 512,
      vpc: props.neptuneVpc,
      securityGroups: [props.neptuneSecurityGroup],
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      environment: {
        NEPTUNE_ENDPOINT: props.neptuneClusterEndpoint,
        NEPTUNE_PORT: '8182',
        ALIAS_TABLE_NAME: this.aliasTable.tableName,
        AUTO_CREATE_ENVIRONMENTS: 'true',
        AWS_NODEJS_CONNECTION_REUSE_ENABLED: '1',
        USE_IAM: 'true',
      },
      logGroup: new logs.LogGroup(this, 'PceDiscoveryLogGroup', {
        retention: logs.RetentionDays.ONE_WEEK,
        removalPolicy: cdk.RemovalPolicy.DESTROY,
      }),
    });

    // --- S3 Notification: trigger Lambda on CSV upload ---
    this.csvBucket.addEventNotification(
      s3.EventType.OBJECT_CREATED,
      new s3n.LambdaDestination(this.discoveryLambda),
      { prefix: 'uploads/', suffix: '.csv' }
    );

    // --- API Gateway: CSV upload endpoint ---
    this.discoveryApi = new apigateway.RestApi(this, 'PceDiscoveryApi', {
      restApiName: 'PCE Discovery API',
      description: 'Upload CSV for PCE environment discovery',
      defaultCorsPreflightOptions: {
        allowOrigins: apigateway.Cors.ALL_ORIGINS,
        allowMethods: ['GET', 'POST', 'OPTIONS'],
        allowHeaders: ['Content-Type', 'Authorization', 'Accept', 'Origin', 'X-Requested-With', 'X-Api-Key', 'x-api-key'],
      },
    });

    const discoveryResource = this.discoveryApi.root.addResource('pce-discovery');
    const uploadResource = discoveryResource.addResource('upload-csv');
    uploadResource.addMethod('POST', new apigateway.LambdaIntegration(this.discoveryLambda), {
      apiKeyRequired: true,
    });
    uploadResource.addMethod('GET', new apigateway.LambdaIntegration(this.discoveryLambda), {
      apiKeyRequired: true,
    });

    // API Key + Usage Plan
    const apiKey = this.discoveryApi.addApiKey('PceDiscoveryApiKey', {
      apiKeyName: 'ems-pce-discovery-api-key',
      description: 'API key for PCE Discovery API',
    });
    const usagePlan = this.discoveryApi.addUsagePlan('PceDiscoveryUsagePlan', {
      name: 'ems-pce-discovery-usage-plan',
      throttle: { rateLimit: 10, burstLimit: 20 },
      quota: { limit: 1000, period: apigateway.Period.DAY },
    });
    usagePlan.addApiKey(apiKey);
    usagePlan.addApiStage({ stage: this.discoveryApi.deploymentStage });

    // Gateway Responses — ensure CORS headers on API Gateway-generated errors
    this.discoveryApi.addGatewayResponse('Pce4xxCors', {
      type: apigateway.ResponseType.DEFAULT_4XX,
      responseHeaders: {
        'Access-Control-Allow-Origin': "'*'",
        'Access-Control-Allow-Headers': "'Content-Type,Authorization,Accept,Origin,X-Requested-With,X-Api-Key,x-api-key'",
        'Access-Control-Allow-Methods': "'GET,POST,OPTIONS'",
      },
    });
    this.discoveryApi.addGatewayResponse('Pce5xxCors', {
      type: apigateway.ResponseType.DEFAULT_5XX,
      responseHeaders: {
        'Access-Control-Allow-Origin': "'*'",
        'Access-Control-Allow-Headers': "'Content-Type,Authorization,Accept,Origin,X-Requested-With,X-Api-Key,x-api-key'",
        'Access-Control-Allow-Methods': "'GET,POST,OPTIONS'",
      },
    });

    // --- Outputs ---
    new cdk.CfnOutput(this, 'CsvBucketName', {
      value: this.csvBucket.bucketName,
      description: 'S3 bucket for CSV uploads (put files in uploads/ prefix)',
    });

    new cdk.CfnOutput(this, 'UploadApiEndpoint', {
      value: `${this.discoveryApi.url}pce-discovery/upload-csv`,
      description: 'API endpoint for CSV upload',
    });

    new cdk.CfnOutput(this, 'AliasTableName', {
      value: this.aliasTable.tableName,
      description: 'DynamoDB table for hostname → environment aliases',
    });
  }
}
