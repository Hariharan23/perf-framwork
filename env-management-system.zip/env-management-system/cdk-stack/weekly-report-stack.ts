import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as logs from 'aws-cdk-lib/aws-logs';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as events from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
import { Construct } from 'constructs';
import { execSync } from 'child_process';
import * as path from 'path';

export interface WeeklyReportStackProps extends cdk.StackProps {
  neptuneClusterEndpoint: string;
  neptuneVpc: ec2.IVpc;
  neptuneSecurityGroup: ec2.ISecurityGroup;
  neptuneSubnets: ec2.ISubnet[];
  /** Cron schedule for weekly reports (default: Monday 8am UTC) */
  weeklySchedule?: string;
  /** Comma-separated list of owners to generate weekly reports for (empty = auto-discover) */
  defaultOwners?: string;
}

export class WeeklyReportStack extends cdk.Stack {
  public readonly reportLambda: lambda.Function;
  public readonly reportBucket: s3.Bucket;
  public readonly reportApi: apigateway.RestApi;

  constructor(scope: Construct, id: string, props: WeeklyReportStackProps) {
    super(scope, id, props);

    // --- S3: Report storage ---
    this.reportBucket = new s3.Bucket(this, 'ReportBucket', {
      bucketName: `${this.stackName.toLowerCase()}-reports`,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
      autoDeleteObjects: true,
      lifecycleRules: [
        {
          prefix: 'reports/',
          expiration: cdk.Duration.days(90),
        },
      ],
      cors: [
        {
          allowedMethods: [s3.HttpMethods.GET],
          allowedOrigins: ['*'],
          allowedHeaders: ['*'],
        },
      ],
    });

    // --- IAM Role ---
    const lambdaRole = new iam.Role(this, 'ReportLambdaRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaVPCAccessExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
      ],
    });

    // Neptune permissions
    lambdaRole.addToPolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'neptune-db:ReadDataViaQuery',
        'neptune-db:connect',
      ],
      resources: [`arn:aws:neptune-db:${this.region}:${this.account}:*/*`],
    }));

    // S3 permissions
    this.reportBucket.grantReadWrite(lambdaRole);

    // --- Lambda Function ---
    this.reportLambda = new lambda.Function(this, 'ReportGeneratorLambda', {
      functionName: 'EMS-Report-Generator',
      runtime: lambda.Runtime.NODEJS_20_X,
      handler: 'src/report-generator.handler',
      code: lambda.Code.fromAsset('./lambdas', {
        bundling: {
          image: lambda.Runtime.NODEJS_20_X.bundlingImage,
          command: [
            'bash', '-c',
            'cp -r /asset-input/dist/* /asset-output/ && ' +
            'cp -r /asset-input/node_modules /asset-output/',
          ],
          local: {
            tryBundle(outputDir: string) {
              try {
                execSync(`cp -r ${path.resolve('./lambdas/dist')}/* ${outputDir}/`);
                execSync(`cp -r ${path.resolve('./lambdas/node_modules')} ${outputDir}/`);
                return true;
              } catch { return false; }
            },
          },
        },
      }),
      role: lambdaRole,
      timeout: cdk.Duration.minutes(5),
      memorySize: 1024, // extra memory for HTML generation
      vpc: props.neptuneVpc,
      securityGroups: [props.neptuneSecurityGroup],
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      environment: {
        NEPTUNE_ENDPOINT: props.neptuneClusterEndpoint,
        NEPTUNE_PORT: '8182',
        REPORT_BUCKET: this.reportBucket.bucketName,
        DEFAULT_OWNERS: props.defaultOwners || '',
        AWS_NODEJS_CONNECTION_REUSE_ENABLED: '1',
        USE_IAM: 'true',
        DISPLAY_TIMEZONE: 'America/Phoenix',
      },
      logGroup: new logs.LogGroup(this, 'ReportLambdaLogGroup', {
        retention: logs.RetentionDays.TWO_WEEKS,
        removalPolicy: cdk.RemovalPolicy.DESTROY,
      }),
    });

    // --- EventBridge: Weekly scheduled report generation ---
    const weeklySchedule = props.weeklySchedule || 'cron(0 8 ? * MON *)'; // Monday 8am UTC
    new events.Rule(this, 'WeeklyReportSchedule', {
      ruleName: `${this.stackName}-weekly-report`,
      description: 'Generate weekly EMS owner reports every Monday at 8am UTC',
      schedule: events.Schedule.expression(weeklySchedule),
      targets: [new targets.LambdaFunction(this.reportLambda)],
      enabled: true,
    });

    // --- API Gateway: On-demand report generation ---
    this.reportApi = new apigateway.RestApi(this, 'ReportApi', {
      restApiName: 'EMS Report Generator API',
      description: 'Generate and retrieve EMS owner reports (daily on-demand, weekly scheduled)',
      defaultCorsPreflightOptions: {
        allowOrigins: apigateway.Cors.ALL_ORIGINS,
        allowMethods: apigateway.Cors.ALL_METHODS,
        allowHeaders: ['Content-Type', 'Authorization', 'Accept', 'Origin', 'X-Requested-With', 'X-Api-Key', 'x-api-key'],
      },
    });

    const reportResource = this.reportApi.root.addResource('reports');
    const operationResource = reportResource.addResource('{operation}');
    const lambdaIntegration = new apigateway.LambdaIntegration(this.reportLambda);

    operationResource.addMethod('POST', lambdaIntegration, {
      apiKeyRequired: true,
    });
    operationResource.addMethod('GET', lambdaIntegration, {
      apiKeyRequired: true,
    });

    // API Key + Usage Plan
    const apiKey = this.reportApi.addApiKey('ReportApiKey', {
      apiKeyName: 'ems-report-api-key',
      description: 'API key for Weekly Report API',
    });
    const usagePlan = this.reportApi.addUsagePlan('ReportUsagePlan', {
      name: 'ems-report-usage-plan',
      throttle: { rateLimit: 30, burstLimit: 60 },
      quota: { limit: 5000, period: apigateway.Period.DAY },
    });
    usagePlan.addApiKey(apiKey);
    usagePlan.addApiStage({ stage: this.reportApi.deploymentStage });

    // Gateway Responses — ensure CORS headers on API Gateway-generated errors (403 missing key, etc.)
    this.reportApi.addGatewayResponse('Report4xxCors', {
      type: apigateway.ResponseType.DEFAULT_4XX,
      responseHeaders: {
        'Access-Control-Allow-Origin': "'*'",
        'Access-Control-Allow-Headers': "'Content-Type,Authorization,Accept,Origin,X-Requested-With,X-Api-Key,x-api-key'",
        'Access-Control-Allow-Methods': "'GET,POST,OPTIONS'",
      },
    });
    this.reportApi.addGatewayResponse('Report5xxCors', {
      type: apigateway.ResponseType.DEFAULT_5XX,
      responseHeaders: {
        'Access-Control-Allow-Origin': "'*'",
        'Access-Control-Allow-Headers': "'Content-Type,Authorization,Accept,Origin,X-Requested-With,X-Api-Key,x-api-key'",
        'Access-Control-Allow-Methods': "'GET,POST,OPTIONS'",
      },
    });

    // --- Outputs ---
    new cdk.CfnOutput(this, 'ReportBucketName', {
      value: this.reportBucket.bucketName,
      description: 'S3 bucket storing generated reports',
    });

    new cdk.CfnOutput(this, 'ReportApiEndpoint', {
      value: `${this.reportApi.url}reports`,
      description: 'API Gateway endpoint for report operations',
    });

    new cdk.CfnOutput(this, 'GenerateDailyExample', {
      value: `curl -X POST ${this.reportApi.url}reports/generate-daily -H "Content-Type: application/json" -d '{"owner":"Prasanna"}'`,
      description: 'Example: generate daily on-demand report',
    });

    new cdk.CfnOutput(this, 'GenerateWeeklyExample', {
      value: `curl -X POST ${this.reportApi.url}reports/generate-weekly -H "Content-Type: application/json" -d '{"owner":"Prasanna"}'`,
      description: 'Example: generate weekly report on-demand',
    });

    new cdk.CfnOutput(this, 'ListReportsExample', {
      value: `curl "${this.reportApi.url}reports/list-reports?owner=prasanna"`,
      description: 'Example: list generated reports for an owner',
    });
  }
}
