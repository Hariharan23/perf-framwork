#!/usr/bin/env python3
"""Create all environments in a fresh Neptune instance."""

import json, subprocess, time

INGEST = "https://uenp8g53a8.execute-api.us-east-1.amazonaws.com/prod/ingest"
API_KEY = "RHA63tJfqR5DcTMNDxy4UYBM7VWUwVB8vvrQ7Zwi"

ENVIRONMENTS = [
    # Web & Frontend — Hari
    "web-portal-prod", "web-portal-qa", "web-portal-staging",
    "mobile-bff-prod", "mobile-bff-qa",
    "cms-platform-prod", "cms-platform-qa",
    # Payments & Finance — Prasanna
    "payment-gateway-prod", "payment-gateway-qa", "payment-gateway-staging",
    "fraud-engine-prod", "fraud-engine-qa",
    "loyalty-svc-prod", "loyalty-svc-qa",
    # Identity & Security — Kumar
    "identity-svc-prod", "identity-svc-qa", "identity-svc-staging",
    "audit-trail-prod", "audit-trail-qa",
    # Orders & Inventory — Deepa
    "order-mgmt-prod", "order-mgmt-qa", "order-mgmt-staging",
    "inventory-mgr-prod", "inventory-mgr-qa",
    "shipping-svc-prod", "shipping-svc-qa",
    "warehouse-mgr-prod", "warehouse-mgr-qa",
    "supplier-portal-prod", "supplier-portal-qa",
    # Platform & Infra — Ravi
    "api-gateway-prod", "api-gateway-qa",
    "config-server-prod", "config-server-qa",
    "service-mesh-prod", "service-mesh-qa",
    "ci-cd-platform-prod", "ci-cd-platform-qa",
    "monitoring-stack-prod", "monitoring-stack-qa",
    # Data & Analytics — Meena
    "analytics-platform-prod", "analytics-platform-qa",
    "data-pipeline-prod", "data-pipeline-qa",
    "search-engine-prod", "search-engine-qa",
    "ml-recommender-prod", "ml-recommender-qa",
    # Comms & Support — Arun
    "notify-svc-prod", "notify-svc-qa",
    "customer-support-prod", "customer-support-qa",
    "catalog-svc-prod", "catalog-svc-qa",
    "alert-svc-prod", "alert-svc-qa",
]

def call(payload):
    r = subprocess.run(
        ["curl", "-s", "-X", "POST", INGEST,
         "-H", "Content-Type: application/json",
         "-H", f"x-api-key: {API_KEY}",
         "-d", json.dumps(payload)],
        capture_output=True, text=True, timeout=30)
    try:
        return json.loads(r.stdout)
    except Exception:
        return {"error": r.stdout[:200]}

ok = 0
fail = 0
for name in ENVIRONMENTS:
    payload = {
        "operation": "create",
        "name": name,
        "type": "Environment",
        "description": f"Environment {name}",
        "status": "active",
    }
    print(f"  Creating {name}...", end=" ", flush=True)
    resp = call(payload)
    if resp.get("success") or resp.get("data") or resp.get("id"):
        print("OK")
        ok += 1
    else:
        print(f"FAIL: {json.dumps(resp)[:100]}")
        fail += 1
    time.sleep(0.2)

print(f"\nCreated {ok}, failed {fail}")
