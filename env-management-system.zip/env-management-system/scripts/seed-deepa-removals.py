#!/usr/bin/env python3
"""Seed delete-integration history entries for Deepa's environments to test REMOVED display."""
import json, urllib.request, uuid, time

QUERY_API = "https://0qhbaqienl.execute-api.us-east-1.amazonaws.com/prod/query"
ONT = "http://neptune.aws.com/envmgmt/ontology/"

def get_entity_id(name):
    q = f'PREFIX env: <{ONT}> SELECT ?id WHERE {{ ?e env:name "{name}" ; env:id ?id }} LIMIT 1'
    req = urllib.request.Request(QUERY_API, data=json.dumps({"operation":"sparql-query","query":q}).encode(), headers={"Content-Type":"application/json"}, method="POST")
    r = json.loads(urllib.request.urlopen(req).read().decode())
    bindings = r.get("data",{}).get("results",{}).get("bindings",[])
    return bindings[0]["id"]["value"] if bindings else ""

# Simulated removed integrations (these are fictitious old integrations that were "removed")
REMOVALS = [
    {
        "envName": "order-mgmt-prod",
        "integrationName": "Legacy Payment Bridge",
        "targetEnvName": "payment-legacy-prod",
        "removedBy": "Deepa",
    },
    {
        "envName": "warehouse-mgr-prod",
        "integrationName": "Old Inventory Sync",
        "targetEnvName": "legacy-inv-prod",
        "removedBy": "Hari",
    },
    {
        "envName": "supplier-portal-prod",
        "integrationName": "Deprecated Auth Connector",
        "targetEnvName": "old-auth-svc-prod",
        "removedBy": "Kumar",
    },
]

now = time.strftime('%Y-%m-%dT%H:%M:%S.000Z')

for removal in REMOVALS:
    env_id = get_entity_id(removal["envName"])
    if not env_id:
        print(f"  SKIP {removal['envName']}: env not found")
        continue

    history_id = f"history_{uuid.uuid4()}"
    history_uri = f"{ONT}entity/{history_id}"
    changes_json = json.dumps({
        "integrationName": removal["integrationName"],
        "targetEnvName": removal["targetEnvName"],
        "targetEnvId": "",
        "removedBy": removal["removedBy"],
    }).replace('"', '\\"')

    sparql = f"""PREFIX env: <{ONT}>
INSERT DATA {{
    <{history_uri}> env:id "{history_id}" .
    <{history_uri}> env:type "History" .
    <{history_uri}> env:entityId "{env_id}" .
    <{history_uri}> env:entityName "{removal['envName']}" .
    <{history_uri}> env:action "delete-integration" .
    <{history_uri}> env:timestamp "{now}" .
    <{history_uri}> env:user "{removal['removedBy']}" .
    <{history_uri}> env:changes "{changes_json}" .
}}"""
    req = urllib.request.Request(
        QUERY_API,
        data=json.dumps({"operation": "sparql-update", "query": sparql}).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    r = json.loads(urllib.request.urlopen(req).read().decode())
    ok = r.get("success", False)
    print(f"  {removal['envName']}: removed '{removal['integrationName']}' -> {'OK' if ok else 'FAIL: '+str(r)}")
    time.sleep(0.3)

print("\nDone! Generate Deepa's report to see REMOVED entries.")
