#!/usr/bin/env python3
"""Debug network graph to understand cross-owner connections."""
import json, urllib.request

url = "https://0qhbaqienl.execute-api.us-east-1.amazonaws.com/prod/query"
req = urllib.request.Request(url, data=json.dumps({"operation": "network-graph"}).encode(), headers={"Content-Type": "application/json"}, method="POST")
d = json.loads(urllib.request.urlopen(req).read().decode())
nodes = d.get("nodes", [])
edges = d.get("edges", [])
print(f"Total nodes: {len(nodes)}, edges: {len(edges)}")

# Build node lookup
node_map = {n["id"]: n for n in nodes}

# Find web-portal-prod
wp = [n for n in nodes if n.get("label") == "web-portal-prod"]
if wp:
    wp = wp[0]
    print(f"\nweb-portal-prod id: {wp['id']}")
    print(f"  owner in properties: {wp.get('properties', {}).get('owner', 'NONE')}")
    print(f"  owner on top-level: {wp.get('owner', 'NONE')}")
    print(f"  type: {wp.get('type')}")
    
    # Find its edges
    out_edges = [e for e in edges if e["source"] == wp["id"]]
    print(f"  Outbound edges: {len(out_edges)}")
    for e in out_edges[:10]:
        tn = node_map.get(e["target"], {})
        print(f"    -> {tn.get('label','?')} (type={e['type']}, target_type={tn.get('type','?')})")

# Find payment-gateway-prod 
pg = [n for n in nodes if n.get("label") == "payment-gateway-prod"]
if pg:
    pg = pg[0]
    print(f"\npayment-gateway-prod id: {pg['id']}")
    print(f"  owner in properties: {pg.get('properties', {}).get('owner', 'NONE')}")
    print(f"  owner on top-level: {pg.get('owner', 'NONE')}")

# Check: are there ANY direct connections between Hari envs and other owner envs?
hari_envs = set()
other_envs = {}
for n in nodes:
    owner = n.get("properties", {}).get("owner") or n.get("owner", "")
    if owner.lower() == "hari":
        hari_envs.add(n["id"])
    elif owner:
        other_envs[n["id"]] = (n.get("label", ""), owner)

print(f"\nHari's env count: {len(hari_envs)}")
print(f"Other owners' env count: {len(other_envs)}")

# Find integration nodes connected to Hari's envs
hari_integrations = set()
for e in edges:
    if e["source"] in hari_envs and e["type"] == "hasIntegration":
        hari_integrations.add(e["target"])

print(f"Hari's integration nodes: {len(hari_integrations)}")

# Find where those integrations connect
for int_id in list(hari_integrations)[:5]:
    int_edges = [e for e in edges if e["source"] == int_id and e["type"] == "integratesWith"]
    for ie in int_edges:
        target = node_map.get(ie["target"], {})
        towner = target.get("properties", {}).get("owner") or target.get("owner", "")
        ttype = target.get("type", "")
        print(f"  Integration {node_map.get(int_id, {}).get('label', '?')} -> {target.get('label', '?')} (owner={towner}, type={ttype})")
