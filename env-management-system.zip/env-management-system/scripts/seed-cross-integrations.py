#!/usr/bin/env python3
"""Seed cross-owner integrations between named environments."""
import json, urllib.request, time, uuid

API = "https://0qhbaqienl.execute-api.us-east-1.amazonaws.com/prod/ingest"

# Cross-owner integrations: source_env -> target_env with integration name
INTEGRATIONS = [
    # Hari's web-portal-prod depends on Prasanna's payment-gateway-prod
    ("web-portal-prod", "payment-gateway-prod", "Payment Processing API", "API"),
    # Hari's web-portal-prod depends on Kumar's identity-svc-prod
    ("web-portal-prod", "identity-svc-prod", "OAuth SSO Integration", "API"),
    # Hari's web-portal-prod depends on Deepa's order-mgmt-prod
    ("web-portal-prod", "order-mgmt-prod", "Order Service API", "API"),
    # Hari's cms-platform-prod depends on Kumar's api-gateway-prod
    ("cms-platform-prod", "api-gateway-prod", "Gateway Routing", "API"),
    # Hari's mobile-bff-prod depends on Prasanna's payment-gateway-prod
    ("mobile-bff-prod", "payment-gateway-prod", "Mobile Payment SDK", "API"),
    # Hari's mobile-bff-prod depends on Arun's notify-svc-prod
    ("mobile-bff-prod", "notify-svc-prod", "Push Notification Relay", "API"),
    # Prasanna's payment-gateway-prod depends on Kumar's identity-svc-prod
    ("payment-gateway-prod", "identity-svc-prod", "PCI Auth Validation", "API"),
    # Prasanna's payment-gateway-prod depends on Ravi's db-cluster-prod
    ("payment-gateway-prod", "db-cluster-prod", "Transaction Store", "Database"),
    # Deepa's order-mgmt-prod depends on Deepa's inventory-mgr-prod
    ("order-mgmt-prod", "inventory-mgr-prod", "Stock Check API", "API"),
    # Deepa's order-mgmt-prod depends on Prasanna's payment-gateway-prod
    ("order-mgmt-prod", "payment-gateway-prod", "Payment Capture", "API"),
    # Kumar's api-gateway-prod depends on Meena's analytics-svc-prod
    ("api-gateway-prod", "analytics-svc-prod", "Request Telemetry", "API"),
    # Ravi's k8s-platform-prod depends on Meena's analytics-svc-prod
    ("k8s-platform-prod", "analytics-svc-prod", "Cluster Metrics Feed", "API"),
    # Ravi's cache-layer-prod depends on Kumar's identity-svc-prod
    ("cache-layer-prod", "identity-svc-prod", "Session Cache Sync", "Cache"),
    # Arun's notify-svc-prod depends on Meena's data-pipeline-prod
    ("notify-svc-prod", "data-pipeline-prod", "Event Stream Consumer", "Streaming"),
    # Meena's analytics-svc-prod depends on Ravi's db-cluster-prod
    ("analytics-svc-prod", "db-cluster-prod", "Analytics Warehouse", "Database"),
    # Hari's web-portal-prod depends on Arun's catalog-svc-prod
    ("web-portal-prod", "catalog-svc-prod", "Product Catalog API", "API"),
]

def create_integration(source, target, name, int_type):
    # Step 1: Create the Integration entity
    payload = {
        "operation": "create",
        "name": name,
        "type": "Integration",
        "sourceService": source,
        "targetService": target,
        "status": "active",
        "description": f"{int_type} integration from {source} to {target}",
    }
    req = urllib.request.Request(
        API,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        resp = urllib.request.urlopen(req)
        result = json.loads(resp.read().decode())
        int_id = result.get("data", {}).get("id", "") or result.get("id", "")
        if not int_id:
            return {"error": f"No integration ID in response: {result}"}

        # Step 2: Create relationships sourceEnv->hasIntegration->integration->integratesWith->targetEnv
        QUERY_API = "https://0qhbaqienl.execute-api.us-east-1.amazonaws.com/prod/query"
        rel1_id = f"rel_{uuid.uuid4().hex[:8]}"
        rel2_id = f"rel_{uuid.uuid4().hex[:8]}"

        # Look up entity IDs by name
        def get_entity_id(entity_name):
            lookup = {
                "operation": "sparql-query",
                "query": f'PREFIX env: <http://neptune.aws.com/envmgmt/ontology/> SELECT ?id WHERE {{ ?e env:name "{entity_name}" ; env:id ?id }} LIMIT 1'
            }
            req2 = urllib.request.Request(QUERY_API, data=json.dumps(lookup).encode(), headers={"Content-Type": "application/json"}, method="POST")
            r2 = json.loads(urllib.request.urlopen(req2).read().decode())
            bindings = r2.get("data", {}).get("results", {}).get("bindings", [])
            if bindings:
                return bindings[0].get("id", {}).get("value", "")
            return ""

        source_id = get_entity_id(source)
        target_id = get_entity_id(target)

        if not source_id or not target_id:
            return {"error": f"Could not find IDs: source={source_id}, target={target_id}"}

        ONT = "http://neptune.aws.com/envmgmt/ontology/"
        now = time.strftime('%Y-%m-%dT%H:%M:%S.000Z')
        rel1_uri = f"{ONT}entity/{rel1_id}"
        rel2_uri = f"{ONT}entity/{rel2_id}"

        # Create both relationships via SPARQL INSERT DATA (same pattern as neptune-sparql-client.ts createRelationship)
        rel_update = {
            "operation": "sparql-update",
            "query": f"""
                PREFIX env: <{ONT}>
                INSERT DATA {{
                    <{rel1_uri}> env:id "{rel1_id}" .
                    <{rel1_uri}> env:name "{source}_hasIntegration_{name}" .
                    <{rel1_uri}> env:type "Relationship" .
                    <{rel1_uri}> env:relationshipType "hasIntegration" .
                    <{rel1_uri}> env:sourceEntity "{source}" .
                    <{rel1_uri}> env:targetEntity "{name}" .
                    <{rel1_uri}> env:sourceEntityId "{source_id}" .
                    <{rel1_uri}> env:targetEntityId "{int_id}" .
                    <{rel1_uri}> env:description "Relationship: {source} hasIntegration {name}" .
                    <{rel1_uri}> env:createdAt "{now}" .
                    
                    <{rel2_uri}> env:id "{rel2_id}" .
                    <{rel2_uri}> env:name "{name}_integratesWith_{target}" .
                    <{rel2_uri}> env:type "Relationship" .
                    <{rel2_uri}> env:relationshipType "integratesWith" .
                    <{rel2_uri}> env:sourceEntity "{name}" .
                    <{rel2_uri}> env:targetEntity "{target}" .
                    <{rel2_uri}> env:sourceEntityId "{int_id}" .
                    <{rel2_uri}> env:targetEntityId "{target_id}" .
                    <{rel2_uri}> env:description "Relationship: {name} integratesWith {target}" .
                    <{rel2_uri}> env:createdAt "{now}" .
                }}
            """
        }
        req3 = urllib.request.Request(QUERY_API, data=json.dumps(rel_update).encode(), headers={"Content-Type": "application/json"}, method="POST")
        try:
            r3 = json.loads(urllib.request.urlopen(req3).read().decode())
            if not r3.get("success"):
                return {"error": f"SPARQL update failed: {r3}"}
        except Exception as e2:
            return {"error": f"SPARQL update error: {e2}"}
        
        return {"id": int_id, "relationships": "created"}
    except Exception as e:
        return {"error": str(e)}

print("Seeding cross-owner integrations...")
ok = 0
fail = 0
for source, target, name, itype in INTEGRATIONS:
    result = create_integration(source, target, name, itype)
    status = "OK" if result.get("id") and result.get("relationships") else f"FAIL: {result}"
    print(f"  {source} -> {target} ({name}): {status}")
    if "FAIL" not in status:
        ok += 1
    else:
        fail += 1
    time.sleep(0.3)

print(f"\nDone! {ok} created, {fail} failed")
