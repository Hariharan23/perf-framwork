#!/usr/bin/env python3
"""
Seed scheduled updates and collaborators for all owner-assigned environments.
Some windows intentionally conflict to test the report's schedule conflict detection.
"""

import json
import subprocess
import time

API = "https://uenp8g53a8.execute-api.us-east-1.amazonaws.com/prod/ingest"
API_KEY = "RHA63tJfqR5DcTMNDxy4UYBM7VWUwVB8vvrQ7Zwi"

# Scheduled updates — mix of conflicting and non-conflicting maintenance windows
# Conflicts: web-portal-prod & payment-gateway-prod both on Jun 7 0200-0400 UTC
#            identity-svc-prod & api-gateway-prod both on Jun 8 0300-0500 UTC
#            order-mgmt-prod & inventory-mgr-prod both on Jun 6 0100-0300 UTC
SCHEDULED_UPDATES = {
    # ── Hari (Web & Frontend) ──
    "web-portal-prod":       "Jun 7 02:00-04:00 UTC — TLS cert rotation + CDN cache purge",
    "web-portal-qa":         "May 27 10:00-11:00 UTC — Load test v3.9.0 release candidate",
    "web-portal-staging":    "May 25 14:00-15:00 UTC — Deploy v3.9.0-rc1 for smoke test",
    "mobile-bff-prod":       "Jun 10 03:00-04:30 UTC — API schema migration v2.6",
    "mobile-bff-qa":         "May 28 09:00-10:00 UTC — Integration test with iOS 20 client",
    "cms-platform-prod":     "Jun 12 01:00-02:00 UTC — Content DB reindex",
    "cms-platform-qa":       "",

    # ── Prasanna (Payments & Finance) ──
    "payment-gateway-prod":  "Jun 7 02:00-04:00 UTC — PCI compliance patch + key rotation",  # CONFLICT with web-portal-prod
    "payment-gateway-qa":    "May 27 11:00-12:00 UTC — Regression suite for PCI patch",
    "payment-gateway-staging": "May 25 16:00-17:00 UTC — PCI patch staging validation",
    "fraud-engine-prod":     "Jun 8 04:00-05:00 UTC — ML model v4.3 rollout",
    "fraud-engine-qa":       "Jun 1 10:00-11:00 UTC — Model accuracy benchmark",
    "loyalty-svc-prod":      "Jun 14 02:00-03:00 UTC — Points calculation engine upgrade",
    "loyalty-svc-qa":        "",

    # ── Kumar (Identity & Security) ──
    "identity-svc-prod":     "Jun 8 03:00-05:00 UTC — OAuth2 token signing key rotation",  # CONFLICT with api-gateway-prod
    "identity-svc-qa":       "May 28 13:00-14:00 UTC — SAML federation test",
    "identity-svc-staging":  "May 25 15:00-16:00 UTC — OAuth2 staging dry-run",
    "audit-trail-prod":      "Jun 11 01:00-02:00 UTC — Log retention policy update (90→180 days)",
    "audit-trail-qa":        "",

    # ── Deepa (Orders & Inventory) ──
    "order-mgmt-prod":       "Jun 6 01:00-03:00 UTC — Order DB schema migration v8",  # CONFLICT with inventory-mgr-prod
    "order-mgmt-qa":         "May 26 10:00-12:00 UTC — Migration dry-run",
    "order-mgmt-staging":    "May 24 08:00-09:00 UTC — Schema v8 staging deploy",
    "inventory-mgr-prod":    "Jun 6 01:00-03:00 UTC — Stock sync rebalancing + warehouse cutover",  # CONFLICT with order-mgmt-prod
    "inventory-mgr-qa":      "May 27 08:00-09:00 UTC — Rebalance algorithm test",
    "shipping-svc-prod":     "Jun 11 05:00-06:00 UTC — Carrier API v4 migration",
    "shipping-svc-qa":       "",
    "warehouse-mgr-prod":    "Jun 13 02:00-03:30 UTC — Barcode scanner firmware OTA",
    "warehouse-mgr-qa":      "",
    "supplier-portal-prod":  "Jun 15 01:00-02:00 UTC — EDI gateway protocol upgrade",
    "supplier-portal-qa":    "",

    # ── Ravi (Platform & Infra) ──
    "api-gateway-prod":      "Jun 8 03:00-05:00 UTC — Rate limiter config + WAF rule update",  # CONFLICT with identity-svc-prod
    "api-gateway-qa":        "May 28 14:00-15:00 UTC — Load test new WAF rules",
    "config-server-prod":    "Jun 10 02:00-03:00 UTC — Config encryption key rotation",
    "config-server-qa":      "",
    "service-mesh-prod":     "Jun 12 03:00-04:30 UTC — Envoy sidecar upgrade v1.30",
    "service-mesh-qa":       "Jun 3 10:00-11:00 UTC — Sidecar canary test",
    "ci-cd-platform-prod":   "Jun 7 06:00-08:00 UTC — Jenkins → GitHub Actions migration phase 3",
    "ci-cd-platform-qa":     "",
    "monitoring-stack-prod":  "Jun 14 03:00-04:00 UTC — Prometheus storage compaction",
    "monitoring-stack-qa":   "",

    # ── Meena (Data & Analytics) ──
    "analytics-platform-prod": "Jun 11 04:00-06:00 UTC — Clickhouse cluster vertical scaling",
    "analytics-platform-qa":   "Jun 2 09:00-10:00 UTC — New dashboard deploy",
    "data-pipeline-prod":      "Jun 7 05:00-07:00 UTC — Kafka topic partition rebalance",
    "data-pipeline-qa":        "May 27 09:00-10:00 UTC — Partition strategy test",
    "search-engine-prod":      "Jun 13 04:00-05:30 UTC — Elasticsearch index rolling upgrade",
    "search-engine-qa":        "",
    "ml-recommender-prod":     "Jun 9 06:00-07:00 UTC — Model serving infra scale-out",
    "ml-recommender-qa":       "",

    # ── Arun (Comms & Support) ──
    "notify-svc-prod":        "Jun 10 02:00-03:00 UTC — Email provider failover drill",
    "notify-svc-qa":          "Jun 1 10:00-11:00 UTC — SMS gateway integration test",
    "customer-support-prod":  "Jun 12 05:00-06:00 UTC — Zendesk API v3 migration",
    "customer-support-qa":    "",
    "catalog-svc-prod":       "Jun 15 04:00-05:00 UTC — Product taxonomy reindex",
    "catalog-svc-qa":         "",
    "alert-svc-prod":         "Jun 11 06:00-07:00 UTC — PagerDuty webhook rotation",
    "alert-svc-qa":           "",
}

# Collaborators — ensure all environments have them
COLLABORATORS = {
    # Hari's environments
    "web-portal-prod":       "Prasanna, Kumar, Arun",
    "web-portal-qa":         "Prasanna, Kumar",
    "web-portal-staging":    "Kumar",
    "mobile-bff-prod":       "Ravi, Arun",
    "mobile-bff-qa":         "Ravi",
    "cms-platform-prod":     "Arun, Meena",
    "cms-platform-qa":       "Arun",

    # Prasanna's environments
    "payment-gateway-prod":  "Kumar, Deepa, Hari",
    "payment-gateway-qa":    "Kumar, Deepa",
    "payment-gateway-staging": "Kumar",
    "fraud-engine-prod":     "Kumar, Ravi",
    "fraud-engine-qa":       "Kumar",
    "loyalty-svc-prod":      "Deepa, Hari",
    "loyalty-svc-qa":        "Deepa",

    # Kumar's environments
    "identity-svc-prod":     "Prasanna, Ravi, Hari",
    "identity-svc-qa":       "Prasanna, Ravi",
    "identity-svc-staging":  "Prasanna",
    "audit-trail-prod":      "Ravi, Prasanna",
    "audit-trail-qa":        "Ravi",

    # Deepa's environments
    "order-mgmt-prod":       "Prasanna, Hari, Arun",
    "order-mgmt-qa":         "Prasanna, Hari",
    "order-mgmt-staging":    "Prasanna",
    "inventory-mgr-prod":    "Ravi, Meena",
    "inventory-mgr-qa":      "Ravi",
    "shipping-svc-prod":     "Arun, Prasanna",
    "shipping-svc-qa":       "Arun",
    "warehouse-mgr-prod":    "Ravi, Meena",
    "warehouse-mgr-qa":      "Ravi",
    "supplier-portal-prod":  "Prasanna, Arun",
    "supplier-portal-qa":    "Prasanna",

    # Ravi's environments
    "api-gateway-prod":      "Hari, Prasanna, Kumar, Deepa, Meena, Arun",
    "api-gateway-qa":        "Hari, Kumar",
    "config-server-prod":    "Kumar, Prasanna",
    "config-server-qa":      "Kumar",
    "service-mesh-prod":     "Hari, Prasanna, Kumar",
    "service-mesh-qa":       "Hari",
    "ci-cd-platform-prod":   "Hari, Prasanna, Kumar, Deepa, Meena, Arun",
    "ci-cd-platform-qa":     "Hari, Prasanna",
    "monitoring-stack-prod":  "Hari, Prasanna, Kumar, Deepa, Meena, Arun",
    "monitoring-stack-qa":   "Hari",

    # Meena's environments
    "analytics-platform-prod": "Hari, Ravi, Deepa",
    "analytics-platform-qa":   "Ravi",
    "data-pipeline-prod":      "Ravi, Deepa",
    "data-pipeline-qa":        "Ravi",
    "search-engine-prod":      "Hari, Ravi",
    "search-engine-qa":        "Ravi",
    "ml-recommender-prod":     "Hari, Ravi",
    "ml-recommender-qa":       "Ravi",

    # Arun's environments
    "notify-svc-prod":        "Hari, Prasanna, Deepa",
    "notify-svc-qa":          "Hari",
    "customer-support-prod":  "Deepa, Hari",
    "customer-support-qa":    "Deepa",
    "catalog-svc-prod":       "Deepa, Meena",
    "catalog-svc-qa":         "Deepa",
    "alert-svc-prod":         "Ravi, Kumar",
    "alert-svc-qa":           "Ravi",
}

# Owner mapping (needed for the update payload)
OWNERS = {
    "web-portal-prod": "Hari", "web-portal-qa": "Hari", "web-portal-staging": "Hari",
    "mobile-bff-prod": "Hari", "mobile-bff-qa": "Hari",
    "cms-platform-prod": "Hari", "cms-platform-qa": "Hari",
    "payment-gateway-prod": "Prasanna", "payment-gateway-qa": "Prasanna", "payment-gateway-staging": "Prasanna",
    "fraud-engine-prod": "Prasanna", "fraud-engine-qa": "Prasanna",
    "loyalty-svc-prod": "Prasanna", "loyalty-svc-qa": "Prasanna",
    "identity-svc-prod": "Kumar", "identity-svc-qa": "Kumar", "identity-svc-staging": "Kumar",
    "audit-trail-prod": "Kumar", "audit-trail-qa": "Kumar",
    "order-mgmt-prod": "Deepa", "order-mgmt-qa": "Deepa", "order-mgmt-staging": "Deepa",
    "inventory-mgr-prod": "Deepa", "inventory-mgr-qa": "Deepa",
    "shipping-svc-prod": "Deepa", "shipping-svc-qa": "Deepa",
    "warehouse-mgr-prod": "Deepa", "warehouse-mgr-qa": "Deepa",
    "supplier-portal-prod": "Deepa", "supplier-portal-qa": "Deepa",
    "api-gateway-prod": "Ravi", "api-gateway-qa": "Ravi",
    "config-server-prod": "Ravi", "config-server-qa": "Ravi",
    "service-mesh-prod": "Ravi", "service-mesh-qa": "Ravi",
    "ci-cd-platform-prod": "Ravi", "ci-cd-platform-qa": "Ravi",
    "monitoring-stack-prod": "Ravi", "monitoring-stack-qa": "Ravi",
    "analytics-platform-prod": "Meena", "analytics-platform-qa": "Meena",
    "data-pipeline-prod": "Meena", "data-pipeline-qa": "Meena",
    "search-engine-prod": "Meena", "search-engine-qa": "Meena",
    "ml-recommender-prod": "Meena", "ml-recommender-qa": "Meena",
    "notify-svc-prod": "Arun", "notify-svc-qa": "Arun",
    "customer-support-prod": "Arun", "customer-support-qa": "Arun",
    "catalog-svc-prod": "Arun", "catalog-svc-qa": "Arun",
    "alert-svc-prod": "Arun", "alert-svc-qa": "Arun",
}


def call_api(payload):
    for attempt in range(3):
        try:
            result = subprocess.run(
                ["curl", "-s", "-X", "POST", API,
                 "-H", "Content-Type: application/json",
                 "-H", f"x-api-key: {API_KEY}",
                 "-d", json.dumps(payload)],
                capture_output=True, text=True, timeout=30
            )
            resp = json.loads(result.stdout) if result.stdout else {}
            return resp
        except Exception as e:
            print(f"  Attempt {attempt+1} failed: {e}")
            time.sleep(2)
    return {"error": "All attempts failed"}


# Fetch all environment IDs
print("Fetching all environments...")
result = subprocess.run(
    ["curl", "-s", "https://uenp8g53a8.execute-api.us-east-1.amazonaws.com/prod/query",
     "-H", "Content-Type: application/json",
     "-H", f"x-api-key: {API_KEY}",
     "-d", json.dumps({"operation": "get-environments"})],
    capture_output=True, text=True, timeout=30
)
data = json.loads(result.stdout)
all_envs = data["data"]["environments"]
env_map = {e["name"]: e["id"] for e in all_envs}
print(f"Found {len(all_envs)} environments")

# Update each environment with scheduledUpdates + collaborators
success = 0
failed = 0
for env_name in SCHEDULED_UPDATES:
    env_id = env_map.get(env_name)
    if not env_id:
        print(f"  SKIP {env_name} — not found")
        failed += 1
        continue

    sched = SCHEDULED_UPDATES.get(env_name, "")
    collab = COLLABORATORS.get(env_name, "")
    owner = OWNERS.get(env_name, "")

    payload = {
        "operation": "update-entity",
        "id": env_id,
        "type": "Environment",
        "name": env_name,
        "owner": owner,
        "status": "active",
        "scheduledUpdates": sched,
        "collaborators": collab,
    }

    label = f"{env_name} (sched={'YES' if sched else 'none'}, collab={collab[:20]}...)" if collab else f"{env_name} (sched={'YES' if sched else 'none'})"
    print(f"  {label}...", end=" ", flush=True)
    resp = call_api(payload)
    if resp.get("success") or resp.get("data"):
        print("OK")
        success += 1
    else:
        print(f"FAIL: {json.dumps(resp)[:100]}")
        failed += 1

    time.sleep(0.3)

print(f"\nDone! {success} updated, {failed} failed/skipped")
print("\nConflicting maintenance windows:")
print("  1. web-portal-prod & payment-gateway-prod: Apr 12 02:00-04:00 UTC")
print("  2. identity-svc-prod & api-gateway-prod: Apr 13 03:00-05:00 UTC")
print("  3. order-mgmt-prod & inventory-mgr-prod: Apr 11 01:00-03:00 UTC")
