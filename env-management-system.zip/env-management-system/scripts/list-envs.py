#!/usr/bin/env python3
import json, sys

data = json.load(sys.stdin)
envs = data if isinstance(data, list) else data.get('environments', data.get('entities', []))
for e in sorted(envs, key=lambda x: x['name']):
    print(f"{e['name']}|{e['id']}")
