#!/usr/bin/env python3
"""
Bulk update environments with owners, collaborators, stats, and descriptions
to test the weekly report generation.
"""

import json
import subprocess
import time
import sys

API = "https://uenp8g53a8.execute-api.us-east-1.amazonaws.com/prod/ingest"
API_KEY = "RHA63tJfqR5DcTMNDxy4UYBM7VWUwVB8vvrQ7Zwi"

# Owner assignments by domain
OWNERS = {
    # Web & Frontend — Hari
    "web-portal-prod": "Hari",
    "web-portal-qa": "Hari",
    "web-portal-staging": "Hari",
    "mobile-bff-prod": "Hari",
    "mobile-bff-qa": "Hari",
    "cms-platform-prod": "Hari",
    "cms-platform-qa": "Hari",
    
    # Payments & Finance — Prasanna
    "payment-gateway-prod": "Prasanna",
    "payment-gateway-qa": "Prasanna",
    "payment-gateway-staging": "Prasanna",
    "fraud-engine-prod": "Prasanna",
    "fraud-engine-qa": "Prasanna",
    "loyalty-svc-prod": "Prasanna",
    "loyalty-svc-qa": "Prasanna",
    
    # Identity & Security — Kumar
    "identity-svc-prod": "Kumar",
    "identity-svc-qa": "Kumar",
    "identity-svc-staging": "Kumar",
    "audit-trail-prod": "Kumar",
    "audit-trail-qa": "Kumar",
    
    # Orders & Inventory — Deepa
    "order-mgmt-prod": "Deepa",
    "order-mgmt-qa": "Deepa",
    "order-mgmt-staging": "Deepa",
    "inventory-mgr-prod": "Deepa",
    "inventory-mgr-qa": "Deepa",
    "shipping-svc-prod": "Deepa",
    "shipping-svc-qa": "Deepa",
    "warehouse-mgr-prod": "Deepa",
    "warehouse-mgr-qa": "Deepa",
    "supplier-portal-prod": "Deepa",
    "supplier-portal-qa": "Deepa",
    
    # Platform & Infra — Ravi
    "api-gateway-prod": "Ravi",
    "api-gateway-qa": "Ravi",
    "config-server-prod": "Ravi",
    "config-server-qa": "Ravi",
    "service-mesh-prod": "Ravi",
    "service-mesh-qa": "Ravi",
    "ci-cd-platform-prod": "Ravi",
    "ci-cd-platform-qa": "Ravi",
    "monitoring-stack-prod": "Ravi",
    "monitoring-stack-qa": "Ravi",
    
    # Data & Analytics — Meena
    "analytics-platform-prod": "Meena",
    "analytics-platform-qa": "Meena",
    "data-pipeline-prod": "Meena",
    "data-pipeline-qa": "Meena",
    "search-engine-prod": "Meena",
    "search-engine-qa": "Meena",
    "ml-recommender-prod": "Meena",
    "ml-recommender-qa": "Meena",
    
    # Comms & Support — Arun
    "notify-svc-prod": "Arun",
    "notify-svc-qa": "Arun",
    "customer-support-prod": "Arun",
    "customer-support-qa": "Arun",
    "catalog-svc-prod": "Arun",
    "catalog-svc-qa": "Arun",
    "alert-svc-prod": "Arun",  
    "alert-svc-qa": "Arun",
}

# Collaborators by environment
COLLABORATORS = {
    "web-portal-prod": "Prasanna, Kumar, Arun",
    "web-portal-qa": "Prasanna, Kumar",
    "payment-gateway-prod": "Kumar, Deepa, Hari",
    "payment-gateway-qa": "Kumar, Deepa",
    "identity-svc-prod": "Prasanna, Ravi",
    "identity-svc-qa": "Prasanna",
    "order-mgmt-prod": "Prasanna, Hari, Arun",
    "order-mgmt-qa": "Prasanna, Hari",
    "api-gateway-prod": "Hari, Prasanna, Kumar, Deepa, Meena, Arun",
    "api-gateway-qa": "Hari, Kumar",
    "analytics-platform-prod": "Hari, Ravi",
    "analytics-platform-qa": "Ravi",
    "data-pipeline-prod": "Ravi, Deepa",
    "data-pipeline-qa": "Ravi",
    "monitoring-stack-prod": "Hari, Prasanna, Kumar, Deepa, Meena, Arun",
    "notify-svc-prod": "Hari, Prasanna, Deepa",
    "customer-support-prod": "Deepa, Hari",
    "fraud-engine-prod": "Kumar, Ravi",
    "service-mesh-prod": "Hari, Prasanna, Kumar",
    "ci-cd-platform-prod": "Hari, Prasanna, Kumar, Deepa, Meena, Arun",
}

# Descriptions by environment
DESCRIPTIONS = {
    "web-portal-prod": "Customer-facing web portal — production",
    "web-portal-qa": "Customer-facing web portal — QA environment",
    "web-portal-staging": "Customer-facing web portal — staging",
    "mobile-bff-prod": "Backend for frontend — mobile apps production",
    "mobile-bff-qa": "Backend for frontend — mobile apps QA",
    "cms-platform-prod": "Content management system — production",
    "cms-platform-qa": "Content management system — QA",
    "payment-gateway-prod": "Payment processing gateway — production",
    "payment-gateway-qa": "Payment processing gateway — QA",
    "payment-gateway-staging": "Payment processing gateway — staging",
    "fraud-engine-prod": "Real-time fraud detection engine — production",
    "fraud-engine-qa": "Fraud detection engine — QA",
    "loyalty-svc-prod": "Customer loyalty & rewards service — production",
    "loyalty-svc-qa": "Customer loyalty service — QA",
    "identity-svc-prod": "Authentication & identity management — production",
    "identity-svc-qa": "Authentication & identity — QA",
    "identity-svc-staging": "Authentication & identity — staging",
    "audit-trail-prod": "Compliance audit trail & logging — production",
    "audit-trail-qa": "Audit trail & logging — QA",
    "order-mgmt-prod": "Order lifecycle management — production",
    "order-mgmt-qa": "Order management — QA",
    "order-mgmt-staging": "Order management — staging",
    "inventory-mgr-prod": "Inventory & stock management — production",
    "inventory-mgr-qa": "Inventory management — QA",
    "shipping-svc-prod": "Shipping & delivery orchestration — production",
    "shipping-svc-qa": "Shipping service — QA",
    "warehouse-mgr-prod": "Warehouse operations management — production",
    "warehouse-mgr-qa": "Warehouse management — QA",
    "supplier-portal-prod": "Supplier self-service portal — production",
    "supplier-portal-qa": "Supplier portal — QA",
    "api-gateway-prod": "Central API gateway & rate limiting — production",
    "api-gateway-qa": "API gateway — QA",
    "config-server-prod": "Centralized configuration server — production",
    "config-server-qa": "Configuration server — QA",
    "service-mesh-prod": "Service mesh (Envoy/Istio) control plane — production",
    "service-mesh-qa": "Service mesh control plane — QA",
    "ci-cd-platform-prod": "CI/CD pipeline platform — production",
    "ci-cd-platform-qa": "CI/CD pipeline platform — QA",
    "monitoring-stack-prod": "Observability stack (metrics, logs, traces) — production",
    "monitoring-stack-qa": "Monitoring stack — QA",
    "analytics-platform-prod": "Business analytics & reporting — production",
    "analytics-platform-qa": "Analytics platform — QA",
    "data-pipeline-prod": "ETL & streaming data pipeline — production",
    "data-pipeline-qa": "Data pipeline — QA",
    "search-engine-prod": "Product search (Elasticsearch) — production",
    "search-engine-qa": "Search engine — QA",
    "ml-recommender-prod": "ML-based product recommendation engine — production",
    "ml-recommender-qa": "ML recommendation engine — QA",
    "notify-svc-prod": "Multi-channel notification service — production",
    "notify-svc-qa": "Notification service — QA",
    "customer-support-prod": "Customer support ticketing platform — production",
    "customer-support-qa": "Customer support platform — QA",
    "catalog-svc-prod": "Product catalog service — production",
    "catalog-svc-qa": "Product catalog service — QA",
    "alert-svc-prod": "Alerting & incident notification — production",
    "alert-svc-qa": "Alerting service — QA",
}

# Stats — realistic production metrics  
import random
random.seed(42)

def gen_stats(env_name):
    is_prod = "-prod" in env_name
    is_warning = env_name in ["fraud-engine-prod", "data-pipeline-prod", "order-mgmt-prod"]
    is_critical = env_name in ["shipping-svc-prod"]
    
    if is_critical:
        return {
            "cpu": str(random.randint(82, 95)),
            "memory": str(random.randint(87, 94)),
            "storage": str(random.randint(78, 88)),
            "availability": f"{random.uniform(97.5, 99.2):.1f}",
            "latency": str(random.randint(180, 350)),
            "healthScore": str(random.randint(35, 55)),
            "currentState": "Critical",
            "swap": str(random.randint(40, 60)),
            "lastSyncedAt": "2026-04-07T10:00:00Z",
        }
    elif is_warning:
        return {
            "cpu": str(random.randint(65, 82)),
            "memory": str(random.randint(72, 86)),
            "storage": str(random.randint(60, 78)),
            "availability": f"{random.uniform(99.0, 99.7):.1f}",
            "latency": str(random.randint(80, 180)),
            "healthScore": str(random.randint(58, 74)),
            "currentState": "Warning",
            "swap": str(random.randint(20, 40)),
            "lastSyncedAt": "2026-04-07T14:30:00Z",
        }
    elif is_prod:
        return {
            "cpu": str(random.randint(25, 65)),
            "memory": str(random.randint(40, 75)),
            "storage": str(random.randint(30, 65)),
            "availability": f"{random.uniform(99.5, 99.99):.2f}",
            "latency": str(random.randint(12, 85)),
            "healthScore": str(random.randint(78, 98)),
            "currentState": "Healthy",
            "swap": str(random.randint(5, 20)),
            "lastSyncedAt": "2026-04-07T15:00:00Z",
        }
    else:
        return {
            "cpu": str(random.randint(15, 50)),
            "memory": str(random.randint(30, 60)),
            "storage": str(random.randint(20, 50)),
            "availability": f"{random.uniform(98.0, 99.9):.1f}",
            "latency": str(random.randint(20, 120)),
            "healthScore": str(random.randint(70, 95)),
            "currentState": "Healthy",
            "swap": str(random.randint(3, 15)),
            "lastSyncedAt": "2026-04-07T15:00:00Z",
        }


def call_api(payload):
    """Call the ingest API with retries"""
    for attempt in range(3):
        try:
            result = subprocess.run(
                ["curl", "-s", "-X", "POST", API,
                 "-H", "Content-Type: application/json",
                 "-H", f"x-api-key: {API_KEY}",
                 "-d", json.dumps(payload)],
                capture_output=True, text=True, timeout=30
            )
            resp = json.loads(result.stdout) if result.stdout else {}
            return resp
        except Exception as e:
            print(f"  Attempt {attempt+1} failed: {e}")
            time.sleep(2)
    return {"error": "All attempts failed"}


# First: Get all environment IDs
print("Fetching all environments...")
result = subprocess.run(
    ["curl", "-s", "https://uenp8g53a8.execute-api.us-east-1.amazonaws.com/prod/query",
     "-H", "Content-Type: application/json",
     "-H", f"x-api-key: {API_KEY}",
     "-d", json.dumps({"operation": "get-environments"})],
    capture_output=True, text=True, timeout=30
)
data = json.loads(result.stdout)
all_envs = data["data"]["environments"]
env_map = {e["name"]: e["id"] for e in all_envs}
print(f"Found {len(all_envs)} environments in Neptune")

# Update each named environment
success = 0
failed = 0
for env_name, owner in OWNERS.items():
    env_id = env_map.get(env_name)
    if not env_id:
        print(f"  SKIP {env_name} — not found in Neptune")
        failed += 1
        continue

    payload = {
        "operation": "update-entity",
        "id": env_id,
        "type": "Environment",
        "name": env_name,
        "owner": owner,
        "description": DESCRIPTIONS.get(env_name, f"Environment {env_name}"),
        "status": "active",
        "collaborators": COLLABORATORS.get(env_name, ""),
        "stats": gen_stats(env_name),
    }

    print(f"  Updating {env_name} (owner={owner})...", end=" ", flush=True)
    resp = call_api(payload)
    if resp.get("success") or resp.get("data"):
        print("OK")
        success += 1
    else:
        print(f"FAIL: {json.dumps(resp)[:120]}")
        failed += 1
    
    time.sleep(0.3)  # rate limiting

print(f"\nDone! {success} updated, {failed} failed/skipped")
