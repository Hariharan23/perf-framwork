#!/usr/bin/env python3
"""Debug script to check the generated report for details and cross-owner deps."""
import json, urllib.request, re, sys

# Generate report
url = "https://623dr8r8ee.execute-api.us-east-1.amazonaws.com/prod/reports/generate-daily"
req = urllib.request.Request(url, data=json.dumps({"owner": "Hari"}).encode(), headers={"Content-Type": "application/json"})
resp = json.loads(urllib.request.urlopen(req).read().decode())
print(f"Report generated: {resp.get('environmentCount')} envs, {resp.get('alertCount')} alerts")

# Fetch HTML
html = urllib.request.urlopen(resp["presignedUrl"]).read().decode()
print(f"HTML length: {len(html)}")

# 1. Check change history details
print("\n=== CHANGE HISTORY DETAILS ===")
tables = re.findall(r'Change History.*?</table>', html, re.S)
print(f"Found {len(tables)} history tables")
for i, table in enumerate(tables):
    rows = re.findall(r'<tr>(.*?)</tr>', table, re.S)
    for row in rows[:3]:
        cells = re.findall(r'<td[^>]*>(.*?)</td>', row, re.S)
        if len(cells) >= 5:
            details = re.sub(r'<[^>]+>', ' ', cells[4]).strip()
            print(f"  Table {i}: details='{details[:200]}'")

# 2. Check cross-owner dependencies  
print("\n=== CROSS-OWNER DEPS ===")
sections = re.findall(r'Cross-Owner Dependencies.*?(?=<!-- ==|$)', html, re.S)
for i, section in enumerate(sections):
    if 'No cross-owner' in section:
        print(f"  Env {i}: No cross-owner dependencies")
    else:
        rows = re.findall(r'<tr>(.*?)</tr>', section, re.S)
        for row in rows:
            cells = re.findall(r'<td[^>]*>(.*?)</td>', row, re.S)
            if cells:
                clean = [re.sub(r'<[^>]+>', '', c).strip() for c in cells]
                print(f"  Env {i}: {clean}")

# 3. Sample raw connected env data from graph
print("\n=== GRAPH NODE OWNERS ===")
# Check the D3 graph data for owner info — look at ALL nodes
for m in re.finditer(r'const graphData = \{(.*?)\};', html, re.S):
    graph_str = '{' + m.group(1) + '}'
    # Find all nodes with owner info
    for nm in re.finditer(r'"owner"\s*:\s*"([^"]*)"', m.group(1)):
        pass  # Just count
    # Find all nodes
    for nm in re.finditer(r'\{"id"\s*:\s*"([^"]+)"[^}]*?"owner"\s*:\s*"([^"]*)"', m.group(1)):
        print(f"  Node: {nm.group(1)[:40]}, Owner: {nm.group(2)}")
    for nm in re.finditer(r'\{"id"\s*:\s*"([^"]+)"[^}]*?\}', m.group(1)):
        if '"owner"' not in nm.group():
            print(f"  Node (no owner): {nm.group(1)[:40]}")

# 4. Check what we're looking for in connectivity
print("\n=== ENV SECTIONS ===")
for m in re.finditer(r'<!-- =+ ENVIRONMENT: ([^=]+?) =+ -->', html):
    print(f"  {m.group(1)}")
