#!/usr/bin/env python3
"""
Seed Hari's environments with clear before/after graph data:
- 10 OLD integrations (created 30 days ago) — show in Before & After
- 1 NEW integration (created today) — dimmed in Before, green in After
- 1 REMOVED integration (history entry) — red in Before, absent in After
"""
import json, urllib.request, uuid, time

INGEST_API = "https://0qhbaqienl.execute-api.us-east-1.amazonaws.com/prod/ingest"
QUERY_API  = "https://0qhbaqienl.execute-api.us-east-1.amazonaws.com/prod/query"
ONT = "http://neptune.aws.com/envmgmt/ontology/"

OLD_DATE = "2026-03-05T10:00:00.000Z"   # 30+ days ago
NEW_DATE = time.strftime('%Y-%m-%dT%H:%M:%S.000Z')  # today

# --- 10 OLD integrations (established, pre-existing) ---
OLD_INTEGRATIONS = [
    # Hari's web-portal-prod connects to many services
    ("web-portal-prod", "identity-svc-prod",         "Portal Auth Service",       "API"),
    ("web-portal-prod", "cache-layer-prod",           "Portal Cache Layer",        "Cache"),
    ("web-portal-prod", "api-gateway-prod",           "Portal API Gateway",        "API"),
    ("web-portal-prod", "analytics-svc-prod",         "Portal Analytics Feed",     "Streaming"),
    # Hari's mobile-bff-prod connects to several
    ("mobile-bff-prod", "api-gateway-prod",           "Mobile API Router",         "API"),
    ("mobile-bff-prod", "payment-gateway-prod",       "Mobile Payment Flow",       "API"),
    ("mobile-bff-prod", "notify-svc-prod",            "Mobile Push Notifier",      "Messaging"),
    # Hari's cms-platform-prod connects to others
    ("cms-platform-prod", "search-engine-prod",       "CMS Search Index",          "Search"),
    ("cms-platform-prod", "db-cluster-prod",          "CMS Database Cluster",      "Database"),
    ("cms-platform-prod", "monitoring-stack-prod",    "CMS Health Monitor",        "Monitoring"),
]

# --- 1 NEW integration (created today) ---
NEW_INTEGRATIONS = [
    ("web-portal-prod", "ml-recommender-prod",  "Portal ML Recommendations", "ML"),
]

# --- 1 REMOVED integration (history entry only) ---
REMOVALS = [
    {
        "envName": "mobile-bff-prod",
        "integrationName": "Legacy SMS Gateway",
        "targetEnvName": "sms-gateway-legacy-prod",
        "removedBy": "Hari",
    },
]


def get_entity_id(name):
    q = f'PREFIX env: <{ONT}> SELECT ?id WHERE {{ ?e env:name "{name}" ; env:id ?id }} LIMIT 1'
    req = urllib.request.Request(QUERY_API, data=json.dumps({"operation":"sparql-query","query":q}).encode(),
                                headers={"Content-Type":"application/json"}, method="POST")
    r = json.loads(urllib.request.urlopen(req).read().decode())
    bindings = r.get("data",{}).get("results",{}).get("bindings",[])
    return bindings[0]["id"]["value"] if bindings else ""


def create_integration(source, target, name, itype, created_at):
    """Create integration entity + relationship triples."""
    # Step 1: Create Integration entity
    payload = {
        "operation": "create",
        "name": name,
        "type": "Integration",
        "sourceService": source,
        "targetService": target,
        "status": "active",
        "description": f"{itype} integration from {source} to {target}",
    }
    req = urllib.request.Request(INGEST_API, data=json.dumps(payload).encode(),
                                headers={"Content-Type":"application/json"}, method="POST")
    result = json.loads(urllib.request.urlopen(req).read().decode())
    int_id = result.get("data",{}).get("id","")
    if not int_id:
        print(f"  FAIL creating {name}: {result}")
        return False

    # Step 2: Look up source/target env IDs
    source_id = get_entity_id(source)
    target_id = get_entity_id(target)
    if not source_id or not target_id:
        print(f"  FAIL lookups for {name}: src={source_id} tgt={target_id}")
        return False

    # Step 3: Create relationship triples with specific createdAt
    rel1_id = f"rel_{uuid.uuid4().hex[:8]}"
    rel2_id = f"rel_{uuid.uuid4().hex[:8]}"
    rel1_uri = f"{ONT}entity/{rel1_id}"
    rel2_uri = f"{ONT}entity/{rel2_id}"

    sparql = f"""PREFIX env: <{ONT}>
INSERT DATA {{
    <{rel1_uri}> env:id "{rel1_id}" .
    <{rel1_uri}> env:name "{source}_hasIntegration_{name}" .
    <{rel1_uri}> env:type "Relationship" .
    <{rel1_uri}> env:relationshipType "hasIntegration" .
    <{rel1_uri}> env:sourceEntity "{source}" .
    <{rel1_uri}> env:targetEntity "{name}" .
    <{rel1_uri}> env:sourceEntityId "{source_id}" .
    <{rel1_uri}> env:targetEntityId "{int_id}" .
    <{rel1_uri}> env:description "Relationship: {source} hasIntegration {name}" .
    <{rel1_uri}> env:createdAt "{created_at}" .
    <{rel2_uri}> env:id "{rel2_id}" .
    <{rel2_uri}> env:name "{name}_integratesWith_{target}" .
    <{rel2_uri}> env:type "Relationship" .
    <{rel2_uri}> env:relationshipType "integratesWith" .
    <{rel2_uri}> env:sourceEntity "{name}" .
    <{rel2_uri}> env:targetEntity "{target}" .
    <{rel2_uri}> env:sourceEntityId "{int_id}" .
    <{rel2_uri}> env:targetEntityId "{target_id}" .
    <{rel2_uri}> env:description "Relationship: {name} integratesWith {target}" .
    <{rel2_uri}> env:createdAt "{created_at}" .
}}"""
    req3 = urllib.request.Request(QUERY_API, data=json.dumps({"operation":"sparql-update","query":sparql}).encode(),
                                 headers={"Content-Type":"application/json"}, method="POST")
    r3 = json.loads(urllib.request.urlopen(req3).read().decode())

    # Step 4: Backdate the integration entity's createdAt
    int_uri = f"{ONT}{int_id}"
    backdate_sparql = f"""PREFIX env: <{ONT}>
DELETE {{ <{int_uri}> env:createdAt ?old }}
INSERT {{ <{int_uri}> env:createdAt "{created_at}" }}
WHERE {{ OPTIONAL {{ <{int_uri}> env:createdAt ?old }} }}"""
    req4 = urllib.request.Request(QUERY_API, data=json.dumps({"operation":"sparql-update","query":backdate_sparql}).encode(),
                                 headers={"Content-Type":"application/json"}, method="POST")
    r4 = json.loads(urllib.request.urlopen(req4).read().decode())

    ok = r3.get("success", False) and r4.get("success", False)
    return ok


print("=" * 60)
print("SEEDING HARI'S GRAPH DATA")
print("=" * 60)

# --- Create 10 OLD integrations ---
print(f"\n--- Creating 10 OLD integrations (dated {OLD_DATE[:10]}) ---")
for source, target, name, itype in OLD_INTEGRATIONS:
    ok = create_integration(source, target, name, itype, OLD_DATE)
    label = "OK" if ok else "FAIL"
    print(f"  [{label}] {source} -> {target} ({name})")
    time.sleep(0.4)

# --- Create 1 NEW integration ---
print(f"\n--- Creating 1 NEW integration (dated {NEW_DATE[:10]}) ---")
for source, target, name, itype in NEW_INTEGRATIONS:
    ok = create_integration(source, target, name, itype, NEW_DATE)
    label = "OK" if ok else "FAIL"
    print(f"  [{label}] {source} -> {target} ({name})")
    time.sleep(0.4)

# --- Create 1 REMOVAL history entry ---
print(f"\n--- Creating 1 REMOVAL history entry ---")
for removal in REMOVALS:
    env_id = get_entity_id(removal["envName"])
    if not env_id:
        print(f"  SKIP {removal['envName']}: env not found")
        continue

    history_id = f"history_{uuid.uuid4()}"
    history_uri = f"{ONT}entity/{history_id}"
    changes_json = json.dumps({
        "integrationName": removal["integrationName"],
        "targetEnvName": removal["targetEnvName"],
        "targetEnvId": "",
        "removedBy": removal["removedBy"],
    }).replace('"', '\\"')

    sparql = f"""PREFIX env: <{ONT}>
INSERT DATA {{
    <{history_uri}> env:id "{history_id}" .
    <{history_uri}> env:type "History" .
    <{history_uri}> env:entityId "{env_id}" .
    <{history_uri}> env:entityName "{removal['envName']}" .
    <{history_uri}> env:action "delete-integration" .
    <{history_uri}> env:timestamp "{NEW_DATE}" .
    <{history_uri}> env:user "{removal['removedBy']}" .
    <{history_uri}> env:changes "{changes_json}" .
}}"""
    req = urllib.request.Request(QUERY_API, data=json.dumps({"operation":"sparql-update","query":sparql}).encode(),
                                headers={"Content-Type":"application/json"}, method="POST")
    r = json.loads(urllib.request.urlopen(req).read().decode())
    ok = r.get("success", False)
    label = "OK" if ok else "FAIL"
    print(f"  [{label}] {removal['envName']}: removed '{removal['integrationName']}' -> {removal['targetEnvName']}")
    time.sleep(0.3)

print("\n" + "=" * 60)
print("SUMMARY")
print("=" * 60)
print(f"  10 OLD integrations (created {OLD_DATE[:10]}) — normal gray in both graphs")
print(f"   1 NEW integration  (created {NEW_DATE[:10]}) — dimmed in Before, green in After")
print(f"   1 REMOVED          (deleted {NEW_DATE[:10]}) — red in Before, absent in After")
print("\nGenerate Hari's report:")
print('  curl -X POST https://623dr8r8ee.execute-api.us-east-1.amazonaws.com/prod/reports/generate-daily -H "Content-Type: application/json" -d \'{"owner":"Hari"}\'')
