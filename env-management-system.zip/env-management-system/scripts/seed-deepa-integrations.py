#!/usr/bin/env python3
"""Add new integrations for Deepa's environments to test Recent Changes."""
import json, urllib.request, time, uuid

INGEST_API = "https://0qhbaqienl.execute-api.us-east-1.amazonaws.com/prod/ingest"
QUERY_API = "https://0qhbaqienl.execute-api.us-east-1.amazonaws.com/prod/query"
ONT = "http://neptune.aws.com/envmgmt/ontology/"

NEW_INTEGRATIONS = [
    # New: Deepa's warehouse-mgr-prod connects to Ravi's db-cluster-prod
    ("warehouse-mgr-prod", "db-cluster-prod", "Warehouse DB Sync", "Database"),
    # New: Deepa's order-mgmt-prod connects to Meena's data-pipeline-prod
    ("order-mgmt-prod", "data-pipeline-prod", "Order Event Stream", "Streaming"),
    # New: Deepa's supplier-portal-prod connects to Kumar's identity-svc-prod
    ("supplier-portal-prod", "identity-svc-prod", "Supplier Auth Gateway", "API"),
]

def get_entity_id(name):
    q = f'PREFIX env: <{ONT}> SELECT ?id WHERE {{ ?e env:name "{name}" ; env:id ?id }} LIMIT 1'
    req = urllib.request.Request(QUERY_API, data=json.dumps({"operation":"sparql-query","query":q}).encode(), headers={"Content-Type":"application/json"}, method="POST")
    r = json.loads(urllib.request.urlopen(req).read().decode())
    bindings = r.get("data",{}).get("results",{}).get("bindings",[])
    return bindings[0]["id"]["value"] if bindings else ""

for source, target, name, itype in NEW_INTEGRATIONS:
    # Step 1: Create Integration entity
    payload = {"operation":"create","name":name,"type":"Integration","sourceService":source,"targetService":target,"status":"active","description":f"{itype} integration from {source} to {target}"}
    req = urllib.request.Request(INGEST_API, data=json.dumps(payload).encode(), headers={"Content-Type":"application/json"}, method="POST")
    result = json.loads(urllib.request.urlopen(req).read().decode())
    int_id = result.get("data",{}).get("id","")
    if not int_id:
        print(f"  FAIL creating {name}: {result}")
        continue

    # Step 2: Look up entity IDs
    source_id = get_entity_id(source)
    target_id = get_entity_id(target)
    if not source_id or not target_id:
        print(f"  FAIL lookups for {name}: src={source_id} tgt={target_id}")
        continue

    # Step 3: Create relationships
    rel1_id = f"rel_{uuid.uuid4().hex[:8]}"
    rel2_id = f"rel_{uuid.uuid4().hex[:8]}"
    now = time.strftime('%Y-%m-%dT%H:%M:%S.000Z')
    rel1_uri = f"{ONT}entity/{rel1_id}"
    rel2_uri = f"{ONT}entity/{rel2_id}"

    sparql = f"""PREFIX env: <{ONT}>
INSERT DATA {{
    <{rel1_uri}> env:id "{rel1_id}" .
    <{rel1_uri}> env:name "{source}_hasIntegration_{name}" .
    <{rel1_uri}> env:type "Relationship" .
    <{rel1_uri}> env:relationshipType "hasIntegration" .
    <{rel1_uri}> env:sourceEntity "{source}" .
    <{rel1_uri}> env:targetEntity "{name}" .
    <{rel1_uri}> env:sourceEntityId "{source_id}" .
    <{rel1_uri}> env:targetEntityId "{int_id}" .
    <{rel1_uri}> env:description "Relationship: {source} hasIntegration {name}" .
    <{rel1_uri}> env:createdAt "{now}" .
    <{rel2_uri}> env:id "{rel2_id}" .
    <{rel2_uri}> env:name "{name}_integratesWith_{target}" .
    <{rel2_uri}> env:type "Relationship" .
    <{rel2_uri}> env:relationshipType "integratesWith" .
    <{rel2_uri}> env:sourceEntity "{name}" .
    <{rel2_uri}> env:targetEntity "{target}" .
    <{rel2_uri}> env:sourceEntityId "{int_id}" .
    <{rel2_uri}> env:targetEntityId "{target_id}" .
    <{rel2_uri}> env:description "Relationship: {name} integratesWith {target}" .
    <{rel2_uri}> env:createdAt "{now}" .
}}"""
    req3 = urllib.request.Request(QUERY_API, data=json.dumps({"operation":"sparql-update","query":sparql}).encode(), headers={"Content-Type":"application/json"}, method="POST")
    r3 = json.loads(urllib.request.urlopen(req3).read().decode())
    ok = r3.get("success", False)
    print(f"  {source} -> {target} ({name}): {'OK' if ok else 'FAIL: '+str(r3)}")
    time.sleep(0.3)

print("\nDone! Generate Deepa's report to verify.")
