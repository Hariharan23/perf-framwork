# EMS — Complete Roadmap

> Data Pipelines · Real-Time Alerting · Entra ID Auth · Trending AI Analytics

---

## Context

| Item | Detail |
|---|---|
| **Infrastructure** | AWS-native: Neptune (RDF/SPARQL), Lambda (Node.js 20.x), CDK, API Gateway |
| **Frontend** | Static HTML + D3.js served by Express (`server.js`) — no framework migration |
| **Existing pipelines** | PCE PostgreSQL (batch, manual trigger only), ScienceLogic (data model ready, no sync Lambda yet) |
| **Priority sources** | ScienceLogic, PCE (live), GitHub/GitLab, Splunk logs, Custom webhooks |
| **Latency target** | Batch (hourly/daily) for data pipelines; real-time (SQS-driven) for alerting only |
| **Change tracking** | Full `env:ChangeEvent` writes for every delta across all pipelines |
| **Auth** | Entra ID MSAL/PKCE on the existing HTML app — no React migration |

---

## Phase 1 — Pipeline Foundation

> **Blocks all subsequent pipeline phases. Build this first.**

### New files

| File | Purpose |
|---|---|
| `lambdas/shared/change-event-writer.ts` | Writes `env:ChangeEvent` triples to Neptune: `entityId`, `changeType` (add/update/remove), `oldValue`, `newValue`, `timestamp`, `sourceSystem`. Activates unused ontology classes defined in `ontology.ttl`. |
| `lambdas/shared/pipeline-delta-detector.ts` | Fetches current Neptune state for an entity, diffs against incoming payload, returns `{ added[], updated[], removed[] }`. Prevents no-op `ChangeEvent` writes on unchanged re-runs. |
| `cdk-stack/data-pipeline-stack.ts` | New CDK stack: shared S3 file-drop bucket, SQS DLQs per pipeline, Secrets Manager references, EventBridge Scheduler rules, IAM roles for all pipeline Lambdas. Reference VPC/IAM patterns from `cdk-stack/neptune-environment-stack.ts`. |

### Verification
- Seed script in `scripts/` invokes `change-event-writer` directly. Confirm the triple appears in Neptune via the query Lambda.

---

## Phase 2 — PCE Live Sync

> Lowest lift — mostly already built.

### Changes

| File | Change |
|---|---|
| `cdk-stack/pce-discovery-stack.ts` | Add `EventBridge Scheduler` rule at `rate(1 hour)` targeting the existing PCE Lambda. |
| `lambdas/src/pce-discovery.ts` | After each upsert in the orchestrator loop, call `change-event-writer` with the detected delta. |

### Verification
- Trigger PCE Lambda manually; confirm `ChangeEvent` triples appear in Neptune and the weekly report reflects the connectivity delta.

---

## Phase 3 — ScienceLogic Sync

> Activates the `EntityStats` fields that are already modeled in Neptune but currently unpopulated.

### New files

| File | Purpose |
|---|---|
| `lambdas/shared/sciencelogic-client.ts` | REST API client. Credentials via Secrets Manager — follow the pattern in `lambdas/shared/pce-client.ts`. |
| `lambdas/src/sciencelogic-sync.ts` | Hourly EventBridge schedule. Polls ScienceLogic, normalizes response to the existing `EntityStats` shape (defined in `lambdas/shared/neptune-sparql-client.ts`), runs delta-detector, calls change-event-writer, upserts stats to Neptune. |

### Decision needed
- ScienceLogic auth type — API key, OAuth, or basic auth? If OAuth, `sciencelogic-client.ts` needs a token-refresh loop.

### Verification
- Query Neptune for `env:healthScore` on a known device; confirm it matches the ScienceLogic UI value.

---

## Phase 4 — GitHub / GitLab Integration

> Populates `currentBuild` on `env:Application` nodes from CI/CD deployment events.

### New files

| File | Purpose |
|---|---|
| `lambdas/shared/github-client.ts` | REST client with a `provider` flag (`github` \| `gitlab`). PAT stored in Secrets Manager. Supports both providers behind a shared interface. |
| `lambdas/src/github-sync.ts` | Daily EventBridge schedule. Fetches repos + latest deployment events, name-matches to `env:Application` nodes in Neptune, updates `currentBuild` property + writes `ChangeEvent`. |

### Decision needed
- GitHub only, GitLab only, or both? Determines which base URLs and auth header formats `github-client.ts` needs to handle.

### Verification
- Push a commit on a mapped repo; after the daily sync, confirm `currentBuild` is updated on the corresponding Application node.

---

## Phase 5 — Splunk Log Processor

> Extracts deployment config metadata from log batches forwarded by Splunk.

### New infrastructure

| Resource | Detail |
|---|---|
| S3 bucket `splunk-log-drops` | Provisioned in `data-pipeline-stack`. Splunk Universal Forwarder or HEC writes log batches here — no Splunk-side code needed. |

### New files

| File | Purpose |
|---|---|
| `lambdas/src/splunk-processor.ts` | Triggered by S3 `PutObject`. Parses log lines for deployment config patterns (env name, app, build version, timestamps). Upserts Neptune `currentBuild` / `ConfigurationEntry` + writes `ChangeEvent`. |

### Decision needed
- Splunk log format — structured JSON export or raw syslog lines? A regex pattern or export schema must be agreed on before the parser is built.

### Verification
- Drop a sample log file in `splunk-log-drops`; confirm Lambda processes it and Neptune reflects the extracted metadata.

---

## Phase 6 — Custom Webhook Gateway

> Generic ingestion endpoint for any system that can POST JSON — CI/CD tools, scripts, third-party SaaS.

### New files

| File | Purpose |
|---|---|
| `lambdas/src/webhook-ingest.ts` | Accepts a normalized envelope: `{ sourceSystem, entityType, entityId, properties }`. API key authenticated — follow the API key pattern in `cdk-stack/bedrock-ai-query-stack.ts`. Calls `change-event-writer` on every accepted payload. |

### CDK changes
- Register API Gateway endpoint + API key in `data-pipeline-stack`.

---

## Phase 7 — Real-Time Alerting Pipeline

> The only phase with sub-minute behavior. ScienceLogic sync publishes threshold breaches to SQS; a dispatcher Lambda fans out to SNS.

### New files

| File | Purpose |
|---|---|
| `lambdas/shared/alert-rule-engine.ts` | Evaluates configurable threshold rules (`healthScore < 80`, `cpu > 90`, `availability < 99`, etc.) against incoming metric payloads. Looks up per-entity and global-default rules from DynamoDB. |
| `lambdas/src/alert-dispatcher.ts` | SQS trigger (`alert-queue`). Checks `AlertHistory` for deduplication window; if not suppressed, publishes to SNS topic `ems-alerts` (email / Teams / Slack subscribers). |

### New DynamoDB tables

| Table | PK | SK | Purpose |
|---|---|---|---|
| `AlertRules` | `entityId` | `metricName` | Configurable thresholds per environment/app, or `GLOBAL` defaults. |
| `AlertHistory` | `entityId#metricName` | `timestamp` | Deduplication — suppresses repeat alerts within a configurable window (e.g., 30 min). |

### CDK changes (in `data-pipeline-stack`)
- SQS queue `alert-queue` (with DLQ)
- SNS topic `ems-alerts`
- Modify `lambdas/src/sciencelogic-sync.ts` — after each metric upsert, if `alert-rule-engine` fires, publish breach event to `alert-queue`
- API Gateway CRUD routes: `GET / POST / DELETE /alert-rules`

### Verification
- Set a deliberately low threshold on a test entity. Trigger a ScienceLogic sync. Confirm SNS notification fires. Trigger a second sync within the dedup window and confirm no second alert is sent.

---

## Phase 8 — Entra ID Authentication

> No React migration needed — MSAL.js works directly in the existing static HTML app.

### Steps

1. **Azure Portal** — Register SPA app. Enable PKCE (automatic for SPA platform — no client secret). Expose scope `api://<client-id>/access_as_user`. Record `clientId` and `tenantId`.
2. **`environment-management-app.html`** — Add `@azure/msal-browser` (CDN or bundled). Initialize `PublicClientApplication` with `clientId` / `authority`. Wrap all API calls in a helper that calls `acquireTokenSilent` → attaches `Authorization: Bearer <token>`. Add login/logout UI with visibility toggling.
3. **`lambdas/src/authorizer.ts`** (new) — Lambda TOKEN authorizer: fetches JWKS from `https://login.microsoftonline.com/<tenant-id>/discovery/v2.0/keys` (module-scoped cache across warm invocations). Verifies RS256 signature via `jose`. Validates `iss`, `aud`, `exp`, `scp`. Returns IAM Allow/Deny policy + user identity in `context`.
4. **All CDK stacks** — Attach `TokenAuthorizer` (results cache TTL: 300s) to every API Gateway method. Update CORS `allowOrigins` from `*` to the specific frontend URL.

### Dependency note
- Phase 8 can be developed in parallel with Phases 3–7. It **must complete before production deployment** of alerting API routes (Phase 7) and the webhook gateway (Phase 6).

### Verification
- Open the app unauthenticated; confirm redirect to Entra login. After auth, confirm all API calls return 200. Confirm a direct unauthenticated API call returns 401.

---

## Phase 9 — Trending AI Query Analytics

> Based on the fully-designed architecture in `bedrock-trending-queries-plan.md`. Normalizes queries by SPARQL output so semantically identical natural-language questions are grouped automatically.

### New DynamoDB resources (in `cdk-stack/bedrock-ai-query-stack.ts`)

| Resource | Detail |
|---|---|
| Table `QueryAnalytics` | PK: `sparqlHash`. Attributes: `sampleQuestion`, `sparqlQuery`, `totalCount`, `uniqueUsers` (StringSet), `recentTimestamps` (List), `templateHash`, `lastExecuted`, `createdAt`. |
| GSI `templateHash-index` | PK: `templateHash`. Groups semantically equivalent queries (e.g., "show PROD integrations" and "show QA integrations" share a template). |

### New files

| File | Purpose |
|---|---|
| `lambdas/src/analytics-recorder.ts` | SHA-256 hashes the raw SPARQL. Templatizes it (replaces entity literals with `?_PARAM_N`). Atomic `UpdateItem` — increments `totalCount`, adds user to `uniqueUsers` set, appends timestamp. |
| `lambdas/src/popular-queries.ts` | Queries the GSI. Scores with time-decay: `(24h_count × 3) + (7d_count × 1.5) + (uniqueUsers × 2)`. Generalizes display text (`"Show integrations for PROD-WEST"` → `"Show integrations for [environment]"`). Returns top 15. |

### Changes to existing files

| File | Change |
|---|---|
| `bedrock-lambda/src/bedrock-query.ts` | After SPARQL execution, async-invoke `analytics-recorder` Lambda (fire-and-forget — does not block the query response). |
| `environment-management-app.html` | Replace hardcoded popular queries list with `GET /popular-queries` call. Cache result in `localStorage` with session TTL. |

### Verification
- Submit 10 identical AI queries. Call `GET /popular-queries`. Confirm the query appears with the correct count in the top 15 results.

---

## Cross-Cutting Concerns

| Concern | Approach |
|---|---|
| **Credentials** | All API keys, DB passwords, tokens via Secrets Manager — no hardcoded values anywhere. Follow pattern in `lambdas/shared/pce-client.ts`. |
| **Error handling** | Every pipeline Lambda has an SQS DLQ in `data-pipeline-stack`. Failed batches are retained for reprocessing. |
| **No-op protection** | `pipeline-delta-detector.ts` (Phase 1) prevents spurious `ChangeEvent` writes when data hasn't changed between syncs. |
| **Auth gate** | Phase 8 (Entra) should complete before Phase 6 (webhooks) and Phase 7 (alert rules API) go to production. |
| **Alerting + auth** | Alert rules management UI (Phase 7) benefits from Entra auth being in place to scope rules per user/team. |
| **Analytics is fire-and-forget** | `analytics-recorder` is async-invoked so it never adds latency to AI query responses. |

---

## Relevant Files

| File | Role |
|---|---|
| `lambdas/shared/pce-client.ts` | Secrets Manager pattern to replicate across all source clients |
| `lambdas/shared/neptune-sparql-client.ts` | `EntityStats` type + Neptune upsert methods to extend |
| `lambdas/shared/discovery-orchestrator.ts` | Delta/upsert orchestration pattern for all sync Lambdas |
| `cdk-stack/neptune-environment-stack.ts` | VPC + IAM reference for `data-pipeline-stack` |
| `cdk-stack/pce-discovery-stack.ts` | EventBridge + Lambda CDK pattern to replicate |
| `cdk-stack/bedrock-ai-query-stack.ts` | API key auth pattern (Phase 6) + extend for Phase 9 |
| `bedrock-lambda/src/bedrock-query.ts` | Modify for async analytics recording (Phase 9) |
| `environment-management-app.html` | Frontend changes for auth (Phase 8) + trending queries (Phase 9) |
| `ontology.ttl` | `env:ChangeEvent` and change-tracking classes to activate |
| `react-entra-auth-plan.md` | Full Entra PKCE + Lambda Authorizer implementation detail |
| `bedrock-trending-queries-plan.md` | Full trending query architecture with caching diagram |
