import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { NeptuneSparqlClient } from '../shared/neptune-sparql-client';

/**
 * AWS Lambda handler for Neptune database cleanup operations
 * Provides functionality to delete all data or specific entity types
 */
export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': 'http://localhost:3000',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, Accept, Origin, X-Requested-With',
    'Access-Control-Max-Age': '300'
  };

  try {
    // Handle CORS preflight requests
    if (event.httpMethod === 'OPTIONS') {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ message: 'CORS preflight successful' })
      };
    }

    const neptuneEndpoint = process.env.NEPTUNE_ENDPOINT;
    if (!neptuneEndpoint) {
      throw new Error('NEPTUNE_ENDPOINT environment variable is not set');
    }

    const client = new NeptuneSparqlClient(neptuneEndpoint);
    
    // Parse request body if present
    let requestBody: any = {};
    if (event.body) {
      try {
        requestBody = JSON.parse(event.body);
      } catch (e) {
        console.warn('Failed to parse request body:', e);
      }
    }
    
    // Get operation from path, query parameters, or request body
    const operation = event.pathParameters?.operation || 
                     event.queryStringParameters?.operation || 
                     requestBody.operation || 
                     'health';

    let result: any;

    switch (operation) {
      case 'health':
        const isHealthy = await client.healthCheck();
        result = {
          status: isHealthy ? 'healthy' : 'unhealthy',
          timestamp: new Date().toISOString(),
          service: 'neptune-cleanup'
        };
        break;

      case 'delete-all':
      case 'delete-all-data':
        result = await deleteAllData(client);
        break;

      case 'delete-entity':
        const entityId = requestBody.entityId || event.queryStringParameters?.entityId;
        if (!entityId) {
          throw new Error('entityId parameter is required for delete-entity operation');
        }
        result = await deleteEntity(client, entityId);
        break;

      case 'delete-type':
        const entityType = requestBody.entityType || event.queryStringParameters?.entityType;
        if (!entityType) {
          throw new Error('entityType parameter is required for delete-type operation');
        }
        result = await deleteByType(client, entityType);
        break;

      case 'delete-property':
        const property = requestBody.property || event.queryStringParameters?.property;
        const value = requestBody.value || event.queryStringParameters?.value;
        if (!property) {
          throw new Error('property parameter is required for delete-property operation');
        }
        result = await deleteByProperty(client, property, value);
        break;

      case 'count-entities':
        result = await countEntities(client);
        break;

      case 'list-types':
        result = await listEntityTypes(client);
        break;

      default:
        throw new Error(`Unknown operation: ${operation}. Available operations: health, delete-all, delete-all-data, delete-entity, delete-type, delete-property, count-entities, list-types`);
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        operation,
        data: result,
        timestamp: new Date().toISOString()
      })
    };

  } catch (error: any) {
    console.error('Cleanup operation failed:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};

/**
 * Delete all data from Neptune database
 */
async function deleteAllData(client: NeptuneSparqlClient): Promise<any> {
  console.log('Starting complete database cleanup...');
  
  // First get a count of entities before deletion
  const beforeCount = await countEntities(client);
  
  // Delete all triples (this removes all data)
  const deleteQuery = `
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    PREFIX env: <http://example.org/environment/>
    
    DELETE {
      ?s ?p ?o
    }
    WHERE {
      ?s ?p ?o
    }
  `;

  await client.executeSparqlUpdate(deleteQuery);
  
  // Get count after deletion to verify
  const afterCount = await countEntities(client);
  
  console.log(`Database cleanup completed. Deleted ${beforeCount.total - afterCount.total} entities.`);
  
  return {
    message: 'All data deleted successfully',
    deletedEntities: beforeCount.total - afterCount.total,
    beforeCount,
    afterCount,
    timestamp: new Date().toISOString()
  };
}

/**
 * Delete entities of a specific type
 */
async function deleteByType(client: NeptuneSparqlClient, entityType: string): Promise<any> {
  console.log(`Deleting entities of type: ${entityType}`);
  
  // Get count before deletion
  const beforeQuery = `
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX env: <http://example.org/environment/>
    
    SELECT (COUNT(?entity) as ?count)
    WHERE {
      ?entity rdf:type env:${entityType}
    }
  `;
  
  const beforeResult = await client.executeSparqlQuery(beforeQuery);
  const beforeCount = parseInt(beforeResult.results?.bindings?.[0]?.count?.value || '0');
  
  // Delete entities of specified type and all their properties
  const deleteQuery = `
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX env: <http://example.org/environment/>
    
    DELETE {
      ?entity ?p ?o .
      ?s ?q ?entity .
    }
    WHERE {
      ?entity rdf:type env:${entityType} .
      OPTIONAL { ?entity ?p ?o }
      OPTIONAL { ?s ?q ?entity }
    }
  `;

  await client.executeSparqlUpdate(deleteQuery);
  
  // Get count after deletion
  const afterResult = await client.executeSparqlQuery(beforeQuery);
  const afterCount = parseInt(afterResult.results?.bindings?.[0]?.count?.value || '0');
  
  return {
    message: `Deleted ${beforeCount - afterCount} entities of type ${entityType}`,
    entityType,
    deletedCount: beforeCount - afterCount,
    remainingCount: afterCount,
    timestamp: new Date().toISOString()
  };
}

/**
 * Delete entities by property value
 */
async function deleteByProperty(client: NeptuneSparqlClient, property: string, value?: string): Promise<any> {
  console.log(`Deleting entities with property: ${property}${value ? ` = ${value}` : ''}`);
  
  // Build the WHERE clause based on whether value is specified
  const whereClause = value 
    ? `?entity env:${property} "${value}" .`
    : `?entity env:${property} ?propValue .`;
  
  // Get count before deletion
  const beforeQuery = `
    PREFIX env: <http://example.org/environment/>
    
    SELECT (COUNT(DISTINCT ?entity) as ?count)
    WHERE {
      ${whereClause}
    }
  `;
  
  const beforeResult = await client.executeSparqlQuery(beforeQuery);
  const beforeCount = parseInt(beforeResult.results?.bindings?.[0]?.count?.value || '0');
  
  // Delete entities with specified property/value and all their connections
  const deleteQuery = `
    PREFIX env: <http://example.org/environment/>
    
    DELETE {
      ?entity ?p ?o .
      ?s ?q ?entity .
    }
    WHERE {
      ${whereClause}
      OPTIONAL { ?entity ?p ?o }
      OPTIONAL { ?s ?q ?entity }
    }
  `;

  await client.executeSparqlUpdate(deleteQuery);
  
  // Get count after deletion
  const afterResult = await client.executeSparqlQuery(beforeQuery);
  const afterCount = parseInt(afterResult.results?.bindings?.[0]?.count?.value || '0');
  
  return {
    message: `Deleted ${beforeCount - afterCount} entities with property ${property}${value ? ` = ${value}` : ''}`,
    property,
    value: value || 'any',
    deletedCount: beforeCount - afterCount,
    remainingCount: afterCount,
    timestamp: new Date().toISOString()
  };
}

/**
 * Count all entities by type
 */
async function countEntities(client: NeptuneSparqlClient): Promise<any> {
  const query = `
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX env: <http://example.org/environment/>
    
    SELECT ?type (COUNT(?entity) as ?count)
    WHERE {
      ?entity rdf:type ?type .
      FILTER(STRSTARTS(STR(?type), "http://example.org/environment/"))
    }
    GROUP BY ?type
    ORDER BY DESC(?count)
  `;

  const result = await client.executeSparqlQuery(query);
  const bindings = result.results?.bindings || [];
  
  const counts: any = {};
  let total = 0;
  
  bindings.forEach((binding: any) => {
    const typeUri = binding.type?.value || '';
    const typeName = typeUri.replace('http://example.org/environment/', '');
    const count = parseInt(binding.count?.value || '0');
    counts[typeName] = count;
    total += count;
  });
  
  return {
    total,
    byType: counts,
    timestamp: new Date().toISOString()
  };
}

/**
 * List all entity types in the database
 */
async function listEntityTypes(client: NeptuneSparqlClient): Promise<any> {
  const query = `
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX env: <http://example.org/environment/>
    
    SELECT DISTINCT ?type
    WHERE {
      ?entity rdf:type ?type .
      FILTER(STRSTARTS(STR(?type), "http://example.org/environment/"))
    }
    ORDER BY ?type
  `;

  const result = await client.executeSparqlQuery(query);
  const bindings = result.results?.bindings || [];
  
  const types = bindings.map((binding: any) => {
    const typeUri = binding.type?.value || '';
    return typeUri.replace('http://example.org/environment/', '');
  });
  
  return {
    entityTypes: types,
    count: types.length,
    timestamp: new Date().toISOString()
  };
}

/**
 * Delete a specific entity by ID
 */
async function deleteEntity(client: NeptuneSparqlClient, entityId: string): Promise<any> {
  const query = `
    DELETE {
      <${entityId}> ?p ?o .
      ?s ?q <${entityId}> .
    }
    WHERE {
      OPTIONAL { <${entityId}> ?p ?o }
      OPTIONAL { ?s ?q <${entityId}> }
    }
  `;

  console.log('Executing entity deletion query:', query);
  
  const result = await client.executeSparqlUpdate(query);
  
  return {
    entityId,
    deleted: true,
    result,
    timestamp: new Date().toISOString()
  };
}