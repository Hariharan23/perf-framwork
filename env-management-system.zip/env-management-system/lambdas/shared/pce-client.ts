// PCE Client for Discovery Pipeline
// Connects to PostgreSQL PCE table and retrieves environment property data
// Returns PceRecord[] — the same interface that pce-csv-parser.ts produces

import { PceRecord } from './pce-csv-parser';

// Re-export for convenience
export { PceRecord, groupByEnvironment } from './pce-csv-parser';

export interface PceClientConfig {
  host: string;
  port: number;
  database: string;
  user: string;
  password: string;
  ssl?: boolean;
  table?: string;          // Default: 'pce_properties'
  connectionTimeoutMs?: number;
}

/**
 * PCE PostgreSQL Client
 * Queries the PCE table for environment properties
 */
export class PceClient {
  private config: PceClientConfig;
  private table: string;

  constructor(config: PceClientConfig) {
    this.config = config;
    this.table = config.table || 'pce_properties';
  }

  /**
   * Fetch all properties from the PCE table
   */
  async fetchAllProperties(): Promise<PceRecord[]> {
    const { Client } = await import('pg');
    const client = new Client({
      host: this.config.host,
      port: this.config.port,
      database: this.config.database,
      user: this.config.user,
      password: this.config.password,
      ssl: this.config.ssl ? { rejectUnauthorized: false } : undefined,
      connectionTimeoutMillis: this.config.connectionTimeoutMs || 10000,
    });

    try {
      await client.connect();
      console.log(`Connected to PCE database at ${this.config.host}:${this.config.port}`);

      // Parameterized query — table name is from config, not user input
      const query = `SELECT environment_name, property_key, property_value FROM ${this.sanitizeIdentifier(this.table)} WHERE environment_name IS NOT NULL AND property_key IS NOT NULL AND property_value IS NOT NULL`;
      const result = await client.query(query);

      const records: PceRecord[] = result.rows.map((row: any) => ({
        environmentName: String(row.environment_name).trim(),
        propertyKey: String(row.property_key).trim(),
        propertyValue: String(row.property_value).trim(),
      }));

      console.log(`Fetched ${records.length} PCE records from ${this.table}`);
      return records;
    } finally {
      await client.end();
    }
  }

  /**
   * Fetch properties for a specific environment
   */
  async fetchByEnvironment(environmentName: string): Promise<PceRecord[]> {
    const { Client } = await import('pg');
    const client = new Client({
      host: this.config.host,
      port: this.config.port,
      database: this.config.database,
      user: this.config.user,
      password: this.config.password,
      ssl: this.config.ssl ? { rejectUnauthorized: false } : undefined,
      connectionTimeoutMillis: this.config.connectionTimeoutMs || 10000,
    });

    try {
      await client.connect();

      const query = `SELECT environment_name, property_key, property_value FROM ${this.sanitizeIdentifier(this.table)} WHERE environment_name = $1 AND property_key IS NOT NULL AND property_value IS NOT NULL`;
      const result = await client.query(query, [environmentName]);

      const records: PceRecord[] = result.rows.map((row: any) => ({
        environmentName: String(row.environment_name).trim(),
        propertyKey: String(row.property_key).trim(),
        propertyValue: String(row.property_value).trim(),
      }));

      console.log(`Fetched ${records.length} PCE records for environment "${environmentName}"`);
      return records;
    } finally {
      await client.end();
    }
  }

  /**
   * Sanitize a SQL identifier to prevent injection
   * Only allows alphanumeric, underscores, and dots (for schema.table)
   */
  private sanitizeIdentifier(identifier: string): string {
    if (!/^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(identifier)) {
      throw new Error(`Invalid table identifier: ${identifier}`);
    }
    return identifier;
  }
}
