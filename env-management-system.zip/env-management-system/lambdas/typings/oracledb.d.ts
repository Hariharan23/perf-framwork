/* eslint-disable */
// Minimal ambient declaration to satisfy TypeScript when oracledb doesn't
// ship its own .d.ts file.  Replace with @types/oracledb if needed.
declare module 'oracledb' {
  const oracledb: any;
  export = oracledb;
}
