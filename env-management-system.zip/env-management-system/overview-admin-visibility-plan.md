# Plan: Overview Admin Widget Visibility Controller

**Status:** Planned — not yet implemented  
**Date authored:** 29 May 2026  
**Scope:** Overview tab only

---

## 1. Goal

Add an admin-controlled visibility layer to the Overview dashboard so that:

1. An admin can toggle which sections / widgets are visible to users.
2. Disabled widgets' data is **never written to S3** — the snapshot payload itself is masked at the Lambda level, not just hidden in the UI.
3. The design is **group-aware from day one** so user-group-level access (SRE vs Dev vs Readonly) can be layered on top without a breaking migration.

---

## 2. Background

The Overview page is **snapshot-driven**:

```
EventBridge (15–30 min)
  → Lambda (overview-snapshot)
      → collects 13+ data sources in parallel
      → writes overview-snapshot.json → S3
      → AppSync mutation → DynamoDB (presignedUrl)
  → Browser
      → GraphQL getLatestSnapshot → presignedUrl
      → GET presignedUrl → render all widgets
```

Because the browser fetches data directly from S3 via a presigned URL, client-side hiding alone is **not sufficient** — the data is still in the S3 object. True masking requires the Lambda to omit disabled data keys before writing to S3.

---

## 3. The 14 Widgets (across 4 sections)

| Section                    | Widget                       | Snapshot data key(s) needed                                               |
| -------------------------- | ---------------------------- | ------------------------------------------------------------------------- |
| **KPI Strip**              | Environments count           | `envData`                                                                 |
|                            | Monitored Environments       | `healthData`                                                              |
|                            | Integrations count           | `integrationsData`                                                        |
|                            | Orphans count                | `orphanData`                                                              |
|                            | Config Changes               | `historyData`                                                             |
|                            | Aliases                      | `aliasData`                                                               |
| **Alerts & Topology**      | Active Alerts table          | `healthData`                                                              |
|                            | Environments by Status Donut | `networkData`                                                             |
|                            | Live Topology Graph          | `networkData`                                                             |
|                            | Blast Radius Hotspots        | `degreeData`, `integrationsData`                                          |
| **Discovery & Governance** | Discovery Pipelines          | `pipelineData`                                                            |
|                            | Governance & Hygiene Score   | `envData`, `orphanData`, `aliasData`                                      |
|                            | Recent Reconciler Runs       | `reconcilerData`                                                          |
|                            | Upcoming Scheduled Updates   | `scheduleData`                                                            |
| **Activity & Reports**     | Integration Changes + Log    | `integrationHistoryData`, `historyData`                                   |
|                            | Unresolved Orphans           | `orphanData`                                                              |
|                            | Recent Activity Feed         | `healthData`, `historyData`, `pipelineData`, `scheduleData`, `reportData` |
|                            | Reports & Health Trend       | `reportData`, `healthTrendData`                                           |

**Lambda masking rule:** include a data key in the snapshot if and only if **at least one enabled widget** depends on it.

---

## 4. Architecture

### 4.1 Config Storage

Reuse the existing DynamoDB table `SRE-POC-ems-snapshot-meta` (PK: `id`). Add a new item:

```json
{
  "id": "OVERVIEW_WIDGET_CONFIG",
  "groups": {
    "admin": {
      "sections": {
        "kpiStrip": {
          "visible": true,
          "cards": {
            "environments": true,
            "monitored": true,
            "integrations": true,
            "orphans": true,
            "configChanges": true,
            "aliases": true
          }
        },
        "alertsTopology": {
          "visible": true,
          "widgets": {
            "activeAlerts": true,
            "statusDonut": true,
            "liveTopology": true,
            "blastRadius": true
          }
        },
        "discoveryGovernance": {
          "visible": true,
          "widgets": {
            "discoveryPipelines": true,
            "governanceScore": true,
            "reconcilerRuns": true,
            "upcomingUpdates": true
          }
        },
        "activityReports": {
          "visible": true,
          "widgets": {
            "integrationChanges": true,
            "unresolvedOrphans": true,
            "recentActivity": true,
            "reportsHealthTrend": true
          }
        }
      }
    }
  },
  "defaultGroup": "admin",
  "updatedAt": "2026-05-29T00:00:00.000Z",
  "updatedBy": "system"
}
```

> **Why `groups` wrapper now?** Adding SRE / Dev / Readonly groups later is purely additive — no schema migration needed. See §6.

### 4.2 AppSync Schema Extension

File: `cdk-stack/dashboard-schema.graphql`

Add the following types and operations:

```graphql
type WidgetCardConfig {
  environments: Boolean
  monitored: Boolean
  integrations: Boolean
  orphans: Boolean
  configChanges: Boolean
  aliases: Boolean
}

type WidgetSectionConfig {
  visible: Boolean
  cards: WidgetCardConfig # kpiStrip only
  widgets: AWSJSON # alertsTopology / discoveryGovernance / activityReports
}

type GroupSectionConfig {
  kpiStrip: WidgetSectionConfig
  alertsTopology: WidgetSectionConfig
  discoveryGovernance: WidgetSectionConfig
  activityReports: WidgetSectionConfig
}

type WidgetConfig {
  id: String!
  groups: AWSJSON! # map of groupId -> GroupSectionConfig
  defaultGroup: String!
  updatedAt: AWSDateTime
  updatedBy: String
}

input WidgetConfigInput {
  groups: AWSJSON!
  defaultGroup: String!
  updatedBy: String
}

type Query {
  # existing...
  getLatestSnapshot: Snapshot
  getWidgetConfig: WidgetConfig # NEW — reads id="OVERVIEW_WIDGET_CONFIG"
}

type Mutation {
  # existing...
  updateWidgetConfig(input: WidgetConfigInput!): WidgetConfig # NEW — PutItem
}
```

### 4.3 CDK AppSync Resolvers

File: `cdk-stack/overview-snapshot-stack.ts`

Add two new AppSync resolvers against the existing DynamoDB data source:

- **`getWidgetConfig`** → DynamoDB `GetItem` with hard-coded key `{ id: "OVERVIEW_WIDGET_CONFIG" }`. If the item does not exist, return a default all-visible config.
- **`updateWidgetConfig`** → DynamoDB `PutItem` merging input + `updatedAt: $util.time.nowISO8601()`.

No new DynamoDB tables or IAM roles are needed — the Lambda already has `GetItem`/`PutItem` on this table.

### 4.4 Lambda Changes

File: `lambdas/src/overview-snapshot.ts`

**Step 1 — Read config at handler start:**

```ts
const configItem = await dynamo
  .getItem({
    TableName: SNAPSHOT_META_TABLE,
    Key: { id: { S: "OVERVIEW_WIDGET_CONFIG" } },
  })
  .promise();

const config = configItem.Item
  ? unmarshal(configItem.Item)
  : DEFAULT_ALL_VISIBLE_CONFIG;

const groupCfg = config.groups[config.defaultGroup].sections;
```

**Step 2 — Derive required data keys:**

```ts
function requiredKeys(s: GroupSectionConfig): Set<string> {
  const keys = new Set<string>();
  if (
    s.kpiStrip.cards.environments ||
    s.discoveryGovernance.widgets.governanceScore
  )
    keys.add("envData");
  if (
    s.kpiStrip.cards.monitored ||
    s.alertsTopology.widgets.activeAlerts ||
    s.activityReports.widgets.recentActivity
  )
    keys.add("healthData");
  if (
    s.alertsTopology.widgets.statusDonut ||
    s.alertsTopology.widgets.liveTopology
  )
    keys.add("networkData");
  if (s.kpiStrip.cards.integrations || s.alertsTopology.widgets.blastRadius)
    keys.add("integrationsData");
  if (
    s.kpiStrip.cards.configChanges ||
    s.activityReports.widgets.integrationChanges ||
    s.activityReports.widgets.recentActivity
  )
    keys.add("historyData");
  if (s.alertsTopology.widgets.blastRadius) keys.add("degreeData");
  if (
    s.kpiStrip.cards.orphans ||
    s.discoveryGovernance.widgets.governanceScore ||
    s.activityReports.widgets.unresolvedOrphans
  )
    keys.add("orphanData");
  if (s.kpiStrip.cards.aliases || s.discoveryGovernance.widgets.governanceScore)
    keys.add("aliasData");
  if (s.discoveryGovernance.widgets.reconcilerRuns) keys.add("reconcilerData");
  if (
    s.discoveryGovernance.widgets.upcomingUpdates ||
    s.activityReports.widgets.recentActivity
  )
    keys.add("scheduleData");
  if (
    s.activityReports.widgets.recentActivity ||
    s.activityReports.widgets.reportsHealthTrend
  )
    keys.add("reportData");
  if (
    s.discoveryGovernance.widgets.discoveryPipelines ||
    s.activityReports.widgets.recentActivity
  )
    keys.add("pipelineData");
  if (s.activityReports.widgets.integrationChanges)
    keys.add("integrationHistoryData");
  if (s.activityReports.widgets.reportsHealthTrend) keys.add("healthTrendData");
  // relationshipsData is always internal — keep as-is
  return keys;
}
```

**Step 3 — Conditionally run collectors** — skip any `Promise.allSettled` collector whose output key is not in `requiredKeys`.

**Step 4 — Write group-keyed S3 object:**

```
dashboard/overview-snapshot-admin.json   (today)
dashboard/overview-snapshot-sre.json     (future)
...
```

**Step 5 — Embed `_widgetConfig` in the snapshot:**

```json
{ "_widgetConfig": { ...groupCfg... }, "envData": [...], ... }
```

One S3 fetch gives both data and visibility config — no second AppSync call during page load.

**Step 6 — Store group-keyed presigned URLs in DynamoDB meta:**

```json
{
  "id": "OVERVIEW",
  "presignedUrls": { "admin": "https://s3..." },
  "generatedAt": "..."
}
```

### 4.5 Admin UI

File: `environment-management-app.html` (existing Admin tab)

Add a new card **"Overview Display Config"** below the existing Danger Zone section.

**Layout:**

```
┌─────────────────────────────────────────────────────┐
│ Overview Display Config                             │
│ Configure for: [ Admin ▾ ]  (group selector)        │
├─────────────────────────────────────────────────────┤
│ ▸ KPI Strip                          [●  visible]   │
│     ├ Environments         [toggle]                 │
│     ├ Monitored Envs       [toggle]                 │
│     ├ Integrations         [toggle]                 │
│     ├ Orphans              [toggle]                 │
│     ├ Config Changes       [toggle]                 │
│     └ Aliases              [toggle]                 │
│ ▸ Alerts & Topology                  [●  visible]   │
│     ├ Active Alerts        [toggle]                 │
│     ├ Status Donut         [toggle]                 │
│     ├ Live Topology        [toggle]                 │
│     └ Blast Radius         [toggle]                 │
│ ▸ Discovery & Governance             [●  visible]   │
│     ├ Discovery Pipelines  [toggle]                 │
│     ├ Governance Score     [toggle]                 │
│     ├ Reconciler Runs      [toggle]                 │
│     └ Upcoming Updates     [toggle]                 │
│ ▸ Activity & Reports                 [●  visible]   │
│     ├ Integration Changes  [toggle]                 │
│     ├ Unresolved Orphans   [toggle]                 │
│     ├ Recent Activity      [toggle]                 │
│     └ Reports & Trend      [toggle]                 │
├─────────────────────────────────────────────────────┤
│ [Reset to Defaults]         [Save Config]           │
│ Last saved: 29 May 2026 14:32 by admin              │
└─────────────────────────────────────────────────────┘
```

**Behaviour:**

- On admin tab open: call `getWidgetConfig` via AppSync and populate toggles.
- Section master toggle disabling sets all child widgets to `false` in the saved payload (not just visually).
- **Save Config** → `updateWidgetConfig` AppSync mutation → shows success toast.
- Config change takes effect on the **next Lambda run** (15–30 min). Optionally add a "Save & Regenerate Now" button that also triggers the Lambda via a direct invoke call.

### 4.6 Frontend Overview Rendering

After fetching the S3 snapshot, read `snapshot._widgetConfig`:

- For each disabled widget: skip the render call entirely (no DOM node created).
- For CSS grid sections: sections with all widgets hidden get `display: none` — the remaining sections reflow naturally.
- KPI Strip with partial cards disabled: surviving cards expand to fill the 6-column grid with `flex-grow` / `auto-fill`.

---

## 5. Files to Modify

| File                                   | Change                                                                                                                                    |
| -------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| `cdk-stack/dashboard-schema.graphql`   | Add `WidgetConfig` type hierarchy + `getWidgetConfig` query + `updateWidgetConfig` mutation                                               |
| `cdk-stack/overview-snapshot-stack.ts` | Add AppSync resolvers for both config operations against existing DynamoDB data source                                                    |
| `lambdas/src/overview-snapshot.ts`     | Read config, derive required keys, conditional collectors, write group-keyed S3 objects, embed `_widgetConfig`, store `presignedUrls` map |
| `environment-management-app.html`      | Add "Overview Display Config" card to Admin tab                                                                                           |
| Overview React component (future)      | Read `_widgetConfig` from snapshot, conditional renders, CSS grid adjustment                                                              |

---

## 6. Future Extension: User-Group Level Access

### Problem

A single S3 snapshot cannot serve multiple user groups with different masking rules. Presigned URLs are public — anyone holding the URL gets the full file.

### Recommended Approach: Multiple Group Snapshots (Option A)

When user-group access is introduced:

1. **Lambda** loops over `Object.keys(config.groups)` and generates one snapshot per group **in parallel**.
2. **S3 layout:** `dashboard/overview-snapshot-{group}.json` — already the layout from §4.4 Step 4.
3. **DynamoDB meta** already stores `presignedUrls: { admin: "...", sre: "...", ... }` — already the layout from §4.4 Step 6.
4. **AppSync `getLatestSnapshot`** reads the JWT `groups` claim → returns only that group's presigned URL. No data from another group's snapshot is ever exposed.

**This requires zero schema migrations** — all the data structures are group-aware from day one.

### Alternative: API Gateway Filter Proxy (Option B)

Drop presigned URLs entirely. Route snapshot fetches through APIGW + Lambda Authorizer. The filter Lambda reads the full snapshot from S3 and strips fields based on the JWT group claim before returning the response. More overhead per page load but supports fully dynamic per-field masking without regenerating snapshots.

### Planned Groups

| Group      | Intended audience         | Overview access                            |
| ---------- | ------------------------- | ------------------------------------------ |
| `admin`    | SRE / platform ops        | All 14 widgets                             |
| `sre`      | On-call SRE               | All widgets except Reconciler Runs         |
| `dev`      | App dev teams             | KPI strip + Topology + Integration Changes |
| `readonly` | Management / stakeholders | KPI strip + Status Donut only              |

### Entra Integration Hook

The `react-entra-auth-plan.md` Lambda Authorizer already validates JWT claims. When groups are live:

1. Entra App Registration → Token Configuration → add **Groups** claim.
2. AppSync auth on `getLatestSnapshot` switches from `API_KEY` → Cognito/Entra user pool.
3. Resolver reads `identity.claims.groups[0]` → maps to a key in `config.groups` → returns the matching presigned URL.
4. No Lambda or S3 changes needed — the group-keyed file layout is already in place.

---

## 7. Verification Checklist

- [ ] Save config with `blastRadius: false` → trigger Lambda → download S3 snapshot → confirm `degreeData` key is absent.
- [ ] Disable `alertsTopology` entirely → confirm `healthData`, `networkData`, `degreeData`, `integrationsData` are all absent (no other enabled widget depends on them).
- [ ] Load admin tab → confirm toggles reflect saved state.
- [ ] Toggle off "Unresolved Orphans" → save → reload Overview → widget absent, Activity & Reports section reflows.
- [ ] Reset to defaults → save → confirm next snapshot contains all data keys.
- [ ] (Future) Add `sre` group config → trigger Lambda → confirm `dashboard/overview-snapshot-sre.json` exists in S3 with correct masking.
