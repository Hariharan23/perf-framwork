#!/usr/bin/env node
import 'source-map-support/register';
import * as cdk from 'aws-cdk-lib';
import { NeptuneEnvironmentStack } from './cdk-stack/neptune-environment-stack';
import { BedrockAiQueryStack } from './cdk-stack/bedrock-ai-query-stack';
import { PceDiscoveryStack } from './cdk-stack/pce-discovery-stack';
import { WeeklyReportStack } from './cdk-stack/weekly-report-stack';

const app = new cdk.App();

// Deploy Neptune Environment Stack
const neptuneStack = new NeptuneEnvironmentStack(app, 'SRE-POC-NeptuneEnvironmentStack', {
  env: {
    account: process.env.CDK_DEFAULT_ACCOUNT,
    region: process.env.CDK_DEFAULT_REGION || 'us-east-1',
  },
  description: 'SRE POC Environment Management System with Neptune Database'
});

// Deploy Bedrock AI Query Stack (depends on Neptune stack)
const bedrockStack = new BedrockAiQueryStack(app, 'SRE-POC-BedrockAiQueryStack', {
  env: {
    account: process.env.CDK_DEFAULT_ACCOUNT,
    region: process.env.CDK_DEFAULT_REGION || 'us-east-1',
  },
  description: 'AI-powered natural language query interface for Neptune using AWS Bedrock',
  neptuneClusterEndpoint: neptuneStack.neptuneCluster.attrEndpoint,
  neptuneSecurityGroup: neptuneStack.neptuneSecurityGroup,
  neptuneVpc: neptuneStack.vpc,
  neptuneSubnets: neptuneStack.vpc.privateSubnets,
});

// Add dependency so Bedrock stack deploys after Neptune stack
bedrockStack.addDependency(neptuneStack);

// Deploy PCE Discovery Stack (depends on Neptune stack)
const pceDiscoveryStack = new PceDiscoveryStack(app, 'SRE-POC-PceDiscoveryStack', {
  env: {
    account: process.env.CDK_DEFAULT_ACCOUNT,
    region: process.env.CDK_DEFAULT_REGION || 'us-east-1',
  },
  description: 'PCE table-based environment discovery pipeline',
  neptuneClusterEndpoint: neptuneStack.neptuneCluster.attrEndpoint,
  neptuneSecurityGroup: neptuneStack.neptuneSecurityGroup,
  neptuneVpc: neptuneStack.vpc,
  neptuneSubnets: neptuneStack.vpc.privateSubnets,
});
pceDiscoveryStack.addDependency(neptuneStack);

// Deploy Weekly Report Stack (depends on Neptune stack)
const reportStack = new WeeklyReportStack(app, 'SRE-POC-WeeklyReportStack', {
  env: {
    account: process.env.CDK_DEFAULT_ACCOUNT,
    region: process.env.CDK_DEFAULT_REGION || 'us-east-1',
  },
  description: 'EMS Weekly/Daily Report Generator — scheduled and on-demand',
  neptuneClusterEndpoint: neptuneStack.neptuneCluster.attrEndpoint,
  neptuneSecurityGroup: neptuneStack.neptuneSecurityGroup,
  neptuneVpc: neptuneStack.vpc,
  neptuneSubnets: neptuneStack.vpc.privateSubnets,
});
reportStack.addDependency(neptuneStack);


app.synth();
