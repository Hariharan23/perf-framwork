#!/usr/bin/env node
import 'source-map-support/register';
import * as cdk from 'aws-cdk-lib';
import { NeptuneEnvironmentStack } from './cdk-stack/neptune-environment-stack';

const app = new cdk.App();

new NeptuneEnvironmentStack(app, 'SRE-POC-NeptuneEnvironmentStack', {
  env: {
    account: process.env.CDK_DEFAULT_ACCOUNT,
    region: process.env.CDK_DEFAULT_REGION || 'us-east-1',
  },
  description: 'SRE POC Environment Management System'
});

app.synth();
