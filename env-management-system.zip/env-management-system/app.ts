#!/usr/bin/env node
import 'source-map-support/register';
import * as cdk from 'aws-cdk-lib';
import { NeptuneEnvironmentStack } from './cdk-stack/neptune-environment-stack';
import { BedrockAiQueryStack } from './cdk-stack/bedrock-ai-query-stack';

const app = new cdk.App();

// Deploy Neptune Environment Stack
const neptuneStack = new NeptuneEnvironmentStack(app, 'SRE-POC-NeptuneEnvironmentStack', {
  env: {
    account: process.env.CDK_DEFAULT_ACCOUNT,
    region: process.env.CDK_DEFAULT_REGION || 'us-east-1',
  },
  description: 'SRE POC Environment Management System with Neptune Database'
});

// Deploy Bedrock AI Query Stack (depends on Neptune stack)
const bedrockStack = new BedrockAiQueryStack(app, 'SRE-POC-BedrockAiQueryStack', {
  env: {
    account: process.env.CDK_DEFAULT_ACCOUNT,
    region: process.env.CDK_DEFAULT_REGION || 'us-east-1',
  },
  description: 'AI-powered natural language query interface for Neptune using AWS Bedrock',
  neptuneClusterEndpoint: neptuneStack.neptuneCluster.attrEndpoint,
  neptuneSecurityGroup: neptuneStack.neptuneSecurityGroup,
  neptuneVpc: neptuneStack.vpc,
  neptuneSubnets: neptuneStack.vpc.privateSubnets,
});

// Add dependency so Bedrock stack deploys after Neptune stack
bedrockStack.addDependency(neptuneStack);

app.synth();
