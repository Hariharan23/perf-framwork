# Pipeline Topology Editor — Design & Implementation Plan

## Conceptual Model

Each **SourceBlock** is a registered connector type (`PAS`, `CSV`, `ScienceLogic`). Each block has one or more _instances_ underneath it (the SSM-configured `envId` entries). A **MappingEdge** is a persisted rule: "when this source produces a record, look up an existing Neptune entity where `entityField = sourceField`, then write data into it using `mode`."

```
SourceBlock  ──[MappingEdge]──▶  EntityBlock
  (PAS)          joinKey:           (Environment)
                 PAS.envName
                   = Env.name
                 mode: upsert

SourceBlock  ──[MappingEdge]──▶  EntityBlock
  (ScienceLogic) joinKey:          (EntityStats on Environment)
                 SL.deviceHostname
                   = Env.name
                 mode: enrich-only   ← never creates, only enriches
```

The canvas **IS** the configuration. Drawing an edge from ScienceLogic to Environment and setting the join key is all that is needed to wire in a new source — no code change.

---

## MappingEdge Modes

| Mode           | What happens                                                                                         | Example                                  |
| -------------- | ---------------------------------------------------------------------------------------------------- | ---------------------------------------- |
| `upsert`       | Find existing entity by join key → update it. If not found → create it.                              | PAS → Environment                        |
| `enrich-only`  | Find existing entity by join key → add stats/config properties. If not found → skip (never creates). | ScienceLogic → Environment               |
| `create-child` | Use matched entity as parent → create a new child entity linked to it.                               | PAS → Integration (parent = Environment) |

---

## New DynamoDB Table: `pipeline-topology`

Single table, two record types distinguished by PK prefix.

### Source Block record (PK: `BLOCK#{sourceType}`)

```json
{
  "pk": "BLOCK#PAS",
  "displayName": "PAS Application DB",
  "creates": ["Environment", "Integration"],
  "connectorType": "PAS",
  "enabled": true
}
```

### Mapping Edge records (PK: `EDGE#{id}`)

```json
{
  "pk": "EDGE#pas-env-001",
  "fromSource": "PAS",
  "toEntity": "Environment",
  "mode": "upsert",
  "joinKey": { "sourceField": "envName", "entityField": "name" },
  "parentEdgeId": null,
  "enabled": true
}

{
  "pk": "EDGE#pas-int-001",
  "fromSource": "PAS",
  "toEntity": "Integration",
  "mode": "create-child",
  "joinKey": { "sourceField": "propertyKey", "entityField": "name" },
  "parentEdgeId": "EDGE#pas-env-001",
  "enabled": true
}

{
  "pk": "EDGE#sl-env-001",
  "fromSource": "ScienceLogic",
  "toEntity": "Environment",
  "mode": "enrich-only",
  "joinKey": { "sourceField": "deviceHostname", "entityField": "name" },
  "parentEdgeId": null,
  "enabled": false
}
```

The `parentEdgeId` field links child-creation edges to the parent entity edge (e.g. Integration is a child of Environment in the PAS flow).

---

## New API Operations in `pipeline-config.ts`

| Operation             | Description                                                                          |
| --------------------- | ------------------------------------------------------------------------------------ |
| `get-topology`        | Scan all `BLOCK#` and `EDGE#` records → return `{ blocks, edges }` for canvas render |
| `upsert-source-block` | Create/update a BLOCK record — admin registers a new source type                     |
| `delete-source-block` | Remove a BLOCK record and cascade-delete all its edges                               |
| `upsert-mapping-edge` | Create/update an EDGE record — called when admin draws or edits an edge on canvas    |
| `delete-mapping-edge` | Remove an EDGE record — called when admin deletes an edge                            |
| `toggle-mapping-edge` | Flip `enabled` true/false — pause a mapping without deleting it                      |

### Runtime consumption

`discovery-orchestrator.ts` reads EDGE records at pipeline start and routes each record type according to `mode` instead of having the mapping logic hardcoded. The `TOPOLOGY_TABLE_NAME` env var is injected via CDK.

---

## Frontend Component Architecture

```
PipelineTopologyPage
├── <ReactFlow canvas>
│   ├── SourceBlock (custom node)              ← one per BLOCK# record
│   │   ├── header: icon + displayName
│   │   ├── body: list of SSM-configured instances with last-run badges
│   │   ├── footer: [+ Add Instance] [Run All]
│   │   └── handles: one output handle per entity type it creates/enriches
│   │
│   ├── EntityBlock (custom node)              ← one per entity type (Env / Int / Stats)
│   │   ├── header: entity type icon + name
│   │   ├── body: live count from Neptune
│   │   ├── badge: "42 nodes" / "128 nodes"
│   │   └── handles: input handle for each source that can write to it
│   │
│   └── MappingEdge (custom edge)              ← one per EDGE# record
│       ├── label chip: join key display ("envName = name")
│       ├── mode badge: upsert / enrich-only / create-child
│       ├── enabled toggle (click to pause without deleting)
│       └── click → opens MappingEdgeDrawer
│
├── MappingEdgeDrawer (right slide-out panel)
│   ├── Source field selector (dropdown of fields from ConnectorConfigSchema)
│   ├── Entity field selector (id / name / hostname / etc.)
│   ├── Mode selector (upsert / enrich-only / create-child)
│   ├── Parent edge selector (shown only when mode = create-child)
│   └── [Save] [Delete Edge] [Test Mapping]
│
└── TestMappingPanel (inline dry-run)
    ├── Paste sample record from source
    ├── Shows: "Would match entity: DCM (id=abc-123)" or "No match — would create"
    └── Shows: "Would write fields: name, discoveredBy, discoveredAt"
```

---

## How ScienceLogic Wires In (Zero Code Change)

1. Admin drags a new `SourceBlock` onto the canvas and names it `ScienceLogic`.
2. Draws an edge from `ScienceLogic → Environment`, sets join key `deviceHostname = name`, mode `enrich-only`.
3. Admin clicks `[+ Add Instance]` and fills in the ScienceLogic API host/key in the connector form.
4. At runtime, `discovery-orchestrator` reads the topology edge, calls `getEntityByName(deviceHostname, 'Environment')`, and if found calls `updateStatsProperties(entity.id, slStats)`.

The **ScienceLogic connector** only needs to implement `DataSourceConnector.fetch()` returning records with a consistent schema. All routing, matching, and write logic is driven by the topology table.

---

## Implementation Phases

### Phase 1 — Backend topology storage

1. Add `pipeline-topology` DynamoDB table to `data-pipeline-stack.ts`
   - PK: `pk` (String)
   - Seed with default BLOCK and EDGE records for PAS and CSV on first deploy
2. Add `TOPOLOGY_TABLE_NAME` env var to `pipeline-config.ts` Lambda in CDK
3. Implement `get-topology`, `upsert-source-block`, `upsert-mapping-edge`, `delete-mapping-edge`, `toggle-mapping-edge` in `pipeline-config.ts`

### Phase 2 — Runtime topology consumption

4. Modify `discovery-orchestrator.ts` to load EDGE records at pipeline start and route each record according to `mode` instead of hardcoded logic
5. Add `get-source-lineage` to `query.ts` — reads `config_discoveredBy` from Neptune, returns entities grouped by source
6. Add `rename-environment` and `merge-environments` operations to `query.ts`

### Phase 3 — Alias map CRUD

7. Add `list-alias-map`, `upsert-alias`, `delete-alias` operations to `pipeline-config.ts` targeting the `{stackName}-hostname-aliases` DynamoDB table

### Phase 4 — Frontend canvas

8. `PipelineTopologyPage` with React Flow — loads from `get-topology` on mount
9. `SourceBlock` and `EntityBlock` custom node components
10. `MappingEdge` custom edge component with mode badge and enable/disable toggle
11. `MappingEdgeDrawer` right panel with field selectors and `Test Mapping` dry-run
12. `SourceInstancePanel` inside each SourceBlock showing SSM instances with last-run status badges

---

## Verification Checklist

- [ ] Add a ScienceLogic block and edge from the canvas UI → confirm `EDGE#sl-env-001` record persists to DynamoDB
- [ ] Run `trigger-sync` for PAS → confirm orchestrator reads topology table and routes correctly
- [ ] `Test Mapping` on the SL edge with a sample device record → "Would match env X"
- [ ] `get-source-lineage` returns entities grouped by `config_discoveredBy`
- [ ] Disable an edge via toggle → pipeline run skips that mapping, no data written
- [ ] Delete a source block → all associated edges also removed (cascade)
- [ ] Alias map CRUD operations persist correctly to hostname-aliases table

---

## Files Affected

| File                                                  | Change                                                                                   |
| ----------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| `cdk-stack/data-pipeline-stack.ts`                    | Add `pipeline-topology` DynamoDB table; inject `TOPOLOGY_TABLE_NAME` env var             |
| `lambdas/src/pipeline-config.ts`                      | Add topology CRUD operations + alias map CRUD operations                                 |
| `lambdas/src/query.ts`                                | Add `get-source-lineage`, `rename-environment`, `merge-environments`                     |
| `lambdas/shared/discovery-orchestrator.ts`            | Load and consume EDGE records at runtime                                                 |
| `lambdas/shared/connector-registry.ts`                | Register ScienceLogic connector when implemented                                         |
| `lambdas/shared/connectors/sciencelogic-connector.ts` | New file — implement `DataSourceConnector` in enrich mode                                |
| Frontend (new)                                        | `PipelineTopologyPage`, `SourceBlock`, `EntityBlock`, `MappingEdge`, `MappingEdgeDrawer` |
