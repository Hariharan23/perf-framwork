# EMS Operations Hub React UI

An isolated React interface for the streamlined EMS experience. It does not modify the existing application or backend.

The UI includes a compatibility adapter for the existing EMS Lambda contracts. It never substitutes mock operational data: when an endpoint is not configured or returns no records, the relevant screen shows an explicit configuration, empty, or error state.

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Connect the existing backend

Copy `.env.example` to `.env.local` and supply the same Lambda/API Gateway URLs and API keys currently injected into `environment-management-app.html`.

No backend route, graph schema, Lambda operation, or CDK stack change is required. The adapter uses the existing POST body contract:

```json
{ "operation": "get-entities" }
```

Supported operations include `health`, `get-entities`, `get-entity`, `get-network`, `get-network-for-envs`, `sparql-query`, `create`, `update-entity`, `bulk-ingest`, relationship operations, and pipeline operations.

The ServiceNow areas also map the existing CMDB connector, CI Link Intelligence, and Service Map gateways. Endpoint values may be either the API stage root (for example `.../prod`) or the CDK output containing a route/template (for example `.../prod/cmdb/{operation}`); the compatibility adapter normalizes both forms.

## D3 dependency graph

The Visualize workspace uses D3.js with force layout, node dragging, pan/zoom, fit/reset controls, node and environment filters, progressive hop expansion, entity/relationship inspection, relationship mutation through existing operations, SVG/PNG export, and a viewport-filling full-screen mode.

The Query & Explore workspace provides an editable SPARQL editor. Custom text is sent using the current backend contract: `POST <VITE_QUERY_URL>?operation=sparql-query` with `{ "query": "..." }` in the request body.

## Production build

```bash
npm run build
```
