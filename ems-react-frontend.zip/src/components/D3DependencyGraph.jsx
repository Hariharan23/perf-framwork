import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as d3 from 'd3';
import { Download, Maximize2, Minimize2, Network, RefreshCw, Search, ZoomIn, ZoomOut } from 'lucide-react';
import { emsApi, isConfigured } from '../api/emsApi';

const ref = (value) => typeof value === 'object' ? value?.id : value;
const pick = (object, keys) => keys.map(key => object?.[key]).find(Boolean);

function normalizeGraph(entities, relationships) {
  const nodes = entities.map((entity, index) => ({
    ...entity,
    id: String(entity.id || entity.code || `node-${index}`),
    label: entity.name || entity.code || `Entity ${index + 1}`,
    entityType: entity.entityType || 'Environment',
  }));
  const lookup = new Map(nodes.flatMap(node => [[node.id, node.id], [node.name, node.id], [node.code, node.id]]));
  const links = relationships.map((edge, index) => {
    const rawSource = ref(pick(edge, ['sourceId','sourceEntityId','from','source']));
    const rawTarget = ref(pick(edge, ['targetId','targetEntityId','to','target']));
    return {
      ...edge,
      id: String(edge.id || edge.relationshipId || `edge-${index}`),
      relationshipId: edge.relationshipId || edge.id,
      source: lookup.get(rawSource) || String(rawSource || ''),
      target: lookup.get(rawTarget) || String(rawTarget || ''),
      label: edge.label || edge.relationshipType || edge.type || 'depends on',
    };
  }).filter(edge => lookup.has(edge.source) && lookup.has(edge.target));
  return { nodes, links };
}

function D3DependencyGraph({ entities, relationships, selected, setSelected, notify = () => {} }) {
  const svgRef = useRef(null);
  const viewportRef = useRef(null);
  const zoomRef = useRef(null);
  const [query, setQuery] = useState('');
  const [depth, setDepth] = useState(2);
  const [environment, setEnvironment] = useState('All environments');
  const [type, setType] = useState('All types');
  const [focusedId, setFocusedId] = useState(selected?.id || '');
  const [selectedEdge, setSelectedEdge] = useState(null);
  const [fullScreen, setFullScreen] = useState(false);
  const [revision, setRevision] = useState(0);
  const graph = useMemo(() => normalizeGraph(entities, relationships), [entities, relationships]);

  useEffect(() => {
    const onKeyDown = event => { if (event.key === 'Escape') setFullScreen(false); };
    document.body.classList.toggle('graph-fullscreen-open', fullScreen);
    window.addEventListener('keydown', onKeyDown);
    return () => { document.body.classList.remove('graph-fullscreen-open'); window.removeEventListener('keydown', onKeyDown); };
  }, [fullScreen]);

  const visibleGraph = useMemo(() => {
    let allowed = new Set(graph.nodes.map(node => node.id));
    if (environment !== 'All environments') allowed = new Set(graph.nodes.filter(node => node.type === environment).map(node => node.id));
    if (type !== 'All types') allowed = new Set([...allowed].filter(id => graph.nodes.find(node => node.id === id)?.entityType === type));
    if (focusedId && graph.nodes.some(node => node.id === focusedId)) {
      const adjacency = new Map(graph.nodes.map(node => [node.id, new Set()]));
      graph.links.forEach(link => { adjacency.get(ref(link.source))?.add(ref(link.target)); adjacency.get(ref(link.target))?.add(ref(link.source)); });
      const reached = new Set([focusedId]); let frontier = [focusedId];
      for (let hop = 0; hop < depth; hop += 1) { const next = []; frontier.forEach(id => adjacency.get(id)?.forEach(neighbor => { if (!reached.has(neighbor)) { reached.add(neighbor); next.push(neighbor); } })); frontier = next; }
      allowed = new Set([...allowed].filter(id => reached.has(id)));
    }
    const nodes = graph.nodes.filter(node => allowed.has(node.id) && (!query || `${node.name} ${node.code} ${node.owner}`.toLowerCase().includes(query.toLowerCase()))).slice(0, 80);
    const ids = new Set(nodes.map(node => node.id));
    return { nodes: nodes.map(node => ({ ...node })), links: graph.links.filter(link => ids.has(ref(link.source)) && ids.has(ref(link.target))).map(link => ({ ...link })) };
  }, [graph, environment, type, focusedId, depth, query, revision]);

  useEffect(() => {
    const svg = d3.select(svgRef.current); const width = svgRef.current?.clientWidth || 900; const height = svgRef.current?.clientHeight || 620;
    svg.selectAll('*').remove();
    const defs = svg.append('defs');
    defs.append('marker').attr('id','d3-arrow').attr('viewBox','0 -5 10 10').attr('refX',29).attr('refY',0).attr('markerWidth',5).attr('markerHeight',5).attr('orient','auto').append('path').attr('d','M0,-5L10,0L0,5').attr('fill','#999');
    const root = svg.append('g').attr('class','d3-viewport'); viewportRef.current = root;
    const zoom = d3.zoom().scaleExtent([.2,4]).on('zoom', event => root.attr('transform',event.transform)); zoomRef.current = zoom; svg.call(zoom);
    const links = root.append('g').selectAll('line').data(visibleGraph.links).join('line').attr('class','d3-link').attr('marker-end','url(#d3-arrow)').on('click',(event,d)=>{event.stopPropagation();setSelectedEdge(d)});
    const labels = root.append('g').selectAll('text').data(visibleGraph.links).join('text').attr('class','d3-edge-label').text(d=>d.label);
    const nodes = root.append('g').selectAll('g').data(visibleGraph.nodes,d=>d.id).join('g').attr('class',d=>`d3-node ${selected?.id===d.id?'selected':''}`).on('click',(event,d)=>{event.stopPropagation();setSelected(d);setSelectedEdge(null)}).on('dblclick',(event,d)=>{event.stopPropagation();setFocusedId(d.id);setDepth(value=>Math.min(3,value+1));notify(`Expanded ${d.name} to the next dependency level.`)});
    nodes.append('circle').attr('r',25).attr('class',d=>`node-circle ${String(d.health||'healthy').toLowerCase()}`);
    nodes.append('text').attr('class','node-monogram').text(d=>(d.name||'?')[0].toUpperCase());
    nodes.append('text').attr('class','node-name').attr('y',40).text(d=>(d.name||d.id).length>22?`${(d.name||d.id).slice(0,21)}…`:d.name||d.id);
    nodes.append('text').attr('class','node-type').attr('y',54).text(d=>d.entityType);
    const simulation = d3.forceSimulation(visibleGraph.nodes).force('link',d3.forceLink(visibleGraph.links).id(d=>d.id).distance(150).strength(.75)).force('charge',d3.forceManyBody().strength(-520)).force('center',d3.forceCenter(width/2,height/2)).force('collision',d3.forceCollide(62));
    const drag = d3.drag().on('start',(event,d)=>{if(!event.active)simulation.alphaTarget(.3).restart();d.fx=d.x;d.fy=d.y}).on('drag',(event,d)=>{d.fx=event.x;d.fy=event.y}).on('end',(event,d)=>{if(!event.active)simulation.alphaTarget(0);d.fx=null;d.fy=null}); nodes.call(drag);
    simulation.on('tick',()=>{links.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y).attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);labels.attr('x',d=>(d.source.x+d.target.x)/2).attr('y',d=>(d.source.y+d.target.y)/2-7);nodes.attr('transform',d=>`translate(${d.x},${d.y})`)});
    return () => simulation.stop();
  }, [visibleGraph, selected?.id, setSelected, notify]);

  const zoomBy = factor => d3.select(svgRef.current).transition().duration(220).call(zoomRef.current.scaleBy, factor);
  const reset = () => d3.select(svgRef.current).transition().duration(350).call(zoomRef.current.transform,d3.zoomIdentity);
  const fit = () => { const bounds=viewportRef.current?.node()?.getBBox(); if(!bounds?.width)return; const svg=svgRef.current;const scale=Math.min(1.5,.9/Math.max(bounds.width/svg.clientWidth,bounds.height/svg.clientHeight));const transform=d3.zoomIdentity.translate(svg.clientWidth/2-scale*(bounds.x+bounds.width/2),svg.clientHeight/2-scale*(bounds.y+bounds.height/2)).scale(scale);d3.select(svg).transition().duration(450).call(zoomRef.current.transform,transform) };
  const download = (blob,name) => { const url=URL.createObjectURL(blob);const anchor=document.createElement('a');anchor.href=url;anchor.download=name;anchor.click();URL.revokeObjectURL(url) };
  const exportSvg = () => { const clone=svgRef.current.cloneNode(true);clone.setAttribute('xmlns','http://www.w3.org/2000/svg');download(new Blob([new XMLSerializer().serializeToString(clone)],{type:'image/svg+xml'}),'ems-dependency-graph.svg') };
  const exportPng = () => { const xml=new XMLSerializer().serializeToString(svgRef.current);const image=new Image();const url=URL.createObjectURL(new Blob([xml],{type:'image/svg+xml'}));image.onload=()=>{const canvas=document.createElement('canvas');canvas.width=svgRef.current.clientWidth*2;canvas.height=svgRef.current.clientHeight*2;const context=canvas.getContext('2d');context.scale(2,2);context.fillStyle='#fff';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(image,0,0,svgRef.current.clientWidth,svgRef.current.clientHeight);canvas.toBlob(blob=>download(blob,'ems-dependency-graph.png'));URL.revokeObjectURL(url)};image.src=url };
  const mutateEdge = async operation => { if(!selectedEdge?.relationshipId)return notify('This inferred relationship has no mutable relationship ID.');try{await (operation==='reverse'?emsApi.reverseRelationship(selectedEdge.relationshipId):emsApi.deleteRelationship(selectedEdge.relationshipId));notify(`Relationship ${operation} completed.`);setSelectedEdge(null);setRevision(value=>value+1)}catch(error){notify(isConfigured('ingest')?error.message:'Configure the existing ingestion endpoint to modify relationships.')} };
  const types=['All types',...new Set(entities.map(entity=>entity.entityType||'Environment'))]; const environments=['All environments',...new Set(entities.map(entity=>entity.type).filter(Boolean))];
  return <div className={fullScreen?'d3-workspace fullscreen':'d3-workspace'}><div className="hero-row"><div><h2>Dependency visualization</h2><p>Explore the same EMS relationship graph with progressive, evidence-aware navigation.</p></div><div className="hero-actions"><button className="secondary" onClick={()=>setFullScreen(value=>!value)}>{fullScreen?<Minimize2 size={16}/>:<Maximize2 size={16}/>} {fullScreen?'Exit full screen':'Full screen'}</button><button className="secondary" onClick={exportSvg}><Download size={16}/>SVG</button><button className="primary" onClick={exportPng}><Download size={16}/>Export PNG</button></div></div><div className="d3-toolbar"><label><Search size={15}/><input value={query} onChange={event=>setQuery(event.target.value)} placeholder="Find entity…"/></label><select value={environment} onChange={event=>setEnvironment(event.target.value)}>{environments.map(value=><option key={value}>{value}</option>)}</select><select value={type} onChange={event=>setType(event.target.value)}>{types.map(value=><option key={value}>{value}</option>)}</select><select value={depth} onChange={event=>setDepth(Number(event.target.value))}><option value={1}>1 hop</option><option value={2}>2 hops</option><option value={3}>3 hops</option></select><button onClick={()=>{setQuery('');setEnvironment('All environments');setType('All types');setFocusedId('')}}><RefreshCw size={14}/>Full graph</button><span>{visibleGraph.nodes.length} nodes · {visibleGraph.links.length} edges</span></div><div className="d3-layout"><section className="d3-canvas"><svg ref={svgRef}/><div className="d3-controls"><button onClick={()=>zoomBy(1.25)}><ZoomIn size={16}/></button><button onClick={()=>zoomBy(.8)}><ZoomOut size={16}/></button><button onClick={reset}>Reset</button><button onClick={fit}><Maximize2 size={15}/>Fit</button></div><div className="d3-help">Drag nodes · scroll to zoom · double-click to expand · Esc exits full screen</div></section><aside className="d3-inspector">{selectedEdge?<><span className="section-kicker">Selected relationship</span><h3>{selectedEdge.label}</h3><div className="edge-route"><strong>{selectedEdge.source.name||selectedEdge.source}</strong><Network size={16}/><strong>{selectedEdge.target.name||selectedEdge.target}</strong></div><dl><dt>Relationship ID</dt><dd>{selectedEdge.relationshipId||'Inferred edge'}</dd><dt>Evidence</dt><dd>{selectedEdge.property||selectedEdge.evidence||'Graph topology'}</dd><dt>Source</dt><dd>{selectedEdge.sourceSystem||'EMS'}</dd></dl><div className="inspector-actions"><button onClick={()=>mutateEdge('reverse')}>Reverse direction</button><button className="danger" onClick={()=>mutateEdge('delete')}>Delete relationship</button></div></>:<><span className="section-kicker">Selected entity</span><div className="inspector-entity"><span>{selected?.name?.[0]||'E'}</span><div><h3>{selected?.name||'Select a node'}</h3><p>{selected?.code}</p></div></div><dl><dt>Entity type</dt><dd>{selected?.entityType||'Environment'}</dd><dt>Owner</dt><dd>{selected?.owner||'Unassigned'}</dd><dt>Health</dt><dd>{selected?.health||'Unknown'}</dd><dt>Dependencies</dt><dd>{(selected?.upstream||0)+(selected?.downstream||0)}</dd></dl><button className="primary full" onClick={()=>{setFocusedId(selected?.id||'');setDepth(1)}}>Focus on entity</button></>}</aside></div></div>;
}

export default D3DependencyGraph;
