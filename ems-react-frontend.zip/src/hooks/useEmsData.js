import {useCallback,useEffect,useState} from 'react';
import {emsApi,flattenEntities,isConfigured,normalizeEntity,normalizeRelationships} from '../api/emsApi';

const message=error=>error?.name==='AbortError'?'EMS API timed out':error?.message||'Unable to load EMS data';

export function useEmsData(){
 const [entities,setEntities]=useState([]);
 const [relationships,setRelationships]=useState([]);
 const [mode,setMode]=useState(isConfigured('query')?'connecting':'unconfigured');
 const [error,setError]=useState('');
 const [loading,setLoading]=useState(false);
 const [lastUpdated,setLastUpdated]=useState(null);
 const refresh=useCallback(async(force=false)=>{
  if(!isConfigured('query')){setMode('unconfigured');setError('Configure VITE_QUERY_URL');return}
  setLoading(true);setMode(current=>current==='live'?'live':'connecting');setError('');
  const [entityResult,networkResult]=await Promise.allSettled([emsApi.getEntities({force}),emsApi.getNetwork({force})]);
  const failures=[];
  if(entityResult.status==='fulfilled')setEntities(flattenEntities(entityResult.value).map(normalizeEntity));else failures.push(`Entities: ${message(entityResult.reason)}`);
  if(networkResult.status==='fulfilled')setRelationships(normalizeRelationships(networkResult.value));else failures.push(`Topology: ${message(networkResult.reason)}`);
  const success=entityResult.status==='fulfilled'||networkResult.status==='fulfilled';
  setMode(success?'live':'error');setError(failures.join(' · '));if(success)setLastUpdated(new Date());setLoading(false);
 },[]);
 useEffect(()=>{refresh()},[refresh]);
 return{entities,relationships,mode,error,loading,lastUpdated,refresh};
}
