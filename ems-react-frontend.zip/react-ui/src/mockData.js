export const environments = [
  { id:'env-101', name:'Payments Production', code:'payments-prod', type:'Production', owner:'Digital Payments', health:'Healthy', ci:'Payments API Production', ciStatus:'Linked', upstream:4, downstream:12, confidence:98, updated:'8 min ago' },
  { id:'env-102', name:'Authentication QA', code:'auth-qa', type:'QA', owner:'Identity Platform', health:'Warning', ci:'Authentication QA Service', ciStatus:'Linked', upstream:2, downstream:8, confidence:94, updated:'19 min ago' },
  { id:'env-103', name:'Refund Certification', code:'refund-cert', type:'Certification', owner:'Money Movement', health:'Healthy', ci:'—', ciStatus:'Unlinked', upstream:3, downstream:5, confidence:0, updated:'34 min ago' },
  { id:'env-104', name:'Ledger Performance', code:'ledger-perf', type:'Performance', owner:'Core Ledger', health:'Critical', ci:'Ledger PERF Application', ciStatus:'Retired', upstream:6, downstream:18, confidence:91, updated:'1 hr ago' },
  { id:'env-105', name:'Checkout Development', code:'checkout-dev', type:'Development', owner:'Commerce', health:'Healthy', ci:'Checkout DEV', ciStatus:'Linked', upstream:5, downstream:3, confidence:96, updated:'2 hrs ago' },
];

export const dependencies = [
  { from:'Payments Production', to:'Authentication QA', direction:'Upstream', type:'Calls', endpoint:'https://auth-qa.internal/token', property:'authentication.service.url', source:'PCE', confidence:97, observed:'8 min ago' },
  { from:'Payments Production', to:'Ledger Performance', direction:'Upstream', type:'Writes to', endpoint:'jdbc:oracle:thin:@ledger-perf:1521', property:'ledger.datasource.url', source:'DCM', confidence:94, observed:'12 min ago' },
  { from:'Checkout Development', to:'Payments Production', direction:'Downstream', type:'Calls', endpoint:'https://payments.prod/api/v2', property:'payment.api.baseUrl', source:'Guidewire', confidence:99, observed:'16 min ago' },
  { from:'Refund Certification', to:'Payments Production', direction:'Downstream', type:'Calls', endpoint:'https://payments.prod/refunds', property:'refund.payment.endpoint', source:'Payment Central', confidence:92, observed:'34 min ago' },
];

export const ciSuggestions = [
  { entity:'Refund Certification', candidate:'Refund Processing CERT', ciClass:'Application Service', confidence:92, evidence:['Canonical name match','Certification environment','Owner matched'], state:'Operational' },
  { entity:'Notification QA', candidate:'Notification Delivery QA', ciClass:'Application', confidence:86, evidence:['Alias match','QA environment'], state:'Operational' },
  { entity:'Ledger Performance', candidate:'Ledger PERF v1', ciClass:'Application', confidence:78, evidence:['Hostname match','Performance environment'], state:'Retired' },
];

export const alerts = [
  { severity:'Critical', title:'Production environment unhealthy', subject:'Ledger Performance', detail:'Three configuration endpoints stopped responding after the latest discovery.', age:'14 min', owner:'Core Ledger' },
  { severity:'High', title:'Dependency target changed', subject:'Payments Production', detail:'ledger.datasource.url now resolves to a new target.', age:'28 min', owner:'Digital Payments' },
  { severity:'Medium', title:'Environment ownership missing', subject:'Refund Certification', detail:'No accountable technical owner is assigned.', age:'1 hr', owner:'Platform Governance' },
  { severity:'Low', title:'Discovery pipeline delayed', subject:'Guidewire', detail:'Last successful run is 47 minutes outside its expected schedule.', age:'2 hrs', owner:'Platform Ops' },
];

export const pipelineRuns = [
  { source:'PCE', status:'Succeeded', records:'18,420', changes:42, duration:'2m 18s', finished:'8 min ago' },
  { source:'DCM', status:'Succeeded', records:'6,128', changes:8, duration:'1m 04s', finished:'12 min ago' },
  { source:'Guidewire', status:'Delayed', records:'—', changes:0, duration:'—', finished:'2 hrs ago' },
  { source:'Payment Central', status:'Succeeded', records:'2,942', changes:16, duration:'48s', finished:'34 min ago' },
];

export const changes = [
  { number:'CHG0042187', title:'Payments API certificate rotation', ci:'Payments API Production', window:'Today, 22:00–23:00', risk:'High', affected:12, incidents:1 },
  { number:'CHG0042214', title:'Ledger database maintenance', ci:'Ledger PERF Application', window:'Tomorrow, 01:00–03:00', risk:'Critical', affected:18, incidents:2 },
  { number:'CHG0042251', title:'Authentication service deployment', ci:'Authentication QA Service', window:'Fri, 18:00–19:00', risk:'Medium', affected:8, incidents:0 },
];
