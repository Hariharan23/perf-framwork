const endpoints = {
  query: import.meta.env.VITE_QUERY_URL || '',
  ingest: import.meta.env.VITE_INGEST_URL || '',
  cleanup: import.meta.env.VITE_CLEANUP_URL || '',
  pipeline: import.meta.env.VITE_PIPELINE_API_URL || '',
  report: import.meta.env.VITE_REPORT_API_URL || '',
};

const keys = {
  query: import.meta.env.VITE_API_KEY_NEPTUNE || '',
  ingest: import.meta.env.VITE_API_KEY_NEPTUNE || '',
  cleanup: import.meta.env.VITE_API_KEY_NEPTUNE || '',
  pipeline: import.meta.env.VITE_API_KEY_PIPELINE || '',
  report: import.meta.env.VITE_API_KEY_REPORT || '',
};

export const isConfigured = service => Boolean(endpoints[service]);

async function call(service, operation, data = {}, timeout = 15000, operationInQuery = false) {
  const url = endpoints[service];
  if (!url) throw new Error(`${service} endpoint is not configured`);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const requestUrl = operationInQuery ? `${url}${url.includes('?')?'&':'?'}operation=${encodeURIComponent(operation)}` : url;
    const response = await fetch(requestUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...(keys[service] ? { 'x-api-key': keys[service] } : {}),
      },
      body: JSON.stringify(operationInQuery ? data : { operation, ...data }),
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`${operation} failed with HTTP ${response.status}`);
    const result = await response.json();
    if (result?.success === false) throw new Error(result.error || `${operation} failed`);
    return result;
  } finally {
    clearTimeout(timer);
  }
}

export const emsApi = {
  health: () => call('query', 'health'),
  getEntities: () => call('query', 'get-entities'),
  getEntity: id => call('query', 'get-entity', { id }),
  getEntityHistory: entityId => call('query', 'get-entity-history', { entityId }),
  getNetwork: () => call('query', 'get-network'),
  getNetworkForEnvironments: (envIds, maxHops = 2) => call('query', 'get-network-for-envs', { envIds, maxHops }),
  // The current backend expects sparql-query in the URL and the query in the body.
  runSparql: query => call('query', 'sparql-query', { query }, 15000, true),
  createEntity: entity => call('ingest', 'create', entity),
  updateEntity: entity => call('ingest', 'update-entity', entity),
  bulkImport: entities => call('ingest', 'bulk-ingest', { entities }, 60000),
  createRelationship: relationship => call('ingest', 'create-relationship', relationship),
  reverseRelationship: relationshipId => call('ingest', 'reverse-relationship', { relationshipId }),
  deleteRelationship: relationshipId => call('ingest', 'delete-relationship', { relationshipId }),
  deleteEntity: entity => call('cleanup', 'delete-entity', entity),
  pipeline: (operation, data = {}) => call('pipeline', operation, data, 30000),
};

export function flattenEntities(result) {
  const groups = result?.data?.entities || result?.entities || {};
  return Object.entries(groups).flatMap(([type, items]) =>
    Array.isArray(items) ? items.map(item => ({ ...item, type: item.type || type })) : []
  );
}

export function normalizeEntity(entity, index = 0) {
  const entityType = entity.type || 'Environment';
  const rawEnvironmentType = String(entity.environmentType || entity.stage || '').toLowerCase();
  const environmentTypes = { prod:'Production', production:'Production', qa:'QA', quality:'QA', cert:'Certification', certification:'Certification', perf:'Performance', performance:'Performance', dev:'Development', development:'Development' };
  const environmentType = environmentTypes[rawEnvironmentType] || (entityType === 'Environment' ? 'Unclassified' : entityType);
  const rawHealth = String(entity.health || entity.status || 'healthy').toLowerCase();
  const health = rawHealth === 'critical' || rawHealth === 'failed' ? 'Critical' : rawHealth === 'warning' || rawHealth === 'inactive' || rawHealth === 'degraded' ? 'Warning' : 'Healthy';
  return {
    ...entity,
    id: entity.id || entity.uniqueIdentifier || `entity-${index}`,
    name: entity.name || entity.uniqueIdentifier || 'Unnamed entity',
    code: entity.uniqueIdentifier || entity.code || entity.id || `entity-${index}`,
    type: environmentType,
    entityType,
    owner: entity.owner || 'Unassigned',
    health,
    ci: entity.ciName || entity.serviceNowCiName || '—',
    ciStatus: entity.ciName || entity.serviceNowCiName ? 'Linked' : 'Unlinked',
    upstream: Number(entity.upstreamCount || entity.upstream || 0),
    downstream: Number(entity.downstreamCount || entity.downstream || 0),
    confidence: Number(entity.ciConfidence || 0),
    updated: entity.lastSyncedAt || entity.updatedAt || 'Recently',
  };
}
