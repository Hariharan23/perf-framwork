import { useCallback, useEffect, useState } from 'react';
import { dependencies as mockRelationships, environments as mockEntities } from '../mockData';
import { emsApi, flattenEntities, isConfigured, normalizeEntity } from '../api/emsApi';

export function useEmsData() {
  const [entities, setEntities] = useState(mockEntities);
  const [relationships, setRelationships] = useState(mockRelationships);
  const [mode, setMode] = useState(isConfigured('query') ? 'connecting' : 'demo');
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    if (!isConfigured('query')) {
      setMode('demo');
      return;
    }
    setMode('connecting');
    try {
      const [entityResult, networkResult] = await Promise.all([
        emsApi.getEntities(),
        emsApi.getNetwork().catch(() => null),
      ]);
      const liveEntities = flattenEntities(entityResult).map(normalizeEntity);
      if (liveEntities.length) setEntities(liveEntities);
      // Current query Lambda returns either data.networkData or data directly.
      const network = networkResult?.data?.networkData || networkResult?.data || networkResult;
      const edges = network?.edges;
      if (Array.isArray(edges) && edges.length) setRelationships(edges);
      setError('');
      setMode('live');
    } catch (requestError) {
      setError(requestError.name === 'AbortError' ? 'Existing API timed out' : requestError.message);
      setMode('fallback');
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);
  return { entities, relationships, mode, error, refresh };
}
