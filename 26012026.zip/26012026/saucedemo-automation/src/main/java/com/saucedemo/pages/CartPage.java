package com.saucedemo.pages;

import com.performance.framework.pages.BasePage;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.List;

/**
 * SauceDemo Cart Page Object.
 */
@Slf4j
public class CartPage extends BasePage {

    private static final String PAGE_NAME = "Cart Page";

    @FindBy(css = ".title")
    private WebElement pageTitle;

    @FindBy(css = ".cart_item")
    private List<WebElement> cartItems;

    @FindBy(id = "continue-shopping")
    private WebElement continueShoppingButton;

    @FindBy(id = "checkout")
    private WebElement checkoutButton;

    @FindBy(css = ".shopping_cart_badge")
    private WebElement cartBadge;

    public CartPage() {
        super();
    }

    public CartPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public String getPageName() {
        return PAGE_NAME;
    }

    @Override
    public boolean isLoaded() {
        try {
            return pageTitle.isDisplayed() && pageTitle.getText().equals("Your Cart");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Navigate to cart page
     */
    public CartPage open() {
        String cartUrl = appConfigManager.getFullPageUrl("cart");
        navigateTo(cartUrl);
        log.info("Navigated to cart page: {}", cartUrl);
        return this;
    }

    /**
     * Get page title text
     */
    public String getPageTitleText() {
        return getText(pageTitle);
    }

    /**
     * Get number of items in cart
     */
    public int getCartItemCount() {
        return cartItems.size();
    }

    /**
     * Get list of product names in cart
     */
    public List<String> getCartProductNames() {
        List<String> names = new ArrayList<>();
        for (WebElement item : cartItems) {
            WebElement nameElement = item.findElement(By.cssSelector(".inventory_item_name"));
            names.add(nameElement.getText());
        }
        return names;
    }

    /**
     * Check if product is in cart
     */
    public boolean isProductInCart(String productName) {
        return getCartProductNames().contains(productName);
    }

    /**
     * Remove item from cart by name
     */
    public CartPage removeItem(String productName) {
        for (WebElement item : cartItems) {
            WebElement nameElement = item.findElement(By.cssSelector(".inventory_item_name"));
            if (nameElement.getText().equals(productName)) {
                WebElement removeButton = item.findElement(By.cssSelector("button[id^='remove']"));
                click(removeButton);
                log.info("Removed item from cart: {}", productName);
                break;
            }
        }
        return this;
    }

    /**
     * Get item price by name
     */
    public String getItemPrice(String productName) {
        for (WebElement item : cartItems) {
            WebElement nameElement = item.findElement(By.cssSelector(".inventory_item_name"));
            if (nameElement.getText().equals(productName)) {
                WebElement priceElement = item.findElement(By.cssSelector(".inventory_item_price"));
                return priceElement.getText();
            }
        }
        return "";
    }

    /**
     * Get item quantity by name
     */
    public String getItemQuantity(String productName) {
        for (WebElement item : cartItems) {
            WebElement nameElement = item.findElement(By.cssSelector(".inventory_item_name"));
            if (nameElement.getText().equals(productName)) {
                WebElement qtyElement = item.findElement(By.cssSelector(".cart_quantity"));
                return qtyElement.getText();
            }
        }
        return "";
    }

    /**
     * Continue shopping
     */
    public InventoryPage continueShopping() {
        click(continueShoppingButton);
        log.info("Continue shopping clicked");
        return new InventoryPage(driver);
    }

    /**
     * Proceed to checkout
     */
    public CheckoutPage proceedToCheckout() {
        click(checkoutButton);
        log.info("Proceeding to checkout");
        return new CheckoutPage(driver);
    }

    /**
     * Get cart badge count
     */
    public int getCartBadgeCount() {
        try {
            return Integer.parseInt(cartBadge.getText());
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Check if cart is empty
     */
    public boolean isCartEmpty() {
        return cartItems.isEmpty();
    }
}
