package com.saucedemo.pages;

import com.performance.framework.pages.BasePage;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * SauceDemo Inventory (Products) Page Object.
 */
@Slf4j
public class InventoryPage extends BasePage {

    private static final String PAGE_NAME = "Inventory Page";

    @FindBy(css = ".title")
    private WebElement pageTitle;

    @FindBy(css = ".inventory_item")
    private List<WebElement> inventoryItems;

    @FindBy(css = ".product_sort_container")
    private WebElement sortDropdown;

    @FindBy(css = ".shopping_cart_link")
    private WebElement cartLink;

    @FindBy(css = ".shopping_cart_badge")
    private WebElement cartBadge;

    @FindBy(id = "react-burger-menu-btn")
    private WebElement menuButton;

    @FindBy(id = "logout_sidebar_link")
    private WebElement logoutLink;

    @FindBy(id = "reset_sidebar_link")
    private WebElement resetAppStateLink;

    public InventoryPage() {
        super();
    }

    public InventoryPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public String getPageName() {
        return PAGE_NAME;
    }

    @Override
    public boolean isLoaded() {
        try {
            return pageTitle.isDisplayed() && pageTitle.getText().equals("Products");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Navigate to inventory page
     */
    public InventoryPage open() {
        String inventoryUrl = appConfigManager.getFullPageUrl("inventory");
        navigateTo(inventoryUrl);
        log.info("Navigated to inventory page: {}", inventoryUrl);
        return this;
    }

    /**
     * Get page title text
     */
    public String getPageTitleText() {
        return getText(pageTitle);
    }

    /**
     * Get number of products displayed
     */
    public int getProductCount() {
        return inventoryItems.size();
    }

    /**
     * Add product to cart by name
     */
    public InventoryPage addProductToCart(String productName) {
        for (WebElement item : inventoryItems) {
            WebElement nameElement = item.findElement(By.cssSelector(".inventory_item_name"));
            if (nameElement.getText().equals(productName)) {
                WebElement addButton = item.findElement(By.cssSelector("button[id^='add-to-cart']"));
                click(addButton);
                log.info("Added product to cart: {}", productName);
                break;
            }
        }
        return this;
    }

    /**
     * Add product using test data key
     */
    public InventoryPage addProductFromTestData(String productKey) {
        String productName = appConfigManager.getTestData("products." + productKey + ".name");
        return addProductToCart(productName);
    }

    /**
     * Remove product from cart
     */
    public InventoryPage removeProductFromCart(String productName) {
        for (WebElement item : inventoryItems) {
            WebElement nameElement = item.findElement(By.cssSelector(".inventory_item_name"));
            if (nameElement.getText().equals(productName)) {
                WebElement removeButton = item.findElement(By.cssSelector("button[id^='remove']"));
                click(removeButton);
                log.info("Removed product from cart: {}", productName);
                break;
            }
        }
        return this;
    }

    /**
     * Sort products
     */
    public InventoryPage sortProducts(String sortOption) {
        click(sortDropdown);
        WebElement option = driver.findElement(By.cssSelector("option[value='" + sortOption + "']"));
        click(option);
        log.info("Sorted products by: {}", sortOption);
        return this;
    }

    /**
     * Go to cart
     */
    public CartPage goToCart() {
        click(cartLink);
        log.info("Navigated to cart");
        return new CartPage(driver);
    }

    /**
     * Get cart item count
     */
    public int getCartItemCount() {
        try {
            return Integer.parseInt(cartBadge.getText());
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Open menu
     */
    public InventoryPage openMenu() {
        click(menuButton);
        log.debug("Opened menu");
        return this;
    }

    /**
     * Logout
     */
    public LoginPage logout() {
        openMenu();
        waitForClickable(logoutLink);
        click(logoutLink);
        log.info("Logged out");
        return new LoginPage(driver);
    }

    /**
     * Get product price by name
     */
    public String getProductPrice(String productName) {
        for (WebElement item : inventoryItems) {
            WebElement nameElement = item.findElement(By.cssSelector(".inventory_item_name"));
            if (nameElement.getText().equals(productName)) {
                WebElement priceElement = item.findElement(By.cssSelector(".inventory_item_price"));
                return priceElement.getText();
            }
        }
        return "";
    }

    /**
     * Check if product exists
     */
    public boolean isProductDisplayed(String productName) {
        for (WebElement item : inventoryItems) {
            WebElement nameElement = item.findElement(By.cssSelector(".inventory_item_name"));
            if (nameElement.getText().equals(productName)) {
                return true;
            }
        }
        return false;
    }
}
