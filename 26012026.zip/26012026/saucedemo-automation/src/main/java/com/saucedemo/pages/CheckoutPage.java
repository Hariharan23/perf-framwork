package com.saucedemo.pages;

import com.performance.framework.pages.BasePage;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * SauceDemo Checkout Page Object.
 * Handles checkout step one (information), step two (overview), and complete
 * pages.
 */
@Slf4j
public class CheckoutPage extends BasePage {

    private static final String PAGE_NAME = "Checkout Page";

    // Step One - Information
    @FindBy(css = ".title")
    private WebElement pageTitle;

    @FindBy(id = "first-name")
    private WebElement firstNameInput;

    @FindBy(id = "last-name")
    private WebElement lastNameInput;

    @FindBy(id = "postal-code")
    private WebElement postalCodeInput;

    @FindBy(id = "continue")
    private WebElement continueButton;

    @FindBy(id = "cancel")
    private WebElement cancelButton;

    // Step Two - Overview
    @FindBy(css = ".summary_subtotal_label")
    private WebElement subtotalLabel;

    @FindBy(css = ".summary_tax_label")
    private WebElement taxLabel;

    @FindBy(css = ".summary_total_label")
    private WebElement totalLabel;

    @FindBy(id = "finish")
    private WebElement finishButton;

    // Complete
    @FindBy(css = ".complete-header")
    private WebElement completeHeader;

    @FindBy(css = ".complete-text")
    private WebElement completeText;

    @FindBy(id = "back-to-products")
    private WebElement backToProductsButton;

    // Error handling
    @FindBy(css = "[data-test='error']")
    private WebElement errorMessage;

    public CheckoutPage() {
        super();
    }

    public CheckoutPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public String getPageName() {
        return PAGE_NAME;
    }

    @Override
    public boolean isLoaded() {
        try {
            return pageTitle.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Navigate to checkout step one
     */
    public CheckoutPage open() {
        String checkoutUrl = appConfigManager.getFullPageUrl("checkoutStepOne");
        navigateTo(checkoutUrl);
        log.info("Navigated to checkout page: {}", checkoutUrl);
        return this;
    }

    /**
     * Get page title text
     */
    public String getPageTitleText() {
        return getText(pageTitle);
    }

    /**
     * Enter customer information
     */
    public CheckoutPage enterCustomerInfo(String firstName, String lastName, String postalCode) {
        type(firstNameInput, firstName);
        type(lastNameInput, lastName);
        type(postalCodeInput, postalCode);
        log.info("Entered customer info: {} {}, {}", firstName, lastName, postalCode);
        return this;
    }

    /**
     * Enter customer info from test data
     */
    public CheckoutPage enterCustomerInfoFromTestData() {
        String firstName = appConfigManager.getTestData("checkout.customerInfo.firstName");
        String lastName = appConfigManager.getTestData("checkout.customerInfo.lastName");
        String postalCode = appConfigManager.getTestData("checkout.customerInfo.postalCode");
        return enterCustomerInfo(firstName, lastName, postalCode);
    }

    /**
     * Continue to step two
     */
    public CheckoutPage continueToStepTwo() {
        click(continueButton);
        log.info("Continued to checkout step two");
        return this;
    }

    /**
     * Cancel checkout
     */
    public CartPage cancelCheckout() {
        click(cancelButton);
        log.info("Checkout cancelled");
        return new CartPage(driver);
    }

    /**
     * Get subtotal amount
     */
    public String getSubtotal() {
        return getText(subtotalLabel);
    }

    /**
     * Get tax amount
     */
    public String getTax() {
        return getText(taxLabel);
    }

    /**
     * Get total amount
     */
    public String getTotal() {
        return getText(totalLabel);
    }

    /**
     * Finish checkout
     */
    public CheckoutPage finishCheckout() {
        click(finishButton);
        log.info("Checkout finished");
        return this;
    }

    /**
     * Check if checkout is complete
     */
    public boolean isCheckoutComplete() {
        try {
            return completeHeader.isDisplayed() &&
                    completeHeader.getText().contains("Thank you");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Get completion header text
     */
    public String getCompletionHeader() {
        return getText(completeHeader);
    }

    /**
     * Get completion message text
     */
    public String getCompletionMessage() {
        return getText(completeText);
    }

    /**
     * Back to products
     */
    public InventoryPage backToProducts() {
        click(backToProductsButton);
        log.info("Navigating back to products");
        return new InventoryPage(driver);
    }

    /**
     * Check if error is displayed
     */
    public boolean isErrorDisplayed() {
        try {
            return errorMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Get error message
     */
    public String getErrorMessage() {
        try {
            return getText(errorMessage);
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Complete full checkout with test data
     */
    public CheckoutPage completeCheckoutWithTestData() {
        enterCustomerInfoFromTestData();
        continueToStepTwo();
        finishCheckout();
        return this;
    }
}
