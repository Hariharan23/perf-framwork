# Link Existing Entities via Integration

This guide shows how to create an Integration that connects an **existing Environment** to an **existing Application** in one import.

## Scenario

You have:

- ✅ Environment already created (e.g., `production-aws`)
- ✅ Application already created (e.g., `customer-service-api`)

You want:

- 🔗 Create Integration that links them: `Environment` → `Integration` → `Application`

---

## CSV File

**[link-env-app-via-integration.csv](link-env-app-via-integration.csv)**

```csv
type,name,description,owner,sourceService,targetService,protocol,sourceEntity,relationshipType,targetEntity,config_key1,config_value1
Integration,api-gateway-integration,API Gateway Integration,Platform Team,api-gateway,customer-service-api,HTTPS,production-aws,integrates,customer-service-api,timeout,30s
```

### Key Columns

| Column             | Value                    | Purpose                                  |
| ------------------ | ------------------------ | ---------------------------------------- |
| `type`             | Integration              | Entity type                              |
| `name`             | api-gateway-integration  | Integration name                         |
| `sourceService`    | api-gateway              | Source service name                      |
| `targetService`    | customer-service-api     | Target service name                      |
| `protocol`         | HTTPS                    | Communication protocol                   |
| **`sourceEntity`** | **production-aws**       | **Existing Environment to connect FROM** |
| `relationshipType` | integrates               | Type of relationship                     |
| **`targetEntity`** | **customer-service-api** | **Existing Application to connect TO**   |

---

## What Happens

When you import this CSV:

1. ✅ Creates Integration entity: `api-gateway-integration`
2. ✅ Creates relationship: `production-aws` → integrates → `api-gateway-integration`
3. ✅ Creates relationship: `api-gateway-integration` → integrates → `customer-service-api`

**Result:**

```
production-aws (Environment)
        ↓
    integrates
        ↓
api-gateway-integration (Integration)
        ↓
    integrates
        ↓
customer-service-api (Application)
```

---

## How to Use

### Step 1: Update Entity Names

Edit the CSV and replace with your actual entity names:

- **`sourceEntity`**: Replace `production-aws` with your Environment name
- **`targetEntity`**: Replace `customer-service-api` with your Application name

### Step 2: Import

1. Open the **Bulk Import** tab
2. Upload **link-env-app-via-integration.csv**
3. Click **Import Entities**

### Step 3: Verify

Check the network graph - you should see:

- Your Environment connected to the new Integration
- The Integration connected to your Application

---

## Example with Different Names

If your entities are:

- Environment: `dev-azure`
- Application: `order-service`

Your CSV should be:

```csv
type,name,description,owner,sourceService,targetService,protocol,sourceEntity,relationshipType,targetEntity
Integration,service-mesh,Service Mesh Integration,Platform Team,service-mesh,order-service,gRPC,dev-azure,integrates,order-service
```

---

## Multiple Integrations

You can create multiple integrations connecting different apps to the same environment:

```csv
type,name,description,owner,sourceService,targetService,protocol,sourceEntity,relationshipType,targetEntity
Integration,gateway-customer-api,Gateway to Customer API,Platform,gateway,customer-api,HTTPS,prod-env,integrates,customer-api
Integration,gateway-order-api,Gateway to Order API,Platform,gateway,order-api,HTTPS,prod-env,integrates,order-api
Integration,gateway-payment-api,Gateway to Payment API,Platform,gateway,payment-api,HTTPS,prod-env,integrates,payment-api
```

This creates a hub-and-spoke pattern where one environment connects to multiple applications via separate integrations.

---

## Important Notes

⚠️ **Entities Must Exist**: Both the Environment and Application must already exist in the database before importing this CSV

⚠️ **Exact Names**: The `sourceEntity` and `targetEntity` values must **exactly match** the existing entity names (case-sensitive)

⚠️ **No Duplicates**: Don't create the same Integration twice - it will cause errors

✅ **Configurations**: You can add configurations using `config_key#` and `config_value#` columns

✅ **Any Relationship Type**: Change `integrates` to `runsOn`, `dependsOn`, etc. as needed
