# CSV/Excel Bulk Import Guide

This guide explains how to use CSV and Excel files for bulk entity import.

## CSV/Excel Format

### Standard Column Headers

| Column          | Required | Description                              | Entity Types             |
| --------------- | -------- | ---------------------------------------- | ------------------------ |
| `type`          | Yes      | Environment, Application, or Integration | All                      |
| `name`          | Yes      | Unique entity name                       | All                      |
| `description`   | No       | Entity description                       | All                      |
| `owner`         | No       | Owner name                               | Application, Integration |
| `region`        | No       | AWS region                               | Environment              |
| `endpoint`      | No       | Endpoint URL                             | Environment              |
| `version`       | No       | Version string                           | Application              |
| `sourceService` | No       | Source service name                      | Integration              |
| `targetService` | No       | Target service name                      | Integration              |
| `protocol`      | No       | Protocol (HTTP, HTTPS, gRPC, AMQP, etc.) | Integration              |

### Relationship Columns

| Column             | Description                                          | Example        |
| ------------------ | ---------------------------------------------------- | -------------- |
| `sourceEntity`     | Create relationship FROM this entity TO current row  | `prod-env`     |
| `relationshipType` | Type of relationship (runsOn, integrates, dependsOn) | `integrates`   |
| `targetEntity`     | Create relationship FROM current row TO this entity  | `customer-api` |

### Configuration Columns

Use pairs of `config_key` and `config_value` columns:

- `config_key1` + `config_value1` → First configuration
- `config_key2` + `config_value2` → Second configuration
- `config_key3` + `config_value3` → Third configuration (and so on...)

The number suffix must match between key and value pairs.

**Example:**

```csv
type,name,config_key1,config_value1,config_key2,config_value2
Application,api-service,timeout,30s,max-retries,3
```

Creates configuration: `{ "timeout": "30s", "max-retries": "3" }`

---

## Creating Relationship Chains

You can create complex relationship chains by using the three relationship columns together:

### Example 1: Simple Chain

**CSV:**

```csv
type,name,description,sourceEntity,relationshipType,targetEntity
Environment,prod-env,Production Environment,,,,
Integration,api-gateway,API Gateway,prod-env,integrates,api-service
Application,api-service,Customer API Service,,,
```

**Creates:**

- `prod-env` integrates → `api-gateway`
- `api-gateway` integrates → `api-service`

### Example 2: Multi-Hop Chain

**CSV:**

```csv
type,name,description,sourceEntity,relationshipType,targetEntity
Environment,prod-aws,Production AWS,,,
Integration,load-balancer,Load Balancer,prod-aws,integrates,web-app
Application,web-app,Web Application,load-balancer,integrates,api-backend
Application,api-backend,API Backend,,,
```

**Creates chain:** `prod-aws` → `load-balancer` → `web-app` → `api-backend`

### Example 3: With Configurations

**CSV:**

```csv
type,name,description,owner,region,sourceEntity,relationshipType,targetEntity,config_key1,config_value1
Environment,prod-env,Production,DevOps,us-east-1,,,,timeout,60s
Application,customer-api,Customer API,Backend,,prod-env,runsOn,,timeout,30s
Integration,api-gw,Gateway,Platform,,,customer-api,integrates,order-service,timeout,45s
Application,order-service,Order Service,Backend,,prod-env,runsOn,,timeout,20s
```

**Creates:**

- Environment `prod-env` in `us-east-1` with timeout=60s
- Application `customer-api` runsOn `prod-env` with timeout=30s
- Integration `api-gw` integrates from `customer-api` to `order-service` with timeout=45s
- Application `order-service` runsOn `prod-env` with timeout=20s

---

## Excel Usage

Excel files work the same as CSV - just use the column headers in the first row and fill in data below:

| type        | name        | description | region    | endpoint                 | sourceEntity | relationshipType | targetEntity |
| ----------- | ----------- | ----------- | --------- | ------------------------ | ------------ | ---------------- | ------------ |
| Environment | prod-env    | Production  | us-east-1 | https://prod.example.com |              |                  |              |
| Application | api-service | API         |           |                          | prod-env     | runsOn           |              |
| Integration | gateway     | Gateway     |           |                          | prod-env     | integrates       | api-service  |

---

## Important Notes

1. **Entity Order**: Entities are processed in the order they appear in your CSV/Excel file
2. **Relationship Targets**: Must already exist or be created in the same import batch
3. **Empty Cells**: Leave cells empty if not applicable (don't use "N/A" or "-")
4. **Quoted Values**: If a value contains commas, wrap it in quotes: `"value, with, commas"`
5. **Column Order**: Columns can be in any order - the header names are what matter
6. **Case Sensitivity**: Column headers are case-insensitive (`Type` = `type` = `TYPE`)

---

## Sample CSV File

See `bulk-import-sample.csv` in the project root for a complete example.

---

## Usage

1. Open the "Bulk Import" tab in the application
2. Click "Upload File (JSON, CSV, or Excel)"
3. Select your .csv or .xlsx/.xls file
4. The file will be automatically parsed and converted to JSON
5. Review the preview
6. Click "Import Entities" to create all entities

---

## Troubleshooting

**Issue**: "Error parsing CSV file"

- **Solution**: Check that your file uses commas as delimiters and has a header row

**Issue**: "Missing type or name"

- **Solution**: Ensure every row has values in the `type` and `name` columns

**Issue**: "Target entity not found"

- **Solution**: Make sure relationship targets are either:
  - Already in the database, OR
  - Defined earlier in the same CSV file

**Issue**: "Relationship not created"

- **Solution**: Check that:
  - `relationshipType` column has a valid value (runsOn, integrates, dependsOn)
  - `targetEntity` column has the exact name of the target entity
