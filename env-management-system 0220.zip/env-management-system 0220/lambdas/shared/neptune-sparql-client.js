"use strict";
// Neptune SPARQL Client for Environment Management System
// Pure SPARQL operations following the complete ontology (excluding change tracking)
Object.defineProperty(exports, "__esModule", { value: true });
exports.NeptuneSparqlClient = void 0;
const credential_provider_node_1 = require("@aws-sdk/credential-provider-node");
const protocol_http_1 = require("@smithy/protocol-http");
const sha256_js_1 = require("@aws-crypto/sha256-js");
const signature_v4_1 = require("@smithy/signature-v4");
const uuid_1 = require("uuid");
const axios_1 = require("axios");
class NeptuneSparqlClient {
    constructor(neptuneEndpoint, region = 'us-east-1') {
        // Ontology namespace
        this.ontologyPrefix = 'http://neptune.aws.com/envmgmt/ontology/';
        this.neptuneEndpoint = neptuneEndpoint || process.env.NEPTUNE_ENDPOINT;
        this.region = region || process.env.AWS_REGION || 'us-east-1';
        // Use the AWS SDK's default credential provider chain
        this.credentials = (0, credential_provider_node_1.defaultProvider)();
        this.signer = new signature_v4_1.SignatureV4({
            credentials: this.credentials,
            region: this.region,
            service: 'neptune-db',
            sha256: sha256_js_1.Sha256,
        });
        if (!this.neptuneEndpoint) {
            throw new Error('Neptune endpoint is required. Set NEPTUNE_ENDPOINT environment variable or pass as constructor parameter.');
        }
        // Log configuration for debugging (without sensitive info)
        console.log(`Neptune SPARQL Client initialized:`);
        console.log(`- Endpoint: ${this.neptuneEndpoint}`);
        console.log(`- Region: ${this.region}`);
        console.log(`- Service: neptune-db`);
        console.log(`- IAM Authentication: enabled`);
    }
    /**
     * Extract UUID from full URI or return as-is if already a UUID
     */
    extractEntityId(idOrUri) {
        if (idOrUri.startsWith(this.ontologyPrefix)) {
            return idOrUri.replace(this.ontologyPrefix, '');
        }
        return idOrUri;
    }
    /**
     * Execute SPARQL query against Neptune with IAM authentication
     */
    async executeSparqlQuery(query) {
        const body = `query=${encodeURIComponent(query)}`;
        // Create the request for signing
        const request = new protocol_http_1.HttpRequest({
            method: 'POST',
            protocol: 'https:',
            hostname: this.neptuneEndpoint,
            port: 8182,
            path: '/sparql',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/sparql-results+json',
                'Host': `${this.neptuneEndpoint}:8182`,
            },
            body,
        });
        try {
            // Sign the request with IAM credentials
            const signedRequest = await this.signer.sign(request);
            // Construct the full URL
            const url = `https://${this.neptuneEndpoint}:8182/sparql`;
            console.log(`Executing SPARQL query to: ${url}`);
            console.log(`Query: ${query.substring(0, 200)}...`);
            const response = await (0, axios_1.default)({
                method: 'POST',
                url,
                headers: {
                    ...signedRequest.headers,
                    'Content-Length': body.length.toString(),
                },
                data: body,
                timeout: 30000,
                validateStatus: function (status) {
                    return status >= 200 && status < 500; // Accept 4xx errors for better error handling
                }
            });
            if (response.status >= 400) {
                throw new Error(`Neptune query failed with status ${response.status}: ${JSON.stringify(response.data)}`);
            }
            return response.data;
        }
        catch (error) {
            console.error('SPARQL query error:', error);
            throw error;
        }
    }
    /**
     * Execute SPARQL update against Neptune with IAM authentication
     */
    async executeSparqlUpdate(update) {
        const body = `update=${encodeURIComponent(update)}`;
        // Create the request for signing
        const request = new protocol_http_1.HttpRequest({
            method: 'POST',
            protocol: 'https:',
            hostname: this.neptuneEndpoint,
            port: 8182,
            path: '/sparql',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/sparql-results+json',
                'Host': `${this.neptuneEndpoint}:8182`,
            },
            body,
        });
        try {
            // Sign the request with IAM credentials
            const signedRequest = await this.signer.sign(request);
            // Construct the full URL
            const url = `https://${this.neptuneEndpoint}:8182/sparql`;
            console.log(`Executing SPARQL update to: ${url}`);
            console.log(`Update: ${update.substring(0, 200)}...`);
            const response = await (0, axios_1.default)({
                method: 'POST',
                url,
                headers: {
                    ...signedRequest.headers,
                    'Content-Length': body.length.toString(),
                },
                data: body,
                timeout: 30000,
                validateStatus: function (status) {
                    return status >= 200 && status < 500; // Accept 4xx errors for better error handling
                }
            });
            if (response.status >= 400) {
                throw new Error(`Neptune update failed with status ${response.status}: ${JSON.stringify(response.data)}`);
            }
            return response.data;
        }
        catch (error) {
            console.error('SPARQL update error:', error);
            throw error;
        }
    }
    /**
     * Health check for Neptune cluster
     */
    async healthCheck() {
        try {
            const query = `
        ASK { 
          ?s ?p ?o 
        }
      `;
            await this.executeSparqlQuery(query);
            return true;
        }
        catch (error) {
            console.error('Health check failed:', error);
            return false;
        }
    }
    /**
     * Create Environment using SPARQL following ontology
     */
    async createEnvironment(environment) {
        const id = (0, uuid_1.v4)();
        const timestamp = new Date().toISOString();
        const entity = {
            ...environment,
            id,
            type: 'Environment',
            createdAt: timestamp
        };
        const update = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
      PREFIX env: <${this.ontologyPrefix}>
      PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
      
      INSERT DATA {
        env:${id} rdf:type env:Environment ;
                  env:id "${entity.id}" ;
                  env:name "${entity.name}" ;
                  env:type "${entity.type}" ;
                  env:createdAt "${timestamp}"^^xsd:dateTime ;
                  ${entity.uniqueIdentifier ? `env:uniqueIdentifier "${entity.uniqueIdentifier}" ;` : ''}
                  ${entity.owner ? `env:owner "${entity.owner}" ;` : ''}
                  ${entity.status ? `env:status "${entity.status}" ;` : ''}
                  env:description "${entity.description || ''}" .
      }
    `;
        await this.executeSparqlUpdate(update);
        return entity;
    }
    /**
     * Create Application using SPARQL following ontology
     */
    async createApplication(application) {
        const id = (0, uuid_1.v4)();
        const timestamp = new Date().toISOString();
        const entity = {
            ...application,
            id,
            type: 'Application',
            createdAt: timestamp
        };
        const update = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
      PREFIX env: <${this.ontologyPrefix}>
      PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
      
      INSERT DATA {
        env:${id} rdf:type env:Application ;
                  env:id "${entity.id}" ;
                  env:name "${entity.name}" ;
                  env:type "${entity.type}" ;
                  env:createdAt "${timestamp}"^^xsd:dateTime ;
                  ${entity.uniqueIdentifier ? `env:uniqueIdentifier "${entity.uniqueIdentifier}" ;` : ''}
                  ${entity.owner ? `env:owner "${entity.owner}" ;` : ''}
                  ${entity.status ? `env:status "${entity.status}" ;` : ''}
                  env:description "${entity.description || ''}" .
      }
    `;
        await this.executeSparqlUpdate(update);
        return entity;
    }
    /**
     * Create Integration using SPARQL following ontology
     */
    async createIntegration(integration) {
        const id = (0, uuid_1.v4)();
        const timestamp = new Date().toISOString();
        const entity = {
            ...integration,
            id,
            type: 'Integration',
            createdAt: timestamp
        };
        const update = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
      PREFIX env: <${this.ontologyPrefix}>
      PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
      
      INSERT DATA {
        env:${id} rdf:type env:Integration ;
                  env:id "${entity.id}" ;
                  env:name "${entity.name}" ;
                  env:type "${entity.type}" ;
                  env:createdAt "${timestamp}"^^xsd:dateTime ;
                  ${entity.uniqueIdentifier ? `env:uniqueIdentifier "${entity.uniqueIdentifier}" ;` : ''}
                  ${entity.owner ? `env:owner "${entity.owner}" ;` : ''}
                  ${entity.status ? `env:status "${entity.status}" ;` : ''}
                  env:description "${entity.description || ''}" .
      }
    `;
        await this.executeSparqlUpdate(update);
        return entity;
    }
    /**
     * Create Environment Configuration using SPARQL
     */
    async createEnvironmentConfiguration(config, environmentId) {
        const id = (0, uuid_1.v4)();
        const timestamp = new Date().toISOString();
        const entity = {
            ...config,
            id,
            type: 'EnvironmentConfiguration',
            createdAt: timestamp
        };
        const update = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX env: <${this.ontologyPrefix}>
      PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
      
      INSERT DATA {
        env:${id} rdf:type env:EnvironmentConfiguration ;
                  env:id "${entity.id}" ;
                  env:type "${entity.type}" ;
                  env:createdAt "${timestamp}"^^xsd:dateTime ;
                  ${entity.configurationMap ? `env:configurationMap "${entity.configurationMap}" ;` : ''}
                  rdf:type env:Configuration .
                  
        env:${environmentId} env:hasEnvironmentConfig env:${id} .
      }
    `;
        await this.executeSparqlUpdate(update);
        return entity;
    }
    /**
     * Create Application Configuration using SPARQL
     */
    async createApplicationConfiguration(config, applicationId) {
        const id = (0, uuid_1.v4)();
        const timestamp = new Date().toISOString();
        const entity = {
            ...config,
            id,
            type: 'ApplicationConfiguration',
            createdAt: timestamp
        };
        const update = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX env: <${this.ontologyPrefix}>
      PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
      
      INSERT DATA {
        env:${id} rdf:type env:ApplicationConfiguration ;
                  env:id "${entity.id}" ;
                  env:type "${entity.type}" ;
                  env:createdAt "${timestamp}"^^xsd:dateTime ;
                  ${entity.configurationMap ? `env:configurationMap "${entity.configurationMap}" ;` : ''}
                  rdf:type env:Configuration .
                  
        env:${applicationId} env:hasApplicationConfig env:${id} .
      }
    `;
        await this.executeSparqlUpdate(update);
        return entity;
    }
    /**
     * Create Integration Configuration using SPARQL
     */
    async createIntegrationConfiguration(config, integrationId) {
        const id = (0, uuid_1.v4)();
        const timestamp = new Date().toISOString();
        const entity = {
            ...config,
            id,
            type: 'IntegrationConfiguration',
            createdAt: timestamp
        };
        const update = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX env: <${this.ontologyPrefix}>
      PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
      
      INSERT DATA {
        env:${id} rdf:type env:IntegrationConfiguration ;
                  env:id "${entity.id}" ;
                  env:type "${entity.type}" ;
                  env:createdAt "${timestamp}"^^xsd:dateTime ;
                  ${entity.configurationMap ? `env:configurationMap "${entity.configurationMap}" ;` : ''}
                  ${entity.sourceService ? `env:sourceService "${entity.sourceService}" ;` : ''}
                  ${entity.targetService ? `env:targetService "${entity.targetService}" ;` : ''}
                  rdf:type env:Configuration .
                  
        env:${integrationId} env:hasIntegrationConfig env:${id} .
      }
    `;
        await this.executeSparqlUpdate(update);
        return entity;
    }
    /**
     * Create Configuration Entry using SPARQL
     */
    async createConfigurationEntry(entry, configurationId) {
        const id = (0, uuid_1.v4)();
        const entity = { ...entry, id };
        const update = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX env: <${this.ontologyPrefix}>
      
      INSERT DATA {
        env:${id} rdf:type env:ConfigurationEntry ;
                  env:id "${entity.id}" ;
                  env:configurationKey "${entity.configurationKey}" ;
                  env:configurationValue "${entity.configurationValue}" ;
                  ${entity.configurationType ? `env:configurationType "${entity.configurationType}" ;` : ''}
                  rdf:type env:ConfigurationEntry .
                  
        env:${configurationId} env:hasConfigurationEntry env:${id} .
      }
    `;
        await this.executeSparqlUpdate(update);
        return entity;
    }
    /**
     * Get all entities by type following ontology
     */
    async getEntitiesByType(entityType) {
        const query = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX env: <${this.ontologyPrefix}>
      
      SELECT ?id ?name ?uniqueIdentifier ?owner ?description ?createdAt ?status WHERE {
        ?entity rdf:type env:${entityType} ;
                env:id ?id ;
                env:name ?name ;
                env:type ?type ;
                env:description ?description .
        OPTIONAL { ?entity env:uniqueIdentifier ?uniqueIdentifier }
        OPTIONAL { ?entity env:owner ?owner }
        OPTIONAL { ?entity env:createdAt ?createdAt }
        OPTIONAL { ?entity env:status ?status }
      }
    `;
        const result = await this.executeSparqlQuery(query);
        return result.results?.bindings?.map((binding) => ({
            id: binding.id?.value || '',
            name: binding.name?.value || '',
            type: entityType,
            uniqueIdentifier: binding.uniqueIdentifier?.value,
            owner: binding.owner?.value,
            description: binding.description?.value || '',
            createdAt: binding.createdAt?.value,
            status: binding.status?.value,
        })) || [];
    }
    /**
     * Get network data for visualization following ontology
     */
    async getNetworkData() {
        // Get all nodes with ALL their properties (including config_* properties)
        const nodesQuery = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX env: <${this.ontologyPrefix}>
      
      SELECT ?id ?name ?type ?status ?owner ?property ?value WHERE {
        ?entity env:id ?id ;
                env:name ?name ;
                env:type ?type .
        OPTIONAL { ?entity env:status ?status }
        OPTIONAL { ?entity env:owner ?owner }
        OPTIONAL { 
          ?entity ?property ?value .
          FILTER(STRSTARTS(STR(?property), "${this.ontologyPrefix}"))
          FILTER(?property NOT IN (env:id, env:name, env:type))
        }
        FILTER(?type IN ("Environment", "Application", "Integration"))
      }
    `;
        // Get all edges - both direct predicates and relationship entities
        const edgesQuery = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX env: <${this.ontologyPrefix}>
      
      SELECT ?sourceId ?targetId ?relationType ?relationLabel WHERE {
        {
          # Direct predicate relationships (like your CAS_QA integrates PASQA304)
          ?sourceEntity ?predicate ?targetEntity .
          ?sourceEntity env:name ?sourceName .
          ?targetEntity env:name ?targetName .
          ?sourceEntity env:id ?sourceId .
          ?targetEntity env:id ?targetId .
          FILTER(STRSTARTS(STR(?predicate), "${this.ontologyPrefix}"))
          FILTER(?predicate NOT IN (env:id, env:name, env:type, env:description, env:owner, env:status, env:createdAt, env:uniqueIdentifier, env:version, env:endpoint, env:region, env:sourceService, env:targetService))
          BIND(STRAFTER(STR(?predicate), "${this.ontologyPrefix}") AS ?relationType)
          BIND(?relationType AS ?relationLabel)
        }
        UNION
        {
          # Relationship entities
          ?relationship env:type "Relationship" .
          ?relationship env:sourceEntity ?sourceName .
          ?relationship env:targetEntity ?targetName .
          ?relationship env:relationshipType ?relationType .
          
          # Find the actual entity IDs by name
          ?sourceEntity env:name ?sourceName .
          ?targetEntity env:name ?targetName .
          ?sourceEntity env:id ?sourceId .
          ?targetEntity env:id ?targetId .
          
          BIND(?relationType AS ?relationLabel)
        }
        UNION
        {
          # Integration source relationships
          ?integration env:type "Integration" .
          ?integration env:id ?integrationId .
          ?integration env:sourceService ?sourceUri .
          
          # Extract entity name from URI or use direct name
          BIND(IF(CONTAINS(STR(?sourceUri), "/"), STRAFTER(STR(?sourceUri), "/"), STR(?sourceUri)) AS ?sourceName)
          
          ?sourceEntity env:name ?sourceName .
          ?sourceEntity env:id ?sourceId .
          
          BIND(?integrationId AS ?targetId)
          BIND("sourceOf" AS ?relationType)
          BIND("source of" AS ?relationLabel)
        }
        UNION
        {
          # Integration target relationships  
          ?integration env:type "Integration" .
          ?integration env:id ?integrationId .
          ?integration env:targetService ?targetUri .
          
          # Extract entity name from URI or use direct name
          BIND(IF(CONTAINS(STR(?targetUri), "/"), STRAFTER(STR(?targetUri), "/"), STR(?targetUri)) AS ?targetName)
          
          ?targetEntity env:name ?targetName .
          ?targetEntity env:id ?targetId .
          
          BIND(?integrationId AS ?sourceId)
          BIND("targetOf" AS ?relationType)
          BIND("target of" AS ?relationLabel)
        }
      }
    `;
        const [nodesResult, edgesResult] = await Promise.all([
            this.executeSparqlQuery(nodesQuery),
            this.executeSparqlQuery(edgesQuery)
        ]);
        console.log('Nodes query result:', JSON.stringify(nodesResult, null, 2));
        // Test query to specifically look for config properties
        const configTestQuery = `
      PREFIX env: <${this.ontologyPrefix}>
      
      SELECT ?entity ?property ?value WHERE {
        ?entity ?property ?value .
        FILTER(CONTAINS(STR(?property), "config_"))
      }
      LIMIT 10
    `;
        const configTestResult = await this.executeSparqlQuery(configTestQuery);
        console.log('Config test query result:', JSON.stringify(configTestResult, null, 2));
        // Build nodes with all their properties
        const nodeMap = {};
        nodesResult.results?.bindings?.forEach((binding) => {
            const entityId = binding.id?.value || '';
            if (!nodeMap[entityId]) {
                nodeMap[entityId] = {
                    id: entityId,
                    label: binding.name?.value || '',
                    type: binding.type?.value || '',
                    properties: {
                        status: binding.status?.value,
                        owner: binding.owner?.value,
                    },
                    configurations: {} // Initialize configurations object
                };
            }
            // Add any additional properties, including config_ properties
            const property = binding.property?.value;
            const value = binding.value?.value;
            if (property && value) {
                const propName = property.replace(this.ontologyPrefix, '');
                console.log(`Entity ${entityId}: Found property ${property} -> ${propName} = ${value}`);
                // If it's a config property, add it both directly AND to configurations object
                if (propName.startsWith('config_')) {
                    nodeMap[entityId][propName] = value; // Direct property for backward compatibility
                    const configKey = propName.replace('config_', ''); // Remove config_ prefix for display
                    nodeMap[entityId].configurations[configKey] = value; // Add to configurations object
                    console.log(`  -> Added to configurations as '${configKey}'`);
                }
                else {
                    // Regular property, just add directly
                    nodeMap[entityId][propName] = value;
                }
            }
        });
        const nodes = Object.values(nodeMap);
        const edges = edgesResult.results?.bindings?.map((binding, index) => ({
            id: `edge-${index}`,
            source: binding.sourceId?.value || '',
            target: binding.targetId?.value || '',
            type: binding.relationType?.value || 'related',
            label: binding.relationLabel?.value || binding.relationType?.value || 'related',
            properties: {}
        })) || [];
        return { nodes, edges };
    }
    /**
     * Get entity by ID following ontology
     */
    async getEntityById(id) {
        const query = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX env: <${this.ontologyPrefix}>
      
      SELECT ?name ?type ?uniqueIdentifier ?owner ?description ?createdAt ?status WHERE {
        ?entity env:id "${id}" ;
                env:name ?name ;
                env:type ?type ;
                env:description ?description .
        OPTIONAL { ?entity env:uniqueIdentifier ?uniqueIdentifier }
        OPTIONAL { ?entity env:owner ?owner }
        OPTIONAL { ?entity env:createdAt ?createdAt }
        OPTIONAL { ?entity env:status ?status }
      }
    `;
        const result = await this.executeSparqlQuery(query);
        if (!result.results?.bindings?.length) {
            return null;
        }
        const binding = result.results.bindings[0];
        return {
            id,
            name: binding.name?.value || '',
            type: binding.type?.value || '',
            uniqueIdentifier: binding.uniqueIdentifier?.value,
            owner: binding.owner?.value,
            description: binding.description?.value || '',
            createdAt: binding.createdAt?.value,
            status: binding.status?.value,
        };
    }
    /**
     * Get configurations for an entity
     */
    async getEntityConfigurations(entityId) {
        const query = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX env: <${this.ontologyPrefix}>
      
      SELECT ?configId ?configType ?configMap ?createdAt WHERE {
        ?entity env:id "${entityId}" ;
                env:hasConfiguration ?config .
        ?config env:id ?configId ;
                env:type ?configType .
        OPTIONAL { ?config env:configurationMap ?configMap }
        OPTIONAL { ?config env:createdAt ?createdAt }
      }
    `;
        const result = await this.executeSparqlQuery(query);
        return result.results?.bindings?.map((binding) => ({
            id: binding.configId?.value || '',
            type: binding.configType?.value || '',
            configurationMap: binding.configMap?.value,
            createdAt: binding.createdAt?.value,
        })) || [];
    }
    /**
     * Get configuration entries for a configuration
     */
    async getConfigurationEntries(configurationId) {
        const query = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX env: <${this.ontologyPrefix}>
      
      SELECT ?entryId ?key ?value ?type WHERE {
        ?config env:id "${configurationId}" ;
                env:hasConfigurationEntry ?entry .
        ?entry env:id ?entryId ;
               env:configurationKey ?key ;
               env:configurationValue ?value .
        OPTIONAL { ?entry env:configurationType ?type }
      }
    `;
        const result = await this.executeSparqlQuery(query);
        return result.results?.bindings?.map((binding) => ({
            id: binding.entryId?.value || '',
            configurationKey: binding.key?.value || '',
            configurationValue: binding.value?.value || '',
            configurationType: binding.type?.value,
        })) || [];
    }
    /**
     * Delete entity by ID
     */
    async deleteEntity(id) {
        const update = `
      PREFIX ems: <http://example.org/ems#>
      
      DELETE WHERE {
        ems:${id} ?p ?o .
      }
    `;
        try {
            await this.executeSparqlUpdate(update);
            return true;
        }
        catch (error) {
            console.error(`Failed to delete entity ${id}:`, error);
            return false;
        }
    }
    /**
     * Initialize ontology following the complete schema
     */
    async initializeOntology() {
        const update = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
      PREFIX owl: <http://www.w3.org/2002/07/owl#>
      PREFIX env: <${this.ontologyPrefix}>
      PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
      PREFIX dc: <http://purl.org/dc/elements/1.1/>
      PREFIX dcterms: <http://purl.org/dc/terms/>
      
      INSERT DATA {
        # Ontology metadata
        <${this.ontologyPrefix}> rdf:type owl:Ontology ;
            dc:title "Environment Management System Ontology" ;
            dc:description "RDF ontology for managing environments, applications, integrations and their configurations" ;
            dc:creator "Environment Management Team" ;
            dcterms:created "2025-12-15"^^xsd:date ;
            owl:versionInfo "1.0" .
        
        # Core entity classes
        env:Environment rdf:type owl:Class ;
            rdfs:label "Environment" ;
            rdfs:comment "A deployment or runtime environment" .
        
        env:Application rdf:type owl:Class ;
            rdfs:label "Application" ;
            rdfs:comment "A software application or service" .
        
        env:Integration rdf:type owl:Class ;
            rdfs:label "Integration" ;
            rdfs:comment "An integration between applications or services" .
        
        # Configuration classes
        env:Configuration rdf:type owl:Class ;
            rdfs:label "Configuration" ;
            rdfs:comment "Base class for all configuration types" .
        
        env:EnvironmentConfiguration rdf:type owl:Class ;
            rdfs:subClassOf env:Configuration ;
            rdfs:label "Environment Configuration" ;
            rdfs:comment "Configuration for environment infrastructure and deployment settings" .
        
        env:ApplicationConfiguration rdf:type owl:Class ;
            rdfs:subClassOf env:Configuration ;
            rdfs:label "Application Configuration" ;
            rdfs:comment "Configuration for application runtime and deployment parameters" .
        
        env:IntegrationConfiguration rdf:type owl:Class ;
            rdfs:subClassOf env:Configuration ;
            rdfs:label "Integration Configuration" ;
            rdfs:comment "Configuration for integration connections and protocols" .
        
        env:ConfigurationEntry rdf:type owl:Class ;
            rdfs:label "Configuration Entry" ;
            rdfs:comment "Individual key-value configuration parameter" .
        
        # Core properties
        env:id rdf:type owl:DatatypeProperty ;
            rdfs:label "identifier" ;
            rdfs:comment "Unique identifier for entity" ;
            rdfs:range xsd:string .
        
        env:name rdf:type owl:DatatypeProperty ;
            rdfs:label "name" ;
            rdfs:comment "Human-readable name" ;
            rdfs:range xsd:string .
        
        env:uniqueIdentifier rdf:type owl:DatatypeProperty ;
            rdfs:label "unique identifier" ;
            rdfs:comment "Business unique identifier" ;
            rdfs:range xsd:string .
        
        env:owner rdf:type owl:DatatypeProperty ;
            rdfs:label "owner" ;
            rdfs:comment "Owner or responsible party" ;
            rdfs:range xsd:string .
        
        env:description rdf:type owl:DatatypeProperty ;
            rdfs:label "description" ;
            rdfs:comment "Detailed description" ;
            rdfs:range xsd:string .
        
        env:type rdf:type owl:DatatypeProperty ;
            rdfs:label "type" ;
            rdfs:comment "Entity type classification" ;
            rdfs:range xsd:string .
        
        env:createdAt rdf:type owl:DatatypeProperty ;
            rdfs:label "created at" ;
            rdfs:comment "Creation timestamp" ;
            rdfs:range xsd:dateTime .
        
        env:endpoint rdf:type owl:DatatypeProperty ;
            rdfs:label "endpoint" ;
            rdfs:comment "Service endpoint URL" ;
            rdfs:range xsd:string .
        
        env:region rdf:type owl:DatatypeProperty ;
            rdfs:label "region" ;
            rdfs:comment "Geographic or cloud region" ;
            rdfs:range xsd:string .
        
        env:status rdf:type owl:DatatypeProperty ;
            rdfs:label "status" ;
            rdfs:comment "Current operational status" ;
            rdfs:range xsd:string .
        
        env:version rdf:type owl:DatatypeProperty ;
            rdfs:label "version" ;
            rdfs:comment "Version information" ;
            rdfs:range xsd:string .
        
        # Configuration properties
        env:configurationMap rdf:type owl:DatatypeProperty ;
            rdfs:label "configuration map" ;
            rdfs:comment "Complete configuration as JSON object" ;
            rdfs:domain env:Configuration ;
            rdfs:range xsd:string .
        
        env:configurationKey rdf:type owl:DatatypeProperty ;
            rdfs:label "configuration key" ;
            rdfs:comment "Configuration property name" ;
            rdfs:domain env:ConfigurationEntry ;
            rdfs:range xsd:string .
        
        env:configurationValue rdf:type owl:DatatypeProperty ;
            rdfs:label "configuration value" ;
            rdfs:comment "Configuration property value" ;
            rdfs:domain env:ConfigurationEntry ;
            rdfs:range xsd:string .
        
        env:configurationType rdf:type owl:DatatypeProperty ;
            rdfs:label "configuration type" ;
            rdfs:comment "Data type of configuration value" ;
            rdfs:domain env:ConfigurationEntry ;
            rdfs:range xsd:string .
        
        # Integration specific properties
        env:sourceService rdf:type owl:DatatypeProperty ;
            rdfs:label "source service" ;
            rdfs:comment "Source service identifier in integration" ;
            rdfs:range xsd:string .
        
        env:targetService rdf:type owl:DatatypeProperty ;
            rdfs:label "target service" ;
            rdfs:comment "Target service identifier in integration" ;
            rdfs:range xsd:string .
        
        # Object properties (relationships)
        env:hasConfiguration rdf:type owl:ObjectProperty ;
            rdfs:label "has configuration" ;
            rdfs:comment "Links an entity to its configuration" ;
            rdfs:domain owl:Thing ;
            rdfs:range env:Configuration .
        
        env:hasEnvironmentConfig rdf:type owl:ObjectProperty ;
            rdfs:subPropertyOf env:hasConfiguration ;
            rdfs:label "has environment configuration" ;
            rdfs:domain env:Environment ;
            rdfs:range env:EnvironmentConfiguration .
        
        env:hasApplicationConfig rdf:type owl:ObjectProperty ;
            rdfs:subPropertyOf env:hasConfiguration ;
            rdfs:label "has application configuration" ;
            rdfs:domain env:Application ;
            rdfs:range env:ApplicationConfiguration .
        
        env:hasIntegrationConfig rdf:type owl:ObjectProperty ;
            rdfs:subPropertyOf env:hasConfiguration ;
            rdfs:label "has integration configuration" ;
            rdfs:domain env:Integration ;
            rdfs:range env:IntegrationConfiguration .
        
        env:hasConfigurationEntry rdf:type owl:ObjectProperty ;
            rdfs:label "has configuration entry" ;
            rdfs:domain env:Configuration ;
            rdfs:range env:ConfigurationEntry .
        
        env:integratesWith rdf:type owl:ObjectProperty ;
            rdfs:label "integrates with" ;
            rdfs:comment "Direct integration relationship between services" .
        
        env:deployedIn rdf:type owl:ObjectProperty ;
            rdfs:label "deployed in" ;
            rdfs:comment "Application deployed in environment" ;
            rdfs:domain env:Application ;
            rdfs:range env:Environment .
      }
    `;
        await this.executeSparqlUpdate(update);
    }
    /**
     * Create deployment relationship
     */
    async createDeployment(applicationId, environmentId) {
        const update = `
      PREFIX env: <${this.ontologyPrefix}>
      
      INSERT DATA {
        env:${applicationId} env:deployedIn env:${environmentId} .
      }
    `;
        await this.executeSparqlUpdate(update);
    }
    /**
     * Get deployments for an environment
     */
    async getEnvironmentDeployments(environmentId) {
        const query = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX env: <${this.ontologyPrefix}>
      
      SELECT ?appId ?appName ?appType ?version ?status WHERE {
        ?app env:deployedIn ?env .
        ?env env:id "${environmentId}" .
        ?app env:id ?appId ;
             env:name ?appName ;
             env:type ?appType .
        OPTIONAL { ?app env:version ?version }
        OPTIONAL { ?app env:status ?status }
      }
    `;
        const result = await this.executeSparqlQuery(query);
        return result.results?.bindings?.map((binding) => ({
            id: binding.appId?.value || '',
            name: binding.appName?.value || '',
            type: binding.appType?.value || '',
            version: binding.version?.value,
            status: binding.status?.value,
        })) || [];
    }
    /**
     * Create relationships between entities
     */
    async createRelationship(sourceEntityName, relationshipType, targetEntityName) {
        // Generate a unique ID for this relationship entity
        const relationshipId = `rel_${(0, uuid_1.v4)()}`;
        const relationshipUri = `${this.ontologyPrefix}entity/${relationshipId}`;
        // Create relationship as an entity with source, target, and type properties
        const insertQuery = `
      PREFIX env: <${this.ontologyPrefix}>
      
      INSERT DATA {
        <${relationshipUri}> env:id "${relationshipId}" .
        <${relationshipUri}> env:name "${sourceEntityName}_${relationshipType}_${targetEntityName}" .
        <${relationshipUri}> env:type "Relationship" .
        <${relationshipUri}> env:relationshipType "${relationshipType}" .
        <${relationshipUri}> env:sourceEntity "${sourceEntityName}" .
        <${relationshipUri}> env:targetEntity "${targetEntityName}" .
        <${relationshipUri}> env:description "Relationship: ${sourceEntityName} ${relationshipType} ${targetEntityName}" .
        <${relationshipUri}> env:createdAt "${new Date().toISOString()}" .
      }
    `;
        await this.executeSparqlUpdate(insertQuery);
    }
    /**
     * Add configuration properties directly to an entity
     */
    async addConfigurationProperties(entityId, configurations) {
        if (!configurations || Object.keys(configurations).length === 0) {
            return;
        }
        // Find the entity URI by ID
        const entityQuery = `
      PREFIX env: <${this.ontologyPrefix}>
      
      SELECT ?entity WHERE {
        ?entity env:id "${entityId}"
      }
    `;
        const entityResult = await this.executeSparqlQuery(entityQuery);
        if (!entityResult.results?.bindings?.length) {
            throw new Error(`Entity with ID ${entityId} not found`);
        }
        const entityUri = entityResult.results.bindings[0].entity.value;
        // Build INSERT DATA query to add config properties
        let insertTriples = '';
        for (const [key, value] of Object.entries(configurations)) {
            if (value !== null && value !== undefined && value !== '') {
                const configProperty = `env:config_${key}`;
                // Escape quotes in the value
                const escapedValue = String(value).replace(/"/g, '\\"');
                insertTriples += `    <${entityUri}> ${configProperty} "${escapedValue}" .\n`;
            }
        }
        if (insertTriples) {
            const updateQuery = `
        PREFIX env: <${this.ontologyPrefix}>
        
        INSERT DATA {
${insertTriples}        }
      `;
            await this.executeSparqlUpdate(updateQuery);
            console.log(`Added ${Object.keys(configurations).length} configuration properties to entity ${entityId}`);
        }
    }
}
exports.NeptuneSparqlClient = NeptuneSparqlClient;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVwdHVuZS1zcGFycWwtY2xpZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibmVwdHVuZS1zcGFycWwtY2xpZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSwwREFBMEQ7QUFDMUQscUZBQXFGOzs7QUFHckYsZ0ZBQW9FO0FBRXBFLHlEQUFvRDtBQUNwRCxxREFBK0M7QUFDL0MsdURBQW1EO0FBQ25ELCtCQUFvQztBQUNwQyxpQ0FBMEI7QUE2RTFCLE1BQWEsbUJBQW1CO0lBbUI5QixZQUFZLGVBQXdCLEVBQUUsU0FBaUIsV0FBVztRQWJsRSxxQkFBcUI7UUFDSixtQkFBYyxHQUFHLDBDQUEwQyxDQUFDO1FBYTNFLElBQUksQ0FBQyxlQUFlLEdBQUcsZUFBZSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWlCLENBQUM7UUFDeEUsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksV0FBVyxDQUFDO1FBRTlELHNEQUFzRDtRQUN0RCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUEsMENBQWUsR0FBRSxDQUFDO1FBRXJDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSwwQkFBVyxDQUFDO1lBQzVCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVztZQUM3QixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbkIsT0FBTyxFQUFFLFlBQVk7WUFDckIsTUFBTSxFQUFFLGtCQUFNO1NBQ2YsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDekIsTUFBTSxJQUFJLEtBQUssQ0FBQywyR0FBMkcsQ0FBQyxDQUFDO1NBQzlIO1FBRUQsMkRBQTJEO1FBQzNELE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQztRQUNsRCxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7UUFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ3hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQztRQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixDQUFDLENBQUM7SUFDL0MsQ0FBQztJQWxDRDs7T0FFRztJQUNLLGVBQWUsQ0FBQyxPQUFlO1FBQ3JDLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDM0MsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDakQ7UUFDRCxPQUFPLE9BQU8sQ0FBQztJQUNqQixDQUFDO0lBNEJEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGtCQUFrQixDQUFDLEtBQWE7UUFDcEMsTUFBTSxJQUFJLEdBQUcsU0FBUyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1FBRWxELGlDQUFpQztRQUNqQyxNQUFNLE9BQU8sR0FBRyxJQUFJLDJCQUFXLENBQUM7WUFDOUIsTUFBTSxFQUFFLE1BQU07WUFDZCxRQUFRLEVBQUUsUUFBUTtZQUNsQixRQUFRLEVBQUUsSUFBSSxDQUFDLGVBQWU7WUFDOUIsSUFBSSxFQUFFLElBQUk7WUFDVixJQUFJLEVBQUUsU0FBUztZQUNmLE9BQU8sRUFBRTtnQkFDUCxjQUFjLEVBQUUsbUNBQW1DO2dCQUNuRCxRQUFRLEVBQUUsaUNBQWlDO2dCQUMzQyxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsZUFBZSxPQUFPO2FBQ3ZDO1lBQ0QsSUFBSTtTQUNMLENBQUMsQ0FBQztRQUVILElBQUk7WUFDRix3Q0FBd0M7WUFDeEMsTUFBTSxhQUFhLEdBQUcsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUV0RCx5QkFBeUI7WUFDekIsTUFBTSxHQUFHLEdBQUcsV0FBVyxJQUFJLENBQUMsZUFBZSxjQUFjLENBQUM7WUFFMUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsR0FBRyxFQUFFLENBQUMsQ0FBQztZQUNqRCxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRXBELE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBQSxlQUFLLEVBQUM7Z0JBQzNCLE1BQU0sRUFBRSxNQUFNO2dCQUNkLEdBQUc7Z0JBQ0gsT0FBTyxFQUFFO29CQUNQLEdBQUcsYUFBYSxDQUFDLE9BQU87b0JBQ3hCLGdCQUFnQixFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO2lCQUN6QztnQkFDRCxJQUFJLEVBQUUsSUFBSTtnQkFDVixPQUFPLEVBQUUsS0FBSztnQkFDZCxjQUFjLEVBQUUsVUFBVSxNQUFNO29CQUM5QixPQUFPLE1BQU0sSUFBSSxHQUFHLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLDhDQUE4QztnQkFDdEYsQ0FBQzthQUNGLENBQUMsQ0FBQztZQUVILElBQUksUUFBUSxDQUFDLE1BQU0sSUFBSSxHQUFHLEVBQUU7Z0JBQzFCLE1BQU0sSUFBSSxLQUFLLENBQUMsb0NBQW9DLFFBQVEsQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2FBQzFHO1lBRUQsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDO1NBQ3RCO1FBQUMsT0FBTyxLQUFLLEVBQUU7WUFDZCxPQUFPLENBQUMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzVDLE1BQU0sS0FBSyxDQUFDO1NBQ2I7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsbUJBQW1CLENBQUMsTUFBYztRQUN0QyxNQUFNLElBQUksR0FBRyxVQUFVLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFFcEQsaUNBQWlDO1FBQ2pDLE1BQU0sT0FBTyxHQUFHLElBQUksMkJBQVcsQ0FBQztZQUM5QixNQUFNLEVBQUUsTUFBTTtZQUNkLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLFFBQVEsRUFBRSxJQUFJLENBQUMsZUFBZTtZQUM5QixJQUFJLEVBQUUsSUFBSTtZQUNWLElBQUksRUFBRSxTQUFTO1lBQ2YsT0FBTyxFQUFFO2dCQUNQLGNBQWMsRUFBRSxtQ0FBbUM7Z0JBQ25ELFFBQVEsRUFBRSxpQ0FBaUM7Z0JBQzNDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxlQUFlLE9BQU87YUFDdkM7WUFDRCxJQUFJO1NBQ0wsQ0FBQyxDQUFDO1FBRUgsSUFBSTtZQUNGLHdDQUF3QztZQUN4QyxNQUFNLGFBQWEsR0FBRyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRXRELHlCQUF5QjtZQUN6QixNQUFNLEdBQUcsR0FBRyxXQUFXLElBQUksQ0FBQyxlQUFlLGNBQWMsQ0FBQztZQUUxRCxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixHQUFHLEVBQUUsQ0FBQyxDQUFDO1lBQ2xELE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFdEQsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFBLGVBQUssRUFBQztnQkFDM0IsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsR0FBRztnQkFDSCxPQUFPLEVBQUU7b0JBQ1AsR0FBRyxhQUFhLENBQUMsT0FBTztvQkFDeEIsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUU7aUJBQ3pDO2dCQUNELElBQUksRUFBRSxJQUFJO2dCQUNWLE9BQU8sRUFBRSxLQUFLO2dCQUNkLGNBQWMsRUFBRSxVQUFVLE1BQU07b0JBQzlCLE9BQU8sTUFBTSxJQUFJLEdBQUcsSUFBSSxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsOENBQThDO2dCQUN0RixDQUFDO2FBQ0YsQ0FBQyxDQUFDO1lBRUgsSUFBSSxRQUFRLENBQUMsTUFBTSxJQUFJLEdBQUcsRUFBRTtnQkFDMUIsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQ0FBcUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7YUFDM0c7WUFFRCxPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUM7U0FDdEI7UUFBQyxPQUFPLEtBQUssRUFBRTtZQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDN0MsTUFBTSxLQUFLLENBQUM7U0FDYjtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxXQUFXO1FBQ2YsSUFBSTtZQUNGLE1BQU0sS0FBSyxHQUFHOzs7O09BSWIsQ0FBQztZQUVGLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JDLE9BQU8sSUFBSSxDQUFDO1NBQ2I7UUFBQyxPQUFPLEtBQUssRUFBRTtZQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDN0MsT0FBTyxLQUFLLENBQUM7U0FDZDtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxXQUFvQztRQUMxRCxNQUFNLEVBQUUsR0FBRyxJQUFBLFNBQU0sR0FBRSxDQUFDO1FBQ3BCLE1BQU0sU0FBUyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDM0MsTUFBTSxNQUFNLEdBQWdCO1lBQzFCLEdBQUcsV0FBVztZQUNkLEVBQUU7WUFDRixJQUFJLEVBQUUsYUFBYTtZQUNuQixTQUFTLEVBQUUsU0FBUztTQUNyQixDQUFDO1FBRUYsTUFBTSxNQUFNLEdBQUc7OztxQkFHRSxJQUFJLENBQUMsY0FBYzs7OztjQUkxQixFQUFFOzRCQUNZLE1BQU0sQ0FBQyxFQUFFOzhCQUNQLE1BQU0sQ0FBQyxJQUFJOzhCQUNYLE1BQU0sQ0FBQyxJQUFJO21DQUNOLFNBQVM7b0JBQ3hCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMseUJBQXlCLE1BQU0sQ0FBQyxnQkFBZ0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwRixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxjQUFjLE1BQU0sQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDbkQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsZUFBZSxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7cUNBQ3JDLE1BQU0sQ0FBQyxXQUFXLElBQUksRUFBRTs7S0FFeEQsQ0FBQztRQUVGLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZDLE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxXQUFvQztRQUMxRCxNQUFNLEVBQUUsR0FBRyxJQUFBLFNBQU0sR0FBRSxDQUFDO1FBQ3BCLE1BQU0sU0FBUyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDM0MsTUFBTSxNQUFNLEdBQWdCO1lBQzFCLEdBQUcsV0FBVztZQUNkLEVBQUU7WUFDRixJQUFJLEVBQUUsYUFBYTtZQUNuQixTQUFTLEVBQUUsU0FBUztTQUNyQixDQUFDO1FBRUYsTUFBTSxNQUFNLEdBQUc7OztxQkFHRSxJQUFJLENBQUMsY0FBYzs7OztjQUkxQixFQUFFOzRCQUNZLE1BQU0sQ0FBQyxFQUFFOzhCQUNQLE1BQU0sQ0FBQyxJQUFJOzhCQUNYLE1BQU0sQ0FBQyxJQUFJO21DQUNOLFNBQVM7b0JBQ3hCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMseUJBQXlCLE1BQU0sQ0FBQyxnQkFBZ0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwRixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxjQUFjLE1BQU0sQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDbkQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsZUFBZSxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7cUNBQ3JDLE1BQU0sQ0FBQyxXQUFXLElBQUksRUFBRTs7S0FFeEQsQ0FBQztRQUVGLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZDLE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxXQUFvQztRQUMxRCxNQUFNLEVBQUUsR0FBRyxJQUFBLFNBQU0sR0FBRSxDQUFDO1FBQ3BCLE1BQU0sU0FBUyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDM0MsTUFBTSxNQUFNLEdBQWdCO1lBQzFCLEdBQUcsV0FBVztZQUNkLEVBQUU7WUFDRixJQUFJLEVBQUUsYUFBYTtZQUNuQixTQUFTLEVBQUUsU0FBUztTQUNyQixDQUFDO1FBRUYsTUFBTSxNQUFNLEdBQUc7OztxQkFHRSxJQUFJLENBQUMsY0FBYzs7OztjQUkxQixFQUFFOzRCQUNZLE1BQU0sQ0FBQyxFQUFFOzhCQUNQLE1BQU0sQ0FBQyxJQUFJOzhCQUNYLE1BQU0sQ0FBQyxJQUFJO21DQUNOLFNBQVM7b0JBQ3hCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMseUJBQXlCLE1BQU0sQ0FBQyxnQkFBZ0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwRixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxjQUFjLE1BQU0sQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDbkQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsZUFBZSxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7cUNBQ3JDLE1BQU0sQ0FBQyxXQUFXLElBQUksRUFBRTs7S0FFeEQsQ0FBQztRQUVGLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZDLE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyw4QkFBOEIsQ0FBQyxNQUE0QyxFQUFFLGFBQXFCO1FBQ3RHLE1BQU0sRUFBRSxHQUFHLElBQUEsU0FBTSxHQUFFLENBQUM7UUFDcEIsTUFBTSxTQUFTLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUMzQyxNQUFNLE1BQU0sR0FBNkI7WUFDdkMsR0FBRyxNQUFNO1lBQ1QsRUFBRTtZQUNGLElBQUksRUFBRSwwQkFBMEI7WUFDaEMsU0FBUyxFQUFFLFNBQVM7U0FDckIsQ0FBQztRQUVGLE1BQU0sTUFBTSxHQUFHOztxQkFFRSxJQUFJLENBQUMsY0FBYzs7OztjQUkxQixFQUFFOzRCQUNZLE1BQU0sQ0FBQyxFQUFFOzhCQUNQLE1BQU0sQ0FBQyxJQUFJO21DQUNOLFNBQVM7b0JBQ3hCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMseUJBQXlCLE1BQU0sQ0FBQyxnQkFBZ0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFOzs7Y0FHMUYsYUFBYSxpQ0FBaUMsRUFBRTs7S0FFekQsQ0FBQztRQUVGLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZDLE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyw4QkFBOEIsQ0FBQyxNQUE0QyxFQUFFLGFBQXFCO1FBQ3RHLE1BQU0sRUFBRSxHQUFHLElBQUEsU0FBTSxHQUFFLENBQUM7UUFDcEIsTUFBTSxTQUFTLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUMzQyxNQUFNLE1BQU0sR0FBNkI7WUFDdkMsR0FBRyxNQUFNO1lBQ1QsRUFBRTtZQUNGLElBQUksRUFBRSwwQkFBMEI7WUFDaEMsU0FBUyxFQUFFLFNBQVM7U0FDckIsQ0FBQztRQUVGLE1BQU0sTUFBTSxHQUFHOztxQkFFRSxJQUFJLENBQUMsY0FBYzs7OztjQUkxQixFQUFFOzRCQUNZLE1BQU0sQ0FBQyxFQUFFOzhCQUNQLE1BQU0sQ0FBQyxJQUFJO21DQUNOLFNBQVM7b0JBQ3hCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMseUJBQXlCLE1BQU0sQ0FBQyxnQkFBZ0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFOzs7Y0FHMUYsYUFBYSxpQ0FBaUMsRUFBRTs7S0FFekQsQ0FBQztRQUVGLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZDLE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyw4QkFBOEIsQ0FBQyxNQUE0QyxFQUFFLGFBQXFCO1FBQ3RHLE1BQU0sRUFBRSxHQUFHLElBQUEsU0FBTSxHQUFFLENBQUM7UUFDcEIsTUFBTSxTQUFTLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUMzQyxNQUFNLE1BQU0sR0FBNkI7WUFDdkMsR0FBRyxNQUFNO1lBQ1QsRUFBRTtZQUNGLElBQUksRUFBRSwwQkFBMEI7WUFDaEMsU0FBUyxFQUFFLFNBQVM7U0FDckIsQ0FBQztRQUVGLE1BQU0sTUFBTSxHQUFHOztxQkFFRSxJQUFJLENBQUMsY0FBYzs7OztjQUkxQixFQUFFOzRCQUNZLE1BQU0sQ0FBQyxFQUFFOzhCQUNQLE1BQU0sQ0FBQyxJQUFJO21DQUNOLFNBQVM7b0JBQ3hCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMseUJBQXlCLE1BQU0sQ0FBQyxnQkFBZ0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwRixNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsTUFBTSxDQUFDLGFBQWEsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUMzRSxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsTUFBTSxDQUFDLGFBQWEsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFOzs7Y0FHakYsYUFBYSxpQ0FBaUMsRUFBRTs7S0FFekQsQ0FBQztRQUVGLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZDLE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxLQUFxQyxFQUFFLGVBQXVCO1FBQzNGLE1BQU0sRUFBRSxHQUFHLElBQUEsU0FBTSxHQUFFLENBQUM7UUFDcEIsTUFBTSxNQUFNLEdBQXVCLEVBQUUsR0FBRyxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFFcEQsTUFBTSxNQUFNLEdBQUc7O3FCQUVFLElBQUksQ0FBQyxjQUFjOzs7Y0FHMUIsRUFBRTs0QkFDWSxNQUFNLENBQUMsRUFBRTswQ0FDSyxNQUFNLENBQUMsZ0JBQWdCOzRDQUNyQixNQUFNLENBQUMsa0JBQWtCO29CQUNqRCxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixNQUFNLENBQUMsaUJBQWlCLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTs7O2NBRzdGLGVBQWUsa0NBQWtDLEVBQUU7O0tBRTVELENBQUM7UUFFRixNQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN2QyxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsaUJBQWlCLENBQUMsVUFBa0I7UUFDeEMsTUFBTSxLQUFLLEdBQUc7O3FCQUVHLElBQUksQ0FBQyxjQUFjOzs7K0JBR1QsVUFBVTs7Ozs7Ozs7OztLQVVwQyxDQUFDO1FBRUYsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFcEQsT0FBTyxNQUFNLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQyxPQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDdEQsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFFLEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDM0IsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDL0IsSUFBSSxFQUFFLFVBQVU7WUFDaEIsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLGdCQUFnQixFQUFFLEtBQUs7WUFDakQsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEVBQUUsS0FBSztZQUMzQixXQUFXLEVBQUUsT0FBTyxDQUFDLFdBQVcsRUFBRSxLQUFLLElBQUksRUFBRTtZQUM3QyxTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBRSxLQUFLO1lBQ25DLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLEtBQUs7U0FDOUIsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ1osQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGNBQWM7UUFDbEIsMEVBQTBFO1FBQzFFLE1BQU0sVUFBVSxHQUFHOztxQkFFRixJQUFJLENBQUMsY0FBYzs7Ozs7Ozs7Ozs4Q0FVTSxJQUFJLENBQUMsY0FBYzs7Ozs7S0FLNUQsQ0FBQztRQUVGLG1FQUFtRTtRQUNuRSxNQUFNLFVBQVUsR0FBRzs7cUJBRUYsSUFBSSxDQUFDLGNBQWM7Ozs7Ozs7Ozs7K0NBVU8sSUFBSSxDQUFDLGNBQWM7OzRDQUV0QixJQUFJLENBQUMsY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBc0QxRCxDQUFDO1FBRUYsTUFBTSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDbkQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsQ0FBQztZQUNuQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDO1NBQ3BDLENBQUMsQ0FBQztRQUVILE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFekUsd0RBQXdEO1FBQ3hELE1BQU0sZUFBZSxHQUFHO3FCQUNQLElBQUksQ0FBQyxjQUFjOzs7Ozs7O0tBT25DLENBQUM7UUFFRixNQUFNLGdCQUFnQixHQUFHLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ3hFLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVwRix3Q0FBd0M7UUFDeEMsTUFBTSxPQUFPLEdBQXdCLEVBQUUsQ0FBQztRQUN4QyxXQUFXLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQyxPQUFZLEVBQUUsRUFBRTtZQUN0RCxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsRUFBRSxFQUFFLEtBQUssSUFBSSxFQUFFLENBQUM7WUFFekMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDdEIsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHO29CQUNsQixFQUFFLEVBQUUsUUFBUTtvQkFDWixLQUFLLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxLQUFLLElBQUksRUFBRTtvQkFDaEMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUU7b0JBQy9CLFVBQVUsRUFBRTt3QkFDVixNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxLQUFLO3dCQUM3QixLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxLQUFLO3FCQUM1QjtvQkFDRCxjQUFjLEVBQUUsRUFBRSxDQUFDLG1DQUFtQztpQkFDdkQsQ0FBQzthQUNIO1lBRUQsOERBQThEO1lBQzlELE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDO1lBQ3pDLE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDO1lBRW5DLElBQUksUUFBUSxJQUFJLEtBQUssRUFBRTtnQkFDckIsTUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUMzRCxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsUUFBUSxvQkFBb0IsUUFBUSxPQUFPLFFBQVEsTUFBTSxLQUFLLEVBQUUsQ0FBQyxDQUFDO2dCQUV4RiwrRUFBK0U7Z0JBQy9FLElBQUksUUFBUSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDbEMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLDZDQUE2QztvQkFDbEYsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxvQ0FBb0M7b0JBQ3ZGLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsK0JBQStCO29CQUNwRixPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO2lCQUMvRDtxQkFBTTtvQkFDTCxzQ0FBc0M7b0JBQ3RDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxLQUFLLENBQUM7aUJBQ3JDO2FBQ0Y7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILE1BQU0sS0FBSyxHQUFrQixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXBELE1BQU0sS0FBSyxHQUFrQixXQUFXLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQyxPQUFZLEVBQUUsS0FBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ2hHLEVBQUUsRUFBRSxRQUFRLEtBQUssRUFBRTtZQUNuQixNQUFNLEVBQUUsT0FBTyxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUksRUFBRTtZQUNyQyxNQUFNLEVBQUUsT0FBTyxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUksRUFBRTtZQUNyQyxJQUFJLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFBRSxLQUFLLElBQUksU0FBUztZQUM5QyxLQUFLLEVBQUUsT0FBTyxDQUFDLGFBQWEsRUFBRSxLQUFLLElBQUksT0FBTyxDQUFDLFlBQVksRUFBRSxLQUFLLElBQUksU0FBUztZQUMvRSxVQUFVLEVBQUUsRUFBRTtTQUNmLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUVWLE9BQU8sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGFBQWEsQ0FBQyxFQUFVO1FBQzVCLE1BQU0sS0FBSyxHQUFHOztxQkFFRyxJQUFJLENBQUMsY0FBYzs7OzBCQUdkLEVBQUU7Ozs7Ozs7OztLQVN2QixDQUFDO1FBRUYsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFcEQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRTtZQUNyQyxPQUFPLElBQUksQ0FBQztTQUNiO1FBRUQsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0MsT0FBTztZQUNMLEVBQUU7WUFDRixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxLQUFLLElBQUksRUFBRTtZQUMvQixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxLQUFLLElBQUksRUFBRTtZQUMvQixnQkFBZ0IsRUFBRSxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsS0FBSztZQUNqRCxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxLQUFLO1lBQzNCLFdBQVcsRUFBRSxPQUFPLENBQUMsV0FBVyxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQzdDLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLEtBQUs7WUFDbkMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsS0FBSztTQUM5QixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLHVCQUF1QixDQUFDLFFBQWdCO1FBQzVDLE1BQU0sS0FBSyxHQUFHOztxQkFFRyxJQUFJLENBQUMsY0FBYzs7OzBCQUdkLFFBQVE7Ozs7Ozs7S0FPN0IsQ0FBQztRQUVGLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXBELE9BQU8sTUFBTSxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUMsT0FBWSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ3RELEVBQUUsRUFBRSxPQUFPLENBQUMsUUFBUSxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQ2pDLElBQUksRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQ3JDLGdCQUFnQixFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsS0FBSztZQUMxQyxTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBRSxLQUFLO1NBQ3BDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNaLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxlQUF1QjtRQUNuRCxNQUFNLEtBQUssR0FBRzs7cUJBRUcsSUFBSSxDQUFDLGNBQWM7OzswQkFHZCxlQUFlOzs7Ozs7O0tBT3BDLENBQUM7UUFFRixNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVwRCxPQUFPLE1BQU0sQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDLE9BQVksRUFBRSxFQUFFLENBQUMsQ0FBQztZQUN0RCxFQUFFLEVBQUUsT0FBTyxDQUFDLE9BQU8sRUFBRSxLQUFLLElBQUksRUFBRTtZQUNoQyxnQkFBZ0IsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQzFDLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxLQUFLLEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDOUMsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxLQUFLO1NBQ3ZDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNaLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBVTtRQUMzQixNQUFNLE1BQU0sR0FBRzs7OztjQUlMLEVBQUU7O0tBRVgsQ0FBQztRQUVGLElBQUk7WUFDRixNQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2QyxPQUFPLElBQUksQ0FBQztTQUNiO1FBQUMsT0FBTyxLQUFLLEVBQUU7WUFDZCxPQUFPLENBQUMsS0FBSyxDQUFDLDJCQUEyQixFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN2RCxPQUFPLEtBQUssQ0FBQztTQUNkO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGtCQUFrQjtRQUN0QixNQUFNLE1BQU0sR0FBRzs7OztxQkFJRSxJQUFJLENBQUMsY0FBYzs7Ozs7OztXQU83QixJQUFJLENBQUMsY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7S0FnTHpCLENBQUM7UUFFRixNQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsZ0JBQWdCLENBQUMsYUFBcUIsRUFBRSxhQUFxQjtRQUNqRSxNQUFNLE1BQU0sR0FBRztxQkFDRSxJQUFJLENBQUMsY0FBYzs7O2NBRzFCLGFBQWEsdUJBQXVCLGFBQWE7O0tBRTFELENBQUM7UUFFRixNQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMseUJBQXlCLENBQUMsYUFBcUI7UUFDbkQsTUFBTSxLQUFLLEdBQUc7O3FCQUVHLElBQUksQ0FBQyxjQUFjOzs7O3VCQUlqQixhQUFhOzs7Ozs7O0tBTy9CLENBQUM7UUFFRixNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVwRCxPQUFPLE1BQU0sQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDLE9BQVksRUFBRSxFQUFFLENBQUMsQ0FBQztZQUN0RCxFQUFFLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxLQUFLLElBQUksRUFBRTtZQUM5QixJQUFJLEVBQUUsT0FBTyxDQUFDLE9BQU8sRUFBRSxLQUFLLElBQUksRUFBRTtZQUNsQyxJQUFJLEVBQUUsT0FBTyxDQUFDLE9BQU8sRUFBRSxLQUFLLElBQUksRUFBRTtZQUNsQyxPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU8sRUFBRSxLQUFLO1lBQy9CLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLEtBQUs7U0FDOUIsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ1osQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGtCQUFrQixDQUFDLGdCQUF3QixFQUFFLGdCQUF3QixFQUFFLGdCQUF3QjtRQUNuRyxvREFBb0Q7UUFDcEQsTUFBTSxjQUFjLEdBQUcsT0FBTyxJQUFBLFNBQU0sR0FBRSxFQUFFLENBQUM7UUFDekMsTUFBTSxlQUFlLEdBQUcsR0FBRyxJQUFJLENBQUMsY0FBYyxVQUFVLGNBQWMsRUFBRSxDQUFDO1FBRXpFLDRFQUE0RTtRQUM1RSxNQUFNLFdBQVcsR0FBRztxQkFDSCxJQUFJLENBQUMsY0FBYzs7O1dBRzdCLGVBQWUsYUFBYSxjQUFjO1dBQzFDLGVBQWUsZUFBZSxnQkFBZ0IsSUFBSSxnQkFBZ0IsSUFBSSxnQkFBZ0I7V0FDdEYsZUFBZTtXQUNmLGVBQWUsMkJBQTJCLGdCQUFnQjtXQUMxRCxlQUFlLHVCQUF1QixnQkFBZ0I7V0FDdEQsZUFBZSx1QkFBdUIsZ0JBQWdCO1dBQ3RELGVBQWUsb0NBQW9DLGdCQUFnQixJQUFJLGdCQUFnQixJQUFJLGdCQUFnQjtXQUMzRyxlQUFlLG9CQUFvQixJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTs7S0FFakUsQ0FBQztRQUVGLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxRQUFnQixFQUFFLGNBQW1DO1FBQ3BGLElBQUksQ0FBQyxjQUFjLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQy9ELE9BQU87U0FDUjtRQUVELDRCQUE0QjtRQUM1QixNQUFNLFdBQVcsR0FBRztxQkFDSCxJQUFJLENBQUMsY0FBYzs7OzBCQUdkLFFBQVE7O0tBRTdCLENBQUM7UUFFRixNQUFNLFlBQVksR0FBRyxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNoRSxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFO1lBQzNDLE1BQU0sSUFBSSxLQUFLLENBQUMsa0JBQWtCLFFBQVEsWUFBWSxDQUFDLENBQUM7U0FDekQ7UUFFRCxNQUFNLFNBQVMsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1FBRWhFLG1EQUFtRDtRQUNuRCxJQUFJLGFBQWEsR0FBRyxFQUFFLENBQUM7UUFDdkIsS0FBSyxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDekQsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxLQUFLLEVBQUUsRUFBRTtnQkFDekQsTUFBTSxjQUFjLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztnQkFDM0MsNkJBQTZCO2dCQUM3QixNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDeEQsYUFBYSxJQUFJLFFBQVEsU0FBUyxLQUFLLGNBQWMsS0FBSyxZQUFZLE9BQU8sQ0FBQzthQUMvRTtTQUNGO1FBRUQsSUFBSSxhQUFhLEVBQUU7WUFDakIsTUFBTSxXQUFXLEdBQUc7dUJBQ0gsSUFBSSxDQUFDLGNBQWM7OztFQUd4QyxhQUFhO09BQ1IsQ0FBQztZQUVGLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQzVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sdUNBQXVDLFFBQVEsRUFBRSxDQUFDLENBQUM7U0FDM0c7SUFDSCxDQUFDO0NBQ0Y7QUExaENELGtEQTBoQ0MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBOZXB0dW5lIFNQQVJRTCBDbGllbnQgZm9yIEVudmlyb25tZW50IE1hbmFnZW1lbnQgU3lzdGVtXG4vLyBQdXJlIFNQQVJRTCBvcGVyYXRpb25zIGZvbGxvd2luZyB0aGUgY29tcGxldGUgb250b2xvZ3kgKGV4Y2x1ZGluZyBjaGFuZ2UgdHJhY2tpbmcpXG5cbmltcG9ydCB7IE5lcHR1bmVkYXRhQ2xpZW50IH0gZnJvbSAnQGF3cy1zZGsvY2xpZW50LW5lcHR1bmVkYXRhJztcbmltcG9ydCB7IGRlZmF1bHRQcm92aWRlciB9IGZyb20gJ0Bhd3Mtc2RrL2NyZWRlbnRpYWwtcHJvdmlkZXItbm9kZSc7XG5pbXBvcnQgeyBBd3NDcmVkZW50aWFsSWRlbnRpdHlQcm92aWRlciB9IGZyb20gJ0Bhd3Mtc2RrL3R5cGVzJztcbmltcG9ydCB7IEh0dHBSZXF1ZXN0IH0gZnJvbSAnQHNtaXRoeS9wcm90b2NvbC1odHRwJztcbmltcG9ydCB7IFNoYTI1NiB9IGZyb20gJ0Bhd3MtY3J5cHRvL3NoYTI1Ni1qcyc7XG5pbXBvcnQgeyBTaWduYXR1cmVWNCB9IGZyb20gJ0BzbWl0aHkvc2lnbmF0dXJlLXY0JztcbmltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gJ3V1aWQnO1xuaW1wb3J0IGF4aW9zIGZyb20gJ2F4aW9zJztcblxuLy8gQ29yZSBFbnRpdHkgaW50ZXJmYWNlcyBmb2xsb3dpbmcgb250b2xvZ3lcbmV4cG9ydCBpbnRlcmZhY2UgRW50aXR5IHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICB0eXBlOiBzdHJpbmc7XG4gIHVuaXF1ZUlkZW50aWZpZXI/OiBzdHJpbmc7XG4gIG93bmVyPzogc3RyaW5nO1xuICBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgY3JlYXRlZEF0Pzogc3RyaW5nO1xuICBzdGF0dXM/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRW52aXJvbm1lbnQgZXh0ZW5kcyBFbnRpdHkge1xuICB0eXBlOiAnRW52aXJvbm1lbnQnO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEFwcGxpY2F0aW9uIGV4dGVuZHMgRW50aXR5IHtcbiAgdHlwZTogJ0FwcGxpY2F0aW9uJztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJbnRlZ3JhdGlvbiBleHRlbmRzIEVudGl0eSB7XG4gIHR5cGU6ICdJbnRlZ3JhdGlvbic7XG59XG5cbi8vIENvbmZpZ3VyYXRpb24gaW50ZXJmYWNlcyBmb2xsb3dpbmcgb250b2xvZ3lcbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvbiB7XG4gIGlkOiBzdHJpbmc7XG4gIHR5cGU6IHN0cmluZztcbiAgY29uZmlndXJhdGlvbk1hcD86IHN0cmluZzsgLy8gSlNPTiBzdHJpbmdcbiAgY3JlYXRlZEF0Pzogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEVudmlyb25tZW50Q29uZmlndXJhdGlvbiBleHRlbmRzIENvbmZpZ3VyYXRpb24ge1xuICB0eXBlOiAnRW52aXJvbm1lbnRDb25maWd1cmF0aW9uJztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBBcHBsaWNhdGlvbkNvbmZpZ3VyYXRpb24gZXh0ZW5kcyBDb25maWd1cmF0aW9uIHtcbiAgdHlwZTogJ0FwcGxpY2F0aW9uQ29uZmlndXJhdGlvbic7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSW50ZWdyYXRpb25Db25maWd1cmF0aW9uIGV4dGVuZHMgQ29uZmlndXJhdGlvbiB7XG4gIHR5cGU6ICdJbnRlZ3JhdGlvbkNvbmZpZ3VyYXRpb24nO1xuICBzb3VyY2VTZXJ2aWNlPzogc3RyaW5nO1xuICB0YXJnZXRTZXJ2aWNlPzogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25FbnRyeSB7XG4gIGlkOiBzdHJpbmc7XG4gIGNvbmZpZ3VyYXRpb25LZXk6IHN0cmluZztcbiAgY29uZmlndXJhdGlvblZhbHVlOiBzdHJpbmc7XG4gIGNvbmZpZ3VyYXRpb25UeXBlPzogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE5ldHdvcmtOb2RlIHtcbiAgaWQ6IHN0cmluZztcbiAgbGFiZWw6IHN0cmluZztcbiAgdHlwZTogc3RyaW5nO1xuICBwcm9wZXJ0aWVzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+O1xuICBjb25maWd1cmF0aW9ucz86IFJlY29yZDxzdHJpbmcsIHN0cmluZz47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTmV0d29ya0VkZ2Uge1xuICBpZDogc3RyaW5nO1xuICBzb3VyY2U6IHN0cmluZztcbiAgdGFyZ2V0OiBzdHJpbmc7XG4gIHR5cGU6IHN0cmluZztcbiAgbGFiZWw/OiBzdHJpbmc7XG4gIHByb3BlcnRpZXM6IFJlY29yZDxzdHJpbmcsIGFueT47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTmV0d29ya0RhdGEge1xuICBub2RlczogTmV0d29ya05vZGVbXTtcbiAgZWRnZXM6IE5ldHdvcmtFZGdlW107XG59XG5cbmV4cG9ydCBjbGFzcyBOZXB0dW5lU3BhcnFsQ2xpZW50IHtcbiAgcHJpdmF0ZSBuZXB0dW5lRW5kcG9pbnQ6IHN0cmluZztcbiAgcHJpdmF0ZSByZWdpb246IHN0cmluZztcbiAgcHJpdmF0ZSBjcmVkZW50aWFsczogQXdzQ3JlZGVudGlhbElkZW50aXR5UHJvdmlkZXI7XG4gIHByaXZhdGUgc2lnbmVyOiBTaWduYXR1cmVWNDtcbiAgXG4gIC8vIE9udG9sb2d5IG5hbWVzcGFjZVxuICBwcml2YXRlIHJlYWRvbmx5IG9udG9sb2d5UHJlZml4ID0gJ2h0dHA6Ly9uZXB0dW5lLmF3cy5jb20vZW52bWdtdC9vbnRvbG9neS8nO1xuXG4gIC8qKlxuICAgKiBFeHRyYWN0IFVVSUQgZnJvbSBmdWxsIFVSSSBvciByZXR1cm4gYXMtaXMgaWYgYWxyZWFkeSBhIFVVSURcbiAgICovXG4gIHByaXZhdGUgZXh0cmFjdEVudGl0eUlkKGlkT3JVcmk6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgaWYgKGlkT3JVcmkuc3RhcnRzV2l0aCh0aGlzLm9udG9sb2d5UHJlZml4KSkge1xuICAgICAgcmV0dXJuIGlkT3JVcmkucmVwbGFjZSh0aGlzLm9udG9sb2d5UHJlZml4LCAnJyk7XG4gICAgfVxuICAgIHJldHVybiBpZE9yVXJpO1xuICB9XG5cbiAgY29uc3RydWN0b3IobmVwdHVuZUVuZHBvaW50Pzogc3RyaW5nLCByZWdpb246IHN0cmluZyA9ICd1cy1lYXN0LTEnKSB7XG4gICAgdGhpcy5uZXB0dW5lRW5kcG9pbnQgPSBuZXB0dW5lRW5kcG9pbnQgfHwgcHJvY2Vzcy5lbnYuTkVQVFVORV9FTkRQT0lOVCE7XG4gICAgdGhpcy5yZWdpb24gPSByZWdpb24gfHwgcHJvY2Vzcy5lbnYuQVdTX1JFR0lPTiB8fCAndXMtZWFzdC0xJztcbiAgICBcbiAgICAvLyBVc2UgdGhlIEFXUyBTREsncyBkZWZhdWx0IGNyZWRlbnRpYWwgcHJvdmlkZXIgY2hhaW5cbiAgICB0aGlzLmNyZWRlbnRpYWxzID0gZGVmYXVsdFByb3ZpZGVyKCk7XG4gICAgXG4gICAgdGhpcy5zaWduZXIgPSBuZXcgU2lnbmF0dXJlVjQoe1xuICAgICAgY3JlZGVudGlhbHM6IHRoaXMuY3JlZGVudGlhbHMsXG4gICAgICByZWdpb246IHRoaXMucmVnaW9uLFxuICAgICAgc2VydmljZTogJ25lcHR1bmUtZGInLFxuICAgICAgc2hhMjU2OiBTaGEyNTYsXG4gICAgfSk7XG5cbiAgICBpZiAoIXRoaXMubmVwdHVuZUVuZHBvaW50KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ05lcHR1bmUgZW5kcG9pbnQgaXMgcmVxdWlyZWQuIFNldCBORVBUVU5FX0VORFBPSU5UIGVudmlyb25tZW50IHZhcmlhYmxlIG9yIHBhc3MgYXMgY29uc3RydWN0b3IgcGFyYW1ldGVyLicpO1xuICAgIH1cblxuICAgIC8vIExvZyBjb25maWd1cmF0aW9uIGZvciBkZWJ1Z2dpbmcgKHdpdGhvdXQgc2Vuc2l0aXZlIGluZm8pXG4gICAgY29uc29sZS5sb2coYE5lcHR1bmUgU1BBUlFMIENsaWVudCBpbml0aWFsaXplZDpgKTtcbiAgICBjb25zb2xlLmxvZyhgLSBFbmRwb2ludDogJHt0aGlzLm5lcHR1bmVFbmRwb2ludH1gKTtcbiAgICBjb25zb2xlLmxvZyhgLSBSZWdpb246ICR7dGhpcy5yZWdpb259YCk7XG4gICAgY29uc29sZS5sb2coYC0gU2VydmljZTogbmVwdHVuZS1kYmApO1xuICAgIGNvbnNvbGUubG9nKGAtIElBTSBBdXRoZW50aWNhdGlvbjogZW5hYmxlZGApO1xuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGUgU1BBUlFMIHF1ZXJ5IGFnYWluc3QgTmVwdHVuZSB3aXRoIElBTSBhdXRoZW50aWNhdGlvblxuICAgKi9cbiAgYXN5bmMgZXhlY3V0ZVNwYXJxbFF1ZXJ5KHF1ZXJ5OiBzdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIGNvbnN0IGJvZHkgPSBgcXVlcnk9JHtlbmNvZGVVUklDb21wb25lbnQocXVlcnkpfWA7XG4gICAgXG4gICAgLy8gQ3JlYXRlIHRoZSByZXF1ZXN0IGZvciBzaWduaW5nXG4gICAgY29uc3QgcmVxdWVzdCA9IG5ldyBIdHRwUmVxdWVzdCh7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHByb3RvY29sOiAnaHR0cHM6JyxcbiAgICAgIGhvc3RuYW1lOiB0aGlzLm5lcHR1bmVFbmRwb2ludCxcbiAgICAgIHBvcnQ6IDgxODIsXG4gICAgICBwYXRoOiAnL3NwYXJxbCcsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJyxcbiAgICAgICAgJ0FjY2VwdCc6ICdhcHBsaWNhdGlvbi9zcGFycWwtcmVzdWx0cytqc29uJyxcbiAgICAgICAgJ0hvc3QnOiBgJHt0aGlzLm5lcHR1bmVFbmRwb2ludH06ODE4MmAsXG4gICAgICB9LFxuICAgICAgYm9keSxcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICAvLyBTaWduIHRoZSByZXF1ZXN0IHdpdGggSUFNIGNyZWRlbnRpYWxzXG4gICAgICBjb25zdCBzaWduZWRSZXF1ZXN0ID0gYXdhaXQgdGhpcy5zaWduZXIuc2lnbihyZXF1ZXN0KTtcbiAgICAgIFxuICAgICAgLy8gQ29uc3RydWN0IHRoZSBmdWxsIFVSTFxuICAgICAgY29uc3QgdXJsID0gYGh0dHBzOi8vJHt0aGlzLm5lcHR1bmVFbmRwb2ludH06ODE4Mi9zcGFycWxgO1xuICAgICAgXG4gICAgICBjb25zb2xlLmxvZyhgRXhlY3V0aW5nIFNQQVJRTCBxdWVyeSB0bzogJHt1cmx9YCk7XG4gICAgICBjb25zb2xlLmxvZyhgUXVlcnk6ICR7cXVlcnkuc3Vic3RyaW5nKDAsIDIwMCl9Li4uYCk7XG4gICAgICBcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXhpb3Moe1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgdXJsLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgLi4uc2lnbmVkUmVxdWVzdC5oZWFkZXJzLFxuICAgICAgICAgICdDb250ZW50LUxlbmd0aCc6IGJvZHkubGVuZ3RoLnRvU3RyaW5nKCksXG4gICAgICAgIH0sXG4gICAgICAgIGRhdGE6IGJvZHksXG4gICAgICAgIHRpbWVvdXQ6IDMwMDAwLCAvLyAzMCBzZWNvbmQgdGltZW91dFxuICAgICAgICB2YWxpZGF0ZVN0YXR1czogZnVuY3Rpb24gKHN0YXR1cykge1xuICAgICAgICAgIHJldHVybiBzdGF0dXMgPj0gMjAwICYmIHN0YXR1cyA8IDUwMDsgLy8gQWNjZXB0IDR4eCBlcnJvcnMgZm9yIGJldHRlciBlcnJvciBoYW5kbGluZ1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBOZXB0dW5lIHF1ZXJ5IGZhaWxlZCB3aXRoIHN0YXR1cyAke3Jlc3BvbnNlLnN0YXR1c306ICR7SlNPTi5zdHJpbmdpZnkocmVzcG9uc2UuZGF0YSl9YCk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdTUEFSUUwgcXVlcnkgZXJyb3I6JywgZXJyb3IpO1xuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGUgU1BBUlFMIHVwZGF0ZSBhZ2FpbnN0IE5lcHR1bmUgd2l0aCBJQU0gYXV0aGVudGljYXRpb25cbiAgICovXG4gIGFzeW5jIGV4ZWN1dGVTcGFycWxVcGRhdGUodXBkYXRlOiBzdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIGNvbnN0IGJvZHkgPSBgdXBkYXRlPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHVwZGF0ZSl9YDtcbiAgICBcbiAgICAvLyBDcmVhdGUgdGhlIHJlcXVlc3QgZm9yIHNpZ25pbmdcbiAgICBjb25zdCByZXF1ZXN0ID0gbmV3IEh0dHBSZXF1ZXN0KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgcHJvdG9jb2w6ICdodHRwczonLFxuICAgICAgaG9zdG5hbWU6IHRoaXMubmVwdHVuZUVuZHBvaW50LFxuICAgICAgcG9ydDogODE4MixcbiAgICAgIHBhdGg6ICcvc3BhcnFsJyxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQnLFxuICAgICAgICAnQWNjZXB0JzogJ2FwcGxpY2F0aW9uL3NwYXJxbC1yZXN1bHRzK2pzb24nLFxuICAgICAgICAnSG9zdCc6IGAke3RoaXMubmVwdHVuZUVuZHBvaW50fTo4MTgyYCxcbiAgICAgIH0sXG4gICAgICBib2R5LFxuICAgIH0pO1xuXG4gICAgdHJ5IHtcbiAgICAgIC8vIFNpZ24gdGhlIHJlcXVlc3Qgd2l0aCBJQU0gY3JlZGVudGlhbHNcbiAgICAgIGNvbnN0IHNpZ25lZFJlcXVlc3QgPSBhd2FpdCB0aGlzLnNpZ25lci5zaWduKHJlcXVlc3QpO1xuICAgICAgXG4gICAgICAvLyBDb25zdHJ1Y3QgdGhlIGZ1bGwgVVJMXG4gICAgICBjb25zdCB1cmwgPSBgaHR0cHM6Ly8ke3RoaXMubmVwdHVuZUVuZHBvaW50fTo4MTgyL3NwYXJxbGA7XG4gICAgICBcbiAgICAgIGNvbnNvbGUubG9nKGBFeGVjdXRpbmcgU1BBUlFMIHVwZGF0ZSB0bzogJHt1cmx9YCk7XG4gICAgICBjb25zb2xlLmxvZyhgVXBkYXRlOiAke3VwZGF0ZS5zdWJzdHJpbmcoMCwgMjAwKX0uLi5gKTtcbiAgICAgIFxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBheGlvcyh7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICB1cmwsXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAuLi5zaWduZWRSZXF1ZXN0LmhlYWRlcnMsXG4gICAgICAgICAgJ0NvbnRlbnQtTGVuZ3RoJzogYm9keS5sZW5ndGgudG9TdHJpbmcoKSxcbiAgICAgICAgfSxcbiAgICAgICAgZGF0YTogYm9keSxcbiAgICAgICAgdGltZW91dDogMzAwMDAsIC8vIDMwIHNlY29uZCB0aW1lb3V0XG4gICAgICAgIHZhbGlkYXRlU3RhdHVzOiBmdW5jdGlvbiAoc3RhdHVzKSB7XG4gICAgICAgICAgcmV0dXJuIHN0YXR1cyA+PSAyMDAgJiYgc3RhdHVzIDwgNTAwOyAvLyBBY2NlcHQgNHh4IGVycm9ycyBmb3IgYmV0dGVyIGVycm9yIGhhbmRsaW5nXG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID49IDQwMCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE5lcHR1bmUgdXBkYXRlIGZhaWxlZCB3aXRoIHN0YXR1cyAke3Jlc3BvbnNlLnN0YXR1c306ICR7SlNPTi5zdHJpbmdpZnkocmVzcG9uc2UuZGF0YSl9YCk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdTUEFSUUwgdXBkYXRlIGVycm9yOicsIGVycm9yKTtcbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBIZWFsdGggY2hlY2sgZm9yIE5lcHR1bmUgY2x1c3RlclxuICAgKi9cbiAgYXN5bmMgaGVhbHRoQ2hlY2soKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICBBU0sgeyBcbiAgICAgICAgICA/cyA/cCA/byBcbiAgICAgICAgfVxuICAgICAgYDtcbiAgICAgIFxuICAgICAgYXdhaXQgdGhpcy5leGVjdXRlU3BhcnFsUXVlcnkocXVlcnkpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0hlYWx0aCBjaGVjayBmYWlsZWQ6JywgZXJyb3IpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgRW52aXJvbm1lbnQgdXNpbmcgU1BBUlFMIGZvbGxvd2luZyBvbnRvbG9neVxuICAgKi9cbiAgYXN5bmMgY3JlYXRlRW52aXJvbm1lbnQoZW52aXJvbm1lbnQ6IE9taXQ8RW52aXJvbm1lbnQsICdpZCc+KTogUHJvbWlzZTxFbnZpcm9ubWVudD4ge1xuICAgIGNvbnN0IGlkID0gdXVpZHY0KCk7XG4gICAgY29uc3QgdGltZXN0YW1wID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGNvbnN0IGVudGl0eTogRW52aXJvbm1lbnQgPSB7IFxuICAgICAgLi4uZW52aXJvbm1lbnQsIFxuICAgICAgaWQsIFxuICAgICAgdHlwZTogJ0Vudmlyb25tZW50JyxcbiAgICAgIGNyZWF0ZWRBdDogdGltZXN0YW1wXG4gICAgfTtcbiAgICBcbiAgICBjb25zdCB1cGRhdGUgPSBgXG4gICAgICBQUkVGSVggcmRmOiA8aHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIz5cbiAgICAgIFBSRUZJWCByZGZzOiA8aHR0cDovL3d3dy53My5vcmcvMjAwMC8wMS9yZGYtc2NoZW1hIz5cbiAgICAgIFBSRUZJWCBlbnY6IDwke3RoaXMub250b2xvZ3lQcmVmaXh9PlxuICAgICAgUFJFRklYIHhzZDogPGh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIz5cbiAgICAgIFxuICAgICAgSU5TRVJUIERBVEEge1xuICAgICAgICBlbnY6JHtpZH0gcmRmOnR5cGUgZW52OkVudmlyb25tZW50IDtcbiAgICAgICAgICAgICAgICAgIGVudjppZCBcIiR7ZW50aXR5LmlkfVwiIDtcbiAgICAgICAgICAgICAgICAgIGVudjpuYW1lIFwiJHtlbnRpdHkubmFtZX1cIiA7XG4gICAgICAgICAgICAgICAgICBlbnY6dHlwZSBcIiR7ZW50aXR5LnR5cGV9XCIgO1xuICAgICAgICAgICAgICAgICAgZW52OmNyZWF0ZWRBdCBcIiR7dGltZXN0YW1wfVwiXl54c2Q6ZGF0ZVRpbWUgO1xuICAgICAgICAgICAgICAgICAgJHtlbnRpdHkudW5pcXVlSWRlbnRpZmllciA/IGBlbnY6dW5pcXVlSWRlbnRpZmllciBcIiR7ZW50aXR5LnVuaXF1ZUlkZW50aWZpZXJ9XCIgO2AgOiAnJ31cbiAgICAgICAgICAgICAgICAgICR7ZW50aXR5Lm93bmVyID8gYGVudjpvd25lciBcIiR7ZW50aXR5Lm93bmVyfVwiIDtgIDogJyd9XG4gICAgICAgICAgICAgICAgICAke2VudGl0eS5zdGF0dXMgPyBgZW52OnN0YXR1cyBcIiR7ZW50aXR5LnN0YXR1c31cIiA7YCA6ICcnfVxuICAgICAgICAgICAgICAgICAgZW52OmRlc2NyaXB0aW9uIFwiJHtlbnRpdHkuZGVzY3JpcHRpb24gfHwgJyd9XCIgLlxuICAgICAgfVxuICAgIGA7XG4gICAgXG4gICAgYXdhaXQgdGhpcy5leGVjdXRlU3BhcnFsVXBkYXRlKHVwZGF0ZSk7XG4gICAgcmV0dXJuIGVudGl0eTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgQXBwbGljYXRpb24gdXNpbmcgU1BBUlFMIGZvbGxvd2luZyBvbnRvbG9neVxuICAgKi9cbiAgYXN5bmMgY3JlYXRlQXBwbGljYXRpb24oYXBwbGljYXRpb246IE9taXQ8QXBwbGljYXRpb24sICdpZCc+KTogUHJvbWlzZTxBcHBsaWNhdGlvbj4ge1xuICAgIGNvbnN0IGlkID0gdXVpZHY0KCk7XG4gICAgY29uc3QgdGltZXN0YW1wID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGNvbnN0IGVudGl0eTogQXBwbGljYXRpb24gPSB7IFxuICAgICAgLi4uYXBwbGljYXRpb24sIFxuICAgICAgaWQsIFxuICAgICAgdHlwZTogJ0FwcGxpY2F0aW9uJyxcbiAgICAgIGNyZWF0ZWRBdDogdGltZXN0YW1wXG4gICAgfTtcbiAgICBcbiAgICBjb25zdCB1cGRhdGUgPSBgXG4gICAgICBQUkVGSVggcmRmOiA8aHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIz5cbiAgICAgIFBSRUZJWCByZGZzOiA8aHR0cDovL3d3dy53My5vcmcvMjAwMC8wMS9yZGYtc2NoZW1hIz5cbiAgICAgIFBSRUZJWCBlbnY6IDwke3RoaXMub250b2xvZ3lQcmVmaXh9PlxuICAgICAgUFJFRklYIHhzZDogPGh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIz5cbiAgICAgIFxuICAgICAgSU5TRVJUIERBVEEge1xuICAgICAgICBlbnY6JHtpZH0gcmRmOnR5cGUgZW52OkFwcGxpY2F0aW9uIDtcbiAgICAgICAgICAgICAgICAgIGVudjppZCBcIiR7ZW50aXR5LmlkfVwiIDtcbiAgICAgICAgICAgICAgICAgIGVudjpuYW1lIFwiJHtlbnRpdHkubmFtZX1cIiA7XG4gICAgICAgICAgICAgICAgICBlbnY6dHlwZSBcIiR7ZW50aXR5LnR5cGV9XCIgO1xuICAgICAgICAgICAgICAgICAgZW52OmNyZWF0ZWRBdCBcIiR7dGltZXN0YW1wfVwiXl54c2Q6ZGF0ZVRpbWUgO1xuICAgICAgICAgICAgICAgICAgJHtlbnRpdHkudW5pcXVlSWRlbnRpZmllciA/IGBlbnY6dW5pcXVlSWRlbnRpZmllciBcIiR7ZW50aXR5LnVuaXF1ZUlkZW50aWZpZXJ9XCIgO2AgOiAnJ31cbiAgICAgICAgICAgICAgICAgICR7ZW50aXR5Lm93bmVyID8gYGVudjpvd25lciBcIiR7ZW50aXR5Lm93bmVyfVwiIDtgIDogJyd9XG4gICAgICAgICAgICAgICAgICAke2VudGl0eS5zdGF0dXMgPyBgZW52OnN0YXR1cyBcIiR7ZW50aXR5LnN0YXR1c31cIiA7YCA6ICcnfVxuICAgICAgICAgICAgICAgICAgZW52OmRlc2NyaXB0aW9uIFwiJHtlbnRpdHkuZGVzY3JpcHRpb24gfHwgJyd9XCIgLlxuICAgICAgfVxuICAgIGA7XG4gICAgXG4gICAgYXdhaXQgdGhpcy5leGVjdXRlU3BhcnFsVXBkYXRlKHVwZGF0ZSk7XG4gICAgcmV0dXJuIGVudGl0eTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgSW50ZWdyYXRpb24gdXNpbmcgU1BBUlFMIGZvbGxvd2luZyBvbnRvbG9neVxuICAgKi9cbiAgYXN5bmMgY3JlYXRlSW50ZWdyYXRpb24oaW50ZWdyYXRpb246IE9taXQ8SW50ZWdyYXRpb24sICdpZCc+KTogUHJvbWlzZTxJbnRlZ3JhdGlvbj4ge1xuICAgIGNvbnN0IGlkID0gdXVpZHY0KCk7XG4gICAgY29uc3QgdGltZXN0YW1wID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGNvbnN0IGVudGl0eTogSW50ZWdyYXRpb24gPSB7IFxuICAgICAgLi4uaW50ZWdyYXRpb24sIFxuICAgICAgaWQsIFxuICAgICAgdHlwZTogJ0ludGVncmF0aW9uJyxcbiAgICAgIGNyZWF0ZWRBdDogdGltZXN0YW1wXG4gICAgfTtcbiAgICBcbiAgICBjb25zdCB1cGRhdGUgPSBgXG4gICAgICBQUkVGSVggcmRmOiA8aHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIz5cbiAgICAgIFBSRUZJWCByZGZzOiA8aHR0cDovL3d3dy53My5vcmcvMjAwMC8wMS9yZGYtc2NoZW1hIz5cbiAgICAgIFBSRUZJWCBlbnY6IDwke3RoaXMub250b2xvZ3lQcmVmaXh9PlxuICAgICAgUFJFRklYIHhzZDogPGh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIz5cbiAgICAgIFxuICAgICAgSU5TRVJUIERBVEEge1xuICAgICAgICBlbnY6JHtpZH0gcmRmOnR5cGUgZW52OkludGVncmF0aW9uIDtcbiAgICAgICAgICAgICAgICAgIGVudjppZCBcIiR7ZW50aXR5LmlkfVwiIDtcbiAgICAgICAgICAgICAgICAgIGVudjpuYW1lIFwiJHtlbnRpdHkubmFtZX1cIiA7XG4gICAgICAgICAgICAgICAgICBlbnY6dHlwZSBcIiR7ZW50aXR5LnR5cGV9XCIgO1xuICAgICAgICAgICAgICAgICAgZW52OmNyZWF0ZWRBdCBcIiR7dGltZXN0YW1wfVwiXl54c2Q6ZGF0ZVRpbWUgO1xuICAgICAgICAgICAgICAgICAgJHtlbnRpdHkudW5pcXVlSWRlbnRpZmllciA/IGBlbnY6dW5pcXVlSWRlbnRpZmllciBcIiR7ZW50aXR5LnVuaXF1ZUlkZW50aWZpZXJ9XCIgO2AgOiAnJ31cbiAgICAgICAgICAgICAgICAgICR7ZW50aXR5Lm93bmVyID8gYGVudjpvd25lciBcIiR7ZW50aXR5Lm93bmVyfVwiIDtgIDogJyd9XG4gICAgICAgICAgICAgICAgICAke2VudGl0eS5zdGF0dXMgPyBgZW52OnN0YXR1cyBcIiR7ZW50aXR5LnN0YXR1c31cIiA7YCA6ICcnfVxuICAgICAgICAgICAgICAgICAgZW52OmRlc2NyaXB0aW9uIFwiJHtlbnRpdHkuZGVzY3JpcHRpb24gfHwgJyd9XCIgLlxuICAgICAgfVxuICAgIGA7XG4gICAgXG4gICAgYXdhaXQgdGhpcy5leGVjdXRlU3BhcnFsVXBkYXRlKHVwZGF0ZSk7XG4gICAgcmV0dXJuIGVudGl0eTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgRW52aXJvbm1lbnQgQ29uZmlndXJhdGlvbiB1c2luZyBTUEFSUUxcbiAgICovXG4gIGFzeW5jIGNyZWF0ZUVudmlyb25tZW50Q29uZmlndXJhdGlvbihjb25maWc6IE9taXQ8RW52aXJvbm1lbnRDb25maWd1cmF0aW9uLCAnaWQnPiwgZW52aXJvbm1lbnRJZDogc3RyaW5nKTogUHJvbWlzZTxFbnZpcm9ubWVudENvbmZpZ3VyYXRpb24+IHtcbiAgICBjb25zdCBpZCA9IHV1aWR2NCgpO1xuICAgIGNvbnN0IHRpbWVzdGFtcCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICBjb25zdCBlbnRpdHk6IEVudmlyb25tZW50Q29uZmlndXJhdGlvbiA9IHsgXG4gICAgICAuLi5jb25maWcsIFxuICAgICAgaWQsIFxuICAgICAgdHlwZTogJ0Vudmlyb25tZW50Q29uZmlndXJhdGlvbicsXG4gICAgICBjcmVhdGVkQXQ6IHRpbWVzdGFtcFxuICAgIH07XG4gICAgXG4gICAgY29uc3QgdXBkYXRlID0gYFxuICAgICAgUFJFRklYIHJkZjogPGh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyM+XG4gICAgICBQUkVGSVggZW52OiA8JHt0aGlzLm9udG9sb2d5UHJlZml4fT5cbiAgICAgIFBSRUZJWCB4c2Q6IDxodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSM+XG4gICAgICBcbiAgICAgIElOU0VSVCBEQVRBIHtcbiAgICAgICAgZW52OiR7aWR9IHJkZjp0eXBlIGVudjpFbnZpcm9ubWVudENvbmZpZ3VyYXRpb24gO1xuICAgICAgICAgICAgICAgICAgZW52OmlkIFwiJHtlbnRpdHkuaWR9XCIgO1xuICAgICAgICAgICAgICAgICAgZW52OnR5cGUgXCIke2VudGl0eS50eXBlfVwiIDtcbiAgICAgICAgICAgICAgICAgIGVudjpjcmVhdGVkQXQgXCIke3RpbWVzdGFtcH1cIl5eeHNkOmRhdGVUaW1lIDtcbiAgICAgICAgICAgICAgICAgICR7ZW50aXR5LmNvbmZpZ3VyYXRpb25NYXAgPyBgZW52OmNvbmZpZ3VyYXRpb25NYXAgXCIke2VudGl0eS5jb25maWd1cmF0aW9uTWFwfVwiIDtgIDogJyd9XG4gICAgICAgICAgICAgICAgICByZGY6dHlwZSBlbnY6Q29uZmlndXJhdGlvbiAuXG4gICAgICAgICAgICAgICAgICBcbiAgICAgICAgZW52OiR7ZW52aXJvbm1lbnRJZH0gZW52Omhhc0Vudmlyb25tZW50Q29uZmlnIGVudjoke2lkfSAuXG4gICAgICB9XG4gICAgYDtcbiAgICBcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVTcGFycWxVcGRhdGUodXBkYXRlKTtcbiAgICByZXR1cm4gZW50aXR5O1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBBcHBsaWNhdGlvbiBDb25maWd1cmF0aW9uIHVzaW5nIFNQQVJRTFxuICAgKi9cbiAgYXN5bmMgY3JlYXRlQXBwbGljYXRpb25Db25maWd1cmF0aW9uKGNvbmZpZzogT21pdDxBcHBsaWNhdGlvbkNvbmZpZ3VyYXRpb24sICdpZCc+LCBhcHBsaWNhdGlvbklkOiBzdHJpbmcpOiBQcm9taXNlPEFwcGxpY2F0aW9uQ29uZmlndXJhdGlvbj4ge1xuICAgIGNvbnN0IGlkID0gdXVpZHY0KCk7XG4gICAgY29uc3QgdGltZXN0YW1wID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGNvbnN0IGVudGl0eTogQXBwbGljYXRpb25Db25maWd1cmF0aW9uID0geyBcbiAgICAgIC4uLmNvbmZpZywgXG4gICAgICBpZCwgXG4gICAgICB0eXBlOiAnQXBwbGljYXRpb25Db25maWd1cmF0aW9uJyxcbiAgICAgIGNyZWF0ZWRBdDogdGltZXN0YW1wXG4gICAgfTtcbiAgICBcbiAgICBjb25zdCB1cGRhdGUgPSBgXG4gICAgICBQUkVGSVggcmRmOiA8aHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIz5cbiAgICAgIFBSRUZJWCBlbnY6IDwke3RoaXMub250b2xvZ3lQcmVmaXh9PlxuICAgICAgUFJFRklYIHhzZDogPGh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIz5cbiAgICAgIFxuICAgICAgSU5TRVJUIERBVEEge1xuICAgICAgICBlbnY6JHtpZH0gcmRmOnR5cGUgZW52OkFwcGxpY2F0aW9uQ29uZmlndXJhdGlvbiA7XG4gICAgICAgICAgICAgICAgICBlbnY6aWQgXCIke2VudGl0eS5pZH1cIiA7XG4gICAgICAgICAgICAgICAgICBlbnY6dHlwZSBcIiR7ZW50aXR5LnR5cGV9XCIgO1xuICAgICAgICAgICAgICAgICAgZW52OmNyZWF0ZWRBdCBcIiR7dGltZXN0YW1wfVwiXl54c2Q6ZGF0ZVRpbWUgO1xuICAgICAgICAgICAgICAgICAgJHtlbnRpdHkuY29uZmlndXJhdGlvbk1hcCA/IGBlbnY6Y29uZmlndXJhdGlvbk1hcCBcIiR7ZW50aXR5LmNvbmZpZ3VyYXRpb25NYXB9XCIgO2AgOiAnJ31cbiAgICAgICAgICAgICAgICAgIHJkZjp0eXBlIGVudjpDb25maWd1cmF0aW9uIC5cbiAgICAgICAgICAgICAgICAgIFxuICAgICAgICBlbnY6JHthcHBsaWNhdGlvbklkfSBlbnY6aGFzQXBwbGljYXRpb25Db25maWcgZW52OiR7aWR9IC5cbiAgICAgIH1cbiAgICBgO1xuICAgIFxuICAgIGF3YWl0IHRoaXMuZXhlY3V0ZVNwYXJxbFVwZGF0ZSh1cGRhdGUpO1xuICAgIHJldHVybiBlbnRpdHk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIEludGVncmF0aW9uIENvbmZpZ3VyYXRpb24gdXNpbmcgU1BBUlFMXG4gICAqL1xuICBhc3luYyBjcmVhdGVJbnRlZ3JhdGlvbkNvbmZpZ3VyYXRpb24oY29uZmlnOiBPbWl0PEludGVncmF0aW9uQ29uZmlndXJhdGlvbiwgJ2lkJz4sIGludGVncmF0aW9uSWQ6IHN0cmluZyk6IFByb21pc2U8SW50ZWdyYXRpb25Db25maWd1cmF0aW9uPiB7XG4gICAgY29uc3QgaWQgPSB1dWlkdjQoKTtcbiAgICBjb25zdCB0aW1lc3RhbXAgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgY29uc3QgZW50aXR5OiBJbnRlZ3JhdGlvbkNvbmZpZ3VyYXRpb24gPSB7IFxuICAgICAgLi4uY29uZmlnLCBcbiAgICAgIGlkLCBcbiAgICAgIHR5cGU6ICdJbnRlZ3JhdGlvbkNvbmZpZ3VyYXRpb24nLFxuICAgICAgY3JlYXRlZEF0OiB0aW1lc3RhbXBcbiAgICB9O1xuICAgIFxuICAgIGNvbnN0IHVwZGF0ZSA9IGBcbiAgICAgIFBSRUZJWCByZGY6IDxodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjPlxuICAgICAgUFJFRklYIGVudjogPCR7dGhpcy5vbnRvbG9neVByZWZpeH0+XG4gICAgICBQUkVGSVggeHNkOiA8aHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEjPlxuICAgICAgXG4gICAgICBJTlNFUlQgREFUQSB7XG4gICAgICAgIGVudjoke2lkfSByZGY6dHlwZSBlbnY6SW50ZWdyYXRpb25Db25maWd1cmF0aW9uIDtcbiAgICAgICAgICAgICAgICAgIGVudjppZCBcIiR7ZW50aXR5LmlkfVwiIDtcbiAgICAgICAgICAgICAgICAgIGVudjp0eXBlIFwiJHtlbnRpdHkudHlwZX1cIiA7XG4gICAgICAgICAgICAgICAgICBlbnY6Y3JlYXRlZEF0IFwiJHt0aW1lc3RhbXB9XCJeXnhzZDpkYXRlVGltZSA7XG4gICAgICAgICAgICAgICAgICAke2VudGl0eS5jb25maWd1cmF0aW9uTWFwID8gYGVudjpjb25maWd1cmF0aW9uTWFwIFwiJHtlbnRpdHkuY29uZmlndXJhdGlvbk1hcH1cIiA7YCA6ICcnfVxuICAgICAgICAgICAgICAgICAgJHtlbnRpdHkuc291cmNlU2VydmljZSA/IGBlbnY6c291cmNlU2VydmljZSBcIiR7ZW50aXR5LnNvdXJjZVNlcnZpY2V9XCIgO2AgOiAnJ31cbiAgICAgICAgICAgICAgICAgICR7ZW50aXR5LnRhcmdldFNlcnZpY2UgPyBgZW52OnRhcmdldFNlcnZpY2UgXCIke2VudGl0eS50YXJnZXRTZXJ2aWNlfVwiIDtgIDogJyd9XG4gICAgICAgICAgICAgICAgICByZGY6dHlwZSBlbnY6Q29uZmlndXJhdGlvbiAuXG4gICAgICAgICAgICAgICAgICBcbiAgICAgICAgZW52OiR7aW50ZWdyYXRpb25JZH0gZW52Omhhc0ludGVncmF0aW9uQ29uZmlnIGVudjoke2lkfSAuXG4gICAgICB9XG4gICAgYDtcbiAgICBcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVTcGFycWxVcGRhdGUodXBkYXRlKTtcbiAgICByZXR1cm4gZW50aXR5O1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBDb25maWd1cmF0aW9uIEVudHJ5IHVzaW5nIFNQQVJRTFxuICAgKi9cbiAgYXN5bmMgY3JlYXRlQ29uZmlndXJhdGlvbkVudHJ5KGVudHJ5OiBPbWl0PENvbmZpZ3VyYXRpb25FbnRyeSwgJ2lkJz4sIGNvbmZpZ3VyYXRpb25JZDogc3RyaW5nKTogUHJvbWlzZTxDb25maWd1cmF0aW9uRW50cnk+IHtcbiAgICBjb25zdCBpZCA9IHV1aWR2NCgpO1xuICAgIGNvbnN0IGVudGl0eTogQ29uZmlndXJhdGlvbkVudHJ5ID0geyAuLi5lbnRyeSwgaWQgfTtcbiAgICBcbiAgICBjb25zdCB1cGRhdGUgPSBgXG4gICAgICBQUkVGSVggcmRmOiA8aHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIz5cbiAgICAgIFBSRUZJWCBlbnY6IDwke3RoaXMub250b2xvZ3lQcmVmaXh9PlxuICAgICAgXG4gICAgICBJTlNFUlQgREFUQSB7XG4gICAgICAgIGVudjoke2lkfSByZGY6dHlwZSBlbnY6Q29uZmlndXJhdGlvbkVudHJ5IDtcbiAgICAgICAgICAgICAgICAgIGVudjppZCBcIiR7ZW50aXR5LmlkfVwiIDtcbiAgICAgICAgICAgICAgICAgIGVudjpjb25maWd1cmF0aW9uS2V5IFwiJHtlbnRpdHkuY29uZmlndXJhdGlvbktleX1cIiA7XG4gICAgICAgICAgICAgICAgICBlbnY6Y29uZmlndXJhdGlvblZhbHVlIFwiJHtlbnRpdHkuY29uZmlndXJhdGlvblZhbHVlfVwiIDtcbiAgICAgICAgICAgICAgICAgICR7ZW50aXR5LmNvbmZpZ3VyYXRpb25UeXBlID8gYGVudjpjb25maWd1cmF0aW9uVHlwZSBcIiR7ZW50aXR5LmNvbmZpZ3VyYXRpb25UeXBlfVwiIDtgIDogJyd9XG4gICAgICAgICAgICAgICAgICByZGY6dHlwZSBlbnY6Q29uZmlndXJhdGlvbkVudHJ5IC5cbiAgICAgICAgICAgICAgICAgIFxuICAgICAgICBlbnY6JHtjb25maWd1cmF0aW9uSWR9IGVudjpoYXNDb25maWd1cmF0aW9uRW50cnkgZW52OiR7aWR9IC5cbiAgICAgIH1cbiAgICBgO1xuICAgIFxuICAgIGF3YWl0IHRoaXMuZXhlY3V0ZVNwYXJxbFVwZGF0ZSh1cGRhdGUpO1xuICAgIHJldHVybiBlbnRpdHk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IGFsbCBlbnRpdGllcyBieSB0eXBlIGZvbGxvd2luZyBvbnRvbG9neVxuICAgKi9cbiAgYXN5bmMgZ2V0RW50aXRpZXNCeVR5cGUoZW50aXR5VHlwZTogc3RyaW5nKTogUHJvbWlzZTxFbnRpdHlbXT4ge1xuICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgUFJFRklYIHJkZjogPGh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyM+XG4gICAgICBQUkVGSVggZW52OiA8JHt0aGlzLm9udG9sb2d5UHJlZml4fT5cbiAgICAgIFxuICAgICAgU0VMRUNUID9pZCA/bmFtZSA/dW5pcXVlSWRlbnRpZmllciA/b3duZXIgP2Rlc2NyaXB0aW9uID9jcmVhdGVkQXQgP3N0YXR1cyBXSEVSRSB7XG4gICAgICAgID9lbnRpdHkgcmRmOnR5cGUgZW52OiR7ZW50aXR5VHlwZX0gO1xuICAgICAgICAgICAgICAgIGVudjppZCA/aWQgO1xuICAgICAgICAgICAgICAgIGVudjpuYW1lID9uYW1lIDtcbiAgICAgICAgICAgICAgICBlbnY6dHlwZSA/dHlwZSA7XG4gICAgICAgICAgICAgICAgZW52OmRlc2NyaXB0aW9uID9kZXNjcmlwdGlvbiAuXG4gICAgICAgIE9QVElPTkFMIHsgP2VudGl0eSBlbnY6dW5pcXVlSWRlbnRpZmllciA/dW5pcXVlSWRlbnRpZmllciB9XG4gICAgICAgIE9QVElPTkFMIHsgP2VudGl0eSBlbnY6b3duZXIgP293bmVyIH1cbiAgICAgICAgT1BUSU9OQUwgeyA/ZW50aXR5IGVudjpjcmVhdGVkQXQgP2NyZWF0ZWRBdCB9XG4gICAgICAgIE9QVElPTkFMIHsgP2VudGl0eSBlbnY6c3RhdHVzID9zdGF0dXMgfVxuICAgICAgfVxuICAgIGA7XG4gICAgXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5leGVjdXRlU3BhcnFsUXVlcnkocXVlcnkpO1xuICAgIFxuICAgIHJldHVybiByZXN1bHQucmVzdWx0cz8uYmluZGluZ3M/Lm1hcCgoYmluZGluZzogYW55KSA9PiAoe1xuICAgICAgaWQ6IGJpbmRpbmcuaWQ/LnZhbHVlIHx8ICcnLFxuICAgICAgbmFtZTogYmluZGluZy5uYW1lPy52YWx1ZSB8fCAnJyxcbiAgICAgIHR5cGU6IGVudGl0eVR5cGUsXG4gICAgICB1bmlxdWVJZGVudGlmaWVyOiBiaW5kaW5nLnVuaXF1ZUlkZW50aWZpZXI/LnZhbHVlLFxuICAgICAgb3duZXI6IGJpbmRpbmcub3duZXI/LnZhbHVlLFxuICAgICAgZGVzY3JpcHRpb246IGJpbmRpbmcuZGVzY3JpcHRpb24/LnZhbHVlIHx8ICcnLFxuICAgICAgY3JlYXRlZEF0OiBiaW5kaW5nLmNyZWF0ZWRBdD8udmFsdWUsXG4gICAgICBzdGF0dXM6IGJpbmRpbmcuc3RhdHVzPy52YWx1ZSxcbiAgICB9KSkgfHwgW107XG4gIH1cblxuICAvKipcbiAgICogR2V0IG5ldHdvcmsgZGF0YSBmb3IgdmlzdWFsaXphdGlvbiBmb2xsb3dpbmcgb250b2xvZ3lcbiAgICovXG4gIGFzeW5jIGdldE5ldHdvcmtEYXRhKCk6IFByb21pc2U8TmV0d29ya0RhdGE+IHtcbiAgICAvLyBHZXQgYWxsIG5vZGVzIHdpdGggQUxMIHRoZWlyIHByb3BlcnRpZXMgKGluY2x1ZGluZyBjb25maWdfKiBwcm9wZXJ0aWVzKVxuICAgIGNvbnN0IG5vZGVzUXVlcnkgPSBgXG4gICAgICBQUkVGSVggcmRmOiA8aHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIz5cbiAgICAgIFBSRUZJWCBlbnY6IDwke3RoaXMub250b2xvZ3lQcmVmaXh9PlxuICAgICAgXG4gICAgICBTRUxFQ1QgP2lkID9uYW1lID90eXBlID9zdGF0dXMgP293bmVyID9wcm9wZXJ0eSA/dmFsdWUgV0hFUkUge1xuICAgICAgICA/ZW50aXR5IGVudjppZCA/aWQgO1xuICAgICAgICAgICAgICAgIGVudjpuYW1lID9uYW1lIDtcbiAgICAgICAgICAgICAgICBlbnY6dHlwZSA/dHlwZSAuXG4gICAgICAgIE9QVElPTkFMIHsgP2VudGl0eSBlbnY6c3RhdHVzID9zdGF0dXMgfVxuICAgICAgICBPUFRJT05BTCB7ID9lbnRpdHkgZW52Om93bmVyID9vd25lciB9XG4gICAgICAgIE9QVElPTkFMIHsgXG4gICAgICAgICAgP2VudGl0eSA/cHJvcGVydHkgP3ZhbHVlIC5cbiAgICAgICAgICBGSUxURVIoU1RSU1RBUlRTKFNUUig/cHJvcGVydHkpLCBcIiR7dGhpcy5vbnRvbG9neVByZWZpeH1cIikpXG4gICAgICAgICAgRklMVEVSKD9wcm9wZXJ0eSBOT1QgSU4gKGVudjppZCwgZW52Om5hbWUsIGVudjp0eXBlKSlcbiAgICAgICAgfVxuICAgICAgICBGSUxURVIoP3R5cGUgSU4gKFwiRW52aXJvbm1lbnRcIiwgXCJBcHBsaWNhdGlvblwiLCBcIkludGVncmF0aW9uXCIpKVxuICAgICAgfVxuICAgIGA7XG5cbiAgICAvLyBHZXQgYWxsIGVkZ2VzIC0gYm90aCBkaXJlY3QgcHJlZGljYXRlcyBhbmQgcmVsYXRpb25zaGlwIGVudGl0aWVzXG4gICAgY29uc3QgZWRnZXNRdWVyeSA9IGBcbiAgICAgIFBSRUZJWCByZGY6IDxodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjPlxuICAgICAgUFJFRklYIGVudjogPCR7dGhpcy5vbnRvbG9neVByZWZpeH0+XG4gICAgICBcbiAgICAgIFNFTEVDVCA/c291cmNlSWQgP3RhcmdldElkID9yZWxhdGlvblR5cGUgP3JlbGF0aW9uTGFiZWwgV0hFUkUge1xuICAgICAgICB7XG4gICAgICAgICAgIyBEaXJlY3QgcHJlZGljYXRlIHJlbGF0aW9uc2hpcHMgKGxpa2UgeW91ciBDQVNfUUEgaW50ZWdyYXRlcyBQQVNRQTMwNClcbiAgICAgICAgICA/c291cmNlRW50aXR5ID9wcmVkaWNhdGUgP3RhcmdldEVudGl0eSAuXG4gICAgICAgICAgP3NvdXJjZUVudGl0eSBlbnY6bmFtZSA/c291cmNlTmFtZSAuXG4gICAgICAgICAgP3RhcmdldEVudGl0eSBlbnY6bmFtZSA/dGFyZ2V0TmFtZSAuXG4gICAgICAgICAgP3NvdXJjZUVudGl0eSBlbnY6aWQgP3NvdXJjZUlkIC5cbiAgICAgICAgICA/dGFyZ2V0RW50aXR5IGVudjppZCA/dGFyZ2V0SWQgLlxuICAgICAgICAgIEZJTFRFUihTVFJTVEFSVFMoU1RSKD9wcmVkaWNhdGUpLCBcIiR7dGhpcy5vbnRvbG9neVByZWZpeH1cIikpXG4gICAgICAgICAgRklMVEVSKD9wcmVkaWNhdGUgTk9UIElOIChlbnY6aWQsIGVudjpuYW1lLCBlbnY6dHlwZSwgZW52OmRlc2NyaXB0aW9uLCBlbnY6b3duZXIsIGVudjpzdGF0dXMsIGVudjpjcmVhdGVkQXQsIGVudjp1bmlxdWVJZGVudGlmaWVyLCBlbnY6dmVyc2lvbiwgZW52OmVuZHBvaW50LCBlbnY6cmVnaW9uLCBlbnY6c291cmNlU2VydmljZSwgZW52OnRhcmdldFNlcnZpY2UpKVxuICAgICAgICAgIEJJTkQoU1RSQUZURVIoU1RSKD9wcmVkaWNhdGUpLCBcIiR7dGhpcy5vbnRvbG9neVByZWZpeH1cIikgQVMgP3JlbGF0aW9uVHlwZSlcbiAgICAgICAgICBCSU5EKD9yZWxhdGlvblR5cGUgQVMgP3JlbGF0aW9uTGFiZWwpXG4gICAgICAgIH1cbiAgICAgICAgVU5JT05cbiAgICAgICAge1xuICAgICAgICAgICMgUmVsYXRpb25zaGlwIGVudGl0aWVzXG4gICAgICAgICAgP3JlbGF0aW9uc2hpcCBlbnY6dHlwZSBcIlJlbGF0aW9uc2hpcFwiIC5cbiAgICAgICAgICA/cmVsYXRpb25zaGlwIGVudjpzb3VyY2VFbnRpdHkgP3NvdXJjZU5hbWUgLlxuICAgICAgICAgID9yZWxhdGlvbnNoaXAgZW52OnRhcmdldEVudGl0eSA/dGFyZ2V0TmFtZSAuXG4gICAgICAgICAgP3JlbGF0aW9uc2hpcCBlbnY6cmVsYXRpb25zaGlwVHlwZSA/cmVsYXRpb25UeXBlIC5cbiAgICAgICAgICBcbiAgICAgICAgICAjIEZpbmQgdGhlIGFjdHVhbCBlbnRpdHkgSURzIGJ5IG5hbWVcbiAgICAgICAgICA/c291cmNlRW50aXR5IGVudjpuYW1lID9zb3VyY2VOYW1lIC5cbiAgICAgICAgICA/dGFyZ2V0RW50aXR5IGVudjpuYW1lID90YXJnZXROYW1lIC5cbiAgICAgICAgICA/c291cmNlRW50aXR5IGVudjppZCA/c291cmNlSWQgLlxuICAgICAgICAgID90YXJnZXRFbnRpdHkgZW52OmlkID90YXJnZXRJZCAuXG4gICAgICAgICAgXG4gICAgICAgICAgQklORCg/cmVsYXRpb25UeXBlIEFTID9yZWxhdGlvbkxhYmVsKVxuICAgICAgICB9XG4gICAgICAgIFVOSU9OXG4gICAgICAgIHtcbiAgICAgICAgICAjIEludGVncmF0aW9uIHNvdXJjZSByZWxhdGlvbnNoaXBzXG4gICAgICAgICAgP2ludGVncmF0aW9uIGVudjp0eXBlIFwiSW50ZWdyYXRpb25cIiAuXG4gICAgICAgICAgP2ludGVncmF0aW9uIGVudjppZCA/aW50ZWdyYXRpb25JZCAuXG4gICAgICAgICAgP2ludGVncmF0aW9uIGVudjpzb3VyY2VTZXJ2aWNlID9zb3VyY2VVcmkgLlxuICAgICAgICAgIFxuICAgICAgICAgICMgRXh0cmFjdCBlbnRpdHkgbmFtZSBmcm9tIFVSSSBvciB1c2UgZGlyZWN0IG5hbWVcbiAgICAgICAgICBCSU5EKElGKENPTlRBSU5TKFNUUig/c291cmNlVXJpKSwgXCIvXCIpLCBTVFJBRlRFUihTVFIoP3NvdXJjZVVyaSksIFwiL1wiKSwgU1RSKD9zb3VyY2VVcmkpKSBBUyA/c291cmNlTmFtZSlcbiAgICAgICAgICBcbiAgICAgICAgICA/c291cmNlRW50aXR5IGVudjpuYW1lID9zb3VyY2VOYW1lIC5cbiAgICAgICAgICA/c291cmNlRW50aXR5IGVudjppZCA/c291cmNlSWQgLlxuICAgICAgICAgIFxuICAgICAgICAgIEJJTkQoP2ludGVncmF0aW9uSWQgQVMgP3RhcmdldElkKVxuICAgICAgICAgIEJJTkQoXCJzb3VyY2VPZlwiIEFTID9yZWxhdGlvblR5cGUpXG4gICAgICAgICAgQklORChcInNvdXJjZSBvZlwiIEFTID9yZWxhdGlvbkxhYmVsKVxuICAgICAgICB9XG4gICAgICAgIFVOSU9OXG4gICAgICAgIHtcbiAgICAgICAgICAjIEludGVncmF0aW9uIHRhcmdldCByZWxhdGlvbnNoaXBzICBcbiAgICAgICAgICA/aW50ZWdyYXRpb24gZW52OnR5cGUgXCJJbnRlZ3JhdGlvblwiIC5cbiAgICAgICAgICA/aW50ZWdyYXRpb24gZW52OmlkID9pbnRlZ3JhdGlvbklkIC5cbiAgICAgICAgICA/aW50ZWdyYXRpb24gZW52OnRhcmdldFNlcnZpY2UgP3RhcmdldFVyaSAuXG4gICAgICAgICAgXG4gICAgICAgICAgIyBFeHRyYWN0IGVudGl0eSBuYW1lIGZyb20gVVJJIG9yIHVzZSBkaXJlY3QgbmFtZVxuICAgICAgICAgIEJJTkQoSUYoQ09OVEFJTlMoU1RSKD90YXJnZXRVcmkpLCBcIi9cIiksIFNUUkFGVEVSKFNUUig/dGFyZ2V0VXJpKSwgXCIvXCIpLCBTVFIoP3RhcmdldFVyaSkpIEFTID90YXJnZXROYW1lKVxuICAgICAgICAgIFxuICAgICAgICAgID90YXJnZXRFbnRpdHkgZW52Om5hbWUgP3RhcmdldE5hbWUgLlxuICAgICAgICAgID90YXJnZXRFbnRpdHkgZW52OmlkID90YXJnZXRJZCAuXG4gICAgICAgICAgXG4gICAgICAgICAgQklORCg/aW50ZWdyYXRpb25JZCBBUyA/c291cmNlSWQpXG4gICAgICAgICAgQklORChcInRhcmdldE9mXCIgQVMgP3JlbGF0aW9uVHlwZSlcbiAgICAgICAgICBCSU5EKFwidGFyZ2V0IG9mXCIgQVMgP3JlbGF0aW9uTGFiZWwpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICBgO1xuXG4gICAgY29uc3QgW25vZGVzUmVzdWx0LCBlZGdlc1Jlc3VsdF0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICB0aGlzLmV4ZWN1dGVTcGFycWxRdWVyeShub2Rlc1F1ZXJ5KSxcbiAgICAgIHRoaXMuZXhlY3V0ZVNwYXJxbFF1ZXJ5KGVkZ2VzUXVlcnkpXG4gICAgXSk7XG5cbiAgICBjb25zb2xlLmxvZygnTm9kZXMgcXVlcnkgcmVzdWx0OicsIEpTT04uc3RyaW5naWZ5KG5vZGVzUmVzdWx0LCBudWxsLCAyKSk7XG4gICAgXG4gICAgLy8gVGVzdCBxdWVyeSB0byBzcGVjaWZpY2FsbHkgbG9vayBmb3IgY29uZmlnIHByb3BlcnRpZXNcbiAgICBjb25zdCBjb25maWdUZXN0UXVlcnkgPSBgXG4gICAgICBQUkVGSVggZW52OiA8JHt0aGlzLm9udG9sb2d5UHJlZml4fT5cbiAgICAgIFxuICAgICAgU0VMRUNUID9lbnRpdHkgP3Byb3BlcnR5ID92YWx1ZSBXSEVSRSB7XG4gICAgICAgID9lbnRpdHkgP3Byb3BlcnR5ID92YWx1ZSAuXG4gICAgICAgIEZJTFRFUihDT05UQUlOUyhTVFIoP3Byb3BlcnR5KSwgXCJjb25maWdfXCIpKVxuICAgICAgfVxuICAgICAgTElNSVQgMTBcbiAgICBgO1xuICAgIFxuICAgIGNvbnN0IGNvbmZpZ1Rlc3RSZXN1bHQgPSBhd2FpdCB0aGlzLmV4ZWN1dGVTcGFycWxRdWVyeShjb25maWdUZXN0UXVlcnkpO1xuICAgIGNvbnNvbGUubG9nKCdDb25maWcgdGVzdCBxdWVyeSByZXN1bHQ6JywgSlNPTi5zdHJpbmdpZnkoY29uZmlnVGVzdFJlc3VsdCwgbnVsbCwgMikpO1xuXG4gICAgLy8gQnVpbGQgbm9kZXMgd2l0aCBhbGwgdGhlaXIgcHJvcGVydGllc1xuICAgIGNvbnN0IG5vZGVNYXA6IFJlY29yZDxzdHJpbmcsIGFueT4gPSB7fTtcbiAgICBub2Rlc1Jlc3VsdC5yZXN1bHRzPy5iaW5kaW5ncz8uZm9yRWFjaCgoYmluZGluZzogYW55KSA9PiB7XG4gICAgICBjb25zdCBlbnRpdHlJZCA9IGJpbmRpbmcuaWQ/LnZhbHVlIHx8ICcnO1xuICAgICAgXG4gICAgICBpZiAoIW5vZGVNYXBbZW50aXR5SWRdKSB7XG4gICAgICAgIG5vZGVNYXBbZW50aXR5SWRdID0ge1xuICAgICAgICAgIGlkOiBlbnRpdHlJZCxcbiAgICAgICAgICBsYWJlbDogYmluZGluZy5uYW1lPy52YWx1ZSB8fCAnJyxcbiAgICAgICAgICB0eXBlOiBiaW5kaW5nLnR5cGU/LnZhbHVlIHx8ICcnLFxuICAgICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICAgIHN0YXR1czogYmluZGluZy5zdGF0dXM/LnZhbHVlLFxuICAgICAgICAgICAgb3duZXI6IGJpbmRpbmcub3duZXI/LnZhbHVlLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgY29uZmlndXJhdGlvbnM6IHt9IC8vIEluaXRpYWxpemUgY29uZmlndXJhdGlvbnMgb2JqZWN0XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIEFkZCBhbnkgYWRkaXRpb25hbCBwcm9wZXJ0aWVzLCBpbmNsdWRpbmcgY29uZmlnXyBwcm9wZXJ0aWVzXG4gICAgICBjb25zdCBwcm9wZXJ0eSA9IGJpbmRpbmcucHJvcGVydHk/LnZhbHVlO1xuICAgICAgY29uc3QgdmFsdWUgPSBiaW5kaW5nLnZhbHVlPy52YWx1ZTtcbiAgICAgIFxuICAgICAgaWYgKHByb3BlcnR5ICYmIHZhbHVlKSB7XG4gICAgICAgIGNvbnN0IHByb3BOYW1lID0gcHJvcGVydHkucmVwbGFjZSh0aGlzLm9udG9sb2d5UHJlZml4LCAnJyk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBFbnRpdHkgJHtlbnRpdHlJZH06IEZvdW5kIHByb3BlcnR5ICR7cHJvcGVydHl9IC0+ICR7cHJvcE5hbWV9ID0gJHt2YWx1ZX1gKTtcbiAgICAgICAgXG4gICAgICAgIC8vIElmIGl0J3MgYSBjb25maWcgcHJvcGVydHksIGFkZCBpdCBib3RoIGRpcmVjdGx5IEFORCB0byBjb25maWd1cmF0aW9ucyBvYmplY3RcbiAgICAgICAgaWYgKHByb3BOYW1lLnN0YXJ0c1dpdGgoJ2NvbmZpZ18nKSkge1xuICAgICAgICAgIG5vZGVNYXBbZW50aXR5SWRdW3Byb3BOYW1lXSA9IHZhbHVlOyAvLyBEaXJlY3QgcHJvcGVydHkgZm9yIGJhY2t3YXJkIGNvbXBhdGliaWxpdHlcbiAgICAgICAgICBjb25zdCBjb25maWdLZXkgPSBwcm9wTmFtZS5yZXBsYWNlKCdjb25maWdfJywgJycpOyAvLyBSZW1vdmUgY29uZmlnXyBwcmVmaXggZm9yIGRpc3BsYXlcbiAgICAgICAgICBub2RlTWFwW2VudGl0eUlkXS5jb25maWd1cmF0aW9uc1tjb25maWdLZXldID0gdmFsdWU7IC8vIEFkZCB0byBjb25maWd1cmF0aW9ucyBvYmplY3RcbiAgICAgICAgICBjb25zb2xlLmxvZyhgICAtPiBBZGRlZCB0byBjb25maWd1cmF0aW9ucyBhcyAnJHtjb25maWdLZXl9J2ApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIFJlZ3VsYXIgcHJvcGVydHksIGp1c3QgYWRkIGRpcmVjdGx5XG4gICAgICAgICAgbm9kZU1hcFtlbnRpdHlJZF1bcHJvcE5hbWVdID0gdmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgICBcbiAgICBjb25zdCBub2RlczogTmV0d29ya05vZGVbXSA9IE9iamVjdC52YWx1ZXMobm9kZU1hcCk7XG4gICAgXG4gICAgY29uc3QgZWRnZXM6IE5ldHdvcmtFZGdlW10gPSBlZGdlc1Jlc3VsdC5yZXN1bHRzPy5iaW5kaW5ncz8ubWFwKChiaW5kaW5nOiBhbnksIGluZGV4OiBudW1iZXIpID0+ICh7XG4gICAgICBpZDogYGVkZ2UtJHtpbmRleH1gLFxuICAgICAgc291cmNlOiBiaW5kaW5nLnNvdXJjZUlkPy52YWx1ZSB8fCAnJyxcbiAgICAgIHRhcmdldDogYmluZGluZy50YXJnZXRJZD8udmFsdWUgfHwgJycsXG4gICAgICB0eXBlOiBiaW5kaW5nLnJlbGF0aW9uVHlwZT8udmFsdWUgfHwgJ3JlbGF0ZWQnLFxuICAgICAgbGFiZWw6IGJpbmRpbmcucmVsYXRpb25MYWJlbD8udmFsdWUgfHwgYmluZGluZy5yZWxhdGlvblR5cGU/LnZhbHVlIHx8ICdyZWxhdGVkJyxcbiAgICAgIHByb3BlcnRpZXM6IHt9XG4gICAgfSkpIHx8IFtdO1xuICAgIFxuICAgIHJldHVybiB7IG5vZGVzLCBlZGdlcyB9O1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBlbnRpdHkgYnkgSUQgZm9sbG93aW5nIG9udG9sb2d5XG4gICAqL1xuICBhc3luYyBnZXRFbnRpdHlCeUlkKGlkOiBzdHJpbmcpOiBQcm9taXNlPEVudGl0eSB8IG51bGw+IHtcbiAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgIFBSRUZJWCByZGY6IDxodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjPlxuICAgICAgUFJFRklYIGVudjogPCR7dGhpcy5vbnRvbG9neVByZWZpeH0+XG4gICAgICBcbiAgICAgIFNFTEVDVCA/bmFtZSA/dHlwZSA/dW5pcXVlSWRlbnRpZmllciA/b3duZXIgP2Rlc2NyaXB0aW9uID9jcmVhdGVkQXQgP3N0YXR1cyBXSEVSRSB7XG4gICAgICAgID9lbnRpdHkgZW52OmlkIFwiJHtpZH1cIiA7XG4gICAgICAgICAgICAgICAgZW52Om5hbWUgP25hbWUgO1xuICAgICAgICAgICAgICAgIGVudjp0eXBlID90eXBlIDtcbiAgICAgICAgICAgICAgICBlbnY6ZGVzY3JpcHRpb24gP2Rlc2NyaXB0aW9uIC5cbiAgICAgICAgT1BUSU9OQUwgeyA/ZW50aXR5IGVudjp1bmlxdWVJZGVudGlmaWVyID91bmlxdWVJZGVudGlmaWVyIH1cbiAgICAgICAgT1BUSU9OQUwgeyA/ZW50aXR5IGVudjpvd25lciA/b3duZXIgfVxuICAgICAgICBPUFRJT05BTCB7ID9lbnRpdHkgZW52OmNyZWF0ZWRBdCA/Y3JlYXRlZEF0IH1cbiAgICAgICAgT1BUSU9OQUwgeyA/ZW50aXR5IGVudjpzdGF0dXMgP3N0YXR1cyB9XG4gICAgICB9XG4gICAgYDtcbiAgICBcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLmV4ZWN1dGVTcGFycWxRdWVyeShxdWVyeSk7XG4gICAgXG4gICAgaWYgKCFyZXN1bHQucmVzdWx0cz8uYmluZGluZ3M/Lmxlbmd0aCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IGJpbmRpbmcgPSByZXN1bHQucmVzdWx0cy5iaW5kaW5nc1swXTtcbiAgICByZXR1cm4ge1xuICAgICAgaWQsXG4gICAgICBuYW1lOiBiaW5kaW5nLm5hbWU/LnZhbHVlIHx8ICcnLFxuICAgICAgdHlwZTogYmluZGluZy50eXBlPy52YWx1ZSB8fCAnJyxcbiAgICAgIHVuaXF1ZUlkZW50aWZpZXI6IGJpbmRpbmcudW5pcXVlSWRlbnRpZmllcj8udmFsdWUsXG4gICAgICBvd25lcjogYmluZGluZy5vd25lcj8udmFsdWUsXG4gICAgICBkZXNjcmlwdGlvbjogYmluZGluZy5kZXNjcmlwdGlvbj8udmFsdWUgfHwgJycsXG4gICAgICBjcmVhdGVkQXQ6IGJpbmRpbmcuY3JlYXRlZEF0Py52YWx1ZSxcbiAgICAgIHN0YXR1czogYmluZGluZy5zdGF0dXM/LnZhbHVlLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogR2V0IGNvbmZpZ3VyYXRpb25zIGZvciBhbiBlbnRpdHlcbiAgICovXG4gIGFzeW5jIGdldEVudGl0eUNvbmZpZ3VyYXRpb25zKGVudGl0eUlkOiBzdHJpbmcpOiBQcm9taXNlPENvbmZpZ3VyYXRpb25bXT4ge1xuICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgUFJFRklYIHJkZjogPGh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyM+XG4gICAgICBQUkVGSVggZW52OiA8JHt0aGlzLm9udG9sb2d5UHJlZml4fT5cbiAgICAgIFxuICAgICAgU0VMRUNUID9jb25maWdJZCA/Y29uZmlnVHlwZSA/Y29uZmlnTWFwID9jcmVhdGVkQXQgV0hFUkUge1xuICAgICAgICA/ZW50aXR5IGVudjppZCBcIiR7ZW50aXR5SWR9XCIgO1xuICAgICAgICAgICAgICAgIGVudjpoYXNDb25maWd1cmF0aW9uID9jb25maWcgLlxuICAgICAgICA/Y29uZmlnIGVudjppZCA/Y29uZmlnSWQgO1xuICAgICAgICAgICAgICAgIGVudjp0eXBlID9jb25maWdUeXBlIC5cbiAgICAgICAgT1BUSU9OQUwgeyA/Y29uZmlnIGVudjpjb25maWd1cmF0aW9uTWFwID9jb25maWdNYXAgfVxuICAgICAgICBPUFRJT05BTCB7ID9jb25maWcgZW52OmNyZWF0ZWRBdCA/Y3JlYXRlZEF0IH1cbiAgICAgIH1cbiAgICBgO1xuICAgIFxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuZXhlY3V0ZVNwYXJxbFF1ZXJ5KHF1ZXJ5KTtcbiAgICBcbiAgICByZXR1cm4gcmVzdWx0LnJlc3VsdHM/LmJpbmRpbmdzPy5tYXAoKGJpbmRpbmc6IGFueSkgPT4gKHtcbiAgICAgIGlkOiBiaW5kaW5nLmNvbmZpZ0lkPy52YWx1ZSB8fCAnJyxcbiAgICAgIHR5cGU6IGJpbmRpbmcuY29uZmlnVHlwZT8udmFsdWUgfHwgJycsXG4gICAgICBjb25maWd1cmF0aW9uTWFwOiBiaW5kaW5nLmNvbmZpZ01hcD8udmFsdWUsXG4gICAgICBjcmVhdGVkQXQ6IGJpbmRpbmcuY3JlYXRlZEF0Py52YWx1ZSxcbiAgICB9KSkgfHwgW107XG4gIH1cblxuICAvKipcbiAgICogR2V0IGNvbmZpZ3VyYXRpb24gZW50cmllcyBmb3IgYSBjb25maWd1cmF0aW9uXG4gICAqL1xuICBhc3luYyBnZXRDb25maWd1cmF0aW9uRW50cmllcyhjb25maWd1cmF0aW9uSWQ6IHN0cmluZyk6IFByb21pc2U8Q29uZmlndXJhdGlvbkVudHJ5W10+IHtcbiAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgIFBSRUZJWCByZGY6IDxodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjPlxuICAgICAgUFJFRklYIGVudjogPCR7dGhpcy5vbnRvbG9neVByZWZpeH0+XG4gICAgICBcbiAgICAgIFNFTEVDVCA/ZW50cnlJZCA/a2V5ID92YWx1ZSA/dHlwZSBXSEVSRSB7XG4gICAgICAgID9jb25maWcgZW52OmlkIFwiJHtjb25maWd1cmF0aW9uSWR9XCIgO1xuICAgICAgICAgICAgICAgIGVudjpoYXNDb25maWd1cmF0aW9uRW50cnkgP2VudHJ5IC5cbiAgICAgICAgP2VudHJ5IGVudjppZCA/ZW50cnlJZCA7XG4gICAgICAgICAgICAgICBlbnY6Y29uZmlndXJhdGlvbktleSA/a2V5IDtcbiAgICAgICAgICAgICAgIGVudjpjb25maWd1cmF0aW9uVmFsdWUgP3ZhbHVlIC5cbiAgICAgICAgT1BUSU9OQUwgeyA/ZW50cnkgZW52OmNvbmZpZ3VyYXRpb25UeXBlID90eXBlIH1cbiAgICAgIH1cbiAgICBgO1xuICAgIFxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuZXhlY3V0ZVNwYXJxbFF1ZXJ5KHF1ZXJ5KTtcbiAgICBcbiAgICByZXR1cm4gcmVzdWx0LnJlc3VsdHM/LmJpbmRpbmdzPy5tYXAoKGJpbmRpbmc6IGFueSkgPT4gKHtcbiAgICAgIGlkOiBiaW5kaW5nLmVudHJ5SWQ/LnZhbHVlIHx8ICcnLFxuICAgICAgY29uZmlndXJhdGlvbktleTogYmluZGluZy5rZXk/LnZhbHVlIHx8ICcnLFxuICAgICAgY29uZmlndXJhdGlvblZhbHVlOiBiaW5kaW5nLnZhbHVlPy52YWx1ZSB8fCAnJyxcbiAgICAgIGNvbmZpZ3VyYXRpb25UeXBlOiBiaW5kaW5nLnR5cGU/LnZhbHVlLFxuICAgIH0pKSB8fCBbXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWxldGUgZW50aXR5IGJ5IElEXG4gICAqL1xuICBhc3luYyBkZWxldGVFbnRpdHkoaWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIGNvbnN0IHVwZGF0ZSA9IGBcbiAgICAgIFBSRUZJWCBlbXM6IDxodHRwOi8vZXhhbXBsZS5vcmcvZW1zIz5cbiAgICAgIFxuICAgICAgREVMRVRFIFdIRVJFIHtcbiAgICAgICAgZW1zOiR7aWR9ID9wID9vIC5cbiAgICAgIH1cbiAgICBgO1xuICAgIFxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmV4ZWN1dGVTcGFycWxVcGRhdGUodXBkYXRlKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBGYWlsZWQgdG8gZGVsZXRlIGVudGl0eSAke2lkfTpgLCBlcnJvcik7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEluaXRpYWxpemUgb250b2xvZ3kgZm9sbG93aW5nIHRoZSBjb21wbGV0ZSBzY2hlbWFcbiAgICovXG4gIGFzeW5jIGluaXRpYWxpemVPbnRvbG9neSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB1cGRhdGUgPSBgXG4gICAgICBQUkVGSVggcmRmOiA8aHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIz5cbiAgICAgIFBSRUZJWCByZGZzOiA8aHR0cDovL3d3dy53My5vcmcvMjAwMC8wMS9yZGYtc2NoZW1hIz5cbiAgICAgIFBSRUZJWCBvd2w6IDxodHRwOi8vd3d3LnczLm9yZy8yMDAyLzA3L293bCM+XG4gICAgICBQUkVGSVggZW52OiA8JHt0aGlzLm9udG9sb2d5UHJlZml4fT5cbiAgICAgIFBSRUZJWCB4c2Q6IDxodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSM+XG4gICAgICBQUkVGSVggZGM6IDxodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLz5cbiAgICAgIFBSRUZJWCBkY3Rlcm1zOiA8aHR0cDovL3B1cmwub3JnL2RjL3Rlcm1zLz5cbiAgICAgIFxuICAgICAgSU5TRVJUIERBVEEge1xuICAgICAgICAjIE9udG9sb2d5IG1ldGFkYXRhXG4gICAgICAgIDwke3RoaXMub250b2xvZ3lQcmVmaXh9PiByZGY6dHlwZSBvd2w6T250b2xvZ3kgO1xuICAgICAgICAgICAgZGM6dGl0bGUgXCJFbnZpcm9ubWVudCBNYW5hZ2VtZW50IFN5c3RlbSBPbnRvbG9neVwiIDtcbiAgICAgICAgICAgIGRjOmRlc2NyaXB0aW9uIFwiUkRGIG9udG9sb2d5IGZvciBtYW5hZ2luZyBlbnZpcm9ubWVudHMsIGFwcGxpY2F0aW9ucywgaW50ZWdyYXRpb25zIGFuZCB0aGVpciBjb25maWd1cmF0aW9uc1wiIDtcbiAgICAgICAgICAgIGRjOmNyZWF0b3IgXCJFbnZpcm9ubWVudCBNYW5hZ2VtZW50IFRlYW1cIiA7XG4gICAgICAgICAgICBkY3Rlcm1zOmNyZWF0ZWQgXCIyMDI1LTEyLTE1XCJeXnhzZDpkYXRlIDtcbiAgICAgICAgICAgIG93bDp2ZXJzaW9uSW5mbyBcIjEuMFwiIC5cbiAgICAgICAgXG4gICAgICAgICMgQ29yZSBlbnRpdHkgY2xhc3Nlc1xuICAgICAgICBlbnY6RW52aXJvbm1lbnQgcmRmOnR5cGUgb3dsOkNsYXNzIDtcbiAgICAgICAgICAgIHJkZnM6bGFiZWwgXCJFbnZpcm9ubWVudFwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIkEgZGVwbG95bWVudCBvciBydW50aW1lIGVudmlyb25tZW50XCIgLlxuICAgICAgICBcbiAgICAgICAgZW52OkFwcGxpY2F0aW9uIHJkZjp0eXBlIG93bDpDbGFzcyA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwiQXBwbGljYXRpb25cIiA7XG4gICAgICAgICAgICByZGZzOmNvbW1lbnQgXCJBIHNvZnR3YXJlIGFwcGxpY2F0aW9uIG9yIHNlcnZpY2VcIiAuXG4gICAgICAgIFxuICAgICAgICBlbnY6SW50ZWdyYXRpb24gcmRmOnR5cGUgb3dsOkNsYXNzIDtcbiAgICAgICAgICAgIHJkZnM6bGFiZWwgXCJJbnRlZ3JhdGlvblwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIkFuIGludGVncmF0aW9uIGJldHdlZW4gYXBwbGljYXRpb25zIG9yIHNlcnZpY2VzXCIgLlxuICAgICAgICBcbiAgICAgICAgIyBDb25maWd1cmF0aW9uIGNsYXNzZXNcbiAgICAgICAgZW52OkNvbmZpZ3VyYXRpb24gcmRmOnR5cGUgb3dsOkNsYXNzIDtcbiAgICAgICAgICAgIHJkZnM6bGFiZWwgXCJDb25maWd1cmF0aW9uXCIgO1xuICAgICAgICAgICAgcmRmczpjb21tZW50IFwiQmFzZSBjbGFzcyBmb3IgYWxsIGNvbmZpZ3VyYXRpb24gdHlwZXNcIiAuXG4gICAgICAgIFxuICAgICAgICBlbnY6RW52aXJvbm1lbnRDb25maWd1cmF0aW9uIHJkZjp0eXBlIG93bDpDbGFzcyA7XG4gICAgICAgICAgICByZGZzOnN1YkNsYXNzT2YgZW52OkNvbmZpZ3VyYXRpb24gO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcIkVudmlyb25tZW50IENvbmZpZ3VyYXRpb25cIiA7XG4gICAgICAgICAgICByZGZzOmNvbW1lbnQgXCJDb25maWd1cmF0aW9uIGZvciBlbnZpcm9ubWVudCBpbmZyYXN0cnVjdHVyZSBhbmQgZGVwbG95bWVudCBzZXR0aW5nc1wiIC5cbiAgICAgICAgXG4gICAgICAgIGVudjpBcHBsaWNhdGlvbkNvbmZpZ3VyYXRpb24gcmRmOnR5cGUgb3dsOkNsYXNzIDtcbiAgICAgICAgICAgIHJkZnM6c3ViQ2xhc3NPZiBlbnY6Q29uZmlndXJhdGlvbiA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwiQXBwbGljYXRpb24gQ29uZmlndXJhdGlvblwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIkNvbmZpZ3VyYXRpb24gZm9yIGFwcGxpY2F0aW9uIHJ1bnRpbWUgYW5kIGRlcGxveW1lbnQgcGFyYW1ldGVyc1wiIC5cbiAgICAgICAgXG4gICAgICAgIGVudjpJbnRlZ3JhdGlvbkNvbmZpZ3VyYXRpb24gcmRmOnR5cGUgb3dsOkNsYXNzIDtcbiAgICAgICAgICAgIHJkZnM6c3ViQ2xhc3NPZiBlbnY6Q29uZmlndXJhdGlvbiA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwiSW50ZWdyYXRpb24gQ29uZmlndXJhdGlvblwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIkNvbmZpZ3VyYXRpb24gZm9yIGludGVncmF0aW9uIGNvbm5lY3Rpb25zIGFuZCBwcm90b2NvbHNcIiAuXG4gICAgICAgIFxuICAgICAgICBlbnY6Q29uZmlndXJhdGlvbkVudHJ5IHJkZjp0eXBlIG93bDpDbGFzcyA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwiQ29uZmlndXJhdGlvbiBFbnRyeVwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIkluZGl2aWR1YWwga2V5LXZhbHVlIGNvbmZpZ3VyYXRpb24gcGFyYW1ldGVyXCIgLlxuICAgICAgICBcbiAgICAgICAgIyBDb3JlIHByb3BlcnRpZXNcbiAgICAgICAgZW52OmlkIHJkZjp0eXBlIG93bDpEYXRhdHlwZVByb3BlcnR5IDtcbiAgICAgICAgICAgIHJkZnM6bGFiZWwgXCJpZGVudGlmaWVyXCIgO1xuICAgICAgICAgICAgcmRmczpjb21tZW50IFwiVW5pcXVlIGlkZW50aWZpZXIgZm9yIGVudGl0eVwiIDtcbiAgICAgICAgICAgIHJkZnM6cmFuZ2UgeHNkOnN0cmluZyAuXG4gICAgICAgIFxuICAgICAgICBlbnY6bmFtZSByZGY6dHlwZSBvd2w6RGF0YXR5cGVQcm9wZXJ0eSA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwibmFtZVwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIkh1bWFuLXJlYWRhYmxlIG5hbWVcIiA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIHhzZDpzdHJpbmcgLlxuICAgICAgICBcbiAgICAgICAgZW52OnVuaXF1ZUlkZW50aWZpZXIgcmRmOnR5cGUgb3dsOkRhdGF0eXBlUHJvcGVydHkgO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcInVuaXF1ZSBpZGVudGlmaWVyXCIgO1xuICAgICAgICAgICAgcmRmczpjb21tZW50IFwiQnVzaW5lc3MgdW5pcXVlIGlkZW50aWZpZXJcIiA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIHhzZDpzdHJpbmcgLlxuICAgICAgICBcbiAgICAgICAgZW52Om93bmVyIHJkZjp0eXBlIG93bDpEYXRhdHlwZVByb3BlcnR5IDtcbiAgICAgICAgICAgIHJkZnM6bGFiZWwgXCJvd25lclwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIk93bmVyIG9yIHJlc3BvbnNpYmxlIHBhcnR5XCIgO1xuICAgICAgICAgICAgcmRmczpyYW5nZSB4c2Q6c3RyaW5nIC5cbiAgICAgICAgXG4gICAgICAgIGVudjpkZXNjcmlwdGlvbiByZGY6dHlwZSBvd2w6RGF0YXR5cGVQcm9wZXJ0eSA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwiZGVzY3JpcHRpb25cIiA7XG4gICAgICAgICAgICByZGZzOmNvbW1lbnQgXCJEZXRhaWxlZCBkZXNjcmlwdGlvblwiIDtcbiAgICAgICAgICAgIHJkZnM6cmFuZ2UgeHNkOnN0cmluZyAuXG4gICAgICAgIFxuICAgICAgICBlbnY6dHlwZSByZGY6dHlwZSBvd2w6RGF0YXR5cGVQcm9wZXJ0eSA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwidHlwZVwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIkVudGl0eSB0eXBlIGNsYXNzaWZpY2F0aW9uXCIgO1xuICAgICAgICAgICAgcmRmczpyYW5nZSB4c2Q6c3RyaW5nIC5cbiAgICAgICAgXG4gICAgICAgIGVudjpjcmVhdGVkQXQgcmRmOnR5cGUgb3dsOkRhdGF0eXBlUHJvcGVydHkgO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcImNyZWF0ZWQgYXRcIiA7XG4gICAgICAgICAgICByZGZzOmNvbW1lbnQgXCJDcmVhdGlvbiB0aW1lc3RhbXBcIiA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIHhzZDpkYXRlVGltZSAuXG4gICAgICAgIFxuICAgICAgICBlbnY6ZW5kcG9pbnQgcmRmOnR5cGUgb3dsOkRhdGF0eXBlUHJvcGVydHkgO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcImVuZHBvaW50XCIgO1xuICAgICAgICAgICAgcmRmczpjb21tZW50IFwiU2VydmljZSBlbmRwb2ludCBVUkxcIiA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIHhzZDpzdHJpbmcgLlxuICAgICAgICBcbiAgICAgICAgZW52OnJlZ2lvbiByZGY6dHlwZSBvd2w6RGF0YXR5cGVQcm9wZXJ0eSA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwicmVnaW9uXCIgO1xuICAgICAgICAgICAgcmRmczpjb21tZW50IFwiR2VvZ3JhcGhpYyBvciBjbG91ZCByZWdpb25cIiA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIHhzZDpzdHJpbmcgLlxuICAgICAgICBcbiAgICAgICAgZW52OnN0YXR1cyByZGY6dHlwZSBvd2w6RGF0YXR5cGVQcm9wZXJ0eSA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwic3RhdHVzXCIgO1xuICAgICAgICAgICAgcmRmczpjb21tZW50IFwiQ3VycmVudCBvcGVyYXRpb25hbCBzdGF0dXNcIiA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIHhzZDpzdHJpbmcgLlxuICAgICAgICBcbiAgICAgICAgZW52OnZlcnNpb24gcmRmOnR5cGUgb3dsOkRhdGF0eXBlUHJvcGVydHkgO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcInZlcnNpb25cIiA7XG4gICAgICAgICAgICByZGZzOmNvbW1lbnQgXCJWZXJzaW9uIGluZm9ybWF0aW9uXCIgO1xuICAgICAgICAgICAgcmRmczpyYW5nZSB4c2Q6c3RyaW5nIC5cbiAgICAgICAgXG4gICAgICAgICMgQ29uZmlndXJhdGlvbiBwcm9wZXJ0aWVzXG4gICAgICAgIGVudjpjb25maWd1cmF0aW9uTWFwIHJkZjp0eXBlIG93bDpEYXRhdHlwZVByb3BlcnR5IDtcbiAgICAgICAgICAgIHJkZnM6bGFiZWwgXCJjb25maWd1cmF0aW9uIG1hcFwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIkNvbXBsZXRlIGNvbmZpZ3VyYXRpb24gYXMgSlNPTiBvYmplY3RcIiA7XG4gICAgICAgICAgICByZGZzOmRvbWFpbiBlbnY6Q29uZmlndXJhdGlvbiA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIHhzZDpzdHJpbmcgLlxuICAgICAgICBcbiAgICAgICAgZW52OmNvbmZpZ3VyYXRpb25LZXkgcmRmOnR5cGUgb3dsOkRhdGF0eXBlUHJvcGVydHkgO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcImNvbmZpZ3VyYXRpb24ga2V5XCIgO1xuICAgICAgICAgICAgcmRmczpjb21tZW50IFwiQ29uZmlndXJhdGlvbiBwcm9wZXJ0eSBuYW1lXCIgO1xuICAgICAgICAgICAgcmRmczpkb21haW4gZW52OkNvbmZpZ3VyYXRpb25FbnRyeSA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIHhzZDpzdHJpbmcgLlxuICAgICAgICBcbiAgICAgICAgZW52OmNvbmZpZ3VyYXRpb25WYWx1ZSByZGY6dHlwZSBvd2w6RGF0YXR5cGVQcm9wZXJ0eSA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwiY29uZmlndXJhdGlvbiB2YWx1ZVwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIkNvbmZpZ3VyYXRpb24gcHJvcGVydHkgdmFsdWVcIiA7XG4gICAgICAgICAgICByZGZzOmRvbWFpbiBlbnY6Q29uZmlndXJhdGlvbkVudHJ5IDtcbiAgICAgICAgICAgIHJkZnM6cmFuZ2UgeHNkOnN0cmluZyAuXG4gICAgICAgIFxuICAgICAgICBlbnY6Y29uZmlndXJhdGlvblR5cGUgcmRmOnR5cGUgb3dsOkRhdGF0eXBlUHJvcGVydHkgO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcImNvbmZpZ3VyYXRpb24gdHlwZVwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIkRhdGEgdHlwZSBvZiBjb25maWd1cmF0aW9uIHZhbHVlXCIgO1xuICAgICAgICAgICAgcmRmczpkb21haW4gZW52OkNvbmZpZ3VyYXRpb25FbnRyeSA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIHhzZDpzdHJpbmcgLlxuICAgICAgICBcbiAgICAgICAgIyBJbnRlZ3JhdGlvbiBzcGVjaWZpYyBwcm9wZXJ0aWVzXG4gICAgICAgIGVudjpzb3VyY2VTZXJ2aWNlIHJkZjp0eXBlIG93bDpEYXRhdHlwZVByb3BlcnR5IDtcbiAgICAgICAgICAgIHJkZnM6bGFiZWwgXCJzb3VyY2Ugc2VydmljZVwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIlNvdXJjZSBzZXJ2aWNlIGlkZW50aWZpZXIgaW4gaW50ZWdyYXRpb25cIiA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIHhzZDpzdHJpbmcgLlxuICAgICAgICBcbiAgICAgICAgZW52OnRhcmdldFNlcnZpY2UgcmRmOnR5cGUgb3dsOkRhdGF0eXBlUHJvcGVydHkgO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcInRhcmdldCBzZXJ2aWNlXCIgO1xuICAgICAgICAgICAgcmRmczpjb21tZW50IFwiVGFyZ2V0IHNlcnZpY2UgaWRlbnRpZmllciBpbiBpbnRlZ3JhdGlvblwiIDtcbiAgICAgICAgICAgIHJkZnM6cmFuZ2UgeHNkOnN0cmluZyAuXG4gICAgICAgIFxuICAgICAgICAjIE9iamVjdCBwcm9wZXJ0aWVzIChyZWxhdGlvbnNoaXBzKVxuICAgICAgICBlbnY6aGFzQ29uZmlndXJhdGlvbiByZGY6dHlwZSBvd2w6T2JqZWN0UHJvcGVydHkgO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcImhhcyBjb25maWd1cmF0aW9uXCIgO1xuICAgICAgICAgICAgcmRmczpjb21tZW50IFwiTGlua3MgYW4gZW50aXR5IHRvIGl0cyBjb25maWd1cmF0aW9uXCIgO1xuICAgICAgICAgICAgcmRmczpkb21haW4gb3dsOlRoaW5nIDtcbiAgICAgICAgICAgIHJkZnM6cmFuZ2UgZW52OkNvbmZpZ3VyYXRpb24gLlxuICAgICAgICBcbiAgICAgICAgZW52Omhhc0Vudmlyb25tZW50Q29uZmlnIHJkZjp0eXBlIG93bDpPYmplY3RQcm9wZXJ0eSA7XG4gICAgICAgICAgICByZGZzOnN1YlByb3BlcnR5T2YgZW52Omhhc0NvbmZpZ3VyYXRpb24gO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcImhhcyBlbnZpcm9ubWVudCBjb25maWd1cmF0aW9uXCIgO1xuICAgICAgICAgICAgcmRmczpkb21haW4gZW52OkVudmlyb25tZW50IDtcbiAgICAgICAgICAgIHJkZnM6cmFuZ2UgZW52OkVudmlyb25tZW50Q29uZmlndXJhdGlvbiAuXG4gICAgICAgIFxuICAgICAgICBlbnY6aGFzQXBwbGljYXRpb25Db25maWcgcmRmOnR5cGUgb3dsOk9iamVjdFByb3BlcnR5IDtcbiAgICAgICAgICAgIHJkZnM6c3ViUHJvcGVydHlPZiBlbnY6aGFzQ29uZmlndXJhdGlvbiA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwiaGFzIGFwcGxpY2F0aW9uIGNvbmZpZ3VyYXRpb25cIiA7XG4gICAgICAgICAgICByZGZzOmRvbWFpbiBlbnY6QXBwbGljYXRpb24gO1xuICAgICAgICAgICAgcmRmczpyYW5nZSBlbnY6QXBwbGljYXRpb25Db25maWd1cmF0aW9uIC5cbiAgICAgICAgXG4gICAgICAgIGVudjpoYXNJbnRlZ3JhdGlvbkNvbmZpZyByZGY6dHlwZSBvd2w6T2JqZWN0UHJvcGVydHkgO1xuICAgICAgICAgICAgcmRmczpzdWJQcm9wZXJ0eU9mIGVudjpoYXNDb25maWd1cmF0aW9uIDtcbiAgICAgICAgICAgIHJkZnM6bGFiZWwgXCJoYXMgaW50ZWdyYXRpb24gY29uZmlndXJhdGlvblwiIDtcbiAgICAgICAgICAgIHJkZnM6ZG9tYWluIGVudjpJbnRlZ3JhdGlvbiA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIGVudjpJbnRlZ3JhdGlvbkNvbmZpZ3VyYXRpb24gLlxuICAgICAgICBcbiAgICAgICAgZW52Omhhc0NvbmZpZ3VyYXRpb25FbnRyeSByZGY6dHlwZSBvd2w6T2JqZWN0UHJvcGVydHkgO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcImhhcyBjb25maWd1cmF0aW9uIGVudHJ5XCIgO1xuICAgICAgICAgICAgcmRmczpkb21haW4gZW52OkNvbmZpZ3VyYXRpb24gO1xuICAgICAgICAgICAgcmRmczpyYW5nZSBlbnY6Q29uZmlndXJhdGlvbkVudHJ5IC5cbiAgICAgICAgXG4gICAgICAgIGVudjppbnRlZ3JhdGVzV2l0aCByZGY6dHlwZSBvd2w6T2JqZWN0UHJvcGVydHkgO1xuICAgICAgICAgICAgcmRmczpsYWJlbCBcImludGVncmF0ZXMgd2l0aFwiIDtcbiAgICAgICAgICAgIHJkZnM6Y29tbWVudCBcIkRpcmVjdCBpbnRlZ3JhdGlvbiByZWxhdGlvbnNoaXAgYmV0d2VlbiBzZXJ2aWNlc1wiIC5cbiAgICAgICAgXG4gICAgICAgIGVudjpkZXBsb3llZEluIHJkZjp0eXBlIG93bDpPYmplY3RQcm9wZXJ0eSA7XG4gICAgICAgICAgICByZGZzOmxhYmVsIFwiZGVwbG95ZWQgaW5cIiA7XG4gICAgICAgICAgICByZGZzOmNvbW1lbnQgXCJBcHBsaWNhdGlvbiBkZXBsb3llZCBpbiBlbnZpcm9ubWVudFwiIDtcbiAgICAgICAgICAgIHJkZnM6ZG9tYWluIGVudjpBcHBsaWNhdGlvbiA7XG4gICAgICAgICAgICByZGZzOnJhbmdlIGVudjpFbnZpcm9ubWVudCAuXG4gICAgICB9XG4gICAgYDtcbiAgICBcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVTcGFycWxVcGRhdGUodXBkYXRlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgZGVwbG95bWVudCByZWxhdGlvbnNoaXBcbiAgICovXG4gIGFzeW5jIGNyZWF0ZURlcGxveW1lbnQoYXBwbGljYXRpb25JZDogc3RyaW5nLCBlbnZpcm9ubWVudElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB1cGRhdGUgPSBgXG4gICAgICBQUkVGSVggZW52OiA8JHt0aGlzLm9udG9sb2d5UHJlZml4fT5cbiAgICAgIFxuICAgICAgSU5TRVJUIERBVEEge1xuICAgICAgICBlbnY6JHthcHBsaWNhdGlvbklkfSBlbnY6ZGVwbG95ZWRJbiBlbnY6JHtlbnZpcm9ubWVudElkfSAuXG4gICAgICB9XG4gICAgYDtcbiAgICBcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVTcGFycWxVcGRhdGUodXBkYXRlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgZGVwbG95bWVudHMgZm9yIGFuIGVudmlyb25tZW50XG4gICAqL1xuICBhc3luYyBnZXRFbnZpcm9ubWVudERlcGxveW1lbnRzKGVudmlyb25tZW50SWQ6IHN0cmluZyk6IFByb21pc2U8RW50aXR5W10+IHtcbiAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgIFBSRUZJWCByZGY6IDxodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjPlxuICAgICAgUFJFRklYIGVudjogPCR7dGhpcy5vbnRvbG9neVByZWZpeH0+XG4gICAgICBcbiAgICAgIFNFTEVDVCA/YXBwSWQgP2FwcE5hbWUgP2FwcFR5cGUgP3ZlcnNpb24gP3N0YXR1cyBXSEVSRSB7XG4gICAgICAgID9hcHAgZW52OmRlcGxveWVkSW4gP2VudiAuXG4gICAgICAgID9lbnYgZW52OmlkIFwiJHtlbnZpcm9ubWVudElkfVwiIC5cbiAgICAgICAgP2FwcCBlbnY6aWQgP2FwcElkIDtcbiAgICAgICAgICAgICBlbnY6bmFtZSA/YXBwTmFtZSA7XG4gICAgICAgICAgICAgZW52OnR5cGUgP2FwcFR5cGUgLlxuICAgICAgICBPUFRJT05BTCB7ID9hcHAgZW52OnZlcnNpb24gP3ZlcnNpb24gfVxuICAgICAgICBPUFRJT05BTCB7ID9hcHAgZW52OnN0YXR1cyA/c3RhdHVzIH1cbiAgICAgIH1cbiAgICBgO1xuICAgIFxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuZXhlY3V0ZVNwYXJxbFF1ZXJ5KHF1ZXJ5KTtcbiAgICBcbiAgICByZXR1cm4gcmVzdWx0LnJlc3VsdHM/LmJpbmRpbmdzPy5tYXAoKGJpbmRpbmc6IGFueSkgPT4gKHtcbiAgICAgIGlkOiBiaW5kaW5nLmFwcElkPy52YWx1ZSB8fCAnJyxcbiAgICAgIG5hbWU6IGJpbmRpbmcuYXBwTmFtZT8udmFsdWUgfHwgJycsXG4gICAgICB0eXBlOiBiaW5kaW5nLmFwcFR5cGU/LnZhbHVlIHx8ICcnLFxuICAgICAgdmVyc2lvbjogYmluZGluZy52ZXJzaW9uPy52YWx1ZSxcbiAgICAgIHN0YXR1czogYmluZGluZy5zdGF0dXM/LnZhbHVlLFxuICAgIH0pKSB8fCBbXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgcmVsYXRpb25zaGlwcyBiZXR3ZWVuIGVudGl0aWVzXG4gICAqL1xuICBhc3luYyBjcmVhdGVSZWxhdGlvbnNoaXAoc291cmNlRW50aXR5TmFtZTogc3RyaW5nLCByZWxhdGlvbnNoaXBUeXBlOiBzdHJpbmcsIHRhcmdldEVudGl0eU5hbWU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIC8vIEdlbmVyYXRlIGEgdW5pcXVlIElEIGZvciB0aGlzIHJlbGF0aW9uc2hpcCBlbnRpdHlcbiAgICBjb25zdCByZWxhdGlvbnNoaXBJZCA9IGByZWxfJHt1dWlkdjQoKX1gO1xuICAgIGNvbnN0IHJlbGF0aW9uc2hpcFVyaSA9IGAke3RoaXMub250b2xvZ3lQcmVmaXh9ZW50aXR5LyR7cmVsYXRpb25zaGlwSWR9YDtcbiAgICBcbiAgICAvLyBDcmVhdGUgcmVsYXRpb25zaGlwIGFzIGFuIGVudGl0eSB3aXRoIHNvdXJjZSwgdGFyZ2V0LCBhbmQgdHlwZSBwcm9wZXJ0aWVzXG4gICAgY29uc3QgaW5zZXJ0UXVlcnkgPSBgXG4gICAgICBQUkVGSVggZW52OiA8JHt0aGlzLm9udG9sb2d5UHJlZml4fT5cbiAgICAgIFxuICAgICAgSU5TRVJUIERBVEEge1xuICAgICAgICA8JHtyZWxhdGlvbnNoaXBVcml9PiBlbnY6aWQgXCIke3JlbGF0aW9uc2hpcElkfVwiIC5cbiAgICAgICAgPCR7cmVsYXRpb25zaGlwVXJpfT4gZW52Om5hbWUgXCIke3NvdXJjZUVudGl0eU5hbWV9XyR7cmVsYXRpb25zaGlwVHlwZX1fJHt0YXJnZXRFbnRpdHlOYW1lfVwiIC5cbiAgICAgICAgPCR7cmVsYXRpb25zaGlwVXJpfT4gZW52OnR5cGUgXCJSZWxhdGlvbnNoaXBcIiAuXG4gICAgICAgIDwke3JlbGF0aW9uc2hpcFVyaX0+IGVudjpyZWxhdGlvbnNoaXBUeXBlIFwiJHtyZWxhdGlvbnNoaXBUeXBlfVwiIC5cbiAgICAgICAgPCR7cmVsYXRpb25zaGlwVXJpfT4gZW52OnNvdXJjZUVudGl0eSBcIiR7c291cmNlRW50aXR5TmFtZX1cIiAuXG4gICAgICAgIDwke3JlbGF0aW9uc2hpcFVyaX0+IGVudjp0YXJnZXRFbnRpdHkgXCIke3RhcmdldEVudGl0eU5hbWV9XCIgLlxuICAgICAgICA8JHtyZWxhdGlvbnNoaXBVcml9PiBlbnY6ZGVzY3JpcHRpb24gXCJSZWxhdGlvbnNoaXA6ICR7c291cmNlRW50aXR5TmFtZX0gJHtyZWxhdGlvbnNoaXBUeXBlfSAke3RhcmdldEVudGl0eU5hbWV9XCIgLlxuICAgICAgICA8JHtyZWxhdGlvbnNoaXBVcml9PiBlbnY6Y3JlYXRlZEF0IFwiJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCl9XCIgLlxuICAgICAgfVxuICAgIGA7XG4gICAgXG4gICAgYXdhaXQgdGhpcy5leGVjdXRlU3BhcnFsVXBkYXRlKGluc2VydFF1ZXJ5KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgY29uZmlndXJhdGlvbiBwcm9wZXJ0aWVzIGRpcmVjdGx5IHRvIGFuIGVudGl0eVxuICAgKi9cbiAgYXN5bmMgYWRkQ29uZmlndXJhdGlvblByb3BlcnRpZXMoZW50aXR5SWQ6IHN0cmluZywgY29uZmlndXJhdGlvbnM6IFJlY29yZDxzdHJpbmcsIGFueT4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBpZiAoIWNvbmZpZ3VyYXRpb25zIHx8IE9iamVjdC5rZXlzKGNvbmZpZ3VyYXRpb25zKS5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBGaW5kIHRoZSBlbnRpdHkgVVJJIGJ5IElEXG4gICAgY29uc3QgZW50aXR5UXVlcnkgPSBgXG4gICAgICBQUkVGSVggZW52OiA8JHt0aGlzLm9udG9sb2d5UHJlZml4fT5cbiAgICAgIFxuICAgICAgU0VMRUNUID9lbnRpdHkgV0hFUkUge1xuICAgICAgICA/ZW50aXR5IGVudjppZCBcIiR7ZW50aXR5SWR9XCJcbiAgICAgIH1cbiAgICBgO1xuXG4gICAgY29uc3QgZW50aXR5UmVzdWx0ID0gYXdhaXQgdGhpcy5leGVjdXRlU3BhcnFsUXVlcnkoZW50aXR5UXVlcnkpO1xuICAgIGlmICghZW50aXR5UmVzdWx0LnJlc3VsdHM/LmJpbmRpbmdzPy5sZW5ndGgpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgRW50aXR5IHdpdGggSUQgJHtlbnRpdHlJZH0gbm90IGZvdW5kYCk7XG4gICAgfVxuXG4gICAgY29uc3QgZW50aXR5VXJpID0gZW50aXR5UmVzdWx0LnJlc3VsdHMuYmluZGluZ3NbMF0uZW50aXR5LnZhbHVlO1xuICAgIFxuICAgIC8vIEJ1aWxkIElOU0VSVCBEQVRBIHF1ZXJ5IHRvIGFkZCBjb25maWcgcHJvcGVydGllc1xuICAgIGxldCBpbnNlcnRUcmlwbGVzID0gJyc7XG4gICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoY29uZmlndXJhdGlvbnMpKSB7XG4gICAgICBpZiAodmFsdWUgIT09IG51bGwgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gJycpIHtcbiAgICAgICAgY29uc3QgY29uZmlnUHJvcGVydHkgPSBgZW52OmNvbmZpZ18ke2tleX1gO1xuICAgICAgICAvLyBFc2NhcGUgcXVvdGVzIGluIHRoZSB2YWx1ZVxuICAgICAgICBjb25zdCBlc2NhcGVkVmFsdWUgPSBTdHJpbmcodmFsdWUpLnJlcGxhY2UoL1wiL2csICdcXFxcXCInKTtcbiAgICAgICAgaW5zZXJ0VHJpcGxlcyArPSBgICAgIDwke2VudGl0eVVyaX0+ICR7Y29uZmlnUHJvcGVydHl9IFwiJHtlc2NhcGVkVmFsdWV9XCIgLlxcbmA7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGluc2VydFRyaXBsZXMpIHtcbiAgICAgIGNvbnN0IHVwZGF0ZVF1ZXJ5ID0gYFxuICAgICAgICBQUkVGSVggZW52OiA8JHt0aGlzLm9udG9sb2d5UHJlZml4fT5cbiAgICAgICAgXG4gICAgICAgIElOU0VSVCBEQVRBIHtcbiR7aW5zZXJ0VHJpcGxlc30gICAgICAgIH1cbiAgICAgIGA7XG5cbiAgICAgIGF3YWl0IHRoaXMuZXhlY3V0ZVNwYXJxbFVwZGF0ZSh1cGRhdGVRdWVyeSk7XG4gICAgICBjb25zb2xlLmxvZyhgQWRkZWQgJHtPYmplY3Qua2V5cyhjb25maWd1cmF0aW9ucykubGVuZ3RofSBjb25maWd1cmF0aW9uIHByb3BlcnRpZXMgdG8gZW50aXR5ICR7ZW50aXR5SWR9YCk7XG4gICAgfVxuICB9XG59Il19