"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const neptune_sparql_client_1 = require("../shared/neptune-sparql-client");
/**
 * AWS Lambda handler for Neptune database cleanup operations
 * Provides functionality to delete all data or specific entity types
 */
const handler = async (event) => {
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'http://localhost:3000',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, Accept, Origin, X-Requested-With',
        'Access-Control-Max-Age': '300'
    };
    try {
        // Handle CORS preflight requests
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ message: 'CORS preflight successful' })
            };
        }
        const neptuneEndpoint = process.env.NEPTUNE_ENDPOINT;
        if (!neptuneEndpoint) {
            throw new Error('NEPTUNE_ENDPOINT environment variable is not set');
        }
        const client = new neptune_sparql_client_1.NeptuneSparqlClient(neptuneEndpoint);
        // Parse request body if present
        let requestBody = {};
        if (event.body) {
            try {
                requestBody = JSON.parse(event.body);
            }
            catch (e) {
                console.warn('Failed to parse request body:', e);
            }
        }
        // Get operation from path, query parameters, or request body
        const operation = event.pathParameters?.operation ||
            event.queryStringParameters?.operation ||
            requestBody.operation ||
            'health';
        let result;
        switch (operation) {
            case 'health':
                const isHealthy = await client.healthCheck();
                result = {
                    status: isHealthy ? 'healthy' : 'unhealthy',
                    timestamp: new Date().toISOString(),
                    service: 'neptune-cleanup'
                };
                break;
            case 'delete-all':
            case 'delete-all-data':
                result = await deleteAllData(client);
                break;
            case 'delete-entity':
                const entityId = requestBody.entityId || event.queryStringParameters?.entityId;
                if (!entityId) {
                    throw new Error('entityId parameter is required for delete-entity operation');
                }
                result = await deleteEntity(client, entityId);
                break;
            case 'delete-type':
                const entityType = requestBody.entityType || event.queryStringParameters?.entityType;
                if (!entityType) {
                    throw new Error('entityType parameter is required for delete-type operation');
                }
                result = await deleteByType(client, entityType);
                break;
            case 'delete-property':
                const property = requestBody.property || event.queryStringParameters?.property;
                const value = requestBody.value || event.queryStringParameters?.value;
                if (!property) {
                    throw new Error('property parameter is required for delete-property operation');
                }
                result = await deleteByProperty(client, property, value);
                break;
            case 'count-entities':
                result = await countEntities(client);
                break;
            case 'list-types':
                result = await listEntityTypes(client);
                break;
            default:
                throw new Error(`Unknown operation: ${operation}. Available operations: health, delete-all, delete-all-data, delete-entity, delete-type, delete-property, count-entities, list-types`);
        }
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                success: true,
                operation,
                data: result,
                timestamp: new Date().toISOString()
            })
        };
    }
    catch (error) {
        console.error('Cleanup operation failed:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                success: false,
                error: error.message,
                timestamp: new Date().toISOString()
            })
        };
    }
};
exports.handler = handler;
/**
 * Delete all data from Neptune database
 */
async function deleteAllData(client) {
    console.log('Starting complete database cleanup...');
    // First get a count of entities before deletion
    const beforeCount = await countEntities(client);
    // Delete all triples (this removes all data)
    const deleteQuery = `
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    PREFIX env: <http://example.org/environment/>
    
    DELETE {
      ?s ?p ?o
    }
    WHERE {
      ?s ?p ?o
    }
  `;
    await client.executeSparqlUpdate(deleteQuery);
    // Get count after deletion to verify
    const afterCount = await countEntities(client);
    console.log(`Database cleanup completed. Deleted ${beforeCount.total - afterCount.total} entities.`);
    return {
        message: 'All data deleted successfully',
        deletedEntities: beforeCount.total - afterCount.total,
        beforeCount,
        afterCount,
        timestamp: new Date().toISOString()
    };
}
/**
 * Delete entities of a specific type
 */
async function deleteByType(client, entityType) {
    console.log(`Deleting entities of type: ${entityType}`);
    // Get count before deletion
    const beforeQuery = `
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX env: <http://example.org/environment/>
    
    SELECT (COUNT(?entity) as ?count)
    WHERE {
      ?entity rdf:type env:${entityType}
    }
  `;
    const beforeResult = await client.executeSparqlQuery(beforeQuery);
    const beforeCount = parseInt(beforeResult.results?.bindings?.[0]?.count?.value || '0');
    // Delete entities of specified type and all their properties
    const deleteQuery = `
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX env: <http://example.org/environment/>
    
    DELETE {
      ?entity ?p ?o .
      ?s ?q ?entity .
    }
    WHERE {
      ?entity rdf:type env:${entityType} .
      OPTIONAL { ?entity ?p ?o }
      OPTIONAL { ?s ?q ?entity }
    }
  `;
    await client.executeSparqlUpdate(deleteQuery);
    // Get count after deletion
    const afterResult = await client.executeSparqlQuery(beforeQuery);
    const afterCount = parseInt(afterResult.results?.bindings?.[0]?.count?.value || '0');
    return {
        message: `Deleted ${beforeCount - afterCount} entities of type ${entityType}`,
        entityType,
        deletedCount: beforeCount - afterCount,
        remainingCount: afterCount,
        timestamp: new Date().toISOString()
    };
}
/**
 * Delete entities by property value
 */
async function deleteByProperty(client, property, value) {
    console.log(`Deleting entities with property: ${property}${value ? ` = ${value}` : ''}`);
    // Build the WHERE clause based on whether value is specified
    const whereClause = value
        ? `?entity env:${property} "${value}" .`
        : `?entity env:${property} ?propValue .`;
    // Get count before deletion
    const beforeQuery = `
    PREFIX env: <http://example.org/environment/>
    
    SELECT (COUNT(DISTINCT ?entity) as ?count)
    WHERE {
      ${whereClause}
    }
  `;
    const beforeResult = await client.executeSparqlQuery(beforeQuery);
    const beforeCount = parseInt(beforeResult.results?.bindings?.[0]?.count?.value || '0');
    // Delete entities with specified property/value and all their connections
    const deleteQuery = `
    PREFIX env: <http://example.org/environment/>
    
    DELETE {
      ?entity ?p ?o .
      ?s ?q ?entity .
    }
    WHERE {
      ${whereClause}
      OPTIONAL { ?entity ?p ?o }
      OPTIONAL { ?s ?q ?entity }
    }
  `;
    await client.executeSparqlUpdate(deleteQuery);
    // Get count after deletion
    const afterResult = await client.executeSparqlQuery(beforeQuery);
    const afterCount = parseInt(afterResult.results?.bindings?.[0]?.count?.value || '0');
    return {
        message: `Deleted ${beforeCount - afterCount} entities with property ${property}${value ? ` = ${value}` : ''}`,
        property,
        value: value || 'any',
        deletedCount: beforeCount - afterCount,
        remainingCount: afterCount,
        timestamp: new Date().toISOString()
    };
}
/**
 * Count all entities by type
 */
async function countEntities(client) {
    const query = `
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX env: <http://example.org/environment/>
    
    SELECT ?type (COUNT(?entity) as ?count)
    WHERE {
      ?entity rdf:type ?type .
      FILTER(STRSTARTS(STR(?type), "http://example.org/environment/"))
    }
    GROUP BY ?type
    ORDER BY DESC(?count)
  `;
    const result = await client.executeSparqlQuery(query);
    const bindings = result.results?.bindings || [];
    const counts = {};
    let total = 0;
    bindings.forEach((binding) => {
        const typeUri = binding.type?.value || '';
        const typeName = typeUri.replace('http://example.org/environment/', '');
        const count = parseInt(binding.count?.value || '0');
        counts[typeName] = count;
        total += count;
    });
    return {
        total,
        byType: counts,
        timestamp: new Date().toISOString()
    };
}
/**
 * List all entity types in the database
 */
async function listEntityTypes(client) {
    const query = `
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX env: <http://example.org/environment/>
    
    SELECT DISTINCT ?type
    WHERE {
      ?entity rdf:type ?type .
      FILTER(STRSTARTS(STR(?type), "http://example.org/environment/"))
    }
    ORDER BY ?type
  `;
    const result = await client.executeSparqlQuery(query);
    const bindings = result.results?.bindings || [];
    const types = bindings.map((binding) => {
        const typeUri = binding.type?.value || '';
        return typeUri.replace('http://example.org/environment/', '');
    });
    return {
        entityTypes: types,
        count: types.length,
        timestamp: new Date().toISOString()
    };
}
/**
 * Delete a specific entity by ID
 */
async function deleteEntity(client, entityId) {
    console.log(`Deleting entity with ID: ${entityId}`);
    // First, find the entity URI by its ID
    const findQuery = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    
    SELECT ?entity WHERE {
      ?entity env:id "${entityId}" .
    }
  `;
    console.log('Finding entity URI:', findQuery);
    const findResult = await client.executeSparqlQuery(findQuery);
    if (!findResult.results?.bindings?.length) {
        throw new Error(`Entity with ID ${entityId} not found in Neptune`);
    }
    const entityUri = findResult.results.bindings[0].entity.value;
    console.log(`Found entity URI: ${entityUri}`);
    // Now delete the entity and all its connections
    const deleteQuery = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    
    DELETE {
      <${entityUri}> ?p ?o .
      ?s ?q <${entityUri}> .
    }
    WHERE {
      OPTIONAL { <${entityUri}> ?p ?o }
      OPTIONAL { ?s ?q <${entityUri}> }
    }
  `;
    console.log('Executing entity deletion query:', deleteQuery);
    await client.executeSparqlUpdate(deleteQuery);
    return {
        entityId,
        entityUri,
        deleted: true,
        timestamp: new Date().toISOString()
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xlYW51cC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNsZWFudXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0EsMkVBQXNFO0FBRXRFOzs7R0FHRztBQUNJLE1BQU0sT0FBTyxHQUFHLEtBQUssRUFBRSxLQUEyQixFQUFrQyxFQUFFO0lBQzNGLE1BQU0sT0FBTyxHQUFHO1FBQ2QsY0FBYyxFQUFFLGtCQUFrQjtRQUNsQyw2QkFBNkIsRUFBRSx1QkFBdUI7UUFDdEQsOEJBQThCLEVBQUUsaUNBQWlDO1FBQ2pFLDhCQUE4QixFQUFFLCtEQUErRDtRQUMvRix3QkFBd0IsRUFBRSxLQUFLO0tBQ2hDLENBQUM7SUFFRixJQUFJO1FBQ0YsaUNBQWlDO1FBQ2pDLElBQUksS0FBSyxDQUFDLFVBQVUsS0FBSyxTQUFTLEVBQUU7WUFDbEMsT0FBTztnQkFDTCxVQUFVLEVBQUUsR0FBRztnQkFDZixPQUFPO2dCQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsT0FBTyxFQUFFLDJCQUEyQixFQUFFLENBQUM7YUFDL0QsQ0FBQztTQUNIO1FBRUQsTUFBTSxlQUFlLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztRQUNyRCxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQ3BCLE1BQU0sSUFBSSxLQUFLLENBQUMsa0RBQWtELENBQUMsQ0FBQztTQUNyRTtRQUVELE1BQU0sTUFBTSxHQUFHLElBQUksMkNBQW1CLENBQUMsZUFBZSxDQUFDLENBQUM7UUFFeEQsZ0NBQWdDO1FBQ2hDLElBQUksV0FBVyxHQUFRLEVBQUUsQ0FBQztRQUMxQixJQUFJLEtBQUssQ0FBQyxJQUFJLEVBQUU7WUFDZCxJQUFJO2dCQUNGLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN0QztZQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNWLE9BQU8sQ0FBQyxJQUFJLENBQUMsK0JBQStCLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDbEQ7U0FDRjtRQUVELDZEQUE2RDtRQUM3RCxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsY0FBYyxFQUFFLFNBQVM7WUFDaEMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLFNBQVM7WUFDdEMsV0FBVyxDQUFDLFNBQVM7WUFDckIsUUFBUSxDQUFDO1FBRTFCLElBQUksTUFBVyxDQUFDO1FBRWhCLFFBQVEsU0FBUyxFQUFFO1lBQ2pCLEtBQUssUUFBUTtnQkFDWCxNQUFNLFNBQVMsR0FBRyxNQUFNLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDN0MsTUFBTSxHQUFHO29CQUNQLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVztvQkFDM0MsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO29CQUNuQyxPQUFPLEVBQUUsaUJBQWlCO2lCQUMzQixDQUFDO2dCQUNGLE1BQU07WUFFUixLQUFLLFlBQVksQ0FBQztZQUNsQixLQUFLLGlCQUFpQjtnQkFDcEIsTUFBTSxHQUFHLE1BQU0sYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUNyQyxNQUFNO1lBRVIsS0FBSyxlQUFlO2dCQUNsQixNQUFNLFFBQVEsR0FBRyxXQUFXLENBQUMsUUFBUSxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxRQUFRLENBQUM7Z0JBQy9FLElBQUksQ0FBQyxRQUFRLEVBQUU7b0JBQ2IsTUFBTSxJQUFJLEtBQUssQ0FBQyw0REFBNEQsQ0FBQyxDQUFDO2lCQUMvRTtnQkFDRCxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUM5QyxNQUFNO1lBRVIsS0FBSyxhQUFhO2dCQUNoQixNQUFNLFVBQVUsR0FBRyxXQUFXLENBQUMsVUFBVSxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxVQUFVLENBQUM7Z0JBQ3JGLElBQUksQ0FBQyxVQUFVLEVBQUU7b0JBQ2YsTUFBTSxJQUFJLEtBQUssQ0FBQyw0REFBNEQsQ0FBQyxDQUFDO2lCQUMvRTtnQkFDRCxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO2dCQUNoRCxNQUFNO1lBRVIsS0FBSyxpQkFBaUI7Z0JBQ3BCLE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDLHFCQUFxQixFQUFFLFFBQVEsQ0FBQztnQkFDL0UsTUFBTSxLQUFLLEdBQUcsV0FBVyxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMscUJBQXFCLEVBQUUsS0FBSyxDQUFDO2dCQUN0RSxJQUFJLENBQUMsUUFBUSxFQUFFO29CQUNiLE1BQU0sSUFBSSxLQUFLLENBQUMsOERBQThELENBQUMsQ0FBQztpQkFDakY7Z0JBQ0QsTUFBTSxHQUFHLE1BQU0sZ0JBQWdCLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDekQsTUFBTTtZQUVSLEtBQUssZ0JBQWdCO2dCQUNuQixNQUFNLEdBQUcsTUFBTSxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3JDLE1BQU07WUFFUixLQUFLLFlBQVk7Z0JBQ2YsTUFBTSxHQUFHLE1BQU0sZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUN2QyxNQUFNO1lBRVI7Z0JBQ0UsTUFBTSxJQUFJLEtBQUssQ0FBQyxzQkFBc0IsU0FBUyxzSUFBc0ksQ0FBQyxDQUFDO1NBQzFMO1FBRUQsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsT0FBTztZQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUNuQixPQUFPLEVBQUUsSUFBSTtnQkFDYixTQUFTO2dCQUNULElBQUksRUFBRSxNQUFNO2dCQUNaLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTthQUNwQyxDQUFDO1NBQ0gsQ0FBQztLQUVIO0lBQUMsT0FBTyxLQUFVLEVBQUU7UUFDbkIsT0FBTyxDQUFDLEtBQUssQ0FBQywyQkFBMkIsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVsRCxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixPQUFPO1lBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ25CLE9BQU8sRUFBRSxLQUFLO2dCQUNkLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztnQkFDcEIsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO2FBQ3BDLENBQUM7U0FDSCxDQUFDO0tBQ0g7QUFDSCxDQUFDLENBQUM7QUF4SFcsUUFBQSxPQUFPLFdBd0hsQjtBQUVGOztHQUVHO0FBQ0gsS0FBSyxVQUFVLGFBQWEsQ0FBQyxNQUEyQjtJQUN0RCxPQUFPLENBQUMsR0FBRyxDQUFDLHVDQUF1QyxDQUFDLENBQUM7SUFFckQsZ0RBQWdEO0lBQ2hELE1BQU0sV0FBVyxHQUFHLE1BQU0sYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBRWhELDZDQUE2QztJQUM3QyxNQUFNLFdBQVcsR0FBRzs7Ozs7Ozs7Ozs7R0FXbkIsQ0FBQztJQUVGLE1BQU0sTUFBTSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBRTlDLHFDQUFxQztJQUNyQyxNQUFNLFVBQVUsR0FBRyxNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUUvQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVDQUF1QyxXQUFXLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFLLFlBQVksQ0FBQyxDQUFDO0lBRXJHLE9BQU87UUFDTCxPQUFPLEVBQUUsK0JBQStCO1FBQ3hDLGVBQWUsRUFBRSxXQUFXLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFLO1FBQ3JELFdBQVc7UUFDWCxVQUFVO1FBQ1YsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO0tBQ3BDLENBQUM7QUFDSixDQUFDO0FBRUQ7O0dBRUc7QUFDSCxLQUFLLFVBQVUsWUFBWSxDQUFDLE1BQTJCLEVBQUUsVUFBa0I7SUFDekUsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsVUFBVSxFQUFFLENBQUMsQ0FBQztJQUV4RCw0QkFBNEI7SUFDNUIsTUFBTSxXQUFXLEdBQUc7Ozs7Ozs2QkFNTyxVQUFVOztHQUVwQyxDQUFDO0lBRUYsTUFBTSxZQUFZLEdBQUcsTUFBTSxNQUFNLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDbEUsTUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLEtBQUssSUFBSSxHQUFHLENBQUMsQ0FBQztJQUV2Riw2REFBNkQ7SUFDN0QsTUFBTSxXQUFXLEdBQUc7Ozs7Ozs7Ozs2QkFTTyxVQUFVOzs7O0dBSXBDLENBQUM7SUFFRixNQUFNLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUU5QywyQkFBMkI7SUFDM0IsTUFBTSxXQUFXLEdBQUcsTUFBTSxNQUFNLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDakUsTUFBTSxVQUFVLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLEtBQUssSUFBSSxHQUFHLENBQUMsQ0FBQztJQUVyRixPQUFPO1FBQ0wsT0FBTyxFQUFFLFdBQVcsV0FBVyxHQUFHLFVBQVUscUJBQXFCLFVBQVUsRUFBRTtRQUM3RSxVQUFVO1FBQ1YsWUFBWSxFQUFFLFdBQVcsR0FBRyxVQUFVO1FBQ3RDLGNBQWMsRUFBRSxVQUFVO1FBQzFCLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtLQUNwQyxDQUFDO0FBQ0osQ0FBQztBQUVEOztHQUVHO0FBQ0gsS0FBSyxVQUFVLGdCQUFnQixDQUFDLE1BQTJCLEVBQUUsUUFBZ0IsRUFBRSxLQUFjO0lBQzNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLFFBQVEsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFFekYsNkRBQTZEO0lBQzdELE1BQU0sV0FBVyxHQUFHLEtBQUs7UUFDdkIsQ0FBQyxDQUFDLGVBQWUsUUFBUSxLQUFLLEtBQUssS0FBSztRQUN4QyxDQUFDLENBQUMsZUFBZSxRQUFRLGVBQWUsQ0FBQztJQUUzQyw0QkFBNEI7SUFDNUIsTUFBTSxXQUFXLEdBQUc7Ozs7O1FBS2QsV0FBVzs7R0FFaEIsQ0FBQztJQUVGLE1BQU0sWUFBWSxHQUFHLE1BQU0sTUFBTSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ2xFLE1BQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxLQUFLLElBQUksR0FBRyxDQUFDLENBQUM7SUFFdkYsMEVBQTBFO0lBQzFFLE1BQU0sV0FBVyxHQUFHOzs7Ozs7OztRQVFkLFdBQVc7Ozs7R0FJaEIsQ0FBQztJQUVGLE1BQU0sTUFBTSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBRTlDLDJCQUEyQjtJQUMzQixNQUFNLFdBQVcsR0FBRyxNQUFNLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUNqRSxNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsS0FBSyxJQUFJLEdBQUcsQ0FBQyxDQUFDO0lBRXJGLE9BQU87UUFDTCxPQUFPLEVBQUUsV0FBVyxXQUFXLEdBQUcsVUFBVSwyQkFBMkIsUUFBUSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO1FBQzlHLFFBQVE7UUFDUixLQUFLLEVBQUUsS0FBSyxJQUFJLEtBQUs7UUFDckIsWUFBWSxFQUFFLFdBQVcsR0FBRyxVQUFVO1FBQ3RDLGNBQWMsRUFBRSxVQUFVO1FBQzFCLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtLQUNwQyxDQUFDO0FBQ0osQ0FBQztBQUVEOztHQUVHO0FBQ0gsS0FBSyxVQUFVLGFBQWEsQ0FBQyxNQUEyQjtJQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7Ozs7Ozs7R0FXYixDQUFDO0lBRUYsTUFBTSxNQUFNLEdBQUcsTUFBTSxNQUFNLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDdEQsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLE9BQU8sRUFBRSxRQUFRLElBQUksRUFBRSxDQUFDO0lBRWhELE1BQU0sTUFBTSxHQUFRLEVBQUUsQ0FBQztJQUN2QixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7SUFFZCxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBWSxFQUFFLEVBQUU7UUFDaEMsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxDQUFDO1FBQzFDLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsaUNBQWlDLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDeEUsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsS0FBSyxJQUFJLEdBQUcsQ0FBQyxDQUFDO1FBQ3BELE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxLQUFLLENBQUM7UUFDekIsS0FBSyxJQUFJLEtBQUssQ0FBQztJQUNqQixDQUFDLENBQUMsQ0FBQztJQUVILE9BQU87UUFDTCxLQUFLO1FBQ0wsTUFBTSxFQUFFLE1BQU07UUFDZCxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7S0FDcEMsQ0FBQztBQUNKLENBQUM7QUFFRDs7R0FFRztBQUNILEtBQUssVUFBVSxlQUFlLENBQUMsTUFBMkI7SUFDeEQsTUFBTSxLQUFLLEdBQUc7Ozs7Ozs7Ozs7R0FVYixDQUFDO0lBRUYsTUFBTSxNQUFNLEdBQUcsTUFBTSxNQUFNLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDdEQsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLE9BQU8sRUFBRSxRQUFRLElBQUksRUFBRSxDQUFDO0lBRWhELE1BQU0sS0FBSyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFZLEVBQUUsRUFBRTtRQUMxQyxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsSUFBSSxFQUFFLEtBQUssSUFBSSxFQUFFLENBQUM7UUFDMUMsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLGlDQUFpQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQ2hFLENBQUMsQ0FBQyxDQUFDO0lBRUgsT0FBTztRQUNMLFdBQVcsRUFBRSxLQUFLO1FBQ2xCLEtBQUssRUFBRSxLQUFLLENBQUMsTUFBTTtRQUNuQixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7S0FDcEMsQ0FBQztBQUNKLENBQUM7QUFFRDs7R0FFRztBQUNILEtBQUssVUFBVSxZQUFZLENBQUMsTUFBMkIsRUFBRSxRQUFnQjtJQUN2RSxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBRXBELHVDQUF1QztJQUN2QyxNQUFNLFNBQVMsR0FBRzs7Ozt3QkFJSSxRQUFROztHQUU3QixDQUFDO0lBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxTQUFTLENBQUMsQ0FBQztJQUM5QyxNQUFNLFVBQVUsR0FBRyxNQUFNLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUU5RCxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFO1FBQ3pDLE1BQU0sSUFBSSxLQUFLLENBQUMsa0JBQWtCLFFBQVEsdUJBQXVCLENBQUMsQ0FBQztLQUNwRTtJQUVELE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7SUFDOUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsU0FBUyxFQUFFLENBQUMsQ0FBQztJQUU5QyxnREFBZ0Q7SUFDaEQsTUFBTSxXQUFXLEdBQUc7Ozs7U0FJYixTQUFTO2VBQ0gsU0FBUzs7O29CQUdKLFNBQVM7MEJBQ0gsU0FBUzs7R0FFaEMsQ0FBQztJQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDN0QsTUFBTSxNQUFNLENBQUMsbUJBQW1CLENBQUMsV0FBVyxDQUFDLENBQUM7SUFFOUMsT0FBTztRQUNMLFFBQVE7UUFDUixTQUFTO1FBQ1QsT0FBTyxFQUFFLElBQUk7UUFDYixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7S0FDcEMsQ0FBQztBQUNKLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBUElHYXRld2F5UHJveHlFdmVudCwgQVBJR2F0ZXdheVByb3h5UmVzdWx0IH0gZnJvbSAnYXdzLWxhbWJkYSc7XG5pbXBvcnQgeyBOZXB0dW5lU3BhcnFsQ2xpZW50IH0gZnJvbSAnLi4vc2hhcmVkL25lcHR1bmUtc3BhcnFsLWNsaWVudCc7XG5cbi8qKlxuICogQVdTIExhbWJkYSBoYW5kbGVyIGZvciBOZXB0dW5lIGRhdGFiYXNlIGNsZWFudXAgb3BlcmF0aW9uc1xuICogUHJvdmlkZXMgZnVuY3Rpb25hbGl0eSB0byBkZWxldGUgYWxsIGRhdGEgb3Igc3BlY2lmaWMgZW50aXR5IHR5cGVzXG4gKi9cbmV4cG9ydCBjb25zdCBoYW5kbGVyID0gYXN5bmMgKGV2ZW50OiBBUElHYXRld2F5UHJveHlFdmVudCk6IFByb21pc2U8QVBJR2F0ZXdheVByb3h5UmVzdWx0PiA9PiB7XG4gIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMCcsXG4gICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnR0VULCBQT1NULCBQVVQsIERFTEVURSwgT1BUSU9OUycsXG4gICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnMnOiAnQ29udGVudC1UeXBlLCBBdXRob3JpemF0aW9uLCBBY2NlcHQsIE9yaWdpbiwgWC1SZXF1ZXN0ZWQtV2l0aCcsXG4gICAgJ0FjY2Vzcy1Db250cm9sLU1heC1BZ2UnOiAnMzAwJ1xuICB9O1xuXG4gIHRyeSB7XG4gICAgLy8gSGFuZGxlIENPUlMgcHJlZmxpZ2h0IHJlcXVlc3RzXG4gICAgaWYgKGV2ZW50Lmh0dHBNZXRob2QgPT09ICdPUFRJT05TJykge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBoZWFkZXJzLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IG1lc3NhZ2U6ICdDT1JTIHByZWZsaWdodCBzdWNjZXNzZnVsJyB9KVxuICAgICAgfTtcbiAgICB9XG5cbiAgICBjb25zdCBuZXB0dW5lRW5kcG9pbnQgPSBwcm9jZXNzLmVudi5ORVBUVU5FX0VORFBPSU5UO1xuICAgIGlmICghbmVwdHVuZUVuZHBvaW50KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ05FUFRVTkVfRU5EUE9JTlQgZW52aXJvbm1lbnQgdmFyaWFibGUgaXMgbm90IHNldCcpO1xuICAgIH1cblxuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBOZXB0dW5lU3BhcnFsQ2xpZW50KG5lcHR1bmVFbmRwb2ludCk7XG4gICAgXG4gICAgLy8gUGFyc2UgcmVxdWVzdCBib2R5IGlmIHByZXNlbnRcbiAgICBsZXQgcmVxdWVzdEJvZHk6IGFueSA9IHt9O1xuICAgIGlmIChldmVudC5ib2R5KSB7XG4gICAgICB0cnkge1xuICAgICAgICByZXF1ZXN0Qm9keSA9IEpTT04ucGFyc2UoZXZlbnQuYm9keSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignRmFpbGVkIHRvIHBhcnNlIHJlcXVlc3QgYm9keTonLCBlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgLy8gR2V0IG9wZXJhdGlvbiBmcm9tIHBhdGgsIHF1ZXJ5IHBhcmFtZXRlcnMsIG9yIHJlcXVlc3QgYm9keVxuICAgIGNvbnN0IG9wZXJhdGlvbiA9IGV2ZW50LnBhdGhQYXJhbWV0ZXJzPy5vcGVyYXRpb24gfHwgXG4gICAgICAgICAgICAgICAgICAgICBldmVudC5xdWVyeVN0cmluZ1BhcmFtZXRlcnM/Lm9wZXJhdGlvbiB8fCBcbiAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3RCb2R5Lm9wZXJhdGlvbiB8fCBcbiAgICAgICAgICAgICAgICAgICAgICdoZWFsdGgnO1xuXG4gICAgbGV0IHJlc3VsdDogYW55O1xuXG4gICAgc3dpdGNoIChvcGVyYXRpb24pIHtcbiAgICAgIGNhc2UgJ2hlYWx0aCc6XG4gICAgICAgIGNvbnN0IGlzSGVhbHRoeSA9IGF3YWl0IGNsaWVudC5oZWFsdGhDaGVjaygpO1xuICAgICAgICByZXN1bHQgPSB7XG4gICAgICAgICAgc3RhdHVzOiBpc0hlYWx0aHkgPyAnaGVhbHRoeScgOiAndW5oZWFsdGh5JyxcbiAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICBzZXJ2aWNlOiAnbmVwdHVuZS1jbGVhbnVwJ1xuICAgICAgICB9O1xuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnZGVsZXRlLWFsbCc6XG4gICAgICBjYXNlICdkZWxldGUtYWxsLWRhdGEnOlxuICAgICAgICByZXN1bHQgPSBhd2FpdCBkZWxldGVBbGxEYXRhKGNsaWVudCk7XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlICdkZWxldGUtZW50aXR5JzpcbiAgICAgICAgY29uc3QgZW50aXR5SWQgPSByZXF1ZXN0Qm9keS5lbnRpdHlJZCB8fCBldmVudC5xdWVyeVN0cmluZ1BhcmFtZXRlcnM/LmVudGl0eUlkO1xuICAgICAgICBpZiAoIWVudGl0eUlkKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdlbnRpdHlJZCBwYXJhbWV0ZXIgaXMgcmVxdWlyZWQgZm9yIGRlbGV0ZS1lbnRpdHkgb3BlcmF0aW9uJyk7XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgZGVsZXRlRW50aXR5KGNsaWVudCwgZW50aXR5SWQpO1xuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnZGVsZXRlLXR5cGUnOlxuICAgICAgICBjb25zdCBlbnRpdHlUeXBlID0gcmVxdWVzdEJvZHkuZW50aXR5VHlwZSB8fCBldmVudC5xdWVyeVN0cmluZ1BhcmFtZXRlcnM/LmVudGl0eVR5cGU7XG4gICAgICAgIGlmICghZW50aXR5VHlwZSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcignZW50aXR5VHlwZSBwYXJhbWV0ZXIgaXMgcmVxdWlyZWQgZm9yIGRlbGV0ZS10eXBlIG9wZXJhdGlvbicpO1xuICAgICAgICB9XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGRlbGV0ZUJ5VHlwZShjbGllbnQsIGVudGl0eVR5cGUpO1xuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnZGVsZXRlLXByb3BlcnR5JzpcbiAgICAgICAgY29uc3QgcHJvcGVydHkgPSByZXF1ZXN0Qm9keS5wcm9wZXJ0eSB8fCBldmVudC5xdWVyeVN0cmluZ1BhcmFtZXRlcnM/LnByb3BlcnR5O1xuICAgICAgICBjb25zdCB2YWx1ZSA9IHJlcXVlc3RCb2R5LnZhbHVlIHx8IGV2ZW50LnF1ZXJ5U3RyaW5nUGFyYW1ldGVycz8udmFsdWU7XG4gICAgICAgIGlmICghcHJvcGVydHkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3Byb3BlcnR5IHBhcmFtZXRlciBpcyByZXF1aXJlZCBmb3IgZGVsZXRlLXByb3BlcnR5IG9wZXJhdGlvbicpO1xuICAgICAgICB9XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGRlbGV0ZUJ5UHJvcGVydHkoY2xpZW50LCBwcm9wZXJ0eSwgdmFsdWUpO1xuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnY291bnQtZW50aXRpZXMnOlxuICAgICAgICByZXN1bHQgPSBhd2FpdCBjb3VudEVudGl0aWVzKGNsaWVudCk7XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlICdsaXN0LXR5cGVzJzpcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgbGlzdEVudGl0eVR5cGVzKGNsaWVudCk7XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gb3BlcmF0aW9uOiAke29wZXJhdGlvbn0uIEF2YWlsYWJsZSBvcGVyYXRpb25zOiBoZWFsdGgsIGRlbGV0ZS1hbGwsIGRlbGV0ZS1hbGwtZGF0YSwgZGVsZXRlLWVudGl0eSwgZGVsZXRlLXR5cGUsIGRlbGV0ZS1wcm9wZXJ0eSwgY291bnQtZW50aXRpZXMsIGxpc3QtdHlwZXNgKTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgaGVhZGVycyxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgb3BlcmF0aW9uLFxuICAgICAgICBkYXRhOiByZXN1bHQsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICB9KVxuICAgIH07XG5cbiAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgIGNvbnNvbGUuZXJyb3IoJ0NsZWFudXAgb3BlcmF0aW9uIGZhaWxlZDonLCBlcnJvcik7XG4gICAgXG4gICAgcmV0dXJuIHtcbiAgICAgIHN0YXR1c0NvZGU6IDUwMCxcbiAgICAgIGhlYWRlcnMsXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICBlcnJvcjogZXJyb3IubWVzc2FnZSxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgIH0pXG4gICAgfTtcbiAgfVxufTtcblxuLyoqXG4gKiBEZWxldGUgYWxsIGRhdGEgZnJvbSBOZXB0dW5lIGRhdGFiYXNlXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGRlbGV0ZUFsbERhdGEoY2xpZW50OiBOZXB0dW5lU3BhcnFsQ2xpZW50KTogUHJvbWlzZTxhbnk+IHtcbiAgY29uc29sZS5sb2coJ1N0YXJ0aW5nIGNvbXBsZXRlIGRhdGFiYXNlIGNsZWFudXAuLi4nKTtcbiAgXG4gIC8vIEZpcnN0IGdldCBhIGNvdW50IG9mIGVudGl0aWVzIGJlZm9yZSBkZWxldGlvblxuICBjb25zdCBiZWZvcmVDb3VudCA9IGF3YWl0IGNvdW50RW50aXRpZXMoY2xpZW50KTtcbiAgXG4gIC8vIERlbGV0ZSBhbGwgdHJpcGxlcyAodGhpcyByZW1vdmVzIGFsbCBkYXRhKVxuICBjb25zdCBkZWxldGVRdWVyeSA9IGBcbiAgICBQUkVGSVggcmRmOiA8aHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIz5cbiAgICBQUkVGSVggcmRmczogPGh0dHA6Ly93d3cudzMub3JnLzIwMDAvMDEvcmRmLXNjaGVtYSM+XG4gICAgUFJFRklYIGVudjogPGh0dHA6Ly9leGFtcGxlLm9yZy9lbnZpcm9ubWVudC8+XG4gICAgXG4gICAgREVMRVRFIHtcbiAgICAgID9zID9wID9vXG4gICAgfVxuICAgIFdIRVJFIHtcbiAgICAgID9zID9wID9vXG4gICAgfVxuICBgO1xuXG4gIGF3YWl0IGNsaWVudC5leGVjdXRlU3BhcnFsVXBkYXRlKGRlbGV0ZVF1ZXJ5KTtcbiAgXG4gIC8vIEdldCBjb3VudCBhZnRlciBkZWxldGlvbiB0byB2ZXJpZnlcbiAgY29uc3QgYWZ0ZXJDb3VudCA9IGF3YWl0IGNvdW50RW50aXRpZXMoY2xpZW50KTtcbiAgXG4gIGNvbnNvbGUubG9nKGBEYXRhYmFzZSBjbGVhbnVwIGNvbXBsZXRlZC4gRGVsZXRlZCAke2JlZm9yZUNvdW50LnRvdGFsIC0gYWZ0ZXJDb3VudC50b3RhbH0gZW50aXRpZXMuYCk7XG4gIFxuICByZXR1cm4ge1xuICAgIG1lc3NhZ2U6ICdBbGwgZGF0YSBkZWxldGVkIHN1Y2Nlc3NmdWxseScsXG4gICAgZGVsZXRlZEVudGl0aWVzOiBiZWZvcmVDb3VudC50b3RhbCAtIGFmdGVyQ291bnQudG90YWwsXG4gICAgYmVmb3JlQ291bnQsXG4gICAgYWZ0ZXJDb3VudCxcbiAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxuICB9O1xufVxuXG4vKipcbiAqIERlbGV0ZSBlbnRpdGllcyBvZiBhIHNwZWNpZmljIHR5cGVcbiAqL1xuYXN5bmMgZnVuY3Rpb24gZGVsZXRlQnlUeXBlKGNsaWVudDogTmVwdHVuZVNwYXJxbENsaWVudCwgZW50aXR5VHlwZTogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgY29uc29sZS5sb2coYERlbGV0aW5nIGVudGl0aWVzIG9mIHR5cGU6ICR7ZW50aXR5VHlwZX1gKTtcbiAgXG4gIC8vIEdldCBjb3VudCBiZWZvcmUgZGVsZXRpb25cbiAgY29uc3QgYmVmb3JlUXVlcnkgPSBgXG4gICAgUFJFRklYIHJkZjogPGh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyM+XG4gICAgUFJFRklYIGVudjogPGh0dHA6Ly9leGFtcGxlLm9yZy9lbnZpcm9ubWVudC8+XG4gICAgXG4gICAgU0VMRUNUIChDT1VOVCg/ZW50aXR5KSBhcyA/Y291bnQpXG4gICAgV0hFUkUge1xuICAgICAgP2VudGl0eSByZGY6dHlwZSBlbnY6JHtlbnRpdHlUeXBlfVxuICAgIH1cbiAgYDtcbiAgXG4gIGNvbnN0IGJlZm9yZVJlc3VsdCA9IGF3YWl0IGNsaWVudC5leGVjdXRlU3BhcnFsUXVlcnkoYmVmb3JlUXVlcnkpO1xuICBjb25zdCBiZWZvcmVDb3VudCA9IHBhcnNlSW50KGJlZm9yZVJlc3VsdC5yZXN1bHRzPy5iaW5kaW5ncz8uWzBdPy5jb3VudD8udmFsdWUgfHwgJzAnKTtcbiAgXG4gIC8vIERlbGV0ZSBlbnRpdGllcyBvZiBzcGVjaWZpZWQgdHlwZSBhbmQgYWxsIHRoZWlyIHByb3BlcnRpZXNcbiAgY29uc3QgZGVsZXRlUXVlcnkgPSBgXG4gICAgUFJFRklYIHJkZjogPGh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyM+XG4gICAgUFJFRklYIGVudjogPGh0dHA6Ly9leGFtcGxlLm9yZy9lbnZpcm9ubWVudC8+XG4gICAgXG4gICAgREVMRVRFIHtcbiAgICAgID9lbnRpdHkgP3AgP28gLlxuICAgICAgP3MgP3EgP2VudGl0eSAuXG4gICAgfVxuICAgIFdIRVJFIHtcbiAgICAgID9lbnRpdHkgcmRmOnR5cGUgZW52OiR7ZW50aXR5VHlwZX0gLlxuICAgICAgT1BUSU9OQUwgeyA/ZW50aXR5ID9wID9vIH1cbiAgICAgIE9QVElPTkFMIHsgP3MgP3EgP2VudGl0eSB9XG4gICAgfVxuICBgO1xuXG4gIGF3YWl0IGNsaWVudC5leGVjdXRlU3BhcnFsVXBkYXRlKGRlbGV0ZVF1ZXJ5KTtcbiAgXG4gIC8vIEdldCBjb3VudCBhZnRlciBkZWxldGlvblxuICBjb25zdCBhZnRlclJlc3VsdCA9IGF3YWl0IGNsaWVudC5leGVjdXRlU3BhcnFsUXVlcnkoYmVmb3JlUXVlcnkpO1xuICBjb25zdCBhZnRlckNvdW50ID0gcGFyc2VJbnQoYWZ0ZXJSZXN1bHQucmVzdWx0cz8uYmluZGluZ3M/LlswXT8uY291bnQ/LnZhbHVlIHx8ICcwJyk7XG4gIFxuICByZXR1cm4ge1xuICAgIG1lc3NhZ2U6IGBEZWxldGVkICR7YmVmb3JlQ291bnQgLSBhZnRlckNvdW50fSBlbnRpdGllcyBvZiB0eXBlICR7ZW50aXR5VHlwZX1gLFxuICAgIGVudGl0eVR5cGUsXG4gICAgZGVsZXRlZENvdW50OiBiZWZvcmVDb3VudCAtIGFmdGVyQ291bnQsXG4gICAgcmVtYWluaW5nQ291bnQ6IGFmdGVyQ291bnQsXG4gICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgfTtcbn1cblxuLyoqXG4gKiBEZWxldGUgZW50aXRpZXMgYnkgcHJvcGVydHkgdmFsdWVcbiAqL1xuYXN5bmMgZnVuY3Rpb24gZGVsZXRlQnlQcm9wZXJ0eShjbGllbnQ6IE5lcHR1bmVTcGFycWxDbGllbnQsIHByb3BlcnR5OiBzdHJpbmcsIHZhbHVlPzogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgY29uc29sZS5sb2coYERlbGV0aW5nIGVudGl0aWVzIHdpdGggcHJvcGVydHk6ICR7cHJvcGVydHl9JHt2YWx1ZSA/IGAgPSAke3ZhbHVlfWAgOiAnJ31gKTtcbiAgXG4gIC8vIEJ1aWxkIHRoZSBXSEVSRSBjbGF1c2UgYmFzZWQgb24gd2hldGhlciB2YWx1ZSBpcyBzcGVjaWZpZWRcbiAgY29uc3Qgd2hlcmVDbGF1c2UgPSB2YWx1ZSBcbiAgICA/IGA/ZW50aXR5IGVudjoke3Byb3BlcnR5fSBcIiR7dmFsdWV9XCIgLmBcbiAgICA6IGA/ZW50aXR5IGVudjoke3Byb3BlcnR5fSA/cHJvcFZhbHVlIC5gO1xuICBcbiAgLy8gR2V0IGNvdW50IGJlZm9yZSBkZWxldGlvblxuICBjb25zdCBiZWZvcmVRdWVyeSA9IGBcbiAgICBQUkVGSVggZW52OiA8aHR0cDovL2V4YW1wbGUub3JnL2Vudmlyb25tZW50Lz5cbiAgICBcbiAgICBTRUxFQ1QgKENPVU5UKERJU1RJTkNUID9lbnRpdHkpIGFzID9jb3VudClcbiAgICBXSEVSRSB7XG4gICAgICAke3doZXJlQ2xhdXNlfVxuICAgIH1cbiAgYDtcbiAgXG4gIGNvbnN0IGJlZm9yZVJlc3VsdCA9IGF3YWl0IGNsaWVudC5leGVjdXRlU3BhcnFsUXVlcnkoYmVmb3JlUXVlcnkpO1xuICBjb25zdCBiZWZvcmVDb3VudCA9IHBhcnNlSW50KGJlZm9yZVJlc3VsdC5yZXN1bHRzPy5iaW5kaW5ncz8uWzBdPy5jb3VudD8udmFsdWUgfHwgJzAnKTtcbiAgXG4gIC8vIERlbGV0ZSBlbnRpdGllcyB3aXRoIHNwZWNpZmllZCBwcm9wZXJ0eS92YWx1ZSBhbmQgYWxsIHRoZWlyIGNvbm5lY3Rpb25zXG4gIGNvbnN0IGRlbGV0ZVF1ZXJ5ID0gYFxuICAgIFBSRUZJWCBlbnY6IDxodHRwOi8vZXhhbXBsZS5vcmcvZW52aXJvbm1lbnQvPlxuICAgIFxuICAgIERFTEVURSB7XG4gICAgICA/ZW50aXR5ID9wID9vIC5cbiAgICAgID9zID9xID9lbnRpdHkgLlxuICAgIH1cbiAgICBXSEVSRSB7XG4gICAgICAke3doZXJlQ2xhdXNlfVxuICAgICAgT1BUSU9OQUwgeyA/ZW50aXR5ID9wID9vIH1cbiAgICAgIE9QVElPTkFMIHsgP3MgP3EgP2VudGl0eSB9XG4gICAgfVxuICBgO1xuXG4gIGF3YWl0IGNsaWVudC5leGVjdXRlU3BhcnFsVXBkYXRlKGRlbGV0ZVF1ZXJ5KTtcbiAgXG4gIC8vIEdldCBjb3VudCBhZnRlciBkZWxldGlvblxuICBjb25zdCBhZnRlclJlc3VsdCA9IGF3YWl0IGNsaWVudC5leGVjdXRlU3BhcnFsUXVlcnkoYmVmb3JlUXVlcnkpO1xuICBjb25zdCBhZnRlckNvdW50ID0gcGFyc2VJbnQoYWZ0ZXJSZXN1bHQucmVzdWx0cz8uYmluZGluZ3M/LlswXT8uY291bnQ/LnZhbHVlIHx8ICcwJyk7XG4gIFxuICByZXR1cm4ge1xuICAgIG1lc3NhZ2U6IGBEZWxldGVkICR7YmVmb3JlQ291bnQgLSBhZnRlckNvdW50fSBlbnRpdGllcyB3aXRoIHByb3BlcnR5ICR7cHJvcGVydHl9JHt2YWx1ZSA/IGAgPSAke3ZhbHVlfWAgOiAnJ31gLFxuICAgIHByb3BlcnR5LFxuICAgIHZhbHVlOiB2YWx1ZSB8fCAnYW55JyxcbiAgICBkZWxldGVkQ291bnQ6IGJlZm9yZUNvdW50IC0gYWZ0ZXJDb3VudCxcbiAgICByZW1haW5pbmdDb3VudDogYWZ0ZXJDb3VudCxcbiAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxuICB9O1xufVxuXG4vKipcbiAqIENvdW50IGFsbCBlbnRpdGllcyBieSB0eXBlXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNvdW50RW50aXRpZXMoY2xpZW50OiBOZXB0dW5lU3BhcnFsQ2xpZW50KTogUHJvbWlzZTxhbnk+IHtcbiAgY29uc3QgcXVlcnkgPSBgXG4gICAgUFJFRklYIHJkZjogPGh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyM+XG4gICAgUFJFRklYIGVudjogPGh0dHA6Ly9leGFtcGxlLm9yZy9lbnZpcm9ubWVudC8+XG4gICAgXG4gICAgU0VMRUNUID90eXBlIChDT1VOVCg/ZW50aXR5KSBhcyA/Y291bnQpXG4gICAgV0hFUkUge1xuICAgICAgP2VudGl0eSByZGY6dHlwZSA/dHlwZSAuXG4gICAgICBGSUxURVIoU1RSU1RBUlRTKFNUUig/dHlwZSksIFwiaHR0cDovL2V4YW1wbGUub3JnL2Vudmlyb25tZW50L1wiKSlcbiAgICB9XG4gICAgR1JPVVAgQlkgP3R5cGVcbiAgICBPUkRFUiBCWSBERVNDKD9jb3VudClcbiAgYDtcblxuICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbGllbnQuZXhlY3V0ZVNwYXJxbFF1ZXJ5KHF1ZXJ5KTtcbiAgY29uc3QgYmluZGluZ3MgPSByZXN1bHQucmVzdWx0cz8uYmluZGluZ3MgfHwgW107XG4gIFxuICBjb25zdCBjb3VudHM6IGFueSA9IHt9O1xuICBsZXQgdG90YWwgPSAwO1xuICBcbiAgYmluZGluZ3MuZm9yRWFjaCgoYmluZGluZzogYW55KSA9PiB7XG4gICAgY29uc3QgdHlwZVVyaSA9IGJpbmRpbmcudHlwZT8udmFsdWUgfHwgJyc7XG4gICAgY29uc3QgdHlwZU5hbWUgPSB0eXBlVXJpLnJlcGxhY2UoJ2h0dHA6Ly9leGFtcGxlLm9yZy9lbnZpcm9ubWVudC8nLCAnJyk7XG4gICAgY29uc3QgY291bnQgPSBwYXJzZUludChiaW5kaW5nLmNvdW50Py52YWx1ZSB8fCAnMCcpO1xuICAgIGNvdW50c1t0eXBlTmFtZV0gPSBjb3VudDtcbiAgICB0b3RhbCArPSBjb3VudDtcbiAgfSk7XG4gIFxuICByZXR1cm4ge1xuICAgIHRvdGFsLFxuICAgIGJ5VHlwZTogY291bnRzLFxuICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gIH07XG59XG5cbi8qKlxuICogTGlzdCBhbGwgZW50aXR5IHR5cGVzIGluIHRoZSBkYXRhYmFzZVxuICovXG5hc3luYyBmdW5jdGlvbiBsaXN0RW50aXR5VHlwZXMoY2xpZW50OiBOZXB0dW5lU3BhcnFsQ2xpZW50KTogUHJvbWlzZTxhbnk+IHtcbiAgY29uc3QgcXVlcnkgPSBgXG4gICAgUFJFRklYIHJkZjogPGh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyM+XG4gICAgUFJFRklYIGVudjogPGh0dHA6Ly9leGFtcGxlLm9yZy9lbnZpcm9ubWVudC8+XG4gICAgXG4gICAgU0VMRUNUIERJU1RJTkNUID90eXBlXG4gICAgV0hFUkUge1xuICAgICAgP2VudGl0eSByZGY6dHlwZSA/dHlwZSAuXG4gICAgICBGSUxURVIoU1RSU1RBUlRTKFNUUig/dHlwZSksIFwiaHR0cDovL2V4YW1wbGUub3JnL2Vudmlyb25tZW50L1wiKSlcbiAgICB9XG4gICAgT1JERVIgQlkgP3R5cGVcbiAgYDtcblxuICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbGllbnQuZXhlY3V0ZVNwYXJxbFF1ZXJ5KHF1ZXJ5KTtcbiAgY29uc3QgYmluZGluZ3MgPSByZXN1bHQucmVzdWx0cz8uYmluZGluZ3MgfHwgW107XG4gIFxuICBjb25zdCB0eXBlcyA9IGJpbmRpbmdzLm1hcCgoYmluZGluZzogYW55KSA9PiB7XG4gICAgY29uc3QgdHlwZVVyaSA9IGJpbmRpbmcudHlwZT8udmFsdWUgfHwgJyc7XG4gICAgcmV0dXJuIHR5cGVVcmkucmVwbGFjZSgnaHR0cDovL2V4YW1wbGUub3JnL2Vudmlyb25tZW50LycsICcnKTtcbiAgfSk7XG4gIFxuICByZXR1cm4ge1xuICAgIGVudGl0eVR5cGVzOiB0eXBlcyxcbiAgICBjb3VudDogdHlwZXMubGVuZ3RoLFxuICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gIH07XG59XG5cbi8qKlxuICogRGVsZXRlIGEgc3BlY2lmaWMgZW50aXR5IGJ5IElEXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGRlbGV0ZUVudGl0eShjbGllbnQ6IE5lcHR1bmVTcGFycWxDbGllbnQsIGVudGl0eUlkOiBzdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICBjb25zb2xlLmxvZyhgRGVsZXRpbmcgZW50aXR5IHdpdGggSUQ6ICR7ZW50aXR5SWR9YCk7XG4gIFxuICAvLyBGaXJzdCwgZmluZCB0aGUgZW50aXR5IFVSSSBieSBpdHMgSURcbiAgY29uc3QgZmluZFF1ZXJ5ID0gYFxuICAgIFBSRUZJWCBlbnY6IDxodHRwOi8vbmVwdHVuZS5hd3MuY29tL2Vudm1nbXQvb250b2xvZ3kvPlxuICAgIFxuICAgIFNFTEVDVCA/ZW50aXR5IFdIRVJFIHtcbiAgICAgID9lbnRpdHkgZW52OmlkIFwiJHtlbnRpdHlJZH1cIiAuXG4gICAgfVxuICBgO1xuICBcbiAgY29uc29sZS5sb2coJ0ZpbmRpbmcgZW50aXR5IFVSSTonLCBmaW5kUXVlcnkpO1xuICBjb25zdCBmaW5kUmVzdWx0ID0gYXdhaXQgY2xpZW50LmV4ZWN1dGVTcGFycWxRdWVyeShmaW5kUXVlcnkpO1xuICBcbiAgaWYgKCFmaW5kUmVzdWx0LnJlc3VsdHM/LmJpbmRpbmdzPy5sZW5ndGgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoYEVudGl0eSB3aXRoIElEICR7ZW50aXR5SWR9IG5vdCBmb3VuZCBpbiBOZXB0dW5lYCk7XG4gIH1cbiAgXG4gIGNvbnN0IGVudGl0eVVyaSA9IGZpbmRSZXN1bHQucmVzdWx0cy5iaW5kaW5nc1swXS5lbnRpdHkudmFsdWU7XG4gIGNvbnNvbGUubG9nKGBGb3VuZCBlbnRpdHkgVVJJOiAke2VudGl0eVVyaX1gKTtcbiAgXG4gIC8vIE5vdyBkZWxldGUgdGhlIGVudGl0eSBhbmQgYWxsIGl0cyBjb25uZWN0aW9uc1xuICBjb25zdCBkZWxldGVRdWVyeSA9IGBcbiAgICBQUkVGSVggZW52OiA8aHR0cDovL25lcHR1bmUuYXdzLmNvbS9lbnZtZ210L29udG9sb2d5Lz5cbiAgICBcbiAgICBERUxFVEUge1xuICAgICAgPCR7ZW50aXR5VXJpfT4gP3AgP28gLlxuICAgICAgP3MgP3EgPCR7ZW50aXR5VXJpfT4gLlxuICAgIH1cbiAgICBXSEVSRSB7XG4gICAgICBPUFRJT05BTCB7IDwke2VudGl0eVVyaX0+ID9wID9vIH1cbiAgICAgIE9QVElPTkFMIHsgP3MgP3EgPCR7ZW50aXR5VXJpfT4gfVxuICAgIH1cbiAgYDtcblxuICBjb25zb2xlLmxvZygnRXhlY3V0aW5nIGVudGl0eSBkZWxldGlvbiBxdWVyeTonLCBkZWxldGVRdWVyeSk7XG4gIGF3YWl0IGNsaWVudC5leGVjdXRlU3BhcnFsVXBkYXRlKGRlbGV0ZVF1ZXJ5KTtcbiAgXG4gIHJldHVybiB7XG4gICAgZW50aXR5SWQsXG4gICAgZW50aXR5VXJpLFxuICAgIGRlbGV0ZWQ6IHRydWUsXG4gICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgfTtcbn0iXX0=