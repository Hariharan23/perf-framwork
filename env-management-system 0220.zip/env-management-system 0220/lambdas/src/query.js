"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const neptune_sparql_client_1 = require("../shared/neptune-sparql-client");
const neptuneClient = new neptune_sparql_client_1.NeptuneSparqlClient();
const handler = async (event) => {
    console.log('Event:', JSON.stringify(event, null, 2));
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'http://localhost:3000',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, Accept, Origin, X-Requested-With',
        'Access-Control-Max-Age': '300'
    };
    try {
        // Handle CORS preflight requests
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ message: 'CORS preflight successful' }),
            };
        }
        // Parse request body if present
        let requestBody = {};
        if (event.body) {
            try {
                requestBody = JSON.parse(event.body);
            }
            catch (e) {
                console.warn('Failed to parse request body:', e);
            }
        }
        // Extract operation from path, query parameters, or request body
        const operation = event.pathParameters?.operation ||
            event.queryStringParameters?.operation ||
            requestBody.operation;
        if (!operation) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'Missing operation parameter',
                    availableOperations: [
                        'get-network', 'get-entities', 'get-entity', 'get-configurations',
                        'get-config-entries', 'get-deployments', 'get-environments',
                        'get-applications', 'get-integrations', 'health', 'sparql-query', 'sparql-update'
                    ]
                }),
            };
        }
        let result;
        switch (operation.toLowerCase()) {
            case 'health':
                const isHealthy = await neptuneClient.healthCheck();
                result = {
                    status: isHealthy ? 'healthy' : 'unhealthy',
                    timestamp: new Date().toISOString(),
                    service: 'neptune-query'
                };
                break;
            case 'get-network':
                const networkData = await neptuneClient.getNetworkData();
                result = {
                    networkData,
                    nodeCount: networkData.nodes.length,
                    edgeCount: networkData.edges.length,
                };
                break;
            case 'get-entities':
                const entityType = event.queryStringParameters?.type;
                if (!entityType) {
                    // Get all entity types
                    const [environments, applications, integrations] = await Promise.all([
                        neptuneClient.getEntitiesByType('Environment'),
                        neptuneClient.getEntitiesByType('Application'),
                        neptuneClient.getEntitiesByType('Integration'),
                    ]);
                    result = {
                        entities: {
                            Environment: environments,
                            Application: applications,
                            Integration: integrations,
                        },
                        totalCount: environments.length + applications.length + integrations.length,
                    };
                }
                else {
                    // Get entities of specific type
                    const entities = await neptuneClient.getEntitiesByType(entityType);
                    result = {
                        entities,
                        type: entityType,
                        count: entities.length,
                    };
                }
                break;
            case 'get-entity':
                const entityId = event.queryStringParameters?.id || event.pathParameters?.id;
                if (!entityId) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing entity ID parameter',
                            usage: 'Use ?id=<entity-id> or path parameter'
                        }),
                    };
                }
                const entity = await neptuneClient.getEntityById(entityId);
                if (!entity) {
                    return {
                        statusCode: 404,
                        headers,
                        body: JSON.stringify({
                            error: 'Entity not found',
                            entityId
                        }),
                    };
                }
                result = { entity };
                break;
            case 'get-environments':
                const environments = await neptuneClient.getEntitiesByType('Environment');
                result = {
                    environments,
                    count: environments.length,
                };
                break;
            case 'get-applications':
                const applications = await neptuneClient.getEntitiesByType('Application');
                result = {
                    applications,
                    count: applications.length,
                };
                break;
            case 'get-integrations':
                const integrations = await neptuneClient.getEntitiesByType('Integration');
                result = {
                    integrations,
                    count: integrations.length,
                };
                break;
            case 'get-configurations':
                const configEntityId = event.queryStringParameters?.entityId;
                if (!configEntityId) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing entityId parameter',
                            usage: 'Use ?entityId=<entity-id>'
                        }),
                    };
                }
                const configurations = await neptuneClient.getEntityConfigurations(configEntityId);
                result = {
                    configurations,
                    entityId: configEntityId,
                    count: configurations.length,
                };
                break;
            case 'get-config-entries':
                const configId = event.queryStringParameters?.configId;
                if (!configId) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing configId parameter',
                            usage: 'Use ?configId=<config-id>'
                        }),
                    };
                }
                const configEntries = await neptuneClient.getConfigurationEntries(configId);
                result = {
                    configurationEntries: configEntries,
                    configurationId: configId,
                    count: configEntries.length,
                };
                break;
            case 'get-deployments':
                const envId = event.queryStringParameters?.environmentId;
                if (!envId) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing environmentId parameter',
                            usage: 'Use ?environmentId=<env-id>'
                        }),
                    };
                }
                const deployments = await neptuneClient.getEnvironmentDeployments(envId);
                result = {
                    deployments,
                    environmentId: envId,
                    count: deployments.length,
                };
                break;
            case 'sparql-query':
                if (!requestBody.query) {
                    throw new Error('SPARQL query is required in request body');
                }
                result = await neptuneClient.executeSparqlQuery(requestBody.query);
                break;
            case 'sparql-update':
                if (!requestBody.query) {
                    throw new Error('SPARQL update query is required in request body');
                }
                await neptuneClient.executeSparqlUpdate(requestBody.query);
                result = {
                    message: 'SPARQL update executed successfully',
                    query: requestBody.query,
                };
                break;
            default:
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: `Unknown operation: ${operation}`,
                        availableOperations: [
                            'get-network', 'get-entities', 'get-entity', 'get-configurations',
                            'get-config-entries', 'get-deployments', 'get-environments',
                            'get-applications', 'get-integrations', 'health', 'sparql-query', 'sparql-update'
                        ]
                    }),
                };
        }
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                success: true,
                operation,
                data: result,
                timestamp: new Date().toISOString(),
            }),
        };
    }
    catch (error) {
        console.error('Error processing query request:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'Internal server error',
                message: error instanceof Error ? error.message : 'Unknown error occurred',
                timestamp: new Date().toISOString(),
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicXVlcnkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJxdWVyeS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSwyRUFBMkY7QUFFM0YsTUFBTSxhQUFhLEdBQUcsSUFBSSwyQ0FBbUIsRUFBRSxDQUFDO0FBRXpDLE1BQU0sT0FBTyxHQUFHLEtBQUssRUFBRSxLQUEyQixFQUFrQyxFQUFFO0lBQzNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRXRELE1BQU0sT0FBTyxHQUFHO1FBQ2QsY0FBYyxFQUFFLGtCQUFrQjtRQUNsQyw2QkFBNkIsRUFBRSx1QkFBdUI7UUFDdEQsOEJBQThCLEVBQUUsaUNBQWlDO1FBQ2pFLDhCQUE4QixFQUFFLCtEQUErRDtRQUMvRix3QkFBd0IsRUFBRSxLQUFLO0tBQ2hDLENBQUM7SUFFRixJQUFJO1FBQ0YsaUNBQWlDO1FBQ2pDLElBQUksS0FBSyxDQUFDLFVBQVUsS0FBSyxTQUFTLEVBQUU7WUFDbEMsT0FBTztnQkFDTCxVQUFVLEVBQUUsR0FBRztnQkFDZixPQUFPO2dCQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsT0FBTyxFQUFFLDJCQUEyQixFQUFFLENBQUM7YUFDL0QsQ0FBQztTQUNIO1FBRUQsZ0NBQWdDO1FBQ2hDLElBQUksV0FBVyxHQUFRLEVBQUUsQ0FBQztRQUMxQixJQUFJLEtBQUssQ0FBQyxJQUFJLEVBQUU7WUFDZCxJQUFJO2dCQUNGLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN0QztZQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNWLE9BQU8sQ0FBQyxJQUFJLENBQUMsK0JBQStCLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDbEQ7U0FDRjtRQUVELGlFQUFpRTtRQUNqRSxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsY0FBYyxFQUFFLFNBQVM7WUFDaEMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLFNBQVM7WUFDdEMsV0FBVyxDQUFDLFNBQVMsQ0FBQztRQUV2QyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2QsT0FBTztnQkFDTCxVQUFVLEVBQUUsR0FBRztnQkFDZixPQUFPO2dCQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNuQixLQUFLLEVBQUUsNkJBQTZCO29CQUNwQyxtQkFBbUIsRUFBRTt3QkFDbkIsYUFBYSxFQUFFLGNBQWMsRUFBRSxZQUFZLEVBQUUsb0JBQW9CO3dCQUNqRSxvQkFBb0IsRUFBRSxpQkFBaUIsRUFBRSxrQkFBa0I7d0JBQzNELGtCQUFrQixFQUFFLGtCQUFrQixFQUFFLFFBQVEsRUFBRSxjQUFjLEVBQUUsZUFBZTtxQkFDbEY7aUJBQ0YsQ0FBQzthQUNILENBQUM7U0FDSDtRQUVELElBQUksTUFBVyxDQUFDO1FBRWhCLFFBQVEsU0FBUyxDQUFDLFdBQVcsRUFBRSxFQUFFO1lBQy9CLEtBQUssUUFBUTtnQkFDWCxNQUFNLFNBQVMsR0FBRyxNQUFNLGFBQWEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDcEQsTUFBTSxHQUFHO29CQUNQLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVztvQkFDM0MsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO29CQUNuQyxPQUFPLEVBQUUsZUFBZTtpQkFDekIsQ0FBQztnQkFDRixNQUFNO1lBRVIsS0FBSyxhQUFhO2dCQUNoQixNQUFNLFdBQVcsR0FBZ0IsTUFBTSxhQUFhLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQ3RFLE1BQU0sR0FBRztvQkFDUCxXQUFXO29CQUNYLFNBQVMsRUFBRSxXQUFXLENBQUMsS0FBSyxDQUFDLE1BQU07b0JBQ25DLFNBQVMsRUFBRSxXQUFXLENBQUMsS0FBSyxDQUFDLE1BQU07aUJBQ3BDLENBQUM7Z0JBQ0YsTUFBTTtZQUVSLEtBQUssY0FBYztnQkFDakIsTUFBTSxVQUFVLEdBQUcsS0FBSyxDQUFDLHFCQUFxQixFQUFFLElBQUksQ0FBQztnQkFFckQsSUFBSSxDQUFDLFVBQVUsRUFBRTtvQkFDZix1QkFBdUI7b0JBQ3ZCLE1BQU0sQ0FBQyxZQUFZLEVBQUUsWUFBWSxFQUFFLFlBQVksQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQzt3QkFDbkUsYUFBYSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQzt3QkFDOUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQzt3QkFDOUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQztxQkFDL0MsQ0FBQyxDQUFDO29CQUVILE1BQU0sR0FBRzt3QkFDUCxRQUFRLEVBQUU7NEJBQ1IsV0FBVyxFQUFFLFlBQVk7NEJBQ3pCLFdBQVcsRUFBRSxZQUFZOzRCQUN6QixXQUFXLEVBQUUsWUFBWTt5QkFDMUI7d0JBQ0QsVUFBVSxFQUFFLFlBQVksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUMsTUFBTTtxQkFDNUUsQ0FBQztpQkFDSDtxQkFBTTtvQkFDTCxnQ0FBZ0M7b0JBQ2hDLE1BQU0sUUFBUSxHQUFHLE1BQU0sYUFBYSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUNuRSxNQUFNLEdBQUc7d0JBQ1AsUUFBUTt3QkFDUixJQUFJLEVBQUUsVUFBVTt3QkFDaEIsS0FBSyxFQUFFLFFBQVEsQ0FBQyxNQUFNO3FCQUN2QixDQUFDO2lCQUNIO2dCQUNELE1BQU07WUFFUixLQUFLLFlBQVk7Z0JBQ2YsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLHFCQUFxQixFQUFFLEVBQUUsSUFBSSxLQUFLLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQztnQkFFN0UsSUFBSSxDQUFDLFFBQVEsRUFBRTtvQkFDYixPQUFPO3dCQUNMLFVBQVUsRUFBRSxHQUFHO3dCQUNmLE9BQU87d0JBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ25CLEtBQUssRUFBRSw2QkFBNkI7NEJBQ3BDLEtBQUssRUFBRSx1Q0FBdUM7eUJBQy9DLENBQUM7cUJBQ0gsQ0FBQztpQkFDSDtnQkFFRCxNQUFNLE1BQU0sR0FBRyxNQUFNLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBRTNELElBQUksQ0FBQyxNQUFNLEVBQUU7b0JBQ1gsT0FBTzt3QkFDTCxVQUFVLEVBQUUsR0FBRzt3QkFDZixPQUFPO3dCQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDOzRCQUNuQixLQUFLLEVBQUUsa0JBQWtCOzRCQUN6QixRQUFRO3lCQUNULENBQUM7cUJBQ0gsQ0FBQztpQkFDSDtnQkFFRCxNQUFNLEdBQUcsRUFBRSxNQUFNLEVBQUUsQ0FBQztnQkFDcEIsTUFBTTtZQUVSLEtBQUssa0JBQWtCO2dCQUNyQixNQUFNLFlBQVksR0FBRyxNQUFNLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDMUUsTUFBTSxHQUFHO29CQUNQLFlBQVk7b0JBQ1osS0FBSyxFQUFFLFlBQVksQ0FBQyxNQUFNO2lCQUMzQixDQUFDO2dCQUNGLE1BQU07WUFFUixLQUFLLGtCQUFrQjtnQkFDckIsTUFBTSxZQUFZLEdBQUcsTUFBTSxhQUFhLENBQUMsaUJBQWlCLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQzFFLE1BQU0sR0FBRztvQkFDUCxZQUFZO29CQUNaLEtBQUssRUFBRSxZQUFZLENBQUMsTUFBTTtpQkFDM0IsQ0FBQztnQkFDRixNQUFNO1lBRVIsS0FBSyxrQkFBa0I7Z0JBQ3JCLE1BQU0sWUFBWSxHQUFHLE1BQU0sYUFBYSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUMxRSxNQUFNLEdBQUc7b0JBQ1AsWUFBWTtvQkFDWixLQUFLLEVBQUUsWUFBWSxDQUFDLE1BQU07aUJBQzNCLENBQUM7Z0JBQ0YsTUFBTTtZQUVSLEtBQUssb0JBQW9CO2dCQUN2QixNQUFNLGNBQWMsR0FBRyxLQUFLLENBQUMscUJBQXFCLEVBQUUsUUFBUSxDQUFDO2dCQUU3RCxJQUFJLENBQUMsY0FBYyxFQUFFO29CQUNuQixPQUFPO3dCQUNMLFVBQVUsRUFBRSxHQUFHO3dCQUNmLE9BQU87d0JBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ25CLEtBQUssRUFBRSw0QkFBNEI7NEJBQ25DLEtBQUssRUFBRSwyQkFBMkI7eUJBQ25DLENBQUM7cUJBQ0gsQ0FBQztpQkFDSDtnQkFFRCxNQUFNLGNBQWMsR0FBRyxNQUFNLGFBQWEsQ0FBQyx1QkFBdUIsQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDbkYsTUFBTSxHQUFHO29CQUNQLGNBQWM7b0JBQ2QsUUFBUSxFQUFFLGNBQWM7b0JBQ3hCLEtBQUssRUFBRSxjQUFjLENBQUMsTUFBTTtpQkFDN0IsQ0FBQztnQkFDRixNQUFNO1lBRVIsS0FBSyxvQkFBb0I7Z0JBQ3ZCLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxRQUFRLENBQUM7Z0JBRXZELElBQUksQ0FBQyxRQUFRLEVBQUU7b0JBQ2IsT0FBTzt3QkFDTCxVQUFVLEVBQUUsR0FBRzt3QkFDZixPQUFPO3dCQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDOzRCQUNuQixLQUFLLEVBQUUsNEJBQTRCOzRCQUNuQyxLQUFLLEVBQUUsMkJBQTJCO3lCQUNuQyxDQUFDO3FCQUNILENBQUM7aUJBQ0g7Z0JBRUQsTUFBTSxhQUFhLEdBQUcsTUFBTSxhQUFhLENBQUMsdUJBQXVCLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzVFLE1BQU0sR0FBRztvQkFDUCxvQkFBb0IsRUFBRSxhQUFhO29CQUNuQyxlQUFlLEVBQUUsUUFBUTtvQkFDekIsS0FBSyxFQUFFLGFBQWEsQ0FBQyxNQUFNO2lCQUM1QixDQUFDO2dCQUNGLE1BQU07WUFFUixLQUFLLGlCQUFpQjtnQkFDcEIsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLHFCQUFxQixFQUFFLGFBQWEsQ0FBQztnQkFFekQsSUFBSSxDQUFDLEtBQUssRUFBRTtvQkFDVixPQUFPO3dCQUNMLFVBQVUsRUFBRSxHQUFHO3dCQUNmLE9BQU87d0JBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ25CLEtBQUssRUFBRSxpQ0FBaUM7NEJBQ3hDLEtBQUssRUFBRSw2QkFBNkI7eUJBQ3JDLENBQUM7cUJBQ0gsQ0FBQztpQkFDSDtnQkFFRCxNQUFNLFdBQVcsR0FBRyxNQUFNLGFBQWEsQ0FBQyx5QkFBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDekUsTUFBTSxHQUFHO29CQUNQLFdBQVc7b0JBQ1gsYUFBYSxFQUFFLEtBQUs7b0JBQ3BCLEtBQUssRUFBRSxXQUFXLENBQUMsTUFBTTtpQkFDMUIsQ0FBQztnQkFDRixNQUFNO1lBRVIsS0FBSyxjQUFjO2dCQUNqQixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRTtvQkFDdEIsTUFBTSxJQUFJLEtBQUssQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDO2lCQUM3RDtnQkFDRCxNQUFNLEdBQUcsTUFBTSxhQUFhLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuRSxNQUFNO1lBRVIsS0FBSyxlQUFlO2dCQUNsQixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRTtvQkFDdEIsTUFBTSxJQUFJLEtBQUssQ0FBQyxpREFBaUQsQ0FBQyxDQUFDO2lCQUNwRTtnQkFDRCxNQUFNLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzNELE1BQU0sR0FBRztvQkFDUCxPQUFPLEVBQUUscUNBQXFDO29CQUM5QyxLQUFLLEVBQUUsV0FBVyxDQUFDLEtBQUs7aUJBQ3pCLENBQUM7Z0JBQ0YsTUFBTTtZQUVSO2dCQUNFLE9BQU87b0JBQ0wsVUFBVSxFQUFFLEdBQUc7b0JBQ2YsT0FBTztvQkFDUCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQzt3QkFDbkIsS0FBSyxFQUFFLHNCQUFzQixTQUFTLEVBQUU7d0JBQ3hDLG1CQUFtQixFQUFFOzRCQUNuQixhQUFhLEVBQUUsY0FBYyxFQUFFLFlBQVksRUFBRSxvQkFBb0I7NEJBQ2pFLG9CQUFvQixFQUFFLGlCQUFpQixFQUFFLGtCQUFrQjs0QkFDM0Qsa0JBQWtCLEVBQUUsa0JBQWtCLEVBQUUsUUFBUSxFQUFFLGNBQWMsRUFBRSxlQUFlO3lCQUNsRjtxQkFDRixDQUFDO2lCQUNILENBQUM7U0FDTDtRQUVELE9BQU87WUFDTCxVQUFVLEVBQUUsR0FBRztZQUNmLE9BQU87WUFDUCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDbkIsT0FBTyxFQUFFLElBQUk7Z0JBQ2IsU0FBUztnQkFDVCxJQUFJLEVBQUUsTUFBTTtnQkFDWixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7YUFDcEMsQ0FBQztTQUNILENBQUM7S0FFSDtJQUFDLE9BQU8sS0FBSyxFQUFFO1FBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV4RCxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixPQUFPO1lBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ25CLEtBQUssRUFBRSx1QkFBdUI7Z0JBQzlCLE9BQU8sRUFBRSxLQUFLLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyx3QkFBd0I7Z0JBQzFFLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTthQUNwQyxDQUFDO1NBQ0gsQ0FBQztLQUNIO0FBQ0gsQ0FBQyxDQUFDO0FBdlJXLFFBQUEsT0FBTyxXQXVSbEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBUElHYXRld2F5UHJveHlFdmVudCwgQVBJR2F0ZXdheVByb3h5UmVzdWx0IH0gZnJvbSAnYXdzLWxhbWJkYSc7XG5pbXBvcnQgeyBOZXB0dW5lU3BhcnFsQ2xpZW50LCBOZXR3b3JrRGF0YSwgRW50aXR5IH0gZnJvbSAnLi4vc2hhcmVkL25lcHR1bmUtc3BhcnFsLWNsaWVudCc7XG5cbmNvbnN0IG5lcHR1bmVDbGllbnQgPSBuZXcgTmVwdHVuZVNwYXJxbENsaWVudCgpO1xuXG5leHBvcnQgY29uc3QgaGFuZGxlciA9IGFzeW5jIChldmVudDogQVBJR2F0ZXdheVByb3h5RXZlbnQpOiBQcm9taXNlPEFQSUdhdGV3YXlQcm94eVJlc3VsdD4gPT4ge1xuICBjb25zb2xlLmxvZygnRXZlbnQ6JywgSlNPTi5zdHJpbmdpZnkoZXZlbnQsIG51bGwsIDIpKTtcbiAgXG4gIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMCcsXG4gICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnR0VULCBQT1NULCBQVVQsIERFTEVURSwgT1BUSU9OUycsXG4gICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnMnOiAnQ29udGVudC1UeXBlLCBBdXRob3JpemF0aW9uLCBBY2NlcHQsIE9yaWdpbiwgWC1SZXF1ZXN0ZWQtV2l0aCcsXG4gICAgJ0FjY2Vzcy1Db250cm9sLU1heC1BZ2UnOiAnMzAwJ1xuICB9O1xuXG4gIHRyeSB7XG4gICAgLy8gSGFuZGxlIENPUlMgcHJlZmxpZ2h0IHJlcXVlc3RzXG4gICAgaWYgKGV2ZW50Lmh0dHBNZXRob2QgPT09ICdPUFRJT05TJykge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBoZWFkZXJzLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IG1lc3NhZ2U6ICdDT1JTIHByZWZsaWdodCBzdWNjZXNzZnVsJyB9KSxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgLy8gUGFyc2UgcmVxdWVzdCBib2R5IGlmIHByZXNlbnRcbiAgICBsZXQgcmVxdWVzdEJvZHk6IGFueSA9IHt9O1xuICAgIGlmIChldmVudC5ib2R5KSB7XG4gICAgICB0cnkge1xuICAgICAgICByZXF1ZXN0Qm9keSA9IEpTT04ucGFyc2UoZXZlbnQuYm9keSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignRmFpbGVkIHRvIHBhcnNlIHJlcXVlc3QgYm9keTonLCBlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBFeHRyYWN0IG9wZXJhdGlvbiBmcm9tIHBhdGgsIHF1ZXJ5IHBhcmFtZXRlcnMsIG9yIHJlcXVlc3QgYm9keVxuICAgIGNvbnN0IG9wZXJhdGlvbiA9IGV2ZW50LnBhdGhQYXJhbWV0ZXJzPy5vcGVyYXRpb24gfHwgXG4gICAgICAgICAgICAgICAgICAgICBldmVudC5xdWVyeVN0cmluZ1BhcmFtZXRlcnM/Lm9wZXJhdGlvbiB8fCBcbiAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3RCb2R5Lm9wZXJhdGlvbjtcbiAgICBcbiAgICBpZiAoIW9wZXJhdGlvbikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICBoZWFkZXJzLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIGVycm9yOiAnTWlzc2luZyBvcGVyYXRpb24gcGFyYW1ldGVyJyxcbiAgICAgICAgICBhdmFpbGFibGVPcGVyYXRpb25zOiBbXG4gICAgICAgICAgICAnZ2V0LW5ldHdvcmsnLCAnZ2V0LWVudGl0aWVzJywgJ2dldC1lbnRpdHknLCAnZ2V0LWNvbmZpZ3VyYXRpb25zJywgXG4gICAgICAgICAgICAnZ2V0LWNvbmZpZy1lbnRyaWVzJywgJ2dldC1kZXBsb3ltZW50cycsICdnZXQtZW52aXJvbm1lbnRzJywgXG4gICAgICAgICAgICAnZ2V0LWFwcGxpY2F0aW9ucycsICdnZXQtaW50ZWdyYXRpb25zJywgJ2hlYWx0aCcsICdzcGFycWwtcXVlcnknLCAnc3BhcnFsLXVwZGF0ZSdcbiAgICAgICAgICBdXG4gICAgICAgIH0pLFxuICAgICAgfTtcbiAgICB9XG5cbiAgICBsZXQgcmVzdWx0OiBhbnk7XG5cbiAgICBzd2l0Y2ggKG9wZXJhdGlvbi50b0xvd2VyQ2FzZSgpKSB7XG4gICAgICBjYXNlICdoZWFsdGgnOlxuICAgICAgICBjb25zdCBpc0hlYWx0aHkgPSBhd2FpdCBuZXB0dW5lQ2xpZW50LmhlYWx0aENoZWNrKCk7XG4gICAgICAgIHJlc3VsdCA9IHsgXG4gICAgICAgICAgc3RhdHVzOiBpc0hlYWx0aHkgPyAnaGVhbHRoeScgOiAndW5oZWFsdGh5JyxcbiAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICBzZXJ2aWNlOiAnbmVwdHVuZS1xdWVyeSdcbiAgICAgICAgfTtcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgJ2dldC1uZXR3b3JrJzpcbiAgICAgICAgY29uc3QgbmV0d29ya0RhdGE6IE5ldHdvcmtEYXRhID0gYXdhaXQgbmVwdHVuZUNsaWVudC5nZXROZXR3b3JrRGF0YSgpO1xuICAgICAgICByZXN1bHQgPSB7XG4gICAgICAgICAgbmV0d29ya0RhdGEsXG4gICAgICAgICAgbm9kZUNvdW50OiBuZXR3b3JrRGF0YS5ub2Rlcy5sZW5ndGgsXG4gICAgICAgICAgZWRnZUNvdW50OiBuZXR3b3JrRGF0YS5lZGdlcy5sZW5ndGgsXG4gICAgICAgIH07XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlICdnZXQtZW50aXRpZXMnOlxuICAgICAgICBjb25zdCBlbnRpdHlUeXBlID0gZXZlbnQucXVlcnlTdHJpbmdQYXJhbWV0ZXJzPy50eXBlO1xuICAgICAgICBcbiAgICAgICAgaWYgKCFlbnRpdHlUeXBlKSB7XG4gICAgICAgICAgLy8gR2V0IGFsbCBlbnRpdHkgdHlwZXNcbiAgICAgICAgICBjb25zdCBbZW52aXJvbm1lbnRzLCBhcHBsaWNhdGlvbnMsIGludGVncmF0aW9uc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICBuZXB0dW5lQ2xpZW50LmdldEVudGl0aWVzQnlUeXBlKCdFbnZpcm9ubWVudCcpLFxuICAgICAgICAgICAgbmVwdHVuZUNsaWVudC5nZXRFbnRpdGllc0J5VHlwZSgnQXBwbGljYXRpb24nKSxcbiAgICAgICAgICAgIG5lcHR1bmVDbGllbnQuZ2V0RW50aXRpZXNCeVR5cGUoJ0ludGVncmF0aW9uJyksXG4gICAgICAgICAgXSk7XG4gICAgICAgICAgXG4gICAgICAgICAgcmVzdWx0ID0ge1xuICAgICAgICAgICAgZW50aXRpZXM6IHtcbiAgICAgICAgICAgICAgRW52aXJvbm1lbnQ6IGVudmlyb25tZW50cyxcbiAgICAgICAgICAgICAgQXBwbGljYXRpb246IGFwcGxpY2F0aW9ucyxcbiAgICAgICAgICAgICAgSW50ZWdyYXRpb246IGludGVncmF0aW9ucyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0b3RhbENvdW50OiBlbnZpcm9ubWVudHMubGVuZ3RoICsgYXBwbGljYXRpb25zLmxlbmd0aCArIGludGVncmF0aW9ucy5sZW5ndGgsXG4gICAgICAgICAgfTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBHZXQgZW50aXRpZXMgb2Ygc3BlY2lmaWMgdHlwZVxuICAgICAgICAgIGNvbnN0IGVudGl0aWVzID0gYXdhaXQgbmVwdHVuZUNsaWVudC5nZXRFbnRpdGllc0J5VHlwZShlbnRpdHlUeXBlKTtcbiAgICAgICAgICByZXN1bHQgPSB7XG4gICAgICAgICAgICBlbnRpdGllcyxcbiAgICAgICAgICAgIHR5cGU6IGVudGl0eVR5cGUsXG4gICAgICAgICAgICBjb3VudDogZW50aXRpZXMubGVuZ3RoLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgJ2dldC1lbnRpdHknOlxuICAgICAgICBjb25zdCBlbnRpdHlJZCA9IGV2ZW50LnF1ZXJ5U3RyaW5nUGFyYW1ldGVycz8uaWQgfHwgZXZlbnQucGF0aFBhcmFtZXRlcnM/LmlkO1xuICAgICAgICBcbiAgICAgICAgaWYgKCFlbnRpdHlJZCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDAsXG4gICAgICAgICAgICBoZWFkZXJzLFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgICAgZXJyb3I6ICdNaXNzaW5nIGVudGl0eSBJRCBwYXJhbWV0ZXInLFxuICAgICAgICAgICAgICB1c2FnZTogJ1VzZSA/aWQ9PGVudGl0eS1pZD4gb3IgcGF0aCBwYXJhbWV0ZXInXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZW50aXR5ID0gYXdhaXQgbmVwdHVuZUNsaWVudC5nZXRFbnRpdHlCeUlkKGVudGl0eUlkKTtcbiAgICAgICAgXG4gICAgICAgIGlmICghZW50aXR5KSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwNCxcbiAgICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgICBlcnJvcjogJ0VudGl0eSBub3QgZm91bmQnLFxuICAgICAgICAgICAgICBlbnRpdHlJZCBcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICByZXN1bHQgPSB7IGVudGl0eSB9O1xuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnZ2V0LWVudmlyb25tZW50cyc6XG4gICAgICAgIGNvbnN0IGVudmlyb25tZW50cyA9IGF3YWl0IG5lcHR1bmVDbGllbnQuZ2V0RW50aXRpZXNCeVR5cGUoJ0Vudmlyb25tZW50Jyk7XG4gICAgICAgIHJlc3VsdCA9IHtcbiAgICAgICAgICBlbnZpcm9ubWVudHMsXG4gICAgICAgICAgY291bnQ6IGVudmlyb25tZW50cy5sZW5ndGgsXG4gICAgICAgIH07XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlICdnZXQtYXBwbGljYXRpb25zJzpcbiAgICAgICAgY29uc3QgYXBwbGljYXRpb25zID0gYXdhaXQgbmVwdHVuZUNsaWVudC5nZXRFbnRpdGllc0J5VHlwZSgnQXBwbGljYXRpb24nKTtcbiAgICAgICAgcmVzdWx0ID0ge1xuICAgICAgICAgIGFwcGxpY2F0aW9ucyxcbiAgICAgICAgICBjb3VudDogYXBwbGljYXRpb25zLmxlbmd0aCxcbiAgICAgICAgfTtcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgJ2dldC1pbnRlZ3JhdGlvbnMnOlxuICAgICAgICBjb25zdCBpbnRlZ3JhdGlvbnMgPSBhd2FpdCBuZXB0dW5lQ2xpZW50LmdldEVudGl0aWVzQnlUeXBlKCdJbnRlZ3JhdGlvbicpO1xuICAgICAgICByZXN1bHQgPSB7XG4gICAgICAgICAgaW50ZWdyYXRpb25zLFxuICAgICAgICAgIGNvdW50OiBpbnRlZ3JhdGlvbnMubGVuZ3RoLFxuICAgICAgICB9O1xuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnZ2V0LWNvbmZpZ3VyYXRpb25zJzpcbiAgICAgICAgY29uc3QgY29uZmlnRW50aXR5SWQgPSBldmVudC5xdWVyeVN0cmluZ1BhcmFtZXRlcnM/LmVudGl0eUlkO1xuICAgICAgICBcbiAgICAgICAgaWYgKCFjb25maWdFbnRpdHlJZCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDAsXG4gICAgICAgICAgICBoZWFkZXJzLFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgICAgZXJyb3I6ICdNaXNzaW5nIGVudGl0eUlkIHBhcmFtZXRlcicsXG4gICAgICAgICAgICAgIHVzYWdlOiAnVXNlID9lbnRpdHlJZD08ZW50aXR5LWlkPidcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBjb25maWd1cmF0aW9ucyA9IGF3YWl0IG5lcHR1bmVDbGllbnQuZ2V0RW50aXR5Q29uZmlndXJhdGlvbnMoY29uZmlnRW50aXR5SWQpO1xuICAgICAgICByZXN1bHQgPSB7XG4gICAgICAgICAgY29uZmlndXJhdGlvbnMsXG4gICAgICAgICAgZW50aXR5SWQ6IGNvbmZpZ0VudGl0eUlkLFxuICAgICAgICAgIGNvdW50OiBjb25maWd1cmF0aW9ucy5sZW5ndGgsXG4gICAgICAgIH07XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlICdnZXQtY29uZmlnLWVudHJpZXMnOlxuICAgICAgICBjb25zdCBjb25maWdJZCA9IGV2ZW50LnF1ZXJ5U3RyaW5nUGFyYW1ldGVycz8uY29uZmlnSWQ7XG4gICAgICAgIFxuICAgICAgICBpZiAoIWNvbmZpZ0lkKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwMCxcbiAgICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgICBlcnJvcjogJ01pc3NpbmcgY29uZmlnSWQgcGFyYW1ldGVyJyxcbiAgICAgICAgICAgICAgdXNhZ2U6ICdVc2UgP2NvbmZpZ0lkPTxjb25maWctaWQ+J1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGNvbmZpZ0VudHJpZXMgPSBhd2FpdCBuZXB0dW5lQ2xpZW50LmdldENvbmZpZ3VyYXRpb25FbnRyaWVzKGNvbmZpZ0lkKTtcbiAgICAgICAgcmVzdWx0ID0ge1xuICAgICAgICAgIGNvbmZpZ3VyYXRpb25FbnRyaWVzOiBjb25maWdFbnRyaWVzLFxuICAgICAgICAgIGNvbmZpZ3VyYXRpb25JZDogY29uZmlnSWQsXG4gICAgICAgICAgY291bnQ6IGNvbmZpZ0VudHJpZXMubGVuZ3RoLFxuICAgICAgICB9O1xuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnZ2V0LWRlcGxveW1lbnRzJzpcbiAgICAgICAgY29uc3QgZW52SWQgPSBldmVudC5xdWVyeVN0cmluZ1BhcmFtZXRlcnM/LmVudmlyb25tZW50SWQ7XG4gICAgICAgIFxuICAgICAgICBpZiAoIWVudklkKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwMCxcbiAgICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgICBlcnJvcjogJ01pc3NpbmcgZW52aXJvbm1lbnRJZCBwYXJhbWV0ZXInLFxuICAgICAgICAgICAgICB1c2FnZTogJ1VzZSA/ZW52aXJvbm1lbnRJZD08ZW52LWlkPidcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkZXBsb3ltZW50cyA9IGF3YWl0IG5lcHR1bmVDbGllbnQuZ2V0RW52aXJvbm1lbnREZXBsb3ltZW50cyhlbnZJZCk7XG4gICAgICAgIHJlc3VsdCA9IHtcbiAgICAgICAgICBkZXBsb3ltZW50cyxcbiAgICAgICAgICBlbnZpcm9ubWVudElkOiBlbnZJZCxcbiAgICAgICAgICBjb3VudDogZGVwbG95bWVudHMubGVuZ3RoLFxuICAgICAgICB9O1xuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnc3BhcnFsLXF1ZXJ5JzpcbiAgICAgICAgaWYgKCFyZXF1ZXN0Qm9keS5xdWVyeSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcignU1BBUlFMIHF1ZXJ5IGlzIHJlcXVpcmVkIGluIHJlcXVlc3QgYm9keScpO1xuICAgICAgICB9XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IG5lcHR1bmVDbGllbnQuZXhlY3V0ZVNwYXJxbFF1ZXJ5KHJlcXVlc3RCb2R5LnF1ZXJ5KTtcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgJ3NwYXJxbC11cGRhdGUnOlxuICAgICAgICBpZiAoIXJlcXVlc3RCb2R5LnF1ZXJ5KSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdTUEFSUUwgdXBkYXRlIHF1ZXJ5IGlzIHJlcXVpcmVkIGluIHJlcXVlc3QgYm9keScpO1xuICAgICAgICB9XG4gICAgICAgIGF3YWl0IG5lcHR1bmVDbGllbnQuZXhlY3V0ZVNwYXJxbFVwZGF0ZShyZXF1ZXN0Qm9keS5xdWVyeSk7XG4gICAgICAgIHJlc3VsdCA9IHtcbiAgICAgICAgICBtZXNzYWdlOiAnU1BBUlFMIHVwZGF0ZSBleGVjdXRlZCBzdWNjZXNzZnVsbHknLFxuICAgICAgICAgIHF1ZXJ5OiByZXF1ZXN0Qm9keS5xdWVyeSxcbiAgICAgICAgfTtcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgIGVycm9yOiBgVW5rbm93biBvcGVyYXRpb246ICR7b3BlcmF0aW9ufWAsXG4gICAgICAgICAgICBhdmFpbGFibGVPcGVyYXRpb25zOiBbXG4gICAgICAgICAgICAgICdnZXQtbmV0d29yaycsICdnZXQtZW50aXRpZXMnLCAnZ2V0LWVudGl0eScsICdnZXQtY29uZmlndXJhdGlvbnMnLCBcbiAgICAgICAgICAgICAgJ2dldC1jb25maWctZW50cmllcycsICdnZXQtZGVwbG95bWVudHMnLCAnZ2V0LWVudmlyb25tZW50cycsIFxuICAgICAgICAgICAgICAnZ2V0LWFwcGxpY2F0aW9ucycsICdnZXQtaW50ZWdyYXRpb25zJywgJ2hlYWx0aCcsICdzcGFycWwtcXVlcnknLCAnc3BhcnFsLXVwZGF0ZSdcbiAgICAgICAgICAgIF1cbiAgICAgICAgICB9KSxcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgaGVhZGVycyxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgb3BlcmF0aW9uLFxuICAgICAgICBkYXRhOiByZXN1bHQsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfSksXG4gICAgfTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHByb2Nlc3NpbmcgcXVlcnkgcmVxdWVzdDonLCBlcnJvcik7XG4gICAgXG4gICAgcmV0dXJuIHtcbiAgICAgIHN0YXR1c0NvZGU6IDUwMCxcbiAgICAgIGhlYWRlcnMsXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIGVycm9yOiAnSW50ZXJuYWwgc2VydmVyIGVycm9yJyxcbiAgICAgICAgbWVzc2FnZTogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvciBvY2N1cnJlZCcsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfSksXG4gICAgfTtcbiAgfVxufTsiXX0=