"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const neptune_sparql_client_1 = require("../shared/neptune-sparql-client");
const neptuneClient = new neptune_sparql_client_1.NeptuneSparqlClient();
const handler = async (event) => {
    console.log('Event:', JSON.stringify(event, null, 2));
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'http://localhost:3000',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, Accept, Origin, X-Requested-With',
        'Access-Control-Max-Age': '300'
    };
    try {
        // Handle CORS preflight requests
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ message: 'CORS preflight successful' }),
            };
        }
        // Parse request body if present
        let body = {};
        if (event.body) {
            try {
                body = JSON.parse(event.body);
            }
            catch (parseError) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: 'Invalid JSON in request body' }),
                };
            }
        }
        // Extract operation from path, query parameters, or request body
        const operation = event.pathParameters?.operation ||
            event.queryStringParameters?.operation ||
            body.operation;
        if (!operation) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'Missing operation parameter',
                    availableOperations: [
                        'create-environment', 'create-application', 'create-integration',
                        'create-environment-config', 'create-application-config', 'create-integration-config',
                        'create-config-entry', 'create-deployment', 'initialize-ontology', 'health', 'create',
                        'update-entity', 'bulk-ingest'
                    ]
                }),
            };
        }
        let result;
        switch (operation.toLowerCase()) {
            case 'health':
                const isHealthy = await neptuneClient.healthCheck();
                result = {
                    status: isHealthy ? 'healthy' : 'unhealthy',
                    timestamp: new Date().toISOString(),
                    service: 'neptune-ingestion'
                };
                break;
            case 'create':
                // Generic create operation that determines entity type from body
                if (!body.type || !body.name) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing required fields: type, name',
                            received: body,
                            supportedTypes: ['Environment', 'Application', 'Integration']
                        }),
                    };
                }
                // Route to specific create operation based on type
                switch (body.type.toLowerCase()) {
                    case 'environment':
                        const env = {
                            name: body.name,
                            type: 'Environment',
                            uniqueIdentifier: body.uniqueIdentifier,
                            owner: body.owner,
                            description: body.description
                        };
                        result = await neptuneClient.createEnvironment(env);
                        // Store entity-specific properties as config_ properties
                        const entityConfig = {};
                        if (body.region)
                            entityConfig.region = body.region;
                        if (body.endpoint)
                            entityConfig.endpoint = body.endpoint;
                        // Add custom configurations if provided
                        if (body.configurations && typeof body.configurations === 'object') {
                            Object.assign(entityConfig, body.configurations);
                        }
                        // Store all configurations with config_ prefix
                        if (Object.keys(entityConfig).length > 0) {
                            try {
                                console.log(`Attempting to add ${Object.keys(entityConfig).length} configuration properties to environment ${result.id}`);
                                console.log('Configuration data:', JSON.stringify(entityConfig));
                                await neptuneClient.addConfigurationProperties(result.id, entityConfig);
                                console.log(`Successfully added configuration properties to environment ${result.id}`);
                            }
                            catch (configError) {
                                console.error(`Failed to add configuration properties to environment ${result.id}:`, configError);
                                // Include this in the response so the user knows
                                result.configurationWarning = `Warning: Entity created but configurations could not be saved: ${configError instanceof Error ? configError.message : 'Unknown error'}`;
                            }
                        }
                        // Create relationships if provided
                        if (body.relationships && Array.isArray(body.relationships)) {
                            for (const rel of body.relationships) {
                                try {
                                    await neptuneClient.createRelationship(body.name, rel.type, rel.target);
                                }
                                catch (relError) {
                                    console.warn(`Failed to create relationship ${rel.type} to ${rel.target}:`, relError);
                                }
                            }
                        }
                        break;
                    case 'application':
                        const app = {
                            name: body.name,
                            type: 'Application',
                            owner: body.owner,
                            description: body.description
                        };
                        result = await neptuneClient.createApplication(app);
                        // Store entity-specific properties as config_ properties
                        const appConfig = {};
                        if (body.version)
                            appConfig.version = body.version;
                        if (body.endpoint)
                            appConfig.endpoint = body.endpoint;
                        // Add custom configurations if provided
                        if (body.configurations && typeof body.configurations === 'object') {
                            Object.assign(appConfig, body.configurations);
                        }
                        // Store all configurations with config_ prefix
                        if (Object.keys(appConfig).length > 0) {
                            try {
                                console.log(`Attempting to add ${Object.keys(appConfig).length} configuration properties to application ${result.id}`);
                                console.log('Configuration data:', JSON.stringify(appConfig));
                                await neptuneClient.addConfigurationProperties(result.id, appConfig);
                                console.log(`Successfully added configuration properties to application ${result.id}`);
                            }
                            catch (configError) {
                                console.error(`Failed to add configuration properties to application ${result.id}:`, configError);
                                result.configurationWarning = `Warning: Entity created but configurations could not be saved: ${configError instanceof Error ? configError.message : 'Unknown error'}`;
                            }
                        }
                        // Create relationships if provided
                        if (body.relationships && Array.isArray(body.relationships)) {
                            for (const rel of body.relationships) {
                                try {
                                    await neptuneClient.createRelationship(body.name, rel.type, rel.target);
                                }
                                catch (relError) {
                                    console.warn(`Failed to create relationship ${rel.type} to ${rel.target}:`, relError);
                                }
                            }
                        }
                        break;
                    case 'integration':
                        const integration = {
                            name: body.name,
                            type: 'Integration',
                            owner: body.owner,
                            description: body.description
                        };
                        result = await neptuneClient.createIntegration(integration);
                        // Store entity-specific properties as config_ properties
                        const intConfig = {};
                        if (body.sourceService)
                            intConfig.sourceService = body.sourceService;
                        if (body.targetService)
                            intConfig.targetService = body.targetService;
                        if (body.protocol)
                            intConfig.protocol = body.protocol;
                        // Add custom configurations if provided
                        if (body.configurations && typeof body.configurations === 'object') {
                            Object.assign(intConfig, body.configurations);
                        }
                        // Store all configurations with config_ prefix
                        if (Object.keys(intConfig).length > 0) {
                            try {
                                console.log(`Attempting to add ${Object.keys(intConfig).length} configuration properties to integration ${result.id}`);
                                console.log('Configuration data:', JSON.stringify(intConfig));
                                await neptuneClient.addConfigurationProperties(result.id, intConfig);
                                console.log(`Successfully added configuration properties to integration ${result.id}`);
                            }
                            catch (configError) {
                                console.error(`Failed to add configuration properties to integration ${result.id}:`, configError);
                                result.configurationWarning = `Warning: Entity created but configurations could not be saved: ${configError instanceof Error ? configError.message : 'Unknown error'}`;
                            }
                        }
                        // Create relationships if provided
                        if (body.relationships && Array.isArray(body.relationships)) {
                            for (const rel of body.relationships) {
                                try {
                                    await neptuneClient.createRelationship(body.name, rel.type, rel.target);
                                }
                                catch (relError) {
                                    console.warn(`Failed to create relationship ${rel.type} to ${rel.target}:`, relError);
                                }
                            }
                        }
                        break;
                    default:
                        return {
                            statusCode: 400,
                            headers,
                            body: JSON.stringify({
                                error: 'Unsupported entity type',
                                received: body.type,
                                supported: ['Environment', 'Application', 'Integration']
                            }),
                        };
                }
                break;
            case 'create-environment':
                if (!body.name) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing required fields: name',
                            received: body
                        }),
                    };
                }
                const environment = {
                    name: body.name,
                    type: 'Environment',
                    uniqueIdentifier: body.uniqueIdentifier,
                    owner: body.owner,
                    description: body.description || `Environment ${body.name}`,
                    status: body.status || 'active',
                };
                result = await neptuneClient.createEnvironment(environment);
                break;
            case 'create-application':
                if (!body.name) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing required field: name',
                            received: body
                        }),
                    };
                }
                const application = {
                    name: body.name,
                    type: 'Application',
                    uniqueIdentifier: body.uniqueIdentifier,
                    owner: body.owner,
                    description: body.description || `Application ${body.name}`,
                    status: body.status || 'active',
                };
                result = await neptuneClient.createApplication(application);
                break;
            case 'create-integration':
                if (!body.name) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing required field: name',
                            received: body
                        }),
                    };
                }
                const integration = {
                    name: body.name,
                    type: 'Integration',
                    uniqueIdentifier: body.uniqueIdentifier,
                    owner: body.owner,
                    description: body.description || `Integration: ${body.name}`,
                    status: body.status || 'active',
                };
                result = await neptuneClient.createIntegration(integration);
                break;
            case 'create-environment-config':
                if (!body.entityId) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({ error: 'Missing entityId for environment configuration' }),
                    };
                }
                const envConfig = await neptuneClient.createEnvironmentConfiguration({
                    type: 'EnvironmentConfiguration',
                    configurationMap: body.configurationMap,
                }, body.entityId);
                result = envConfig;
                break;
            case 'create-application-config':
                if (!body.entityId) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({ error: 'Missing entityId for application configuration' }),
                    };
                }
                const appConfig = await neptuneClient.createApplicationConfiguration({
                    type: 'ApplicationConfiguration',
                    configurationMap: body.configurationMap,
                }, body.entityId);
                result = appConfig;
                break;
            case 'create-integration-config':
                if (!body.entityId) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({ error: 'Missing entityId for integration configuration' }),
                    };
                }
                const intConfig = await neptuneClient.createIntegrationConfiguration({
                    type: 'IntegrationConfiguration',
                    configurationMap: body.configurationMap,
                    sourceService: body.sourceService,
                    targetService: body.targetService,
                }, body.entityId);
                result = intConfig;
                break;
            case 'create-config-entry':
                if (!body.configurationId || !body.key || !body.value) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing required fields: configurationId, key, value'
                        }),
                    };
                }
                const configEntry = await neptuneClient.createConfigurationEntry({
                    configurationKey: body.key,
                    configurationValue: body.value,
                    configurationType: body.type,
                }, body.configurationId);
                result = configEntry;
                break;
            case 'create-deployment':
                if (!body.applicationId || !body.environmentId) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing required fields: applicationId, environmentId'
                        }),
                    };
                }
                await neptuneClient.createDeployment(body.applicationId, body.environmentId);
                result = {
                    message: 'Deployment relationship created successfully',
                    applicationId: body.applicationId,
                    environmentId: body.environmentId
                };
                break;
            case 'initialize-ontology':
                await neptuneClient.initializeOntology();
                result = {
                    message: 'Ontology initialized successfully',
                    timestamp: new Date().toISOString()
                };
                break;
            case 'create-relationship':
                const { sourceEntityName, relationshipType, targetEntityName } = body;
                if (!sourceEntityName || !relationshipType || !targetEntityName) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing required fields: sourceEntityName, relationshipType, targetEntityName',
                            received: body
                        }),
                    };
                }
                try {
                    await neptuneClient.createRelationship(sourceEntityName, relationshipType, targetEntityName);
                    result = {
                        message: 'Relationship created successfully',
                        sourceEntityName,
                        relationshipType,
                        targetEntityName,
                        timestamp: new Date().toISOString()
                    };
                }
                catch (relationshipError) {
                    const errorMessage = relationshipError instanceof Error ? relationshipError.message : 'Unknown error';
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: `Failed to create relationship: ${errorMessage}`,
                            sourceEntityName,
                            relationshipType,
                            targetEntityName
                        }),
                    };
                }
                break;
            case 'update-entity':
                if (!body.id || !body.type || !body.name) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing required fields: id, type, name',
                            received: body
                        }),
                    };
                }
                try {
                    // Strip URI prefix if present to get just the UUID
                    let entityId = body.id;
                    const ontologyPrefix = 'http://neptune.aws.com/envmgmt/ontology/';
                    if (entityId.startsWith(ontologyPrefix)) {
                        entityId = entityId.replace(ontologyPrefix, '');
                    }
                    console.log(`Update request for entity ID: ${entityId} (original: ${body.id})`);
                    console.log(`Full update body:`, JSON.stringify(body, null, 2));
                    // First, find the entity URI
                    const findEntityQuery = `
            PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
            
            SELECT ?entity WHERE {
              ?entity env:id "${entityId}" .
            }
          `;
                    console.log(`Executing find entity query:`, findEntityQuery);
                    const findResult = await neptuneClient.executeSparqlQuery(findEntityQuery);
                    console.log(`Find entity result:`, JSON.stringify(findResult, null, 2));
                    if (!findResult.results?.bindings?.length) {
                        // Try to list all entities to debug
                        const debugQuery = `
              PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
              SELECT ?entity ?id WHERE {
                ?entity env:id ?id .
              }
              LIMIT 10
            `;
                        const debugResult = await neptuneClient.executeSparqlQuery(debugQuery);
                        console.log(`Debug - All entities in database:`, JSON.stringify(debugResult, null, 2));
                        throw new Error(`Entity with ID ${entityId} not found in Neptune. Searched for entity with env:id property matching "${entityId}".`);
                    }
                    const entityUri = findResult.results.bindings[0].entity.value;
                    console.log(`Found entity URI: ${entityUri} for ID: ${entityId}`);
                    // Escape special characters in strings for SPARQL
                    const escapeSparql = (str) => {
                        if (!str)
                            return '';
                        return str.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r');
                    };
                    // Update basic entity properties
                    const updateQuery = `
            PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
            
            DELETE {
              <${entityUri}> env:name ?oldName .
              <${entityUri}> env:description ?oldDesc .
              <${entityUri}> env:owner ?oldOwner .
              <${entityUri}> env:status ?oldStatus .
            }
            INSERT {
              <${entityUri}> env:name "${escapeSparql(body.name)}" .
              <${entityUri}> env:description "${escapeSparql(body.description || '')}" .
              <${entityUri}> env:owner "${escapeSparql(body.owner || '')}" .
              <${entityUri}> env:status "${escapeSparql(body.status || 'active')}" .
            }
            WHERE {
              OPTIONAL { <${entityUri}> env:name ?oldName }
              OPTIONAL { <${entityUri}> env:description ?oldDesc }
              OPTIONAL { <${entityUri}> env:owner ?oldOwner }
              OPTIONAL { <${entityUri}> env:status ?oldStatus }
            }
          `;
                    console.log('Executing update query:', updateQuery);
                    await neptuneClient.executeSparqlUpdate(updateQuery);
                    // Delete old config properties
                    const deleteConfigQuery = `
            PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
            
            DELETE {
              <${entityUri}> ?configProp ?configValue .
            }
            WHERE {
              <${entityUri}> ?configProp ?configValue .
              FILTER(CONTAINS(STR(?configProp), "config_"))
            }
          `;
                    console.log('Deleting old config properties');
                    await neptuneClient.executeSparqlUpdate(deleteConfigQuery);
                    // Add new configuration properties if provided
                    if (body.configurations && typeof body.configurations === 'object') {
                        console.log(`Updating configurations for entity ${entityId}:`, body.configurations);
                        await neptuneClient.addConfigurationProperties(entityId, body.configurations);
                    }
                    result = {
                        id: entityId,
                        name: body.name,
                        type: body.type,
                        message: 'Entity updated successfully',
                        timestamp: new Date().toISOString()
                    };
                }
                catch (updateError) {
                    console.error('Error updating entity:', updateError);
                    const errorMessage = updateError instanceof Error ? updateError.message : 'Unknown error';
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: `Failed to update entity: ${errorMessage}`
                        }),
                    };
                }
                break;
            case 'bulk-ingest':
                if (!body.entities || !Array.isArray(body.entities)) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: 'Missing or invalid "entities" array in request body',
                            hint: 'Send a JSON object with an "entities" array containing entity definitions'
                        }),
                    };
                }
                console.log(`Processing bulk ingestion for ${body.entities.length} entities`);
                const results = {
                    total: body.entities.length,
                    successful: 0,
                    failed: 0,
                    results: []
                };
                for (let i = 0; i < body.entities.length; i++) {
                    const entityData = body.entities[i];
                    try {
                        console.log(`Processing entity ${i + 1}/${body.entities.length}: ${entityData.name}`);
                        // Validate required fields
                        if (!entityData.type || !entityData.name) {
                            throw new Error('Missing required fields: type, name');
                        }
                        let entityResult;
                        // Route based on entity type (similar to 'create' operation)
                        switch (entityData.type.toLowerCase()) {
                            case 'environment':
                                const env = {
                                    name: entityData.name,
                                    type: 'Environment',
                                    uniqueIdentifier: entityData.uniqueIdentifier,
                                    owner: entityData.owner,
                                    description: entityData.description
                                };
                                entityResult = await neptuneClient.createEnvironment(env);
                                // Store configurations
                                const envConfig = {};
                                if (entityData.region)
                                    envConfig.region = entityData.region;
                                if (entityData.endpoint)
                                    envConfig.endpoint = entityData.endpoint;
                                if (entityData.configurations)
                                    Object.assign(envConfig, entityData.configurations);
                                if (Object.keys(envConfig).length > 0) {
                                    await neptuneClient.addConfigurationProperties(entityResult.id, envConfig);
                                }
                                break;
                            case 'application':
                                const app = {
                                    name: entityData.name,
                                    type: 'Application',
                                    owner: entityData.owner,
                                    description: entityData.description
                                };
                                entityResult = await neptuneClient.createApplication(app);
                                // Store configurations
                                const appConfig = {};
                                if (entityData.version)
                                    appConfig.version = entityData.version;
                                if (entityData.endpoint)
                                    appConfig.endpoint = entityData.endpoint;
                                if (entityData.configurations)
                                    Object.assign(appConfig, entityData.configurations);
                                if (Object.keys(appConfig).length > 0) {
                                    await neptuneClient.addConfigurationProperties(entityResult.id, appConfig);
                                }
                                break;
                            case 'integration':
                                const integration = {
                                    name: entityData.name,
                                    type: 'Integration',
                                    owner: entityData.owner,
                                    description: entityData.description
                                };
                                entityResult = await neptuneClient.createIntegration(integration);
                                // Store configurations
                                const intConfig = {};
                                if (entityData.sourceService)
                                    intConfig.sourceService = entityData.sourceService;
                                if (entityData.targetService)
                                    intConfig.targetService = entityData.targetService;
                                if (entityData.protocol)
                                    intConfig.protocol = entityData.protocol;
                                if (entityData.configurations)
                                    Object.assign(intConfig, entityData.configurations);
                                if (Object.keys(intConfig).length > 0) {
                                    await neptuneClient.addConfigurationProperties(entityResult.id, intConfig);
                                }
                                break;
                            default:
                                throw new Error(`Unsupported entity type: ${entityData.type}`);
                        }
                        // Create relationships if provided
                        if (entityData.relationships && Array.isArray(entityData.relationships)) {
                            for (const rel of entityData.relationships) {
                                try {
                                    await neptuneClient.createRelationship(entityData.name, rel.type, rel.target);
                                }
                                catch (relError) {
                                    console.warn(`Failed to create relationship for ${entityData.name}:`, relError);
                                }
                            }
                        }
                        results.successful++;
                        results.results.push({
                            index: i,
                            name: entityData.name,
                            type: entityData.type,
                            status: 'success',
                            id: entityResult.id
                        });
                    }
                    catch (entityError) {
                        console.error(`Failed to process entity ${i + 1}:`, entityError);
                        results.failed++;
                        results.results.push({
                            index: i,
                            name: entityData.name || 'Unknown',
                            type: entityData.type || 'Unknown',
                            status: 'failed',
                            error: entityError instanceof Error ? entityError.message : 'Unknown error'
                        });
                    }
                }
                result = results;
                console.log(`Bulk ingestion completed: ${results.successful} successful, ${results.failed} failed`);
                break;
            default:
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: `Unknown operation: ${operation}`,
                        availableOperations: [
                            'create-environment', 'create-application', 'create-integration',
                            'create-environment-config', 'create-application-config', 'create-integration-config',
                            'create-config-entry', 'create-deployment', 'create-relationship', 'initialize-ontology', 'health',
                            'create', 'update-entity', 'bulk-ingest'
                        ]
                    }),
                };
        }
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                success: true,
                operation,
                data: result,
                timestamp: new Date().toISOString(),
            }),
        };
    }
    catch (error) {
        console.error('Error processing request:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'Internal server error',
                message: error instanceof Error ? error.message : 'Unknown error occurred',
                timestamp: new Date().toISOString(),
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5nZXN0aW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiaW5nZXN0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUNBLDJFQUE2RztBQUU3RyxNQUFNLGFBQWEsR0FBRyxJQUFJLDJDQUFtQixFQUFFLENBQUM7QUFFekMsTUFBTSxPQUFPLEdBQUcsS0FBSyxFQUFFLEtBQTJCLEVBQWtDLEVBQUU7SUFDM0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFdEQsTUFBTSxPQUFPLEdBQUc7UUFDZCxjQUFjLEVBQUUsa0JBQWtCO1FBQ2xDLDZCQUE2QixFQUFFLHVCQUF1QjtRQUN0RCw4QkFBOEIsRUFBRSxpQ0FBaUM7UUFDakUsOEJBQThCLEVBQUUsK0RBQStEO1FBQy9GLHdCQUF3QixFQUFFLEtBQUs7S0FDaEMsQ0FBQztJQUVGLElBQUk7UUFDRixpQ0FBaUM7UUFDakMsSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLFNBQVMsRUFBRTtZQUNsQyxPQUFPO2dCQUNMLFVBQVUsRUFBRSxHQUFHO2dCQUNmLE9BQU87Z0JBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsMkJBQTJCLEVBQUUsQ0FBQzthQUMvRCxDQUFDO1NBQ0g7UUFFRCxnQ0FBZ0M7UUFDaEMsSUFBSSxJQUFJLEdBQVEsRUFBRSxDQUFDO1FBQ25CLElBQUksS0FBSyxDQUFDLElBQUksRUFBRTtZQUNkLElBQUk7Z0JBQ0YsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQy9CO1lBQUMsT0FBTyxVQUFVLEVBQUU7Z0JBQ25CLE9BQU87b0JBQ0wsVUFBVSxFQUFFLEdBQUc7b0JBQ2YsT0FBTztvQkFDUCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLEtBQUssRUFBRSw4QkFBOEIsRUFBRSxDQUFDO2lCQUNoRSxDQUFDO2FBQ0g7U0FDRjtRQUVELGlFQUFpRTtRQUNqRSxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsY0FBYyxFQUFFLFNBQVM7WUFDaEMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLFNBQVM7WUFDdEMsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUVoQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2QsT0FBTztnQkFDTCxVQUFVLEVBQUUsR0FBRztnQkFDZixPQUFPO2dCQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNuQixLQUFLLEVBQUUsNkJBQTZCO29CQUNwQyxtQkFBbUIsRUFBRTt3QkFDbkIsb0JBQW9CLEVBQUUsb0JBQW9CLEVBQUUsb0JBQW9CO3dCQUNoRSwyQkFBMkIsRUFBRSwyQkFBMkIsRUFBRSwyQkFBMkI7d0JBQ3JGLHFCQUFxQixFQUFFLG1CQUFtQixFQUFFLHFCQUFxQixFQUFFLFFBQVEsRUFBRSxRQUFRO3dCQUNyRixlQUFlLEVBQUUsYUFBYTtxQkFDL0I7aUJBQ0YsQ0FBQzthQUNILENBQUM7U0FDSDtRQUVELElBQUksTUFBVyxDQUFDO1FBRWhCLFFBQVEsU0FBUyxDQUFDLFdBQVcsRUFBRSxFQUFFO1lBQy9CLEtBQUssUUFBUTtnQkFDWCxNQUFNLFNBQVMsR0FBRyxNQUFNLGFBQWEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDcEQsTUFBTSxHQUFHO29CQUNQLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVztvQkFDM0MsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO29CQUNuQyxPQUFPLEVBQUUsbUJBQW1CO2lCQUM3QixDQUFDO2dCQUNGLE1BQU07WUFFUixLQUFLLFFBQVE7Z0JBQ1gsaUVBQWlFO2dCQUNqRSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7b0JBQzVCLE9BQU87d0JBQ0wsVUFBVSxFQUFFLEdBQUc7d0JBQ2YsT0FBTzt3QkFDUCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQzs0QkFDbkIsS0FBSyxFQUFFLHFDQUFxQzs0QkFDNUMsUUFBUSxFQUFFLElBQUk7NEJBQ2QsY0FBYyxFQUFFLENBQUMsYUFBYSxFQUFFLGFBQWEsRUFBRSxhQUFhLENBQUM7eUJBQzlELENBQUM7cUJBQ0gsQ0FBQztpQkFDSDtnQkFFRCxtREFBbUQ7Z0JBQ25ELFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRTtvQkFDL0IsS0FBSyxhQUFhO3dCQUNoQixNQUFNLEdBQUcsR0FBNEI7NEJBQ25DLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTs0QkFDZixJQUFJLEVBQUUsYUFBYTs0QkFDbkIsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGdCQUFnQjs0QkFDdkMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLOzRCQUNqQixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7eUJBQzlCLENBQUM7d0JBQ0YsTUFBTSxHQUFHLE1BQU0sYUFBYSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDO3dCQUVwRCx5REFBeUQ7d0JBQ3pELE1BQU0sWUFBWSxHQUF3QixFQUFFLENBQUM7d0JBQzdDLElBQUksSUFBSSxDQUFDLE1BQU07NEJBQUUsWUFBWSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO3dCQUNuRCxJQUFJLElBQUksQ0FBQyxRQUFROzRCQUFFLFlBQVksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQzt3QkFFekQsd0NBQXdDO3dCQUN4QyxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksT0FBTyxJQUFJLENBQUMsY0FBYyxLQUFLLFFBQVEsRUFBRTs0QkFDbEUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO3lCQUNsRDt3QkFFRCwrQ0FBK0M7d0JBQy9DLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFOzRCQUN4QyxJQUFJO2dDQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSw0Q0FBNEMsTUFBTSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQzFILE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO2dDQUNqRSxNQUFNLGFBQWEsQ0FBQywwQkFBMEIsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFlBQVksQ0FBQyxDQUFDO2dDQUN4RSxPQUFPLENBQUMsR0FBRyxDQUFDLDhEQUE4RCxNQUFNLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzs2QkFDeEY7NEJBQUMsT0FBTyxXQUFXLEVBQUU7Z0NBQ3BCLE9BQU8sQ0FBQyxLQUFLLENBQUMseURBQXlELE1BQU0sQ0FBQyxFQUFFLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQztnQ0FDbEcsaURBQWlEO2dDQUNqRCxNQUFNLENBQUMsb0JBQW9CLEdBQUcsa0VBQWtFLFdBQVcsWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsRUFBRSxDQUFDOzZCQUN4Szt5QkFDRjt3QkFFRCxtQ0FBbUM7d0JBQ25DLElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTs0QkFDM0QsS0FBSyxNQUFNLEdBQUcsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFO2dDQUNwQyxJQUFJO29DQUNGLE1BQU0sYUFBYSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7aUNBQ3pFO2dDQUFDLE9BQU8sUUFBUSxFQUFFO29DQUNqQixPQUFPLENBQUMsSUFBSSxDQUFDLGlDQUFpQyxHQUFHLENBQUMsSUFBSSxPQUFPLEdBQUcsQ0FBQyxNQUFNLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQztpQ0FDdkY7NkJBQ0Y7eUJBQ0Y7d0JBQ0QsTUFBTTtvQkFFUixLQUFLLGFBQWE7d0JBQ2hCLE1BQU0sR0FBRyxHQUE0Qjs0QkFDbkMsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJOzRCQUNmLElBQUksRUFBRSxhQUFhOzRCQUNuQixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7NEJBQ2pCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVzt5QkFDOUIsQ0FBQzt3QkFDRixNQUFNLEdBQUcsTUFBTSxhQUFhLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBRXBELHlEQUF5RDt3QkFDekQsTUFBTSxTQUFTLEdBQXdCLEVBQUUsQ0FBQzt3QkFDMUMsSUFBSSxJQUFJLENBQUMsT0FBTzs0QkFBRSxTQUFTLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7d0JBQ25ELElBQUksSUFBSSxDQUFDLFFBQVE7NEJBQUUsU0FBUyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO3dCQUV0RCx3Q0FBd0M7d0JBQ3hDLElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxPQUFPLElBQUksQ0FBQyxjQUFjLEtBQUssUUFBUSxFQUFFOzRCQUNsRSxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7eUJBQy9DO3dCQUVELCtDQUErQzt3QkFDL0MsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7NEJBQ3JDLElBQUk7Z0NBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLDRDQUE0QyxNQUFNLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztnQ0FDdkgsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0NBQzlELE1BQU0sYUFBYSxDQUFDLDBCQUEwQixDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0NBQ3JFLE9BQU8sQ0FBQyxHQUFHLENBQUMsOERBQThELE1BQU0sQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDOzZCQUN4Rjs0QkFBQyxPQUFPLFdBQVcsRUFBRTtnQ0FDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQyx5REFBeUQsTUFBTSxDQUFDLEVBQUUsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDO2dDQUNsRyxNQUFNLENBQUMsb0JBQW9CLEdBQUcsa0VBQWtFLFdBQVcsWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsRUFBRSxDQUFDOzZCQUN4Szt5QkFDRjt3QkFFRCxtQ0FBbUM7d0JBQ25DLElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTs0QkFDM0QsS0FBSyxNQUFNLEdBQUcsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFO2dDQUNwQyxJQUFJO29DQUNGLE1BQU0sYUFBYSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7aUNBQ3pFO2dDQUFDLE9BQU8sUUFBUSxFQUFFO29DQUNqQixPQUFPLENBQUMsSUFBSSxDQUFDLGlDQUFpQyxHQUFHLENBQUMsSUFBSSxPQUFPLEdBQUcsQ0FBQyxNQUFNLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQztpQ0FDdkY7NkJBQ0Y7eUJBQ0Y7d0JBQ0QsTUFBTTtvQkFFUixLQUFLLGFBQWE7d0JBQ2hCLE1BQU0sV0FBVyxHQUE0Qjs0QkFDM0MsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJOzRCQUNmLElBQUksRUFBRSxhQUFhOzRCQUNuQixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7NEJBQ2pCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVzt5QkFDOUIsQ0FBQzt3QkFDRixNQUFNLEdBQUcsTUFBTSxhQUFhLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7d0JBRTVELHlEQUF5RDt3QkFDekQsTUFBTSxTQUFTLEdBQXdCLEVBQUUsQ0FBQzt3QkFDMUMsSUFBSSxJQUFJLENBQUMsYUFBYTs0QkFBRSxTQUFTLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7d0JBQ3JFLElBQUksSUFBSSxDQUFDLGFBQWE7NEJBQUUsU0FBUyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO3dCQUNyRSxJQUFJLElBQUksQ0FBQyxRQUFROzRCQUFFLFNBQVMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQzt3QkFFdEQsd0NBQXdDO3dCQUN4QyxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksT0FBTyxJQUFJLENBQUMsY0FBYyxLQUFLLFFBQVEsRUFBRTs0QkFDbEUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO3lCQUMvQzt3QkFFRCwrQ0FBK0M7d0JBQy9DLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFOzRCQUNyQyxJQUFJO2dDQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSw0Q0FBNEMsTUFBTSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQ3ZILE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dDQUM5RCxNQUFNLGFBQWEsQ0FBQywwQkFBMEIsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dDQUNyRSxPQUFPLENBQUMsR0FBRyxDQUFDLDhEQUE4RCxNQUFNLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzs2QkFDeEY7NEJBQUMsT0FBTyxXQUFXLEVBQUU7Z0NBQ3BCLE9BQU8sQ0FBQyxLQUFLLENBQUMseURBQXlELE1BQU0sQ0FBQyxFQUFFLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQztnQ0FDbEcsTUFBTSxDQUFDLG9CQUFvQixHQUFHLGtFQUFrRSxXQUFXLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQzs2QkFDeEs7eUJBQ0Y7d0JBRUQsbUNBQW1DO3dCQUNuQyxJQUFJLElBQUksQ0FBQyxhQUFhLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7NEJBQzNELEtBQUssTUFBTSxHQUFHLElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtnQ0FDcEMsSUFBSTtvQ0FDRixNQUFNLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lDQUN6RTtnQ0FBQyxPQUFPLFFBQVEsRUFBRTtvQ0FDakIsT0FBTyxDQUFDLElBQUksQ0FBQyxpQ0FBaUMsR0FBRyxDQUFDLElBQUksT0FBTyxHQUFHLENBQUMsTUFBTSxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUM7aUNBQ3ZGOzZCQUNGO3lCQUNGO3dCQUNELE1BQU07b0JBRVI7d0JBQ0UsT0FBTzs0QkFDTCxVQUFVLEVBQUUsR0FBRzs0QkFDZixPQUFPOzRCQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO2dDQUNuQixLQUFLLEVBQUUseUJBQXlCO2dDQUNoQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUk7Z0NBQ25CLFNBQVMsRUFBRSxDQUFDLGFBQWEsRUFBRSxhQUFhLEVBQUUsYUFBYSxDQUFDOzZCQUN6RCxDQUFDO3lCQUNILENBQUM7aUJBQ0w7Z0JBQ0QsTUFBTTtZQUVSLEtBQUssb0JBQW9CO2dCQUN2QixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtvQkFDZCxPQUFPO3dCQUNMLFVBQVUsRUFBRSxHQUFHO3dCQUNmLE9BQU87d0JBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ25CLEtBQUssRUFBRSwrQkFBK0I7NEJBQ3RDLFFBQVEsRUFBRSxJQUFJO3lCQUNmLENBQUM7cUJBQ0gsQ0FBQztpQkFDSDtnQkFFRCxNQUFNLFdBQVcsR0FBNEI7b0JBQzNDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtvQkFDZixJQUFJLEVBQUUsYUFBYTtvQkFDbkIsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGdCQUFnQjtvQkFDdkMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO29CQUNqQixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsSUFBSSxlQUFlLElBQUksQ0FBQyxJQUFJLEVBQUU7b0JBQzNELE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxJQUFJLFFBQVE7aUJBQ2hDLENBQUM7Z0JBRUYsTUFBTSxHQUFHLE1BQU0sYUFBYSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUM1RCxNQUFNO1lBRVIsS0FBSyxvQkFBb0I7Z0JBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFO29CQUNkLE9BQU87d0JBQ0wsVUFBVSxFQUFFLEdBQUc7d0JBQ2YsT0FBTzt3QkFDUCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQzs0QkFDbkIsS0FBSyxFQUFFLDhCQUE4Qjs0QkFDckMsUUFBUSxFQUFFLElBQUk7eUJBQ2YsQ0FBQztxQkFDSCxDQUFDO2lCQUNIO2dCQUVELE1BQU0sV0FBVyxHQUE0QjtvQkFDM0MsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO29CQUNmLElBQUksRUFBRSxhQUFhO29CQUNuQixnQkFBZ0IsRUFBRSxJQUFJLENBQUMsZ0JBQWdCO29CQUN2QyxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7b0JBQ2pCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxJQUFJLGVBQWUsSUFBSSxDQUFDLElBQUksRUFBRTtvQkFDM0QsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLElBQUksUUFBUTtpQkFDaEMsQ0FBQztnQkFFRixNQUFNLEdBQUcsTUFBTSxhQUFhLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQzVELE1BQU07WUFFUixLQUFLLG9CQUFvQjtnQkFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7b0JBQ2QsT0FBTzt3QkFDTCxVQUFVLEVBQUUsR0FBRzt3QkFDZixPQUFPO3dCQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDOzRCQUNuQixLQUFLLEVBQUUsOEJBQThCOzRCQUNyQyxRQUFRLEVBQUUsSUFBSTt5QkFDZixDQUFDO3FCQUNILENBQUM7aUJBQ0g7Z0JBRUQsTUFBTSxXQUFXLEdBQTRCO29CQUMzQyxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7b0JBQ2YsSUFBSSxFQUFFLGFBQWE7b0JBQ25CLGdCQUFnQixFQUFFLElBQUksQ0FBQyxnQkFBZ0I7b0JBQ3ZDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztvQkFDakIsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLElBQUksZ0JBQWdCLElBQUksQ0FBQyxJQUFJLEVBQUU7b0JBQzVELE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxJQUFJLFFBQVE7aUJBQ2hDLENBQUM7Z0JBRUYsTUFBTSxHQUFHLE1BQU0sYUFBYSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUM1RCxNQUFNO1lBRVIsS0FBSywyQkFBMkI7Z0JBQzlCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO29CQUNsQixPQUFPO3dCQUNMLFVBQVUsRUFBRSxHQUFHO3dCQUNmLE9BQU87d0JBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxLQUFLLEVBQUUsZ0RBQWdELEVBQUUsQ0FBQztxQkFDbEYsQ0FBQztpQkFDSDtnQkFFRCxNQUFNLFNBQVMsR0FBRyxNQUFNLGFBQWEsQ0FBQyw4QkFBOEIsQ0FBQztvQkFDbkUsSUFBSSxFQUFFLDBCQUEwQjtvQkFDaEMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGdCQUFnQjtpQkFDeEMsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ2xCLE1BQU0sR0FBRyxTQUFTLENBQUM7Z0JBQ25CLE1BQU07WUFFUixLQUFLLDJCQUEyQjtnQkFDOUIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7b0JBQ2xCLE9BQU87d0JBQ0wsVUFBVSxFQUFFLEdBQUc7d0JBQ2YsT0FBTzt3QkFDUCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLEtBQUssRUFBRSxnREFBZ0QsRUFBRSxDQUFDO3FCQUNsRixDQUFDO2lCQUNIO2dCQUVELE1BQU0sU0FBUyxHQUFHLE1BQU0sYUFBYSxDQUFDLDhCQUE4QixDQUFDO29CQUNuRSxJQUFJLEVBQUUsMEJBQTBCO29CQUNoQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsZ0JBQWdCO2lCQUN4QyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDbEIsTUFBTSxHQUFHLFNBQVMsQ0FBQztnQkFDbkIsTUFBTTtZQUVSLEtBQUssMkJBQTJCO2dCQUM5QixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtvQkFDbEIsT0FBTzt3QkFDTCxVQUFVLEVBQUUsR0FBRzt3QkFDZixPQUFPO3dCQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsS0FBSyxFQUFFLGdEQUFnRCxFQUFFLENBQUM7cUJBQ2xGLENBQUM7aUJBQ0g7Z0JBRUQsTUFBTSxTQUFTLEdBQUcsTUFBTSxhQUFhLENBQUMsOEJBQThCLENBQUM7b0JBQ25FLElBQUksRUFBRSwwQkFBMEI7b0JBQ2hDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxnQkFBZ0I7b0JBQ3ZDLGFBQWEsRUFBRSxJQUFJLENBQUMsYUFBYTtvQkFDakMsYUFBYSxFQUFFLElBQUksQ0FBQyxhQUFhO2lCQUNsQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDbEIsTUFBTSxHQUFHLFNBQVMsQ0FBQztnQkFDbkIsTUFBTTtZQUVSLEtBQUsscUJBQXFCO2dCQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFO29CQUNyRCxPQUFPO3dCQUNMLFVBQVUsRUFBRSxHQUFHO3dCQUNmLE9BQU87d0JBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ25CLEtBQUssRUFBRSxzREFBc0Q7eUJBQzlELENBQUM7cUJBQ0gsQ0FBQztpQkFDSDtnQkFFRCxNQUFNLFdBQVcsR0FBRyxNQUFNLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQztvQkFDL0QsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLEdBQUc7b0JBQzFCLGtCQUFrQixFQUFFLElBQUksQ0FBQyxLQUFLO29CQUM5QixpQkFBaUIsRUFBRSxJQUFJLENBQUMsSUFBSTtpQkFDN0IsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBQ3pCLE1BQU0sR0FBRyxXQUFXLENBQUM7Z0JBQ3JCLE1BQU07WUFFUixLQUFLLG1CQUFtQjtnQkFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO29CQUM5QyxPQUFPO3dCQUNMLFVBQVUsRUFBRSxHQUFHO3dCQUNmLE9BQU87d0JBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ25CLEtBQUssRUFBRSx1REFBdUQ7eUJBQy9ELENBQUM7cUJBQ0gsQ0FBQztpQkFDSDtnQkFFRCxNQUFNLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDN0UsTUFBTSxHQUFHO29CQUNQLE9BQU8sRUFBRSw4Q0FBOEM7b0JBQ3ZELGFBQWEsRUFBRSxJQUFJLENBQUMsYUFBYTtvQkFDakMsYUFBYSxFQUFFLElBQUksQ0FBQyxhQUFhO2lCQUNsQyxDQUFDO2dCQUNGLE1BQU07WUFFUixLQUFLLHFCQUFxQjtnQkFDeEIsTUFBTSxhQUFhLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztnQkFDekMsTUFBTSxHQUFHO29CQUNQLE9BQU8sRUFBRSxtQ0FBbUM7b0JBQzVDLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtpQkFDcEMsQ0FBQztnQkFDRixNQUFNO1lBRVIsS0FBSyxxQkFBcUI7Z0JBQ3hCLE1BQU0sRUFBRSxnQkFBZ0IsRUFBRSxnQkFBZ0IsRUFBRSxnQkFBZ0IsRUFBRSxHQUFHLElBQUksQ0FBQztnQkFFdEUsSUFBSSxDQUFDLGdCQUFnQixJQUFJLENBQUMsZ0JBQWdCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtvQkFDL0QsT0FBTzt3QkFDTCxVQUFVLEVBQUUsR0FBRzt3QkFDZixPQUFPO3dCQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDOzRCQUNuQixLQUFLLEVBQUUsK0VBQStFOzRCQUN0RixRQUFRLEVBQUUsSUFBSTt5QkFDZixDQUFDO3FCQUNILENBQUM7aUJBQ0g7Z0JBRUQsSUFBSTtvQkFDRixNQUFNLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxnQkFBZ0IsRUFBRSxnQkFBZ0IsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO29CQUM3RixNQUFNLEdBQUc7d0JBQ1AsT0FBTyxFQUFFLG1DQUFtQzt3QkFDNUMsZ0JBQWdCO3dCQUNoQixnQkFBZ0I7d0JBQ2hCLGdCQUFnQjt3QkFDaEIsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO3FCQUNwQyxDQUFDO2lCQUNIO2dCQUFDLE9BQU8saUJBQWlCLEVBQUU7b0JBQzFCLE1BQU0sWUFBWSxHQUFHLGlCQUFpQixZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUM7b0JBQ3RHLE9BQU87d0JBQ0wsVUFBVSxFQUFFLEdBQUc7d0JBQ2YsT0FBTzt3QkFDUCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQzs0QkFDbkIsS0FBSyxFQUFFLGtDQUFrQyxZQUFZLEVBQUU7NEJBQ3ZELGdCQUFnQjs0QkFDaEIsZ0JBQWdCOzRCQUNoQixnQkFBZ0I7eUJBQ2pCLENBQUM7cUJBQ0gsQ0FBQztpQkFDSDtnQkFDRCxNQUFNO1lBRVIsS0FBSyxlQUFlO2dCQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFO29CQUN4QyxPQUFPO3dCQUNMLFVBQVUsRUFBRSxHQUFHO3dCQUNmLE9BQU87d0JBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ25CLEtBQUssRUFBRSx5Q0FBeUM7NEJBQ2hELFFBQVEsRUFBRSxJQUFJO3lCQUNmLENBQUM7cUJBQ0gsQ0FBQztpQkFDSDtnQkFFRCxJQUFJO29CQUNGLG1EQUFtRDtvQkFDbkQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQztvQkFDdkIsTUFBTSxjQUFjLEdBQUcsMENBQTBDLENBQUM7b0JBQ2xFLElBQUksUUFBUSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsRUFBRTt3QkFDdkMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3FCQUNqRDtvQkFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxRQUFRLGVBQWUsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7b0JBQ2hGLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRWhFLDZCQUE2QjtvQkFDN0IsTUFBTSxlQUFlLEdBQUc7Ozs7Z0NBSUYsUUFBUTs7V0FFN0IsQ0FBQztvQkFFRixPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixFQUFFLGVBQWUsQ0FBQyxDQUFDO29CQUM3RCxNQUFNLFVBQVUsR0FBRyxNQUFNLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLENBQUMsQ0FBQztvQkFDM0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFFeEUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRTt3QkFDekMsb0NBQW9DO3dCQUNwQyxNQUFNLFVBQVUsR0FBRzs7Ozs7O2FBTWxCLENBQUM7d0JBQ0YsTUFBTSxXQUFXLEdBQUcsTUFBTSxhQUFhLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQ3ZFLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRXZGLE1BQU0sSUFBSSxLQUFLLENBQUMsa0JBQWtCLFFBQVEsNkVBQTZFLFFBQVEsSUFBSSxDQUFDLENBQUM7cUJBQ3RJO29CQUVELE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7b0JBQzlELE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLFNBQVMsWUFBWSxRQUFRLEVBQUUsQ0FBQyxDQUFDO29CQUVsRSxrREFBa0Q7b0JBQ2xELE1BQU0sWUFBWSxHQUFHLENBQUMsR0FBVyxFQUFFLEVBQUU7d0JBQ25DLElBQUksQ0FBQyxHQUFHOzRCQUFFLE9BQU8sRUFBRSxDQUFDO3dCQUNwQixPQUFPLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUNyRyxDQUFDLENBQUM7b0JBRUYsaUNBQWlDO29CQUNqQyxNQUFNLFdBQVcsR0FBRzs7OztpQkFJYixTQUFTO2lCQUNULFNBQVM7aUJBQ1QsU0FBUztpQkFDVCxTQUFTOzs7aUJBR1QsU0FBUyxlQUFlLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2lCQUMvQyxTQUFTLHNCQUFzQixZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUM7aUJBQ25FLFNBQVMsZ0JBQWdCLFlBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQztpQkFDdkQsU0FBUyxpQkFBaUIsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksUUFBUSxDQUFDOzs7NEJBR3BELFNBQVM7NEJBQ1QsU0FBUzs0QkFDVCxTQUFTOzRCQUNULFNBQVM7O1dBRTFCLENBQUM7b0JBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsRUFBRSxXQUFXLENBQUMsQ0FBQztvQkFDcEQsTUFBTSxhQUFhLENBQUMsbUJBQW1CLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBRXJELCtCQUErQjtvQkFDL0IsTUFBTSxpQkFBaUIsR0FBRzs7OztpQkFJbkIsU0FBUzs7O2lCQUdULFNBQVM7OztXQUdmLENBQUM7b0JBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO29CQUM5QyxNQUFNLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO29CQUUzRCwrQ0FBK0M7b0JBQy9DLElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxPQUFPLElBQUksQ0FBQyxjQUFjLEtBQUssUUFBUSxFQUFFO3dCQUNsRSxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxRQUFRLEdBQUcsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7d0JBQ3BGLE1BQU0sYUFBYSxDQUFDLDBCQUEwQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7cUJBQy9FO29CQUVELE1BQU0sR0FBRzt3QkFDUCxFQUFFLEVBQUUsUUFBUTt3QkFDWixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7d0JBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO3dCQUNmLE9BQU8sRUFBRSw2QkFBNkI7d0JBQ3RDLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtxQkFDcEMsQ0FBQztpQkFDSDtnQkFBQyxPQUFPLFdBQVcsRUFBRTtvQkFDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsRUFBRSxXQUFXLENBQUMsQ0FBQztvQkFDckQsTUFBTSxZQUFZLEdBQUcsV0FBVyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDO29CQUMxRixPQUFPO3dCQUNMLFVBQVUsRUFBRSxHQUFHO3dCQUNmLE9BQU87d0JBQ1AsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ25CLEtBQUssRUFBRSw0QkFBNEIsWUFBWSxFQUFFO3lCQUNsRCxDQUFDO3FCQUNILENBQUM7aUJBQ0g7Z0JBQ0QsTUFBTTtZQUVSLEtBQUssYUFBYTtnQkFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDbkQsT0FBTzt3QkFDTCxVQUFVLEVBQUUsR0FBRzt3QkFDZixPQUFPO3dCQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDOzRCQUNuQixLQUFLLEVBQUUscURBQXFEOzRCQUM1RCxJQUFJLEVBQUUsMkVBQTJFO3lCQUNsRixDQUFDO3FCQUNILENBQUM7aUJBQ0g7Z0JBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLFdBQVcsQ0FBQyxDQUFDO2dCQUU5RSxNQUFNLE9BQU8sR0FBRztvQkFDZCxLQUFLLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNO29CQUMzQixVQUFVLEVBQUUsQ0FBQztvQkFDYixNQUFNLEVBQUUsQ0FBQztvQkFDVCxPQUFPLEVBQUUsRUFBVztpQkFDckIsQ0FBQztnQkFFRixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQzdDLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRXBDLElBQUk7d0JBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQzt3QkFFdEYsMkJBQTJCO3dCQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUU7NEJBQ3hDLE1BQU0sSUFBSSxLQUFLLENBQUMscUNBQXFDLENBQUMsQ0FBQzt5QkFDeEQ7d0JBRUQsSUFBSSxZQUFpQixDQUFDO3dCQUV0Qiw2REFBNkQ7d0JBQzdELFFBQVEsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRTs0QkFDckMsS0FBSyxhQUFhO2dDQUNoQixNQUFNLEdBQUcsR0FBNEI7b0NBQ25DLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSTtvQ0FDckIsSUFBSSxFQUFFLGFBQWE7b0NBQ25CLGdCQUFnQixFQUFFLFVBQVUsQ0FBQyxnQkFBZ0I7b0NBQzdDLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSztvQ0FDdkIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxXQUFXO2lDQUNwQyxDQUFDO2dDQUNGLFlBQVksR0FBRyxNQUFNLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQ0FFMUQsdUJBQXVCO2dDQUN2QixNQUFNLFNBQVMsR0FBd0IsRUFBRSxDQUFDO2dDQUMxQyxJQUFJLFVBQVUsQ0FBQyxNQUFNO29DQUFFLFNBQVMsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQztnQ0FDNUQsSUFBSSxVQUFVLENBQUMsUUFBUTtvQ0FBRSxTQUFTLENBQUMsUUFBUSxHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUM7Z0NBQ2xFLElBQUksVUFBVSxDQUFDLGNBQWM7b0NBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dDQUVuRixJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQ0FDckMsTUFBTSxhQUFhLENBQUMsMEJBQTBCLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxTQUFTLENBQUMsQ0FBQztpQ0FDNUU7Z0NBQ0QsTUFBTTs0QkFFUixLQUFLLGFBQWE7Z0NBQ2hCLE1BQU0sR0FBRyxHQUE0QjtvQ0FDbkMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxJQUFJO29DQUNyQixJQUFJLEVBQUUsYUFBYTtvQ0FDbkIsS0FBSyxFQUFFLFVBQVUsQ0FBQyxLQUFLO29DQUN2QixXQUFXLEVBQUUsVUFBVSxDQUFDLFdBQVc7aUNBQ3BDLENBQUM7Z0NBQ0YsWUFBWSxHQUFHLE1BQU0sYUFBYSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDO2dDQUUxRCx1QkFBdUI7Z0NBQ3ZCLE1BQU0sU0FBUyxHQUF3QixFQUFFLENBQUM7Z0NBQzFDLElBQUksVUFBVSxDQUFDLE9BQU87b0NBQUUsU0FBUyxDQUFDLE9BQU8sR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDO2dDQUMvRCxJQUFJLFVBQVUsQ0FBQyxRQUFRO29DQUFFLFNBQVMsQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLFFBQVEsQ0FBQztnQ0FDbEUsSUFBSSxVQUFVLENBQUMsY0FBYztvQ0FBRSxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7Z0NBRW5GLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29DQUNyQyxNQUFNLGFBQWEsQ0FBQywwQkFBMEIsQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2lDQUM1RTtnQ0FDRCxNQUFNOzRCQUVSLEtBQUssYUFBYTtnQ0FDaEIsTUFBTSxXQUFXLEdBQTRCO29DQUMzQyxJQUFJLEVBQUUsVUFBVSxDQUFDLElBQUk7b0NBQ3JCLElBQUksRUFBRSxhQUFhO29DQUNuQixLQUFLLEVBQUUsVUFBVSxDQUFDLEtBQUs7b0NBQ3ZCLFdBQVcsRUFBRSxVQUFVLENBQUMsV0FBVztpQ0FDcEMsQ0FBQztnQ0FDRixZQUFZLEdBQUcsTUFBTSxhQUFhLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7Z0NBRWxFLHVCQUF1QjtnQ0FDdkIsTUFBTSxTQUFTLEdBQXdCLEVBQUUsQ0FBQztnQ0FDMUMsSUFBSSxVQUFVLENBQUMsYUFBYTtvQ0FBRSxTQUFTLENBQUMsYUFBYSxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUM7Z0NBQ2pGLElBQUksVUFBVSxDQUFDLGFBQWE7b0NBQUUsU0FBUyxDQUFDLGFBQWEsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDO2dDQUNqRixJQUFJLFVBQVUsQ0FBQyxRQUFRO29DQUFFLFNBQVMsQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLFFBQVEsQ0FBQztnQ0FDbEUsSUFBSSxVQUFVLENBQUMsY0FBYztvQ0FBRSxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7Z0NBRW5GLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29DQUNyQyxNQUFNLGFBQWEsQ0FBQywwQkFBMEIsQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2lDQUM1RTtnQ0FDRCxNQUFNOzRCQUVSO2dDQUNFLE1BQU0sSUFBSSxLQUFLLENBQUMsNEJBQTRCLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO3lCQUNsRTt3QkFFRCxtQ0FBbUM7d0JBQ25DLElBQUksVUFBVSxDQUFDLGFBQWEsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsRUFBRTs0QkFDdkUsS0FBSyxNQUFNLEdBQUcsSUFBSSxVQUFVLENBQUMsYUFBYSxFQUFFO2dDQUMxQyxJQUFJO29DQUNGLE1BQU0sYUFBYSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7aUNBQy9FO2dDQUFDLE9BQU8sUUFBUSxFQUFFO29DQUNqQixPQUFPLENBQUMsSUFBSSxDQUFDLHFDQUFxQyxVQUFVLENBQUMsSUFBSSxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUM7aUNBQ2pGOzZCQUNGO3lCQUNGO3dCQUVELE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQzt3QkFDckIsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7NEJBQ25CLEtBQUssRUFBRSxDQUFDOzRCQUNSLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSTs0QkFDckIsSUFBSSxFQUFFLFVBQVUsQ0FBQyxJQUFJOzRCQUNyQixNQUFNLEVBQUUsU0FBUzs0QkFDakIsRUFBRSxFQUFFLFlBQVksQ0FBQyxFQUFFO3lCQUNwQixDQUFDLENBQUM7cUJBRUo7b0JBQUMsT0FBTyxXQUFXLEVBQUU7d0JBQ3BCLE9BQU8sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQzt3QkFDakUsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO3dCQUNqQixPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQzs0QkFDbkIsS0FBSyxFQUFFLENBQUM7NEJBQ1IsSUFBSSxFQUFFLFVBQVUsQ0FBQyxJQUFJLElBQUksU0FBUzs0QkFDbEMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxJQUFJLElBQUksU0FBUzs0QkFDbEMsTUFBTSxFQUFFLFFBQVE7NEJBQ2hCLEtBQUssRUFBRSxXQUFXLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlO3lCQUM1RSxDQUFDLENBQUM7cUJBQ0o7aUJBQ0Y7Z0JBRUQsTUFBTSxHQUFHLE9BQU8sQ0FBQztnQkFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsT0FBTyxDQUFDLFVBQVUsZ0JBQWdCLE9BQU8sQ0FBQyxNQUFNLFNBQVMsQ0FBQyxDQUFDO2dCQUNwRyxNQUFNO1lBRVI7Z0JBQ0UsT0FBTztvQkFDTCxVQUFVLEVBQUUsR0FBRztvQkFDZixPQUFPO29CQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO3dCQUNuQixLQUFLLEVBQUUsc0JBQXNCLFNBQVMsRUFBRTt3QkFDeEMsbUJBQW1CLEVBQUU7NEJBQ3ZCLG9CQUFvQixFQUFFLG9CQUFvQixFQUFFLG9CQUFvQjs0QkFDaEUsMkJBQTJCLEVBQUUsMkJBQTJCLEVBQUUsMkJBQTJCOzRCQUNyRixxQkFBcUIsRUFBRSxtQkFBbUIsRUFBRSxxQkFBcUIsRUFBRSxxQkFBcUIsRUFBRSxRQUFROzRCQUNsRyxRQUFRLEVBQUUsZUFBZSxFQUFFLGFBQWE7eUJBQ3pDO3FCQUNFLENBQUM7aUJBQ0gsQ0FBQztTQUNMO1FBRUQsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsT0FBTztZQUNQLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUNuQixPQUFPLEVBQUUsSUFBSTtnQkFDYixTQUFTO2dCQUNULElBQUksRUFBRSxNQUFNO2dCQUNaLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTthQUNwQyxDQUFDO1NBQ0gsQ0FBQztLQUVIO0lBQUMsT0FBTyxLQUFLLEVBQUU7UUFDZCxPQUFPLENBQUMsS0FBSyxDQUFDLDJCQUEyQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRWxELE9BQU87WUFDTCxVQUFVLEVBQUUsR0FBRztZQUNmLE9BQU87WUFDUCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDbkIsS0FBSyxFQUFFLHVCQUF1QjtnQkFDOUIsT0FBTyxFQUFFLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLHdCQUF3QjtnQkFDMUUsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO2FBQ3BDLENBQUM7U0FDSCxDQUFDO0tBQ0g7QUFDSCxDQUFDLENBQUM7QUExdUJXLFFBQUEsT0FBTyxXQTB1QmxCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQVBJR2F0ZXdheVByb3h5RXZlbnQsIEFQSUdhdGV3YXlQcm94eVJlc3VsdCB9IGZyb20gJ2F3cy1sYW1iZGEnO1xuaW1wb3J0IHsgTmVwdHVuZVNwYXJxbENsaWVudCwgRW52aXJvbm1lbnQsIEFwcGxpY2F0aW9uLCBJbnRlZ3JhdGlvbiB9IGZyb20gJy4uL3NoYXJlZC9uZXB0dW5lLXNwYXJxbC1jbGllbnQnO1xuXG5jb25zdCBuZXB0dW5lQ2xpZW50ID0gbmV3IE5lcHR1bmVTcGFycWxDbGllbnQoKTtcblxuZXhwb3J0IGNvbnN0IGhhbmRsZXIgPSBhc3luYyAoZXZlbnQ6IEFQSUdhdGV3YXlQcm94eUV2ZW50KTogUHJvbWlzZTxBUElHYXRld2F5UHJveHlSZXN1bHQ+ID0+IHtcbiAgY29uc29sZS5sb2coJ0V2ZW50OicsIEpTT04uc3RyaW5naWZ5KGV2ZW50LCBudWxsLCAyKSk7XG4gIFxuICBjb25zdCBoZWFkZXJzID0ge1xuICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICdodHRwOi8vbG9jYWxob3N0OjMwMDAnLFxuICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1NZXRob2RzJzogJ0dFVCwgUE9TVCwgUFVULCBERUxFVEUsIE9QVElPTlMnLFxuICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ0NvbnRlbnQtVHlwZSwgQXV0aG9yaXphdGlvbiwgQWNjZXB0LCBPcmlnaW4sIFgtUmVxdWVzdGVkLVdpdGgnLFxuICAgICdBY2Nlc3MtQ29udHJvbC1NYXgtQWdlJzogJzMwMCdcbiAgfTtcblxuICB0cnkge1xuICAgIC8vIEhhbmRsZSBDT1JTIHByZWZsaWdodCByZXF1ZXN0c1xuICAgIGlmIChldmVudC5odHRwTWV0aG9kID09PSAnT1BUSU9OUycpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgaGVhZGVycyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBtZXNzYWdlOiAnQ09SUyBwcmVmbGlnaHQgc3VjY2Vzc2Z1bCcgfSksXG4gICAgICB9O1xuICAgIH1cblxuICAgIC8vIFBhcnNlIHJlcXVlc3QgYm9keSBpZiBwcmVzZW50XG4gICAgbGV0IGJvZHk6IGFueSA9IHt9O1xuICAgIGlmIChldmVudC5ib2R5KSB7XG4gICAgICB0cnkge1xuICAgICAgICBib2R5ID0gSlNPTi5wYXJzZShldmVudC5ib2R5KTtcbiAgICAgIH0gY2F0Y2ggKHBhcnNlRXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA0MDAsXG4gICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAnSW52YWxpZCBKU09OIGluIHJlcXVlc3QgYm9keScgfSksXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gRXh0cmFjdCBvcGVyYXRpb24gZnJvbSBwYXRoLCBxdWVyeSBwYXJhbWV0ZXJzLCBvciByZXF1ZXN0IGJvZHlcbiAgICBjb25zdCBvcGVyYXRpb24gPSBldmVudC5wYXRoUGFyYW1ldGVycz8ub3BlcmF0aW9uIHx8IFxuICAgICAgICAgICAgICAgICAgICAgZXZlbnQucXVlcnlTdHJpbmdQYXJhbWV0ZXJzPy5vcGVyYXRpb24gfHwgXG4gICAgICAgICAgICAgICAgICAgICBib2R5Lm9wZXJhdGlvbjtcbiAgICBcbiAgICBpZiAoIW9wZXJhdGlvbikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICBoZWFkZXJzLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIGVycm9yOiAnTWlzc2luZyBvcGVyYXRpb24gcGFyYW1ldGVyJyxcbiAgICAgICAgICBhdmFpbGFibGVPcGVyYXRpb25zOiBbXG4gICAgICAgICAgICAnY3JlYXRlLWVudmlyb25tZW50JywgJ2NyZWF0ZS1hcHBsaWNhdGlvbicsICdjcmVhdGUtaW50ZWdyYXRpb24nLCBcbiAgICAgICAgICAgICdjcmVhdGUtZW52aXJvbm1lbnQtY29uZmlnJywgJ2NyZWF0ZS1hcHBsaWNhdGlvbi1jb25maWcnLCAnY3JlYXRlLWludGVncmF0aW9uLWNvbmZpZycsXG4gICAgICAgICAgICAnY3JlYXRlLWNvbmZpZy1lbnRyeScsICdjcmVhdGUtZGVwbG95bWVudCcsICdpbml0aWFsaXplLW9udG9sb2d5JywgJ2hlYWx0aCcsICdjcmVhdGUnLFxuICAgICAgICAgICAgJ3VwZGF0ZS1lbnRpdHknLCAnYnVsay1pbmdlc3QnXG4gICAgICAgICAgXVxuICAgICAgICB9KSxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgbGV0IHJlc3VsdDogYW55O1xuXG4gICAgc3dpdGNoIChvcGVyYXRpb24udG9Mb3dlckNhc2UoKSkge1xuICAgICAgY2FzZSAnaGVhbHRoJzpcbiAgICAgICAgY29uc3QgaXNIZWFsdGh5ID0gYXdhaXQgbmVwdHVuZUNsaWVudC5oZWFsdGhDaGVjaygpO1xuICAgICAgICByZXN1bHQgPSB7IFxuICAgICAgICAgIHN0YXR1czogaXNIZWFsdGh5ID8gJ2hlYWx0aHknIDogJ3VuaGVhbHRoeScsXG4gICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgc2VydmljZTogJ25lcHR1bmUtaW5nZXN0aW9uJ1xuICAgICAgICB9O1xuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnY3JlYXRlJzpcbiAgICAgICAgLy8gR2VuZXJpYyBjcmVhdGUgb3BlcmF0aW9uIHRoYXQgZGV0ZXJtaW5lcyBlbnRpdHkgdHlwZSBmcm9tIGJvZHlcbiAgICAgICAgaWYgKCFib2R5LnR5cGUgfHwgIWJvZHkubmFtZSkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDAsXG4gICAgICAgICAgICBoZWFkZXJzLFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgICAgZXJyb3I6ICdNaXNzaW5nIHJlcXVpcmVkIGZpZWxkczogdHlwZSwgbmFtZScsXG4gICAgICAgICAgICAgIHJlY2VpdmVkOiBib2R5LFxuICAgICAgICAgICAgICBzdXBwb3J0ZWRUeXBlczogWydFbnZpcm9ubWVudCcsICdBcHBsaWNhdGlvbicsICdJbnRlZ3JhdGlvbiddXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gUm91dGUgdG8gc3BlY2lmaWMgY3JlYXRlIG9wZXJhdGlvbiBiYXNlZCBvbiB0eXBlXG4gICAgICAgIHN3aXRjaCAoYm9keS50eXBlLnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgICAgICBjYXNlICdlbnZpcm9ubWVudCc6XG4gICAgICAgICAgICBjb25zdCBlbnY6IE9taXQ8RW52aXJvbm1lbnQsICdpZCc+ID0ge1xuICAgICAgICAgICAgICBuYW1lOiBib2R5Lm5hbWUsXG4gICAgICAgICAgICAgIHR5cGU6ICdFbnZpcm9ubWVudCcsXG4gICAgICAgICAgICAgIHVuaXF1ZUlkZW50aWZpZXI6IGJvZHkudW5pcXVlSWRlbnRpZmllcixcbiAgICAgICAgICAgICAgb3duZXI6IGJvZHkub3duZXIsXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBib2R5LmRlc2NyaXB0aW9uXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgbmVwdHVuZUNsaWVudC5jcmVhdGVFbnZpcm9ubWVudChlbnYpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBTdG9yZSBlbnRpdHktc3BlY2lmaWMgcHJvcGVydGllcyBhcyBjb25maWdfIHByb3BlcnRpZXNcbiAgICAgICAgICAgIGNvbnN0IGVudGl0eUNvbmZpZzogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9O1xuICAgICAgICAgICAgaWYgKGJvZHkucmVnaW9uKSBlbnRpdHlDb25maWcucmVnaW9uID0gYm9keS5yZWdpb247XG4gICAgICAgICAgICBpZiAoYm9keS5lbmRwb2ludCkgZW50aXR5Q29uZmlnLmVuZHBvaW50ID0gYm9keS5lbmRwb2ludDtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gQWRkIGN1c3RvbSBjb25maWd1cmF0aW9ucyBpZiBwcm92aWRlZFxuICAgICAgICAgICAgaWYgKGJvZHkuY29uZmlndXJhdGlvbnMgJiYgdHlwZW9mIGJvZHkuY29uZmlndXJhdGlvbnMgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAgIE9iamVjdC5hc3NpZ24oZW50aXR5Q29uZmlnLCBib2R5LmNvbmZpZ3VyYXRpb25zKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gU3RvcmUgYWxsIGNvbmZpZ3VyYXRpb25zIHdpdGggY29uZmlnXyBwcmVmaXhcbiAgICAgICAgICAgIGlmIChPYmplY3Qua2V5cyhlbnRpdHlDb25maWcpLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgQXR0ZW1wdGluZyB0byBhZGQgJHtPYmplY3Qua2V5cyhlbnRpdHlDb25maWcpLmxlbmd0aH0gY29uZmlndXJhdGlvbiBwcm9wZXJ0aWVzIHRvIGVudmlyb25tZW50ICR7cmVzdWx0LmlkfWApO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdDb25maWd1cmF0aW9uIGRhdGE6JywgSlNPTi5zdHJpbmdpZnkoZW50aXR5Q29uZmlnKSk7XG4gICAgICAgICAgICAgICAgYXdhaXQgbmVwdHVuZUNsaWVudC5hZGRDb25maWd1cmF0aW9uUHJvcGVydGllcyhyZXN1bHQuaWQsIGVudGl0eUNvbmZpZyk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYFN1Y2Nlc3NmdWxseSBhZGRlZCBjb25maWd1cmF0aW9uIHByb3BlcnRpZXMgdG8gZW52aXJvbm1lbnQgJHtyZXN1bHQuaWR9YCk7XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGNvbmZpZ0Vycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRmFpbGVkIHRvIGFkZCBjb25maWd1cmF0aW9uIHByb3BlcnRpZXMgdG8gZW52aXJvbm1lbnQgJHtyZXN1bHQuaWR9OmAsIGNvbmZpZ0Vycm9yKTtcbiAgICAgICAgICAgICAgICAvLyBJbmNsdWRlIHRoaXMgaW4gdGhlIHJlc3BvbnNlIHNvIHRoZSB1c2VyIGtub3dzXG4gICAgICAgICAgICAgICAgcmVzdWx0LmNvbmZpZ3VyYXRpb25XYXJuaW5nID0gYFdhcm5pbmc6IEVudGl0eSBjcmVhdGVkIGJ1dCBjb25maWd1cmF0aW9ucyBjb3VsZCBub3QgYmUgc2F2ZWQ6ICR7Y29uZmlnRXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGNvbmZpZ0Vycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcid9YDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBDcmVhdGUgcmVsYXRpb25zaGlwcyBpZiBwcm92aWRlZFxuICAgICAgICAgICAgaWYgKGJvZHkucmVsYXRpb25zaGlwcyAmJiBBcnJheS5pc0FycmF5KGJvZHkucmVsYXRpb25zaGlwcykpIHtcbiAgICAgICAgICAgICAgZm9yIChjb25zdCByZWwgb2YgYm9keS5yZWxhdGlvbnNoaXBzKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgIGF3YWl0IG5lcHR1bmVDbGllbnQuY3JlYXRlUmVsYXRpb25zaGlwKGJvZHkubmFtZSwgcmVsLnR5cGUsIHJlbC50YXJnZXQpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKHJlbEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYEZhaWxlZCB0byBjcmVhdGUgcmVsYXRpb25zaGlwICR7cmVsLnR5cGV9IHRvICR7cmVsLnRhcmdldH06YCwgcmVsRXJyb3IpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICBjYXNlICdhcHBsaWNhdGlvbic6XG4gICAgICAgICAgICBjb25zdCBhcHA6IE9taXQ8QXBwbGljYXRpb24sICdpZCc+ID0ge1xuICAgICAgICAgICAgICBuYW1lOiBib2R5Lm5hbWUsXG4gICAgICAgICAgICAgIHR5cGU6ICdBcHBsaWNhdGlvbicsXG4gICAgICAgICAgICAgIG93bmVyOiBib2R5Lm93bmVyLFxuICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogYm9keS5kZXNjcmlwdGlvblxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IG5lcHR1bmVDbGllbnQuY3JlYXRlQXBwbGljYXRpb24oYXBwKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gU3RvcmUgZW50aXR5LXNwZWNpZmljIHByb3BlcnRpZXMgYXMgY29uZmlnXyBwcm9wZXJ0aWVzXG4gICAgICAgICAgICBjb25zdCBhcHBDb25maWc6IFJlY29yZDxzdHJpbmcsIGFueT4gPSB7fTtcbiAgICAgICAgICAgIGlmIChib2R5LnZlcnNpb24pIGFwcENvbmZpZy52ZXJzaW9uID0gYm9keS52ZXJzaW9uO1xuICAgICAgICAgICAgaWYgKGJvZHkuZW5kcG9pbnQpIGFwcENvbmZpZy5lbmRwb2ludCA9IGJvZHkuZW5kcG9pbnQ7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIC8vIEFkZCBjdXN0b20gY29uZmlndXJhdGlvbnMgaWYgcHJvdmlkZWRcbiAgICAgICAgICAgIGlmIChib2R5LmNvbmZpZ3VyYXRpb25zICYmIHR5cGVvZiBib2R5LmNvbmZpZ3VyYXRpb25zID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKGFwcENvbmZpZywgYm9keS5jb25maWd1cmF0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIC8vIFN0b3JlIGFsbCBjb25maWd1cmF0aW9ucyB3aXRoIGNvbmZpZ18gcHJlZml4XG4gICAgICAgICAgICBpZiAoT2JqZWN0LmtleXMoYXBwQ29uZmlnKS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYEF0dGVtcHRpbmcgdG8gYWRkICR7T2JqZWN0LmtleXMoYXBwQ29uZmlnKS5sZW5ndGh9IGNvbmZpZ3VyYXRpb24gcHJvcGVydGllcyB0byBhcHBsaWNhdGlvbiAke3Jlc3VsdC5pZH1gKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnQ29uZmlndXJhdGlvbiBkYXRhOicsIEpTT04uc3RyaW5naWZ5KGFwcENvbmZpZykpO1xuICAgICAgICAgICAgICAgIGF3YWl0IG5lcHR1bmVDbGllbnQuYWRkQ29uZmlndXJhdGlvblByb3BlcnRpZXMocmVzdWx0LmlkLCBhcHBDb25maWcpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBTdWNjZXNzZnVsbHkgYWRkZWQgY29uZmlndXJhdGlvbiBwcm9wZXJ0aWVzIHRvIGFwcGxpY2F0aW9uICR7cmVzdWx0LmlkfWApO1xuICAgICAgICAgICAgICB9IGNhdGNoIChjb25maWdFcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEZhaWxlZCB0byBhZGQgY29uZmlndXJhdGlvbiBwcm9wZXJ0aWVzIHRvIGFwcGxpY2F0aW9uICR7cmVzdWx0LmlkfTpgLCBjb25maWdFcnJvcik7XG4gICAgICAgICAgICAgICAgcmVzdWx0LmNvbmZpZ3VyYXRpb25XYXJuaW5nID0gYFdhcm5pbmc6IEVudGl0eSBjcmVhdGVkIGJ1dCBjb25maWd1cmF0aW9ucyBjb3VsZCBub3QgYmUgc2F2ZWQ6ICR7Y29uZmlnRXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGNvbmZpZ0Vycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcid9YDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBDcmVhdGUgcmVsYXRpb25zaGlwcyBpZiBwcm92aWRlZFxuICAgICAgICAgICAgaWYgKGJvZHkucmVsYXRpb25zaGlwcyAmJiBBcnJheS5pc0FycmF5KGJvZHkucmVsYXRpb25zaGlwcykpIHtcbiAgICAgICAgICAgICAgZm9yIChjb25zdCByZWwgb2YgYm9keS5yZWxhdGlvbnNoaXBzKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgIGF3YWl0IG5lcHR1bmVDbGllbnQuY3JlYXRlUmVsYXRpb25zaGlwKGJvZHkubmFtZSwgcmVsLnR5cGUsIHJlbC50YXJnZXQpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKHJlbEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYEZhaWxlZCB0byBjcmVhdGUgcmVsYXRpb25zaGlwICR7cmVsLnR5cGV9IHRvICR7cmVsLnRhcmdldH06YCwgcmVsRXJyb3IpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICBjYXNlICdpbnRlZ3JhdGlvbic6XG4gICAgICAgICAgICBjb25zdCBpbnRlZ3JhdGlvbjogT21pdDxJbnRlZ3JhdGlvbiwgJ2lkJz4gPSB7XG4gICAgICAgICAgICAgIG5hbWU6IGJvZHkubmFtZSxcbiAgICAgICAgICAgICAgdHlwZTogJ0ludGVncmF0aW9uJyxcbiAgICAgICAgICAgICAgb3duZXI6IGJvZHkub3duZXIsXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBib2R5LmRlc2NyaXB0aW9uXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgbmVwdHVuZUNsaWVudC5jcmVhdGVJbnRlZ3JhdGlvbihpbnRlZ3JhdGlvbik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIC8vIFN0b3JlIGVudGl0eS1zcGVjaWZpYyBwcm9wZXJ0aWVzIGFzIGNvbmZpZ18gcHJvcGVydGllc1xuICAgICAgICAgICAgY29uc3QgaW50Q29uZmlnOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge307XG4gICAgICAgICAgICBpZiAoYm9keS5zb3VyY2VTZXJ2aWNlKSBpbnRDb25maWcuc291cmNlU2VydmljZSA9IGJvZHkuc291cmNlU2VydmljZTtcbiAgICAgICAgICAgIGlmIChib2R5LnRhcmdldFNlcnZpY2UpIGludENvbmZpZy50YXJnZXRTZXJ2aWNlID0gYm9keS50YXJnZXRTZXJ2aWNlO1xuICAgICAgICAgICAgaWYgKGJvZHkucHJvdG9jb2wpIGludENvbmZpZy5wcm90b2NvbCA9IGJvZHkucHJvdG9jb2w7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIC8vIEFkZCBjdXN0b20gY29uZmlndXJhdGlvbnMgaWYgcHJvdmlkZWRcbiAgICAgICAgICAgIGlmIChib2R5LmNvbmZpZ3VyYXRpb25zICYmIHR5cGVvZiBib2R5LmNvbmZpZ3VyYXRpb25zID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKGludENvbmZpZywgYm9keS5jb25maWd1cmF0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIC8vIFN0b3JlIGFsbCBjb25maWd1cmF0aW9ucyB3aXRoIGNvbmZpZ18gcHJlZml4XG4gICAgICAgICAgICBpZiAoT2JqZWN0LmtleXMoaW50Q29uZmlnKS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYEF0dGVtcHRpbmcgdG8gYWRkICR7T2JqZWN0LmtleXMoaW50Q29uZmlnKS5sZW5ndGh9IGNvbmZpZ3VyYXRpb24gcHJvcGVydGllcyB0byBpbnRlZ3JhdGlvbiAke3Jlc3VsdC5pZH1gKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnQ29uZmlndXJhdGlvbiBkYXRhOicsIEpTT04uc3RyaW5naWZ5KGludENvbmZpZykpO1xuICAgICAgICAgICAgICAgIGF3YWl0IG5lcHR1bmVDbGllbnQuYWRkQ29uZmlndXJhdGlvblByb3BlcnRpZXMocmVzdWx0LmlkLCBpbnRDb25maWcpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBTdWNjZXNzZnVsbHkgYWRkZWQgY29uZmlndXJhdGlvbiBwcm9wZXJ0aWVzIHRvIGludGVncmF0aW9uICR7cmVzdWx0LmlkfWApO1xuICAgICAgICAgICAgICB9IGNhdGNoIChjb25maWdFcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEZhaWxlZCB0byBhZGQgY29uZmlndXJhdGlvbiBwcm9wZXJ0aWVzIHRvIGludGVncmF0aW9uICR7cmVzdWx0LmlkfTpgLCBjb25maWdFcnJvcik7XG4gICAgICAgICAgICAgICAgcmVzdWx0LmNvbmZpZ3VyYXRpb25XYXJuaW5nID0gYFdhcm5pbmc6IEVudGl0eSBjcmVhdGVkIGJ1dCBjb25maWd1cmF0aW9ucyBjb3VsZCBub3QgYmUgc2F2ZWQ6ICR7Y29uZmlnRXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGNvbmZpZ0Vycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcid9YDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBDcmVhdGUgcmVsYXRpb25zaGlwcyBpZiBwcm92aWRlZFxuICAgICAgICAgICAgaWYgKGJvZHkucmVsYXRpb25zaGlwcyAmJiBBcnJheS5pc0FycmF5KGJvZHkucmVsYXRpb25zaGlwcykpIHtcbiAgICAgICAgICAgICAgZm9yIChjb25zdCByZWwgb2YgYm9keS5yZWxhdGlvbnNoaXBzKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgIGF3YWl0IG5lcHR1bmVDbGllbnQuY3JlYXRlUmVsYXRpb25zaGlwKGJvZHkubmFtZSwgcmVsLnR5cGUsIHJlbC50YXJnZXQpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKHJlbEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYEZhaWxlZCB0byBjcmVhdGUgcmVsYXRpb25zaGlwICR7cmVsLnR5cGV9IHRvICR7cmVsLnRhcmdldH06YCwgcmVsRXJyb3IpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgICAgICBoZWFkZXJzLFxuICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgICAgIGVycm9yOiAnVW5zdXBwb3J0ZWQgZW50aXR5IHR5cGUnLFxuICAgICAgICAgICAgICAgIHJlY2VpdmVkOiBib2R5LnR5cGUsXG4gICAgICAgICAgICAgICAgc3VwcG9ydGVkOiBbJ0Vudmlyb25tZW50JywgJ0FwcGxpY2F0aW9uJywgJ0ludGVncmF0aW9uJ11cbiAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlICdjcmVhdGUtZW52aXJvbm1lbnQnOlxuICAgICAgICBpZiAoIWJvZHkubmFtZSkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDAsXG4gICAgICAgICAgICBoZWFkZXJzLFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgICAgZXJyb3I6ICdNaXNzaW5nIHJlcXVpcmVkIGZpZWxkczogbmFtZScsXG4gICAgICAgICAgICAgIHJlY2VpdmVkOiBib2R5IFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGVudmlyb25tZW50OiBPbWl0PEVudmlyb25tZW50LCAnaWQnPiA9IHtcbiAgICAgICAgICBuYW1lOiBib2R5Lm5hbWUsXG4gICAgICAgICAgdHlwZTogJ0Vudmlyb25tZW50JyxcbiAgICAgICAgICB1bmlxdWVJZGVudGlmaWVyOiBib2R5LnVuaXF1ZUlkZW50aWZpZXIsXG4gICAgICAgICAgb3duZXI6IGJvZHkub3duZXIsXG4gICAgICAgICAgZGVzY3JpcHRpb246IGJvZHkuZGVzY3JpcHRpb24gfHwgYEVudmlyb25tZW50ICR7Ym9keS5uYW1lfWAsXG4gICAgICAgICAgc3RhdHVzOiBib2R5LnN0YXR1cyB8fCAnYWN0aXZlJyxcbiAgICAgICAgfTtcblxuICAgICAgICByZXN1bHQgPSBhd2FpdCBuZXB0dW5lQ2xpZW50LmNyZWF0ZUVudmlyb25tZW50KGVudmlyb25tZW50KTtcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgJ2NyZWF0ZS1hcHBsaWNhdGlvbic6XG4gICAgICAgIGlmICghYm9keS5uYW1lKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwMCxcbiAgICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgICBlcnJvcjogJ01pc3NpbmcgcmVxdWlyZWQgZmllbGQ6IG5hbWUnLFxuICAgICAgICAgICAgICByZWNlaXZlZDogYm9keSBcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhcHBsaWNhdGlvbjogT21pdDxBcHBsaWNhdGlvbiwgJ2lkJz4gPSB7XG4gICAgICAgICAgbmFtZTogYm9keS5uYW1lLFxuICAgICAgICAgIHR5cGU6ICdBcHBsaWNhdGlvbicsXG4gICAgICAgICAgdW5pcXVlSWRlbnRpZmllcjogYm9keS51bmlxdWVJZGVudGlmaWVyLFxuICAgICAgICAgIG93bmVyOiBib2R5Lm93bmVyLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBib2R5LmRlc2NyaXB0aW9uIHx8IGBBcHBsaWNhdGlvbiAke2JvZHkubmFtZX1gLFxuICAgICAgICAgIHN0YXR1czogYm9keS5zdGF0dXMgfHwgJ2FjdGl2ZScsXG4gICAgICAgIH07XG5cbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgbmVwdHVuZUNsaWVudC5jcmVhdGVBcHBsaWNhdGlvbihhcHBsaWNhdGlvbik7XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlICdjcmVhdGUtaW50ZWdyYXRpb24nOlxuICAgICAgICBpZiAoIWJvZHkubmFtZSkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDAsXG4gICAgICAgICAgICBoZWFkZXJzLFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgICAgZXJyb3I6ICdNaXNzaW5nIHJlcXVpcmVkIGZpZWxkOiBuYW1lJyxcbiAgICAgICAgICAgICAgcmVjZWl2ZWQ6IGJvZHkgXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgaW50ZWdyYXRpb246IE9taXQ8SW50ZWdyYXRpb24sICdpZCc+ID0ge1xuICAgICAgICAgIG5hbWU6IGJvZHkubmFtZSxcbiAgICAgICAgICB0eXBlOiAnSW50ZWdyYXRpb24nLFxuICAgICAgICAgIHVuaXF1ZUlkZW50aWZpZXI6IGJvZHkudW5pcXVlSWRlbnRpZmllcixcbiAgICAgICAgICBvd25lcjogYm9keS5vd25lcixcbiAgICAgICAgICBkZXNjcmlwdGlvbjogYm9keS5kZXNjcmlwdGlvbiB8fCBgSW50ZWdyYXRpb246ICR7Ym9keS5uYW1lfWAsXG4gICAgICAgICAgc3RhdHVzOiBib2R5LnN0YXR1cyB8fCAnYWN0aXZlJyxcbiAgICAgICAgfTtcblxuICAgICAgICByZXN1bHQgPSBhd2FpdCBuZXB0dW5lQ2xpZW50LmNyZWF0ZUludGVncmF0aW9uKGludGVncmF0aW9uKTtcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgJ2NyZWF0ZS1lbnZpcm9ubWVudC1jb25maWcnOlxuICAgICAgICBpZiAoIWJvZHkuZW50aXR5SWQpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICdNaXNzaW5nIGVudGl0eUlkIGZvciBlbnZpcm9ubWVudCBjb25maWd1cmF0aW9uJyB9KSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZW52Q29uZmlnID0gYXdhaXQgbmVwdHVuZUNsaWVudC5jcmVhdGVFbnZpcm9ubWVudENvbmZpZ3VyYXRpb24oe1xuICAgICAgICAgIHR5cGU6ICdFbnZpcm9ubWVudENvbmZpZ3VyYXRpb24nLFxuICAgICAgICAgIGNvbmZpZ3VyYXRpb25NYXA6IGJvZHkuY29uZmlndXJhdGlvbk1hcCxcbiAgICAgICAgfSwgYm9keS5lbnRpdHlJZCk7XG4gICAgICAgIHJlc3VsdCA9IGVudkNvbmZpZztcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgJ2NyZWF0ZS1hcHBsaWNhdGlvbi1jb25maWcnOlxuICAgICAgICBpZiAoIWJvZHkuZW50aXR5SWQpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICdNaXNzaW5nIGVudGl0eUlkIGZvciBhcHBsaWNhdGlvbiBjb25maWd1cmF0aW9uJyB9KSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgYXBwQ29uZmlnID0gYXdhaXQgbmVwdHVuZUNsaWVudC5jcmVhdGVBcHBsaWNhdGlvbkNvbmZpZ3VyYXRpb24oe1xuICAgICAgICAgIHR5cGU6ICdBcHBsaWNhdGlvbkNvbmZpZ3VyYXRpb24nLFxuICAgICAgICAgIGNvbmZpZ3VyYXRpb25NYXA6IGJvZHkuY29uZmlndXJhdGlvbk1hcCxcbiAgICAgICAgfSwgYm9keS5lbnRpdHlJZCk7XG4gICAgICAgIHJlc3VsdCA9IGFwcENvbmZpZztcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgJ2NyZWF0ZS1pbnRlZ3JhdGlvbi1jb25maWcnOlxuICAgICAgICBpZiAoIWJvZHkuZW50aXR5SWQpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICdNaXNzaW5nIGVudGl0eUlkIGZvciBpbnRlZ3JhdGlvbiBjb25maWd1cmF0aW9uJyB9KSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgaW50Q29uZmlnID0gYXdhaXQgbmVwdHVuZUNsaWVudC5jcmVhdGVJbnRlZ3JhdGlvbkNvbmZpZ3VyYXRpb24oe1xuICAgICAgICAgIHR5cGU6ICdJbnRlZ3JhdGlvbkNvbmZpZ3VyYXRpb24nLFxuICAgICAgICAgIGNvbmZpZ3VyYXRpb25NYXA6IGJvZHkuY29uZmlndXJhdGlvbk1hcCxcbiAgICAgICAgICBzb3VyY2VTZXJ2aWNlOiBib2R5LnNvdXJjZVNlcnZpY2UsXG4gICAgICAgICAgdGFyZ2V0U2VydmljZTogYm9keS50YXJnZXRTZXJ2aWNlLFxuICAgICAgICB9LCBib2R5LmVudGl0eUlkKTtcbiAgICAgICAgcmVzdWx0ID0gaW50Q29uZmlnO1xuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnY3JlYXRlLWNvbmZpZy1lbnRyeSc6XG4gICAgICAgIGlmICghYm9keS5jb25maWd1cmF0aW9uSWQgfHwgIWJvZHkua2V5IHx8ICFib2R5LnZhbHVlKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwMCxcbiAgICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgICBlcnJvcjogJ01pc3NpbmcgcmVxdWlyZWQgZmllbGRzOiBjb25maWd1cmF0aW9uSWQsIGtleSwgdmFsdWUnIFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGNvbmZpZ0VudHJ5ID0gYXdhaXQgbmVwdHVuZUNsaWVudC5jcmVhdGVDb25maWd1cmF0aW9uRW50cnkoe1xuICAgICAgICAgIGNvbmZpZ3VyYXRpb25LZXk6IGJvZHkua2V5LFxuICAgICAgICAgIGNvbmZpZ3VyYXRpb25WYWx1ZTogYm9keS52YWx1ZSxcbiAgICAgICAgICBjb25maWd1cmF0aW9uVHlwZTogYm9keS50eXBlLFxuICAgICAgICB9LCBib2R5LmNvbmZpZ3VyYXRpb25JZCk7XG4gICAgICAgIHJlc3VsdCA9IGNvbmZpZ0VudHJ5O1xuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnY3JlYXRlLWRlcGxveW1lbnQnOlxuICAgICAgICBpZiAoIWJvZHkuYXBwbGljYXRpb25JZCB8fCAhYm9keS5lbnZpcm9ubWVudElkKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwMCxcbiAgICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgICBlcnJvcjogJ01pc3NpbmcgcmVxdWlyZWQgZmllbGRzOiBhcHBsaWNhdGlvbklkLCBlbnZpcm9ubWVudElkJyBcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICBhd2FpdCBuZXB0dW5lQ2xpZW50LmNyZWF0ZURlcGxveW1lbnQoYm9keS5hcHBsaWNhdGlvbklkLCBib2R5LmVudmlyb25tZW50SWQpO1xuICAgICAgICByZXN1bHQgPSB7IFxuICAgICAgICAgIG1lc3NhZ2U6ICdEZXBsb3ltZW50IHJlbGF0aW9uc2hpcCBjcmVhdGVkIHN1Y2Nlc3NmdWxseScsXG4gICAgICAgICAgYXBwbGljYXRpb25JZDogYm9keS5hcHBsaWNhdGlvbklkLFxuICAgICAgICAgIGVudmlyb25tZW50SWQ6IGJvZHkuZW52aXJvbm1lbnRJZCBcbiAgICAgICAgfTtcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgJ2luaXRpYWxpemUtb250b2xvZ3knOlxuICAgICAgICBhd2FpdCBuZXB0dW5lQ2xpZW50LmluaXRpYWxpemVPbnRvbG9neSgpO1xuICAgICAgICByZXN1bHQgPSB7IFxuICAgICAgICAgIG1lc3NhZ2U6ICdPbnRvbG9neSBpbml0aWFsaXplZCBzdWNjZXNzZnVsbHknLFxuICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICAgIH07XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlICdjcmVhdGUtcmVsYXRpb25zaGlwJzpcbiAgICAgICAgY29uc3QgeyBzb3VyY2VFbnRpdHlOYW1lLCByZWxhdGlvbnNoaXBUeXBlLCB0YXJnZXRFbnRpdHlOYW1lIH0gPSBib2R5O1xuICAgICAgICBcbiAgICAgICAgaWYgKCFzb3VyY2VFbnRpdHlOYW1lIHx8ICFyZWxhdGlvbnNoaXBUeXBlIHx8ICF0YXJnZXRFbnRpdHlOYW1lKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwMCxcbiAgICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgICBlcnJvcjogJ01pc3NpbmcgcmVxdWlyZWQgZmllbGRzOiBzb3VyY2VFbnRpdHlOYW1lLCByZWxhdGlvbnNoaXBUeXBlLCB0YXJnZXRFbnRpdHlOYW1lJyxcbiAgICAgICAgICAgICAgcmVjZWl2ZWQ6IGJvZHkgXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhd2FpdCBuZXB0dW5lQ2xpZW50LmNyZWF0ZVJlbGF0aW9uc2hpcChzb3VyY2VFbnRpdHlOYW1lLCByZWxhdGlvbnNoaXBUeXBlLCB0YXJnZXRFbnRpdHlOYW1lKTtcbiAgICAgICAgICByZXN1bHQgPSB7XG4gICAgICAgICAgICBtZXNzYWdlOiAnUmVsYXRpb25zaGlwIGNyZWF0ZWQgc3VjY2Vzc2Z1bGx5JyxcbiAgICAgICAgICAgIHNvdXJjZUVudGl0eU5hbWUsXG4gICAgICAgICAgICByZWxhdGlvbnNoaXBUeXBlLFxuICAgICAgICAgICAgdGFyZ2V0RW50aXR5TmFtZSxcbiAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICAgICAgfTtcbiAgICAgICAgfSBjYXRjaCAocmVsYXRpb25zaGlwRXJyb3IpIHtcbiAgICAgICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSByZWxhdGlvbnNoaXBFcnJvciBpbnN0YW5jZW9mIEVycm9yID8gcmVsYXRpb25zaGlwRXJyb3IubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJztcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgICAgIGVycm9yOiBgRmFpbGVkIHRvIGNyZWF0ZSByZWxhdGlvbnNoaXA6ICR7ZXJyb3JNZXNzYWdlfWAsXG4gICAgICAgICAgICAgIHNvdXJjZUVudGl0eU5hbWUsXG4gICAgICAgICAgICAgIHJlbGF0aW9uc2hpcFR5cGUsXG4gICAgICAgICAgICAgIHRhcmdldEVudGl0eU5hbWVcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgJ3VwZGF0ZS1lbnRpdHknOlxuICAgICAgICBpZiAoIWJvZHkuaWQgfHwgIWJvZHkudHlwZSB8fCAhYm9keS5uYW1lKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwMCxcbiAgICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgICBlcnJvcjogJ01pc3NpbmcgcmVxdWlyZWQgZmllbGRzOiBpZCwgdHlwZSwgbmFtZScsXG4gICAgICAgICAgICAgIHJlY2VpdmVkOiBib2R5IFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgLy8gU3RyaXAgVVJJIHByZWZpeCBpZiBwcmVzZW50IHRvIGdldCBqdXN0IHRoZSBVVUlEXG4gICAgICAgICAgbGV0IGVudGl0eUlkID0gYm9keS5pZDtcbiAgICAgICAgICBjb25zdCBvbnRvbG9neVByZWZpeCA9ICdodHRwOi8vbmVwdHVuZS5hd3MuY29tL2Vudm1nbXQvb250b2xvZ3kvJztcbiAgICAgICAgICBpZiAoZW50aXR5SWQuc3RhcnRzV2l0aChvbnRvbG9neVByZWZpeCkpIHtcbiAgICAgICAgICAgIGVudGl0eUlkID0gZW50aXR5SWQucmVwbGFjZShvbnRvbG9neVByZWZpeCwgJycpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBcbiAgICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlIHJlcXVlc3QgZm9yIGVudGl0eSBJRDogJHtlbnRpdHlJZH0gKG9yaWdpbmFsOiAke2JvZHkuaWR9KWApO1xuICAgICAgICAgIGNvbnNvbGUubG9nKGBGdWxsIHVwZGF0ZSBib2R5OmAsIEpTT04uc3RyaW5naWZ5KGJvZHksIG51bGwsIDIpKTtcbiAgICAgICAgICBcbiAgICAgICAgICAvLyBGaXJzdCwgZmluZCB0aGUgZW50aXR5IFVSSVxuICAgICAgICAgIGNvbnN0IGZpbmRFbnRpdHlRdWVyeSA9IGBcbiAgICAgICAgICAgIFBSRUZJWCBlbnY6IDxodHRwOi8vbmVwdHVuZS5hd3MuY29tL2Vudm1nbXQvb250b2xvZ3kvPlxuICAgICAgICAgICAgXG4gICAgICAgICAgICBTRUxFQ1QgP2VudGl0eSBXSEVSRSB7XG4gICAgICAgICAgICAgID9lbnRpdHkgZW52OmlkIFwiJHtlbnRpdHlJZH1cIiAuXG4gICAgICAgICAgICB9XG4gICAgICAgICAgYDtcbiAgICAgICAgICBcbiAgICAgICAgICBjb25zb2xlLmxvZyhgRXhlY3V0aW5nIGZpbmQgZW50aXR5IHF1ZXJ5OmAsIGZpbmRFbnRpdHlRdWVyeSk7XG4gICAgICAgICAgY29uc3QgZmluZFJlc3VsdCA9IGF3YWl0IG5lcHR1bmVDbGllbnQuZXhlY3V0ZVNwYXJxbFF1ZXJ5KGZpbmRFbnRpdHlRdWVyeSk7XG4gICAgICAgICAgY29uc29sZS5sb2coYEZpbmQgZW50aXR5IHJlc3VsdDpgLCBKU09OLnN0cmluZ2lmeShmaW5kUmVzdWx0LCBudWxsLCAyKSk7XG4gICAgICAgICAgXG4gICAgICAgICAgaWYgKCFmaW5kUmVzdWx0LnJlc3VsdHM/LmJpbmRpbmdzPy5sZW5ndGgpIHtcbiAgICAgICAgICAgIC8vIFRyeSB0byBsaXN0IGFsbCBlbnRpdGllcyB0byBkZWJ1Z1xuICAgICAgICAgICAgY29uc3QgZGVidWdRdWVyeSA9IGBcbiAgICAgICAgICAgICAgUFJFRklYIGVudjogPGh0dHA6Ly9uZXB0dW5lLmF3cy5jb20vZW52bWdtdC9vbnRvbG9neS8+XG4gICAgICAgICAgICAgIFNFTEVDVCA/ZW50aXR5ID9pZCBXSEVSRSB7XG4gICAgICAgICAgICAgICAgP2VudGl0eSBlbnY6aWQgP2lkIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBMSU1JVCAxMFxuICAgICAgICAgICAgYDtcbiAgICAgICAgICAgIGNvbnN0IGRlYnVnUmVzdWx0ID0gYXdhaXQgbmVwdHVuZUNsaWVudC5leGVjdXRlU3BhcnFsUXVlcnkoZGVidWdRdWVyeSk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgRGVidWcgLSBBbGwgZW50aXRpZXMgaW4gZGF0YWJhc2U6YCwgSlNPTi5zdHJpbmdpZnkoZGVidWdSZXN1bHQsIG51bGwsIDIpKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFbnRpdHkgd2l0aCBJRCAke2VudGl0eUlkfSBub3QgZm91bmQgaW4gTmVwdHVuZS4gU2VhcmNoZWQgZm9yIGVudGl0eSB3aXRoIGVudjppZCBwcm9wZXJ0eSBtYXRjaGluZyBcIiR7ZW50aXR5SWR9XCIuYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIFxuICAgICAgICAgIGNvbnN0IGVudGl0eVVyaSA9IGZpbmRSZXN1bHQucmVzdWx0cy5iaW5kaW5nc1swXS5lbnRpdHkudmFsdWU7XG4gICAgICAgICAgY29uc29sZS5sb2coYEZvdW5kIGVudGl0eSBVUkk6ICR7ZW50aXR5VXJpfSBmb3IgSUQ6ICR7ZW50aXR5SWR9YCk7XG4gICAgICAgICAgXG4gICAgICAgICAgLy8gRXNjYXBlIHNwZWNpYWwgY2hhcmFjdGVycyBpbiBzdHJpbmdzIGZvciBTUEFSUUxcbiAgICAgICAgICBjb25zdCBlc2NhcGVTcGFycWwgPSAoc3RyOiBzdHJpbmcpID0+IHtcbiAgICAgICAgICAgIGlmICghc3RyKSByZXR1cm4gJyc7XG4gICAgICAgICAgICByZXR1cm4gc3RyLnJlcGxhY2UoL1xcXFwvZywgJ1xcXFxcXFxcJykucmVwbGFjZSgvXCIvZywgJ1xcXFxcIicpLnJlcGxhY2UoL1xcbi9nLCAnXFxcXG4nKS5yZXBsYWNlKC9cXHIvZywgJ1xcXFxyJyk7XG4gICAgICAgICAgfTtcbiAgICAgICAgICBcbiAgICAgICAgICAvLyBVcGRhdGUgYmFzaWMgZW50aXR5IHByb3BlcnRpZXNcbiAgICAgICAgICBjb25zdCB1cGRhdGVRdWVyeSA9IGBcbiAgICAgICAgICAgIFBSRUZJWCBlbnY6IDxodHRwOi8vbmVwdHVuZS5hd3MuY29tL2Vudm1nbXQvb250b2xvZ3kvPlxuICAgICAgICAgICAgXG4gICAgICAgICAgICBERUxFVEUge1xuICAgICAgICAgICAgICA8JHtlbnRpdHlVcml9PiBlbnY6bmFtZSA/b2xkTmFtZSAuXG4gICAgICAgICAgICAgIDwke2VudGl0eVVyaX0+IGVudjpkZXNjcmlwdGlvbiA/b2xkRGVzYyAuXG4gICAgICAgICAgICAgIDwke2VudGl0eVVyaX0+IGVudjpvd25lciA/b2xkT3duZXIgLlxuICAgICAgICAgICAgICA8JHtlbnRpdHlVcml9PiBlbnY6c3RhdHVzID9vbGRTdGF0dXMgLlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgSU5TRVJUIHtcbiAgICAgICAgICAgICAgPCR7ZW50aXR5VXJpfT4gZW52Om5hbWUgXCIke2VzY2FwZVNwYXJxbChib2R5Lm5hbWUpfVwiIC5cbiAgICAgICAgICAgICAgPCR7ZW50aXR5VXJpfT4gZW52OmRlc2NyaXB0aW9uIFwiJHtlc2NhcGVTcGFycWwoYm9keS5kZXNjcmlwdGlvbiB8fCAnJyl9XCIgLlxuICAgICAgICAgICAgICA8JHtlbnRpdHlVcml9PiBlbnY6b3duZXIgXCIke2VzY2FwZVNwYXJxbChib2R5Lm93bmVyIHx8ICcnKX1cIiAuXG4gICAgICAgICAgICAgIDwke2VudGl0eVVyaX0+IGVudjpzdGF0dXMgXCIke2VzY2FwZVNwYXJxbChib2R5LnN0YXR1cyB8fCAnYWN0aXZlJyl9XCIgLlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgV0hFUkUge1xuICAgICAgICAgICAgICBPUFRJT05BTCB7IDwke2VudGl0eVVyaX0+IGVudjpuYW1lID9vbGROYW1lIH1cbiAgICAgICAgICAgICAgT1BUSU9OQUwgeyA8JHtlbnRpdHlVcml9PiBlbnY6ZGVzY3JpcHRpb24gP29sZERlc2MgfVxuICAgICAgICAgICAgICBPUFRJT05BTCB7IDwke2VudGl0eVVyaX0+IGVudjpvd25lciA/b2xkT3duZXIgfVxuICAgICAgICAgICAgICBPUFRJT05BTCB7IDwke2VudGl0eVVyaX0+IGVudjpzdGF0dXMgP29sZFN0YXR1cyB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgYDtcbiAgICAgICAgICBcbiAgICAgICAgICBjb25zb2xlLmxvZygnRXhlY3V0aW5nIHVwZGF0ZSBxdWVyeTonLCB1cGRhdGVRdWVyeSk7XG4gICAgICAgICAgYXdhaXQgbmVwdHVuZUNsaWVudC5leGVjdXRlU3BhcnFsVXBkYXRlKHVwZGF0ZVF1ZXJ5KTtcbiAgICAgICAgICBcbiAgICAgICAgICAvLyBEZWxldGUgb2xkIGNvbmZpZyBwcm9wZXJ0aWVzXG4gICAgICAgICAgY29uc3QgZGVsZXRlQ29uZmlnUXVlcnkgPSBgXG4gICAgICAgICAgICBQUkVGSVggZW52OiA8aHR0cDovL25lcHR1bmUuYXdzLmNvbS9lbnZtZ210L29udG9sb2d5Lz5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgREVMRVRFIHtcbiAgICAgICAgICAgICAgPCR7ZW50aXR5VXJpfT4gP2NvbmZpZ1Byb3AgP2NvbmZpZ1ZhbHVlIC5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFdIRVJFIHtcbiAgICAgICAgICAgICAgPCR7ZW50aXR5VXJpfT4gP2NvbmZpZ1Byb3AgP2NvbmZpZ1ZhbHVlIC5cbiAgICAgICAgICAgICAgRklMVEVSKENPTlRBSU5TKFNUUig/Y29uZmlnUHJvcCksIFwiY29uZmlnX1wiKSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICBgO1xuICAgICAgICAgIFxuICAgICAgICAgIGNvbnNvbGUubG9nKCdEZWxldGluZyBvbGQgY29uZmlnIHByb3BlcnRpZXMnKTtcbiAgICAgICAgICBhd2FpdCBuZXB0dW5lQ2xpZW50LmV4ZWN1dGVTcGFycWxVcGRhdGUoZGVsZXRlQ29uZmlnUXVlcnkpO1xuICAgICAgICAgIFxuICAgICAgICAgIC8vIEFkZCBuZXcgY29uZmlndXJhdGlvbiBwcm9wZXJ0aWVzIGlmIHByb3ZpZGVkXG4gICAgICAgICAgaWYgKGJvZHkuY29uZmlndXJhdGlvbnMgJiYgdHlwZW9mIGJvZHkuY29uZmlndXJhdGlvbnMgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRpbmcgY29uZmlndXJhdGlvbnMgZm9yIGVudGl0eSAke2VudGl0eUlkfTpgLCBib2R5LmNvbmZpZ3VyYXRpb25zKTtcbiAgICAgICAgICAgIGF3YWl0IG5lcHR1bmVDbGllbnQuYWRkQ29uZmlndXJhdGlvblByb3BlcnRpZXMoZW50aXR5SWQsIGJvZHkuY29uZmlndXJhdGlvbnMpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBcbiAgICAgICAgICByZXN1bHQgPSB7XG4gICAgICAgICAgICBpZDogZW50aXR5SWQsXG4gICAgICAgICAgICBuYW1lOiBib2R5Lm5hbWUsXG4gICAgICAgICAgICB0eXBlOiBib2R5LnR5cGUsXG4gICAgICAgICAgICBtZXNzYWdlOiAnRW50aXR5IHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5JyxcbiAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICAgICAgfTtcbiAgICAgICAgfSBjYXRjaCAodXBkYXRlRXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciB1cGRhdGluZyBlbnRpdHk6JywgdXBkYXRlRXJyb3IpO1xuICAgICAgICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IHVwZGF0ZUVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyB1cGRhdGVFcnJvci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InO1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDAsXG4gICAgICAgICAgICBoZWFkZXJzLFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgICAgZXJyb3I6IGBGYWlsZWQgdG8gdXBkYXRlIGVudGl0eTogJHtlcnJvck1lc3NhZ2V9YFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcblxuICAgICAgY2FzZSAnYnVsay1pbmdlc3QnOlxuICAgICAgICBpZiAoIWJvZHkuZW50aXRpZXMgfHwgIUFycmF5LmlzQXJyYXkoYm9keS5lbnRpdGllcykpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgICAgIGVycm9yOiAnTWlzc2luZyBvciBpbnZhbGlkIFwiZW50aXRpZXNcIiBhcnJheSBpbiByZXF1ZXN0IGJvZHknLFxuICAgICAgICAgICAgICBoaW50OiAnU2VuZCBhIEpTT04gb2JqZWN0IHdpdGggYW4gXCJlbnRpdGllc1wiIGFycmF5IGNvbnRhaW5pbmcgZW50aXR5IGRlZmluaXRpb25zJ1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnNvbGUubG9nKGBQcm9jZXNzaW5nIGJ1bGsgaW5nZXN0aW9uIGZvciAke2JvZHkuZW50aXRpZXMubGVuZ3RofSBlbnRpdGllc2ApO1xuICAgICAgICBcbiAgICAgICAgY29uc3QgcmVzdWx0cyA9IHtcbiAgICAgICAgICB0b3RhbDogYm9keS5lbnRpdGllcy5sZW5ndGgsXG4gICAgICAgICAgc3VjY2Vzc2Z1bDogMCxcbiAgICAgICAgICBmYWlsZWQ6IDAsXG4gICAgICAgICAgcmVzdWx0czogW10gYXMgYW55W11cbiAgICAgICAgfTtcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJvZHkuZW50aXRpZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBjb25zdCBlbnRpdHlEYXRhID0gYm9keS5lbnRpdGllc1tpXTtcbiAgICAgICAgICBcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYFByb2Nlc3NpbmcgZW50aXR5ICR7aSArIDF9LyR7Ym9keS5lbnRpdGllcy5sZW5ndGh9OiAke2VudGl0eURhdGEubmFtZX1gKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gVmFsaWRhdGUgcmVxdWlyZWQgZmllbGRzXG4gICAgICAgICAgICBpZiAoIWVudGl0eURhdGEudHlwZSB8fCAhZW50aXR5RGF0YS5uYW1lKSB7XG4gICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignTWlzc2luZyByZXF1aXJlZCBmaWVsZHM6IHR5cGUsIG5hbWUnKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgbGV0IGVudGl0eVJlc3VsdDogYW55O1xuXG4gICAgICAgICAgICAvLyBSb3V0ZSBiYXNlZCBvbiBlbnRpdHkgdHlwZSAoc2ltaWxhciB0byAnY3JlYXRlJyBvcGVyYXRpb24pXG4gICAgICAgICAgICBzd2l0Y2ggKGVudGl0eURhdGEudHlwZS50b0xvd2VyQ2FzZSgpKSB7XG4gICAgICAgICAgICAgIGNhc2UgJ2Vudmlyb25tZW50JzpcbiAgICAgICAgICAgICAgICBjb25zdCBlbnY6IE9taXQ8RW52aXJvbm1lbnQsICdpZCc+ID0ge1xuICAgICAgICAgICAgICAgICAgbmFtZTogZW50aXR5RGF0YS5uYW1lLFxuICAgICAgICAgICAgICAgICAgdHlwZTogJ0Vudmlyb25tZW50JyxcbiAgICAgICAgICAgICAgICAgIHVuaXF1ZUlkZW50aWZpZXI6IGVudGl0eURhdGEudW5pcXVlSWRlbnRpZmllcixcbiAgICAgICAgICAgICAgICAgIG93bmVyOiBlbnRpdHlEYXRhLm93bmVyLFxuICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGVudGl0eURhdGEuZGVzY3JpcHRpb25cbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGVudGl0eVJlc3VsdCA9IGF3YWl0IG5lcHR1bmVDbGllbnQuY3JlYXRlRW52aXJvbm1lbnQoZW52KTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvLyBTdG9yZSBjb25maWd1cmF0aW9uc1xuICAgICAgICAgICAgICAgIGNvbnN0IGVudkNvbmZpZzogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9O1xuICAgICAgICAgICAgICAgIGlmIChlbnRpdHlEYXRhLnJlZ2lvbikgZW52Q29uZmlnLnJlZ2lvbiA9IGVudGl0eURhdGEucmVnaW9uO1xuICAgICAgICAgICAgICAgIGlmIChlbnRpdHlEYXRhLmVuZHBvaW50KSBlbnZDb25maWcuZW5kcG9pbnQgPSBlbnRpdHlEYXRhLmVuZHBvaW50O1xuICAgICAgICAgICAgICAgIGlmIChlbnRpdHlEYXRhLmNvbmZpZ3VyYXRpb25zKSBPYmplY3QuYXNzaWduKGVudkNvbmZpZywgZW50aXR5RGF0YS5jb25maWd1cmF0aW9ucyk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgaWYgKE9iamVjdC5rZXlzKGVudkNvbmZpZykubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgYXdhaXQgbmVwdHVuZUNsaWVudC5hZGRDb25maWd1cmF0aW9uUHJvcGVydGllcyhlbnRpdHlSZXN1bHQuaWQsIGVudkNvbmZpZyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgICAgICAgIGNhc2UgJ2FwcGxpY2F0aW9uJzpcbiAgICAgICAgICAgICAgICBjb25zdCBhcHA6IE9taXQ8QXBwbGljYXRpb24sICdpZCc+ID0ge1xuICAgICAgICAgICAgICAgICAgbmFtZTogZW50aXR5RGF0YS5uYW1lLFxuICAgICAgICAgICAgICAgICAgdHlwZTogJ0FwcGxpY2F0aW9uJyxcbiAgICAgICAgICAgICAgICAgIG93bmVyOiBlbnRpdHlEYXRhLm93bmVyLFxuICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGVudGl0eURhdGEuZGVzY3JpcHRpb25cbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGVudGl0eVJlc3VsdCA9IGF3YWl0IG5lcHR1bmVDbGllbnQuY3JlYXRlQXBwbGljYXRpb24oYXBwKTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvLyBTdG9yZSBjb25maWd1cmF0aW9uc1xuICAgICAgICAgICAgICAgIGNvbnN0IGFwcENvbmZpZzogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9O1xuICAgICAgICAgICAgICAgIGlmIChlbnRpdHlEYXRhLnZlcnNpb24pIGFwcENvbmZpZy52ZXJzaW9uID0gZW50aXR5RGF0YS52ZXJzaW9uO1xuICAgICAgICAgICAgICAgIGlmIChlbnRpdHlEYXRhLmVuZHBvaW50KSBhcHBDb25maWcuZW5kcG9pbnQgPSBlbnRpdHlEYXRhLmVuZHBvaW50O1xuICAgICAgICAgICAgICAgIGlmIChlbnRpdHlEYXRhLmNvbmZpZ3VyYXRpb25zKSBPYmplY3QuYXNzaWduKGFwcENvbmZpZywgZW50aXR5RGF0YS5jb25maWd1cmF0aW9ucyk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgaWYgKE9iamVjdC5rZXlzKGFwcENvbmZpZykubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgYXdhaXQgbmVwdHVuZUNsaWVudC5hZGRDb25maWd1cmF0aW9uUHJvcGVydGllcyhlbnRpdHlSZXN1bHQuaWQsIGFwcENvbmZpZyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgICAgICAgIGNhc2UgJ2ludGVncmF0aW9uJzpcbiAgICAgICAgICAgICAgICBjb25zdCBpbnRlZ3JhdGlvbjogT21pdDxJbnRlZ3JhdGlvbiwgJ2lkJz4gPSB7XG4gICAgICAgICAgICAgICAgICBuYW1lOiBlbnRpdHlEYXRhLm5hbWUsXG4gICAgICAgICAgICAgICAgICB0eXBlOiAnSW50ZWdyYXRpb24nLFxuICAgICAgICAgICAgICAgICAgb3duZXI6IGVudGl0eURhdGEub3duZXIsXG4gICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogZW50aXR5RGF0YS5kZXNjcmlwdGlvblxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgZW50aXR5UmVzdWx0ID0gYXdhaXQgbmVwdHVuZUNsaWVudC5jcmVhdGVJbnRlZ3JhdGlvbihpbnRlZ3JhdGlvbik7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgLy8gU3RvcmUgY29uZmlndXJhdGlvbnNcbiAgICAgICAgICAgICAgICBjb25zdCBpbnRDb25maWc6IFJlY29yZDxzdHJpbmcsIGFueT4gPSB7fTtcbiAgICAgICAgICAgICAgICBpZiAoZW50aXR5RGF0YS5zb3VyY2VTZXJ2aWNlKSBpbnRDb25maWcuc291cmNlU2VydmljZSA9IGVudGl0eURhdGEuc291cmNlU2VydmljZTtcbiAgICAgICAgICAgICAgICBpZiAoZW50aXR5RGF0YS50YXJnZXRTZXJ2aWNlKSBpbnRDb25maWcudGFyZ2V0U2VydmljZSA9IGVudGl0eURhdGEudGFyZ2V0U2VydmljZTtcbiAgICAgICAgICAgICAgICBpZiAoZW50aXR5RGF0YS5wcm90b2NvbCkgaW50Q29uZmlnLnByb3RvY29sID0gZW50aXR5RGF0YS5wcm90b2NvbDtcbiAgICAgICAgICAgICAgICBpZiAoZW50aXR5RGF0YS5jb25maWd1cmF0aW9ucykgT2JqZWN0LmFzc2lnbihpbnRDb25maWcsIGVudGl0eURhdGEuY29uZmlndXJhdGlvbnMpO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIGlmIChPYmplY3Qua2V5cyhpbnRDb25maWcpLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgIGF3YWl0IG5lcHR1bmVDbGllbnQuYWRkQ29uZmlndXJhdGlvblByb3BlcnRpZXMoZW50aXR5UmVzdWx0LmlkLCBpbnRDb25maWcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgZW50aXR5IHR5cGU6ICR7ZW50aXR5RGF0YS50eXBlfWApO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBDcmVhdGUgcmVsYXRpb25zaGlwcyBpZiBwcm92aWRlZFxuICAgICAgICAgICAgaWYgKGVudGl0eURhdGEucmVsYXRpb25zaGlwcyAmJiBBcnJheS5pc0FycmF5KGVudGl0eURhdGEucmVsYXRpb25zaGlwcykpIHtcbiAgICAgICAgICAgICAgZm9yIChjb25zdCByZWwgb2YgZW50aXR5RGF0YS5yZWxhdGlvbnNoaXBzKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgIGF3YWl0IG5lcHR1bmVDbGllbnQuY3JlYXRlUmVsYXRpb25zaGlwKGVudGl0eURhdGEubmFtZSwgcmVsLnR5cGUsIHJlbC50YXJnZXQpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKHJlbEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYEZhaWxlZCB0byBjcmVhdGUgcmVsYXRpb25zaGlwIGZvciAke2VudGl0eURhdGEubmFtZX06YCwgcmVsRXJyb3IpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXN1bHRzLnN1Y2Nlc3NmdWwrKztcbiAgICAgICAgICAgIHJlc3VsdHMucmVzdWx0cy5wdXNoKHtcbiAgICAgICAgICAgICAgaW5kZXg6IGksXG4gICAgICAgICAgICAgIG5hbWU6IGVudGl0eURhdGEubmFtZSxcbiAgICAgICAgICAgICAgdHlwZTogZW50aXR5RGF0YS50eXBlLFxuICAgICAgICAgICAgICBzdGF0dXM6ICdzdWNjZXNzJyxcbiAgICAgICAgICAgICAgaWQ6IGVudGl0eVJlc3VsdC5pZFxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICB9IGNhdGNoIChlbnRpdHlFcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRmFpbGVkIHRvIHByb2Nlc3MgZW50aXR5ICR7aSArIDF9OmAsIGVudGl0eUVycm9yKTtcbiAgICAgICAgICAgIHJlc3VsdHMuZmFpbGVkKys7XG4gICAgICAgICAgICByZXN1bHRzLnJlc3VsdHMucHVzaCh7XG4gICAgICAgICAgICAgIGluZGV4OiBpLFxuICAgICAgICAgICAgICBuYW1lOiBlbnRpdHlEYXRhLm5hbWUgfHwgJ1Vua25vd24nLFxuICAgICAgICAgICAgICB0eXBlOiBlbnRpdHlEYXRhLnR5cGUgfHwgJ1Vua25vd24nLFxuICAgICAgICAgICAgICBzdGF0dXM6ICdmYWlsZWQnLFxuICAgICAgICAgICAgICBlcnJvcjogZW50aXR5RXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVudGl0eUVycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcidcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJlc3VsdCA9IHJlc3VsdHM7XG4gICAgICAgIGNvbnNvbGUubG9nKGBCdWxrIGluZ2VzdGlvbiBjb21wbGV0ZWQ6ICR7cmVzdWx0cy5zdWNjZXNzZnVsfSBzdWNjZXNzZnVsLCAke3Jlc3VsdHMuZmFpbGVkfSBmYWlsZWRgKTtcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgIGVycm9yOiBgVW5rbm93biBvcGVyYXRpb246ICR7b3BlcmF0aW9ufWAsXG4gICAgICAgICAgICBhdmFpbGFibGVPcGVyYXRpb25zOiBbXG4gICAgICAgICAgJ2NyZWF0ZS1lbnZpcm9ubWVudCcsICdjcmVhdGUtYXBwbGljYXRpb24nLCAnY3JlYXRlLWludGVncmF0aW9uJywgXG4gICAgICAgICAgJ2NyZWF0ZS1lbnZpcm9ubWVudC1jb25maWcnLCAnY3JlYXRlLWFwcGxpY2F0aW9uLWNvbmZpZycsICdjcmVhdGUtaW50ZWdyYXRpb24tY29uZmlnJyxcbiAgICAgICAgICAnY3JlYXRlLWNvbmZpZy1lbnRyeScsICdjcmVhdGUtZGVwbG95bWVudCcsICdjcmVhdGUtcmVsYXRpb25zaGlwJywgJ2luaXRpYWxpemUtb250b2xvZ3knLCAnaGVhbHRoJyxcbiAgICAgICAgICAnY3JlYXRlJywgJ3VwZGF0ZS1lbnRpdHknLCAnYnVsay1pbmdlc3QnXG4gICAgICAgIF1cbiAgICAgICAgICB9KSxcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgaGVhZGVycyxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgb3BlcmF0aW9uLFxuICAgICAgICBkYXRhOiByZXN1bHQsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfSksXG4gICAgfTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHByb2Nlc3NpbmcgcmVxdWVzdDonLCBlcnJvcik7XG4gICAgXG4gICAgcmV0dXJuIHtcbiAgICAgIHN0YXR1c0NvZGU6IDUwMCxcbiAgICAgIGhlYWRlcnMsXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIGVycm9yOiAnSW50ZXJuYWwgc2VydmVyIGVycm9yJyxcbiAgICAgICAgbWVzc2FnZTogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvciBvY2N1cnJlZCcsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfSksXG4gICAgfTtcbiAgfVxufTsiXX0=