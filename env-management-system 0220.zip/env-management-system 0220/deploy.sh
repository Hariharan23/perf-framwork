#!/bin/bash
# Deploy SPARQL-only Neptune Environment Management System

echo "Building and deploying SPARQL-only Neptune Environment Management System..."

# Change to the lambdas directory and build
echo "Building Lambda functions..."
cd lambdas
npm run build
if [ $? -ne 0 ]; then
    echo "Build failed"
    exit 1
fi

echo "Build completed successfully"

# Go back to root and deploy with CDK
cd ..
echo "Deploying CDK stack..."
npx cdk deploy --require-approval never --outputs-file cdk-outputs.json

if [ $? -eq 0 ]; then
    echo "Deployment completed successfully!"
    echo "Check cdk-outputs.json for endpoint URLs"
else
    echo "Deployment failed"
    exit 1
fi