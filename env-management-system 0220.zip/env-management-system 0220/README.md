# Environment Management System

A production-ready web application for managing environments, applications, and their relationships using AWS Neptune Graph Database with interactive visualizations and comprehensive entity management.

## Features

### Core Functionality

- **Interactive Graph Visualization**: D3.js-powered network graph with professional tooltips
- **Entity Management**: Full CRUD operations for Environments, Applications, and Integrations
- **Custom Configurations**: Add unlimited key-value pairs to any entity
- **Professional UI**: Clean, responsive design with table-formatted data display
- **Data Export**: Download entity properties as clean JSON files
- **Real-time Updates**: All changes reflect immediately in the visualization

### Advanced Features

- **Clean Property Display**: URI prefixes removed for human-readable names
- **Configuration Storage**: All custom configs stored in Neptune as RDF properties
- **Professional Tooltips**: Table format with separated standard and custom properties
- **Smart Downloads**: Export with clean property names and organized structure
- **Responsive Design**: Modern UI that works on desktop and mobile

## Quick Start

1. **Deploy Infrastructure**:

   ```bash
   npm install
   npx cdk deploy --require-approval never
   ```

2. **Launch Application**:
   ```bash
   node server.js
   # Open http://localhost:3000
   ```

## Web Application Interface

### Main Sections

#### Add Entity Tab

- Create new Environments, Applications, and Integrations
- Dynamic forms that adapt to entity type
- Real-time validation and success feedback
- Type-specific fields (regions, versions, protocols)

#### Query Data Tab

- **Quick Queries**: One-click access to common queries
- **Custom SPARQL**: Full SPARQL query editor with syntax highlighting
- **Results Table**: Formatted results with responsive layout
- **Export Options**: Download query results

#### Visualize Graph Tab

- **Interactive Network**: D3.js force-directed layout
- **Node Types**: Color-coded entities (Environment, Application, Integration)
- **Controls**: Zoom, pan, reset, refresh, export
- **Real-time Stats**: Live node and edge counts
- **Tooltips**: Hover for detailed entity information

#### Delete Entity Tab

- **Search & Filter**: Find entities by name, type, or description
- **Individual Deletion**: Remove specific entities with confirmation
- **Entity Browser**: Paginated list of all entities
- **Safety Checks**: Multiple confirmation prompts

#### Admin Tab

- **Health Monitoring**: System status and connectivity checks
- **Entity Statistics**: Real-time counts by type
- **Bulk Operations**: Delete all data with proper safeguards
- **System Information**: Lambda status and Neptune health

## Architecture

### **Backend Services**

- **AWS Neptune**: Graph database with SPARQL support
- **AWS Lambda Functions**:
  - `ingest`: Entity creation and data ingestion
  - `query`: SPARQL queries and data retrieval
- **CDK Stack**: Infrastructure as Code deployment

### **Frontend Application**

- **Single Page App**: Modern responsive design
- **D3.js Visualization**: Interactive network graphs
- **Real-time API Integration**: Direct Lambda function calls
- **Progressive Enhancement**: Works without JavaScript for basic operations

## API Operations

### **Data Ingestion Lambda**

- `create-environment` - Create new environments
- `create-application` - Create new applications
- `create-integration` - Create new integrations
- `create-deployment` - Deploy applications to environments
- `create-integration-config` - Configure integration relationships

### **Query Lambda**

- `get-network` - Complete network topology
- `get-environments` - All environment entities
- `get-applications` - All application entities
- `get-integrations` - All integration entities
- `sparql-query` - Execute custom SPARQL queries
- `sparql-update` - Execute SPARQL update operations
- `health` - System health and status

## Entity Types & Relationships

### Environments

```javascript
{
  type: "Environment",
  name: "CAS_QA",
  region: "us-east-1",
  endpoint: "https://cas-qa.company.com",
  owner: "CAS Team",
  status: "active"
}
```

### Applications

```javascript
{
  type: "Application",
  name: "CAS",
  version: "2.1.5",
  owner: "CAS Development Team",
  status: "deployed"
}
```

### Integrations

```javascript
{
  type: "Integration",
  name: "Policy Retrieve Personal Auto",
  protocol: "REST",
  owner: "Integration Team",
  status: "active"
}
```

### **Relationships**

- `deployedIn`: Applications deployed in Environments
- `integratesWith`: Applications that integrate with each other
- `sourceOf`: Applications as integration sources
- `targetOf`: Applications as integration targets

## Development

### **Prerequisites**

- Node.js 18+
- AWS CLI configured with appropriate permissions
- CDK CLI installed (`npm install -g aws-cdk`)
- Python 3.x for local development server

### **Local Setup**

```bash
# Install dependencies
npm install

# Build Lambda functions
npm run build

# Deploy infrastructure
cdk deploy

# Start local server
python3 -m http.server 8080
```

### **Testing & Validation**

```bash
# Create sample data
./feed-and-query.sh

# Health check
./cleanup-neptune.sh health

# View entity counts
./cleanup-neptune.sh count
```

## Project Structure

```
├── environment-management-app.html  # Main web application
├── cdk-stack/                      # Infrastructure code
├── lambdas/src/                    # Lambda functions
│   ├── ingest.ts                   # Data creation operations
│   ├── query.ts                    # Data retrieval & SPARQL
│   └── cleanup.ts                  # Database cleanup utilities
├── deploy.sh                       # Deployment automation
├── feed-and-query.sh              # Sample data generation
├── cleanup-neptune.sh             # Database maintenance
├── ontology.ttl                   # RDF schema definition
└── config.env                     # Configuration settings
```

## Security & Safety

- **Confirmation Dialogs**: All destructive operations require explicit confirmation
- **Input Validation**: Client and server-side validation for all inputs
- **Error Handling**: Comprehensive error messages and graceful degradation
- **Safe Defaults**: Non-destructive operations as default choices
- **Audit Trail**: All operations logged with timestamps

## Usage Examples

### **Creating an Environment**

1. Navigate to "Add Entity" tab
2. Select "Environment" from dropdown
3. Fill in required fields (name, region, owner)
4. Click "Create Entity"

### **Visualizing the Network**

1. Go to "Visualize Graph" tab
2. Click "Refresh Graph" to load latest data
3. Use mouse to zoom, pan, and drag nodes
4. Hover over nodes for detailed information

### **Querying Data**

1. Open "Query Data" tab
2. Use quick query buttons or write custom SPARQL
3. View results in formatted table
4. Export results if needed

### **System Administration**

1. Access "Admin" tab
2. Run health checks to verify system status
3. View entity counts and system statistics
4. Use danger zone for bulk operations (with caution)

## Available Scripts

### **Deployment & Setup**

```bash
./deploy.sh              # Deploy AWS infrastructure
./feed-and-query.sh      # Create sample data and test queries
```

### **Database Management**

```bash
./cleanup-neptune.sh health        # Check system health
./cleanup-neptune.sh count         # View entity counts
./cleanup-neptune.sh delete-type Integration  # Delete by type
./cleanup-neptune.sh delete-all    # Remove all data
```

### **Development**

```bash
npm run build           # Build Lambda functions
npm run watch          # Watch for changes
cdk synth              # Synthesize CloudFormation
cdk deploy             # Deploy to AWS
```

---

**Environment Management System** - Build, Query, Visualize, and Manage your infrastructure relationships with ease!
