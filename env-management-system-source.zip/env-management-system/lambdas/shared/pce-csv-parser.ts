// PCE CSV Parser for Discovery Pipeline
// Parses CSV text (uploaded file or API body) into the same PceRecord[] format
// that the PostgreSQL pce-client produces, so downstream processing is identical.

export interface PceRecord {
  environmentName: string;
  propertyKey: string;
  propertyValue: string;
}

const REQUIRED_HEADERS = ['environment_name', 'property_key', 'property_value'];

/**
 * Parse CSV rows handling quoted fields with commas, newlines, and escaped quotes
 */
function parseCsvRows(content: string): string[][] {
  const rows: string[][] = [];
  let currentRow: string[] = [];
  let currentField = '';
  let inQuotes = false;
  let i = 0;

  while (i < content.length) {
    const char = content[i];

    if (inQuotes) {
      if (char === '"') {
        if (i + 1 < content.length && content[i + 1] === '"') {
          // Escaped quote
          currentField += '"';
          i += 2;
          continue;
        }
        // End of quoted field
        inQuotes = false;
        i++;
        continue;
      }
      currentField += char;
      i++;
    } else {
      if (char === '"') {
        inQuotes = true;
        i++;
      } else if (char === ',') {
        currentRow.push(currentField);
        currentField = '';
        i++;
      } else if (char === '\n' || (char === '\r' && i + 1 < content.length && content[i + 1] === '\n')) {
        currentRow.push(currentField);
        currentField = '';
        if (currentRow.some(f => f.trim() !== '')) {
          rows.push(currentRow);
        }
        currentRow = [];
        i += char === '\r' ? 2 : 1;
      } else if (char === '\r') {
        currentRow.push(currentField);
        currentField = '';
        if (currentRow.some(f => f.trim() !== '')) {
          rows.push(currentRow);
        }
        currentRow = [];
        i++;
      } else {
        currentField += char;
        i++;
      }
    }
  }

  // Final field/row
  currentRow.push(currentField);
  if (currentRow.some(f => f.trim() !== '')) {
    rows.push(currentRow);
  }

  return rows;
}

/**
 * Validate CSV headers match expected PCE format
 */
function validateHeaders(headers: string[]): void {
  const normalized = headers.map(h => h.trim().toLowerCase());
  for (const required of REQUIRED_HEADERS) {
    if (!normalized.includes(required)) {
      throw new Error(
        `Missing required CSV header: "${required}". Expected headers: ${REQUIRED_HEADERS.join(', ')}`
      );
    }
  }
}

/**
 * Parse CSV text into PceRecord array
 *
 * Expected CSV format:
 *   environment_name,property_key,property_value
 *   pasqa210,recordPaymentReceiptServiceImpl.endpointRecordPaymentUri,https://soaqa3.aaa.aaa.aaa.pri:8443/payment/record
 *   pasqa210,app.database.maxPoolSize,50
 */
export function parsePceCsv(csvContent: string): PceRecord[] {
  if (!csvContent || !csvContent.trim()) {
    throw new Error('CSV content is empty');
  }

  const rows = parseCsvRows(csvContent);
  if (rows.length < 2) {
    throw new Error('CSV must have a header row and at least one data row');
  }

  const headers = rows[0].map(h => h.trim().toLowerCase());
  validateHeaders(headers);

  const envIdx = headers.indexOf('environment_name');
  const keyIdx = headers.indexOf('property_key');
  const valIdx = headers.indexOf('property_value');

  const records: PceRecord[] = [];

  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    const environmentName = (row[envIdx] || '').trim();
    const propertyKey = (row[keyIdx] || '').trim();
    const propertyValue = (row[valIdx] || '').trim();

    // Skip rows with missing required fields
    if (!environmentName || !propertyKey || !propertyValue) {
      console.warn(`Skipping CSV row ${i + 1}: missing required field(s)`);
      continue;
    }

    records.push({ environmentName, propertyKey, propertyValue });
  }

  if (records.length === 0) {
    throw new Error('No valid data rows found in CSV');
  }

  console.log(`Parsed ${records.length} PCE records from CSV`);
  return records;
}

/**
 * Group PceRecords by environment name
 */
export function groupByEnvironment(records: PceRecord[]): Map<string, PceRecord[]> {
  const grouped = new Map<string, PceRecord[]>();
  for (const record of records) {
    const existing = grouped.get(record.environmentName) || [];
    existing.push(record);
    grouped.set(record.environmentName, existing);
  }
  return grouped;
}
