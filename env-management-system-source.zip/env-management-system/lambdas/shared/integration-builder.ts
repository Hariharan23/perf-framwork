// Integration Builder for PCE Discovery Pipeline
// Creates Environment, Integration entities and Relationships in Neptune
// Handles idempotency, stale detection, and stub vs real classification

import { NeptuneSparqlClient, Environment, Integration } from './neptune-sparql-client';
import { ClassifiedProperty } from './url-parser';
import { toIntegrationName, parsePropertyKey } from './key-parser';
import { HostnameResolver, ResolvedTarget, ConnectionType } from './hostname-resolver';

export interface DiscoveryResult {
  sourceEnvironment: string;
  environmentsCreated: string[];
  integrationsCreated: string[];
  integrationsSkipped: string[];  // Already existed with same config
  integrationsStale: string[];    // Marked stale (no longer in source data)
  nonUrlConfigsStored: number;
  stubsDetected: number;
  errors: Array<{ key: string; error: string }>;
}

export interface IntegrationBuildInput {
  sourceEnvironmentName: string;
  urlProperties: ClassifiedProperty[];
  nonUrlProperties: ClassifiedProperty[];
  discoveredBy: string;  // "pce-discovery-pipeline" or "pce-csv-upload"
  sourceFile?: string;   // CSV filename if uploaded
}

/**
 * Integration Builder
 * Orchestrates Neptune entity creation from classified PCE properties
 */
export class IntegrationBuilder {
  private neptuneClient: NeptuneSparqlClient;
  private hostnameResolver: HostnameResolver;

  constructor(neptuneClient: NeptuneSparqlClient, hostnameResolver: HostnameResolver) {
    this.neptuneClient = neptuneClient;
    this.hostnameResolver = hostnameResolver;
  }

  /**
   * Build all entities for a single source environment
   */
  async buildForEnvironment(input: IntegrationBuildInput): Promise<DiscoveryResult> {
    const result: DiscoveryResult = {
      sourceEnvironment: input.sourceEnvironmentName,
      environmentsCreated: [],
      integrationsCreated: [],
      integrationsSkipped: [],
      integrationsStale: [],
      nonUrlConfigsStored: 0,
      stubsDetected: 0,
      errors: [],
    };

    // Step 1: Ensure source environment exists
    const sourceEnvId = await this.ensureEnvironmentExists(input.sourceEnvironmentName, result);
    if (!sourceEnvId) {
      result.errors.push({ key: '_source', error: `Failed to create/find source environment: ${input.sourceEnvironmentName}` });
      return result;
    }

    // Step 2: Store non-URL properties as config on the source environment
    if (input.nonUrlProperties.length > 0) {
      await this.storeNonUrlConfigs(sourceEnvId, input.nonUrlProperties, result);
    }

    // Step 3: Process URL properties → create integrations
    const activeIntegrationKeys = new Set<string>();

    for (const prop of input.urlProperties) {
      try {
        const integrationKey = await this.processUrlProperty(
          prop,
          input.sourceEnvironmentName,
          sourceEnvId,
          input.discoveredBy,
          input.sourceFile,
          result
        );
        if (integrationKey) {
          activeIntegrationKeys.add(integrationKey);
        }
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : String(err);
        result.errors.push({ key: prop.propertyKey, error: errMsg });
        console.error(`Error processing ${prop.propertyKey}:`, err);
      }
    }

    // Step 4: Mark stale integrations (ones discovered previously but no longer in source data)
    await this.markStaleIntegrations(
      input.sourceEnvironmentName,
      input.discoveredBy,
      activeIntegrationKeys,
      result
    );

    return result;
  }

  /**
   * Ensure an Environment entity exists in Neptune, create if not
   */
  private async ensureEnvironmentExists(name: string, result: DiscoveryResult): Promise<string | null> {
    try {
      const exists = await this.neptuneClient.checkEntityExists(name, 'Environment');
      if (exists) {
        const entities = await this.neptuneClient.getEntitiesByTypeAndName('Environment', name);
        return entities[0]?.id || null;
      }

      const env: Omit<Environment, 'id'> = {
        name,
        type: 'Environment',
        description: `Auto-discovered by PCE pipeline`,
      };
      const created = await this.neptuneClient.createEnvironment(env);
      result.environmentsCreated.push(name);
      console.log(`Created environment: ${name} (${created.id})`);
      return created.id;
    } catch (err) {
      console.error(`Failed to ensure environment "${name}":`, err);
      return null;
    }
  }

  /**
   * Store non-URL properties as configuration on the source environment
   */
  private async storeNonUrlConfigs(
    envId: string,
    nonUrls: ClassifiedProperty[],
    result: DiscoveryResult
  ): Promise<void> {
    const configs: Record<string, string> = {};
    for (const prop of nonUrls) {
      configs[prop.propertyKey] = prop.propertyValue;
    }

    try {
      await this.neptuneClient.addConfigurationProperties(envId, configs);
      result.nonUrlConfigsStored = nonUrls.length;
      console.log(`Stored ${nonUrls.length} non-URL configs on environment ${envId}`);
    } catch (err) {
      console.error(`Failed to store non-URL configs:`, err);
      result.errors.push({ key: '_non_url_configs', error: String(err) });
    }
  }

  /**
   * Process a single URL property: resolve target, create integration, wire relationship
   * Returns the idempotency key for active integration tracking
   */
  private async processUrlProperty(
    prop: ClassifiedProperty,
    sourceEnvName: string,
    sourceEnvId: string,
    discoveredBy: string,
    sourceFile: string | undefined,
    result: DiscoveryResult
  ): Promise<string | null> {
    if (!prop.parsedUrl) return null;

    // Resolve hostname → target environment
    const resolved: ResolvedTarget = await this.hostnameResolver.resolve(prop.parsedUrl, sourceEnvName);

    // Create target environment if new
    if (resolved.isNewEnvironment) {
      const targetEnvId = await this.ensureEnvironmentExists(resolved.resolvedEnvironmentName, result);
      if (!targetEnvId) {
        result.errors.push({ key: prop.propertyKey, error: `Failed to create target environment: ${resolved.resolvedEnvironmentName}` });
        return null;
      }
    }

    // Build integration name from property key
    const integrationName = toIntegrationName(prop.propertyKey);
    const parsedKey = parsePropertyKey(prop.propertyKey);

    // Idempotency key: integration name + source environment
    const idempotencyKey = `${integrationName}::${sourceEnvName}`;

    // Check if this exact integration already exists
    const existingIntegrations = await this.neptuneClient.getEntitiesByTypeAndName('Integration', integrationName);
    let alreadyExists = false;

    for (const existing of existingIntegrations) {
      const existingConfigs = await this.neptuneClient.getEntityConfigurationsAsObject(existing.id);
      if (existingConfigs.config_sourceEnvironment === sourceEnvName) {
        // Same integration from same source — skip (idempotent)
        result.integrationsSkipped.push(integrationName);
        alreadyExists = true;
        console.log(`Integration "${integrationName}" from ${sourceEnvName} already exists, skipping`);
        break;
      }
    }

    if (alreadyExists) return idempotencyKey;

    // Track stub
    if (resolved.connectionType === 'stub') {
      result.stubsDetected++;
    }

    // Create Integration entity
    const relationshipType = resolved.connectionType === 'stub' ? 'stubs' : 'integratesWith';

    const integration: Omit<Integration, 'id'> = {
      name: integrationName,
      type: 'Integration',
      description: `${sourceEnvName} → ${resolved.resolvedEnvironmentName} (${resolved.connectionType})`,
      status: resolved.connectionType === 'stub' ? 'stubbed' : 'active',
    };

    const created = await this.neptuneClient.createIntegration(integration);

    // Add configuration properties
    const configs: Record<string, string> = {
      sourceEnvironment: sourceEnvName,
      targetEnvironment: resolved.resolvedEnvironmentName,
      connectionType: resolved.connectionType,
      protocol: prop.parsedUrl.protocol,
      hostname: prop.parsedUrl.hostname,
      port: String(prop.parsedUrl.port || ''),
      path: prop.parsedUrl.path,
      fullUrl: prop.parsedUrl.original,
      propertyKey: prop.propertyKey,
      endpointHint: parsedKey.endpointHint,
      discoveredBy,
      discoveredAt: new Date().toISOString(),
      resolutionMethod: resolved.resolutionMethod,
    };
    if (sourceFile) {
      configs.sourceFile = sourceFile;
    }

    await this.neptuneClient.addConfigurationProperties(created.id, configs);

    // Create relationships: sourceEnv → hasIntegration → Integration → integratesWith/stubs → targetEnv
    // 1. Source environment → hasIntegration → Integration entity
    await this.neptuneClient.createRelationship(
      sourceEnvName,
      'hasIntegration',
      integrationName,
      sourceEnvId,
      created.id
    );

    // 2. Integration entity → integratesWith/stubs → Target environment
    await this.neptuneClient.createRelationship(
      integrationName,
      relationshipType,
      resolved.resolvedEnvironmentName,
      created.id
    );

    result.integrationsCreated.push(integrationName);
    console.log(`Created integration: "${integrationName}" (${sourceEnvName} → ${resolved.resolvedEnvironmentName}, ${resolved.connectionType})`);

    return idempotencyKey;
  }

  /**
   * Find integrations that were previously discovered by this pipeline for this environment
   * but are no longer present in the source data → mark them as stale
   */
  private async markStaleIntegrations(
    sourceEnvName: string,
    discoveredBy: string,
    activeKeys: Set<string>,
    result: DiscoveryResult
  ): Promise<void> {
    try {
      // Query Neptune for all integrations discovered by this pipeline for this source env
      const query = `
        PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
        SELECT ?id ?name WHERE {
          ?entity env:type "Integration" ;
                  env:id ?id ;
                  env:name ?name ;
                  env:config_discoveredBy "${discoveredBy}" ;
                  env:config_sourceEnvironment "${sourceEnvName}" .
        }
      `;
      const queryResult = await this.neptuneClient.executeSparqlQuery(query);
      const bindings = queryResult.results?.bindings || [];

      for (const binding of bindings) {
        const name = binding.name?.value;
        const id = binding.id?.value;
        if (!name || !id) continue;

        const key = `${name}::${sourceEnvName}`;
        if (!activeKeys.has(key)) {
          // This integration was previously discovered but is no longer in the source data
          await this.neptuneClient.addConfigurationProperties(id, {
            status: 'stale',
            staleDetectedAt: new Date().toISOString(),
          });
          result.integrationsStale.push(name);
          console.log(`Marked integration "${name}" as stale (no longer in source data for ${sourceEnvName})`);
        }
      }
    } catch (err) {
      console.warn(`Stale detection failed for ${sourceEnvName}:`, err);
    }
  }
}
