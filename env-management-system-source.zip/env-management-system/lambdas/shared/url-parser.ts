// URL Parser for PCE Discovery Pipeline
// Classifies property values as URL or NON_URL and extracts components

export interface ParsedUrl {
  original: string;
  protocol: string;
  hostname: string;
  port: number | null;
  path: string;
}

export interface ClassifiedProperty {
  environmentName: string;
  propertyKey: string;
  propertyValue: string;
  isUrl: boolean;
  parsedUrl: ParsedUrl | null;
}

const URL_PATTERN = /^(https?):\/\/([^/:]+)(?::(\d+))?(\/.*)?$/i;

/**
 * Check if a property value is a URL
 */
export function isUrl(value: string): boolean {
  return URL_PATTERN.test(value.trim());
}

/**
 * Parse a URL string into its components
 */
export function parseUrl(value: string): ParsedUrl | null {
  const trimmed = value.trim();
  const match = trimmed.match(URL_PATTERN);
  if (!match) return null;

  const protocol = match[1].toLowerCase();
  const defaultPort = protocol === 'https' ? 443 : 80;

  return {
    original: trimmed,
    protocol,
    hostname: match[2].toLowerCase(),
    port: match[3] ? parseInt(match[3], 10) : defaultPort,
    path: match[4] || '/',
  };
}

/**
 * Classify a PCE property as URL or NON_URL and parse if URL
 */
export function classifyProperty(
  environmentName: string,
  propertyKey: string,
  propertyValue: string
): ClassifiedProperty {
  const parsed = parseUrl(propertyValue);
  return {
    environmentName,
    propertyKey,
    propertyValue,
    isUrl: parsed !== null,
    parsedUrl: parsed,
  };
}

/**
 * Classify a batch of properties, separating URL from NON_URL
 */
export function classifyProperties(
  records: Array<{ environmentName: string; propertyKey: string; propertyValue: string }>
): { urlProperties: ClassifiedProperty[]; nonUrlProperties: ClassifiedProperty[] } {
  const urlProperties: ClassifiedProperty[] = [];
  const nonUrlProperties: ClassifiedProperty[] = [];

  for (const record of records) {
    const classified = classifyProperty(record.environmentName, record.propertyKey, record.propertyValue);
    if (classified.isUrl) {
      urlProperties.push(classified);
    } else {
      nonUrlProperties.push(classified);
    }
  }

  return { urlProperties, nonUrlProperties };
}
