import * as cdk from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';

export interface BedrockStackProps extends cdk.StackProps {
  neptuneClusterEndpoint: string;
  neptuneSecurityGroup: ec2.ISecurityGroup;
  neptuneVpc: ec2.IVpc;
  neptuneSubnets: ec2.ISubnet[];
}

export class BedrockAiQueryStack extends cdk.Stack {
  public readonly bedrockQueryApi: apigateway.RestApi;
  public readonly bedrockQueryLambda: lambda.Function;

  constructor(scope: Construct, id: string, props: BedrockStackProps) {
    super(scope, id, props);

    // Create Lambda execution role with Bedrock and Neptune permissions
    const lambdaRole = new iam.Role(this, 'BedrockQueryLambdaRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      description: 'Execution role for Bedrock AI query Lambda',
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaVPCAccessExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
      ],
    });

    // Add Bedrock permissions (allow all Amazon models - no approval required)
    lambdaRole.addToPolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ['bedrock:InvokeModel'],
      resources: [
        `arn:aws:bedrock:${this.region}::foundation-model/amazon.*`,
      ],
    }));

    // Add Neptune read permissions
    lambdaRole.addToPolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'neptune-db:ReadDataViaQuery',
        'neptune-db:connect',
      ],
      resources: [
        `arn:aws:neptune-db:${this.region}:${this.account}:*/*`,
      ],
    }));

    // Create Bedrock Query Lambda (pre-built: npm install && npm run build in bedrock-lambda/)
    this.bedrockQueryLambda = new lambda.Function(this, 'BedrockQueryLambda', {
      functionName: 'BedrockAI-NeptuneQuery',
      runtime: lambda.Runtime.NODEJS_20_X,
      handler: 'src/bedrock-query.handler',
      code: lambda.Code.fromAsset('bedrock-lambda'),
      timeout: cdk.Duration.seconds(60),
      memorySize: 512,
      environment: {
        NEPTUNE_ENDPOINT: props.neptuneClusterEndpoint,
      },
      role: lambdaRole,
      vpc: props.neptuneVpc,
      vpcSubnets: {
        subnets: props.neptuneSubnets,
      },
      securityGroups: [props.neptuneSecurityGroup],
      description: 'AI-powered natural language query handler for Neptune using AWS Bedrock',
    });

    // Create API Gateway
    this.bedrockQueryApi = new apigateway.RestApi(this, 'BedrockQueryApi', {
      restApiName: 'Bedrock AI Query API',
      description: 'Natural language query interface for Neptune database',
      defaultCorsPreflightOptions: {
        allowOrigins: apigateway.Cors.ALL_ORIGINS,
        allowMethods: apigateway.Cors.ALL_METHODS,
        allowHeaders: ['Content-Type', 'Authorization', 'X-Amz-Date', 'X-Api-Key', 'X-Amz-Security-Token'],
      },
      deployOptions: {
        stageName: 'prod',
        description: 'Production stage for Bedrock AI Query API',
        loggingLevel: apigateway.MethodLoggingLevel.INFO,
        dataTraceEnabled: true,
      },
    });

    // Add /query endpoint
    const queryResource = this.bedrockQueryApi.root.addResource('query');
    const queryIntegration = new apigateway.LambdaIntegration(this.bedrockQueryLambda, {
      proxy: true,
      allowTestInvoke: true,
    });
    
    queryResource.addMethod('POST', queryIntegration, {
      apiKeyRequired: false,
      methodResponses: [
        {
          statusCode: '200',
          responseParameters: {
            'method.response.header.Access-Control-Allow-Origin': true,
          },
        },
      ],
    });

    queryResource.addMethod('GET', queryIntegration, {
      apiKeyRequired: false,
      requestParameters: {
        'method.request.querystring.query': false,
      },
    });

    // Add /stats endpoint for entity stats/health
    const statsResource = this.bedrockQueryApi.root.addResource('stats');
    const statsIntegration = new apigateway.LambdaIntegration(this.bedrockQueryLambda, {
      proxy: true,
      allowTestInvoke: true,
    });

    statsResource.addMethod('GET', statsIntegration, {
      apiKeyRequired: false,
      requestParameters: {
        'method.request.querystring.entityName': false,
        'method.request.querystring.entityId': false,
      },
    });

    statsResource.addMethod('POST', statsIntegration, {
      apiKeyRequired: false,
    });

    // Add /health-dashboard endpoint for health overview
    const healthResource = this.bedrockQueryApi.root.addResource('health-dashboard');
    const healthIntegration = new apigateway.LambdaIntegration(this.bedrockQueryLambda, {
      proxy: true,
      allowTestInvoke: true,
    });

    healthResource.addMethod('GET', healthIntegration, {
      apiKeyRequired: false,
      requestParameters: {
        'method.request.querystring.entityType': false,
      },
    });

    healthResource.addMethod('POST', healthIntegration, {
      apiKeyRequired: false,
    });

    // Add Lambda Function URL for direct access (optional)
    const functionUrl = this.bedrockQueryLambda.addFunctionUrl({
      authType: lambda.FunctionUrlAuthType.NONE,
      cors: {
        allowedOrigins: ['*'],
        allowedMethods: [lambda.HttpMethod.GET, lambda.HttpMethod.POST],
        allowedHeaders: ['*'],
      },
    });

    // CloudFormation Outputs
    new cdk.CfnOutput(this, 'BedrockQueryApiUrl', {
      value: this.bedrockQueryApi.url,
      description: 'Bedrock AI Query API Gateway URL',
      exportName: 'BedrockQueryApiUrl',
    });

    new cdk.CfnOutput(this, 'BedrockQueryEndpoint', {
      value: `${this.bedrockQueryApi.url}query`,
      description: 'Bedrock AI Query Endpoint',
      exportName: 'BedrockQueryEndpoint',
    });

    new cdk.CfnOutput(this, 'BedrockQueryLambdaArn', {
      value: this.bedrockQueryLambda.functionArn,
      description: 'Bedrock Query Lambda Function ARN',
      exportName: 'BedrockQueryLambdaArn',
    });

    new cdk.CfnOutput(this, 'BedrockQueryFunctionUrl', {
      value: functionUrl.url,
      description: 'Bedrock Query Lambda Function URL (direct access)',
      exportName: 'BedrockQueryFunctionUrl',
    });

    // Tags
    cdk.Tags.of(this).add('Project', 'Neptune-Environment-Management');
    cdk.Tags.of(this).add('Component', 'Bedrock-AI-Query');
    cdk.Tags.of(this).add('CostCenter', 'AI-Services');
  }
}
