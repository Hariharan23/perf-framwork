#!/bin/bash
# Deploy SPARQL-only Neptune Environment Management System

echo "Building and deploying SPARQL-only Neptune Environment Management System..."

# Build lambdas
echo "Building Lambda functions..."
cd lambdas
npm run build
if [ $? -ne 0 ]; then
    echo "Lambdas build failed"
    exit 1
fi
cd ..

# Build bedrock-lambda
echo "Building Bedrock Lambda..."
cd bedrock-lambda
npm run build
if [ $? -ne 0 ]; then
    echo "Bedrock Lambda build failed"
    exit 1
fi
cd ..

echo "Build completed successfully"
echo "Deploying CDK stack..."
npx cdk deploy --all --require-approval never --outputs-file cdk-outputs.json

if [ $? -eq 0 ]; then
    echo "Deployment completed successfully!"
    echo "Check cdk-outputs.json for endpoint URLs"
else
    echo "Deployment failed"
    exit 1
fi