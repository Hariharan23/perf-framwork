# Real-Time Trending Queries with Bedrock Integration

## Overview

When the AI Query feature is connected to a live Bedrock agent, replace the current hardcoded popular queries with a real-time trending system. The key insight: normalize queries by the **SPARQL output** (not the natural language input), since Bedrock will generate the same SPARQL for semantically identical questions regardless of phrasing.

---

## Architecture

### 1. Query Normalization

- When a user submits a natural language query, Bedrock returns a SPARQL query.
- **Hash the generated SPARQL** (SHA-256) to create a canonical query ID.
- This automatically groups "show me all environments", "list environments", and "what environments exist?" into the same trending entry.

### 2. DynamoDB Table: `QueryAnalytics`

| Attribute          | Type         | Description                                               |
| ------------------ | ------------ | --------------------------------------------------------- |
| `sparqlHash` (PK)  | String       | SHA-256 of the normalized SPARQL                          |
| `sampleQuestion`   | String       | First natural language question that produced this SPARQL |
| `sparqlQuery`      | String       | The actual SPARQL query                                   |
| `totalCount`       | Number       | Atomic counter — total executions                         |
| `uniqueUsers`      | StringSet    | Set of unique user IDs                                    |
| `recentTimestamps` | List         | Last N timestamps (e.g., last 50) for recency scoring     |
| `lastExecuted`     | String (ISO) | Timestamp of most recent execution                        |
| `createdAt`        | String (ISO) | First time this query was seen                            |

### 3. Recording Query Analytics (Write Path)

On each Bedrock query execution, a Lambda updates the analytics table:

```python
# Pseudocode for the analytics recorder
sparql_hash = sha256(normalize_whitespace(sparql_query))

dynamodb.update_item(
    Key={'sparqlHash': sparql_hash},
    UpdateExpression='''
        SET sampleQuestion = if_not_exists(sampleQuestion, :question),
            sparqlQuery = :sparql,
            lastExecuted = :now,
            createdAt = if_not_exists(createdAt, :now)
        ADD totalCount :one,
            uniqueUsers :userSet
    ''',
    ExpressionAttributeValues={
        ':question': user_question,
        ':sparql': sparql_query,
        ':now': datetime.utcnow().isoformat(),
        ':one': 1,
        ':userSet': {user_id}
    }
)
```

### 4. Trending Score Formula (Time-Decay)

```
trending_score = (executions_last_24h * 3) + (executions_last_7d * 1.5) + (unique_users * 2)
```

- **Recency bias**: Recent queries score higher than stale ones.
- **Breadth bias**: Queries from many different users rank higher than one user running the same query repeatedly.
- Compute this server-side in the popular queries Lambda.

### 5. API Endpoint: `GET /popular-queries`

**Lambda logic:**

1. Scan the `QueryAnalytics` table.
2. Compute `trending_score` for each entry using the time-decay formula.
3. Sort descending by score.
4. Return the top 10–15 entries.

**Response format:**

```json
[
  {
    "question": "Show all critical environments",
    "sparqlHash": "abc123...",
    "totalSearches": 142,
    "uniqueUsers": 12,
    "trendingScore": 87.5,
    "lastExecuted": "2026-04-15T10:30:00Z"
  }
]
```

### 6. Caching Strategy

| Layer                     | TTL     | Purpose                                                                               |
| ------------------------- | ------- | ------------------------------------------------------------------------------------- |
| **API Gateway**           | 15 min  | Cache the `GET /popular-queries` response — trending doesn't need real-time precision |
| **localStorage**          | Session | Cache user's own recent queries client-side (already implemented)                     |
| **CloudFront** (optional) | 30 min  | If serving from a CDN edge                                                            |

### 7. Frontend Integration

Replace the hardcoded `popularQueries` array with an API call:

```javascript
async function loadPopularQueries() {
  try {
    const response = await fetch(CONFIG.POPULAR_QUERIES_URL);
    const data = await response.json();
    popularQueries = data.map((q) => ({
      query: q.question,
      users: q.uniqueUsers,
      searches: q.totalSearches,
      trend: q.trendingScore > 50 ? "up" : "stable",
    }));
    updateAiHistoryDisplay();
  } catch (error) {
    console.error("Failed to load popular queries:", error);
    // Fall back to hardcoded queries
  }
}
```

---

## CDK Infrastructure Additions

1. **DynamoDB Table** — `QueryAnalytics` with `sparqlHash` as partition key, on-demand billing.
2. **Lambda: RecordQueryAnalytics** — Called after each Bedrock query execution. Updates the DynamoDB table with atomic counters.
3. **Lambda: GetPopularQueries** — Scans table, computes trending scores, returns top N. Attached to API Gateway with 15-min cache.
4. **API Gateway Route** — `GET /popular-queries` with API key auth and caching enabled.

---

## Implementation Steps

1. Create the `QueryAnalytics` DynamoDB table in CDK.
2. Write the `RecordQueryAnalytics` Lambda (triggered inline after Bedrock query).
3. Write the `GetPopularQueries` Lambda with time-decay scoring.
4. Add `GET /popular-queries` API Gateway endpoint with caching.
5. Update `environment-management-app.html`:
   - Add `CONFIG.POPULAR_QUERIES_URL`.
   - Replace hardcoded `popularQueries` with `loadPopularQueries()` API call.
   - Keep hardcoded array as fallback.
6. Test with simulated traffic, verify trending scores shift correctly over time.

---

## Notes

- The simulated popular queries (currently hardcoded in the HTML) serve as a good fallback and demo mode.
- User identity can come from API key, Cognito, or a simple client-generated UUID stored in localStorage.
- Consider adding a GSI on `lastExecuted` if you need to efficiently prune stale entries.
