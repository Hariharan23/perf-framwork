# Bedrock AI Query Lambda

AI-powered natural language query interface for Neptune graph database using AWS Bedrock (Amazon Nova Micro).

## Features

- **Natural Language Queries**: Ask questions in plain English
- **Cost-Effective**: Uses Amazon Nova Micro (~$0.0004 per query)
- **SPARQL Generation**: Automatically converts natural language to SPARQL
- **Query History**: Tracks last 10 queries
- **Multiple Result Views**: Table, formatted text, and JSON views

## Architecture

```
User Query → API Gateway → Lambda → Bedrock (Nova Micro) → Generate SPARQL → Execute on Neptune → Return Results
```

## Cost Estimates

- **Amazon Nova Micro**: Cost-effective text generation model
- **Average Query**: ~500 input tokens + ~200 output tokens
- **Cost per query**: ~$0.0004
- **Monthly (1000 queries)**: ~$0.40
- **Monthly (10K queries)**: ~$4.00

## Deployment

### 1. Install Dependencies

```bash
cd bedrock-lambda
npm install
```

### 2. Build TypeScript

```bash
npm run build
```

### 3. Deploy Bedrock Stack

From the root directory:

```bash
cdk deploy SRE-POC-BedrockAiQueryStack
```

### 4. Update Frontend

After deployment, copy the API endpoint from the CloudFormation outputs:

```
BedrockQueryEndpoint = https://XXX.execute-api.us-east-1.amazonaws.com/prod/query
```

Update the `BEDROCK_QUERY_URL` in `environment-management-app.html`:

```javascript
const CONFIG = {
  // ... other URLs
  BEDROCK_QUERY_URL:
    "https://XXX.execute-api.us-east-1.amazonaws.com/prod/query",
};
```

## Example Queries

- "Show all active environments"
- "List applications owned by john@example.com"
- "What integrations exist?"
- "Count total entities"
- "Show configurations for CAS_QA"
- "Which apps are deployed to production?"

## IAM Permissions Required

The Lambda function requires:

```json
{
  "Effect": "Allow",
  "Action": ["bedrock:InvokeModel"],
  "Resource": "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-haiku-*"
}
```

## Neptune SPARQL Ontology

The AI understands this schema:

**Entity Types:**

- Environment (id, name, owner, status, region, endpoint, config\_\*)
- Application (id, name, owner, status, version, config\_\*)
- Integration (id, name, owner, status, protocol, config\_\*)
- Relationship (sourceEntity, relationshipType, targetEntity)

**Namespace:** `http://neptune.aws.com/envmgmt/ontology/`

## Monitoring

- CloudWatch Logs: `/aws/lambda/BedrockAI-NeptuneQuery`
- Average latency: 2-4 seconds (includes Bedrock + Neptune execution)
- Timeout: 60 seconds

## Troubleshooting

### 1. "Bedrock model not found"

Ensure Claude 3 Haiku is available in your region:

```bash
aws bedrock list-foundation-models --region us-east-1 | grep claude-3-haiku
```

### 2. "Neptune connection timeout"

Check VPC configuration:

- Lambda is in same VPC as Neptune
- Security group allows traffic on port 8182
- Subnets are private with NAT gateway for outbound

### 3. "Invalid SPARQL query"

The AI-generated SPARQL may need refinement. Check:

- SPARQL syntax in CloudWatch logs
- Neptune error messages
- Consider refining the system prompt

## Development

### Local Testing

```bash
# Set environment variables
export NEPTUNE_ENDPOINT=your-neptune-cluster.amazonaws.com
export AWS_REGION=us-east-1

# Run tests (if available)
npm test
```

### Modify System Prompt

Edit `src/bedrock-query.ts`, update the `SYSTEM_PROMPT` constant with Neptune schema changes.

## Security

- Uses IAM authentication for Neptune
- Uses VPC private subnets
- API Gateway with CORS enabled
- No sensitive data stored in logs (queries only)

## Future Enhancements

- [ ] Multi-turn conversations with context
- [ ] Query result caching
- [ ] OpenSearch semantic search integration
- [ ] Query suggestions based on current view
- [ ] Rate limiting per user
- [ ] Query validation before execution
