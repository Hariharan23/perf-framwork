import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { BedrockRuntimeClient, InvokeModelCommand } from '@aws-sdk/client-bedrock-runtime';
import { defaultProvider } from '@aws-sdk/credential-provider-node';
import { HttpRequest } from '@smithy/protocol-http';
import { Sha256 } from '@aws-crypto/sha256-js';
import { SignatureV4 } from '@smithy/signature-v4';
import axios from 'axios';

// Initialize Bedrock client
const bedrockClient = new BedrockRuntimeClient({
  region: process.env.AWS_REGION || 'us-east-1',
  credentials: defaultProvider(),
});

// Initialize IAM signer for Neptune
const credentials = defaultProvider();
const region = process.env.AWS_REGION || 'us-east-1';
const signer = new SignatureV4({
  credentials,
  region,
  service: 'neptune-db',
  sha256: Sha256,
});

// Neptune SPARQL endpoint from environment
const NEPTUNE_ENDPOINT = process.env.NEPTUNE_ENDPOINT || '';
const NEPTUNE_PORT = '8182';

// Bedrock model configuration (Amazon Nova Micro - cost-effective and no approval required)
const BEDROCK_MODEL_ID = 'amazon.nova-micro-v1:0';
const MAX_TOKENS = 2000;
const TEMPERATURE = 0.1; // Low temperature for deterministic query generation

/**
 * System prompt with Neptune ontology schema
 */
const SYSTEM_PROMPT = `You are a SPARQL query generator for a Neptune graph database.

DATABASE ONTOLOGY:
- Namespace: http://neptune.aws.com/envmgmt/ontology/
- Prefix: env

ENTITY TYPES:
1. Environment - Infrastructure environments (QA, Prod, etc.)
   Properties: id, name, type, description, owner, status, createdAt
   Config Properties: region, endpoint, config_*
   ScienceLogic Meta: deviceName, deviceDescription, ipAddress, deviceClass, organization, collectionMode, deviceHostname, managedType, category, subClass, uptime, collectionTime, collectorGroup, sourceId, sourceSystem, lastSyncedAt
   ScienceLogic Stats: availability, latency, cpu, memory, swap, currentState, storage, healthScore
   
2. Application - Software applications
   Properties: id, name, type, description, owner, status, createdAt
   Config Properties: version, config_*
   ScienceLogic Meta: deviceName, deviceDescription, ipAddress, deviceClass, organization, collectionMode, deviceHostname, managedType, category, subClass, uptime, collectionTime, collectorGroup, sourceId, sourceSystem, lastSyncedAt
   ScienceLogic Stats: availability, latency, cpu, memory, swap, currentState, storage, healthScore
   
3. Integration - Service integrations
   Properties: id, name, type, description, owner, status, createdAt
   Config Properties: protocol, sourceService, targetService, config_*
   ScienceLogic Meta: deviceName, deviceDescription, ipAddress, deviceClass, organization, collectionMode, deviceHostname, managedType, category, subClass, uptime, collectionTime, collectorGroup, sourceId, sourceSystem, lastSyncedAt
   ScienceLogic Stats: availability, latency, cpu, memory, swap, currentState, storage, healthScore

4. Relationship - Connections between entities
   Properties: id, name, type, relationshipType, sourceEntity, targetEntity, sourceEntityId, targetEntityId

SCIENCELOGIC META PROPERTIES (device metadata):
- deviceName: Device name as shown in ScienceLogic dashboard
- deviceDescription: Device description from ScienceLogic
- ipAddress: IP address or device ID
- deviceClass: Device classification (e.g. server, switch, router)
- organization: Organization the device belongs to
- collectionMode: Data collection mode (e.g. SNMP, Agent, API)
- deviceHostname: Hostname of the device
- managedType: Managed type (e.g. Managed, Unmanaged)
- category: Device category (e.g. Server, Network, Storage)
- subClass: Device sub-class
- uptime: Device uptime
- collectionTime: Last data collection timestamp
- collectorGroup: Collector group or data collector name
- sourceId: External source system identifier
- sourceSystem: External monitoring system name (e.g. ScienceLogic)
- lastSyncedAt: Last sync timestamp

SCIENCELOGIC STATS PROPERTIES (monitoring/health):
- availability: Uptime/availability percentage
- latency: Network latency in milliseconds
- cpu: CPU usage percentage
- memory: Memory usage percentage
- swap: Swap memory usage percentage
- currentState: Current operational state (e.g. Healthy, Warning, Critical, Notice, Major)
- storage: Storage usage percentage
- healthScore: Overall health score (0-100)

CRITICAL REQUIREMENT:
EVERY query MUST start with:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>

SPARQL RULES:
1. Entity types: env:Environment, env:Application, env:Integration
2. Properties are directly on entities (flat structure)
3. Configuration properties start with env:config_
4. Always add LIMIT clause (default: LIMIT 100)
5. Use FILTER for text matching with CONTAINS or regex
6. Escape special characters in string literals
7. For counts, use SELECT (COUNT(?var) AS ?count)
8. Return only valid SPARQL 1.1 queries

COMMON QUERY PATTERNS:

List all entities of a type:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?id ?name ?status ?owner WHERE {
  ?entity rdf:type env:Environment ;
          env:id ?id ;
          env:name ?name .
  OPTIONAL { ?entity env:status ?status }
  OPTIONAL { ?entity env:owner ?owner }
} LIMIT 100

Find entity by name:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?id ?type ?description ?owner ?status WHERE {
  ?entity env:name "CAS_QA" ;
          env:id ?id ;
          env:type ?type .
  OPTIONAL { ?entity env:description ?description }
  OPTIONAL { ?entity env:owner ?owner }
  OPTIONAL { ?entity env:status ?status }
}

Get entity configurations:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?key ?value WHERE {
  ?entity env:name "CAS_QA" ;
          ?configProp ?value .
  FILTER(CONTAINS(STR(?configProp), "config_"))
  BIND(REPLACE(STR(?configProp), ".*config_", "") AS ?key)
}

Find relationships:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?source ?relType ?target WHERE {
  ?rel env:type "Relationship" ;
       env:sourceEntity ?source ;
       env:relationshipType ?relType ;
       env:targetEntity ?target .
}

Count entities:
SELECT (COUNT(?entity) AS ?count) WHERE {
  ?entity rdf:type env:Application .
}

Filter by property:
SELECT ?name ?status WHERE {
  ?entity rdf:type env:Environment ;
          env:name ?name ;
          env:status ?status .
  FILTER(?status = "active")
}

Get entity stats/health:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type ?currentState ?availability ?latency ?cpu ?memory ?swap ?ipAddress ?deviceClass WHERE {
  ?entity env:name ?name ;
          env:type ?type .
  OPTIONAL { ?entity env:currentState ?currentState }
  OPTIONAL { ?entity env:availability ?availability }
  OPTIONAL { ?entity env:latency ?latency }
  OPTIONAL { ?entity env:cpu ?cpu }
  OPTIONAL { ?entity env:memory ?memory }
  OPTIONAL { ?entity env:swap ?swap }
  OPTIONAL { ?entity env:ipAddress ?ipAddress }
  OPTIONAL { ?entity env:deviceClass ?deviceClass }
  FILTER(?type IN ("Environment", "Application", "Integration"))
} LIMIT 100

Get full ScienceLogic details for a specific entity:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type ?currentState ?availability ?latency ?cpu ?memory ?swap ?ipAddress ?deviceClass ?organization ?collectionMode ?deviceHostname ?managedType ?category ?subClass ?uptime ?collectionTime ?collectorGroup ?sourceSystem ?lastSyncedAt WHERE {
  ?entity env:name "CAS_QA" ;
          env:name ?name ;
          env:type ?type .
  OPTIONAL { ?entity env:currentState ?currentState }
  OPTIONAL { ?entity env:availability ?availability }
  OPTIONAL { ?entity env:latency ?latency }
  OPTIONAL { ?entity env:cpu ?cpu }
  OPTIONAL { ?entity env:memory ?memory }
  OPTIONAL { ?entity env:swap ?swap }
  OPTIONAL { ?entity env:ipAddress ?ipAddress }
  OPTIONAL { ?entity env:deviceClass ?deviceClass }
  OPTIONAL { ?entity env:organization ?organization }
  OPTIONAL { ?entity env:collectionMode ?collectionMode }
  OPTIONAL { ?entity env:deviceHostname ?deviceHostname }
  OPTIONAL { ?entity env:managedType ?managedType }
  OPTIONAL { ?entity env:category ?category }
  OPTIONAL { ?entity env:subClass ?subClass }
  OPTIONAL { ?entity env:uptime ?uptime }
  OPTIONAL { ?entity env:collectionTime ?collectionTime }
  OPTIONAL { ?entity env:collectorGroup ?collectorGroup }
  OPTIONAL { ?entity env:sourceSystem ?sourceSystem }
  OPTIONAL { ?entity env:lastSyncedAt ?lastSyncedAt }
}

Find unhealthy entities (Critical or Warning state):
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type ?currentState ?availability ?cpu ?memory ?latency WHERE {
  ?entity env:name ?name ;
          env:type ?type ;
          env:currentState ?currentState .
  FILTER(?currentState IN ("Critical", "Warning", "Major"))
} ORDER BY ?currentState LIMIT 100

Find entities by organization:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type ?organization ?currentState ?ipAddress WHERE {
  ?entity env:name ?name ;
          env:type ?type ;
          env:organization ?organization .
  OPTIONAL { ?entity env:currentState ?currentState }
  OPTIONAL { ?entity env:ipAddress ?ipAddress }
  FILTER(CONTAINS(?organization, "OrgName"))
} LIMIT 100

Find entities with high latency:
PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
SELECT ?name ?type ?latency ?availability ?currentState WHERE {
  ?entity env:name ?name ;
          env:type ?type ;
          env:latency ?latency .
  FILTER(xsd:float(?latency) > 100)
} ORDER BY DESC(xsd:float(?latency)) LIMIT 100

IMPORTANT: Return ONLY the SPARQL query, no explanations or markdown formatting.`;

/**
 * Execute SPARQL query on Neptune with IAM authentication
 */
async function executeSparqlQuery(query: string): Promise<any> {
  const body = `query=${encodeURIComponent(query)}`;
  
  // Create the request for signing
  const request = new HttpRequest({
    method: 'POST',
    protocol: 'https:',
    hostname: NEPTUNE_ENDPOINT,
    port: 8182,
    path: '/sparql',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/sparql-results+json',
      'Host': `${NEPTUNE_ENDPOINT}:8182`,
    },
    body,
  });
  
  try {
    // Sign the request with IAM credentials
    const signedRequest = await signer.sign(request);
    
    // Construct the full URL
    const endpoint = `https://${NEPTUNE_ENDPOINT}:${NEPTUNE_PORT}/sparql`;
    
    console.log(`Executing SPARQL query to: ${endpoint}`);
    console.log(`Query: ${query.substring(0, 200)}...`);
    
    const response = await axios({
      method: 'POST',
      url: endpoint,
      headers: {
        ...signedRequest.headers,
        'Content-Length': body.length.toString(),
      },
      data: body,
      timeout: 30000,
    });
    
    return response.data;
  } catch (error: any) {
    console.error('SPARQL execution error:', error.response?.data || error.message);
    throw new Error(`Neptune query failed: ${error.response?.data?.message || error.message}`);
  }
}

/**
 * Call Bedrock to generate SPARQL from natural language
 */
async function generateSparqlWithBedrock(userQuery: string): Promise<string> {
  // Amazon Nova uses messages format similar to Claude
  const prompt = {
    schemaVersion: "messages-v1",
    messages: [
      {
        role: "user",
        content: [
          {
            text: `${SYSTEM_PROMPT}\n\nConvert this natural language query to SPARQL:\n\n${userQuery}\n\nReturn only the SPARQL query, nothing else.`
          }
        ]
      }
    ],
    inferenceConfig: {
      max_new_tokens: MAX_TOKENS,
      temperature: TEMPERATURE
    }
  };

  const command = new InvokeModelCommand({
    modelId: BEDROCK_MODEL_ID,
    contentType: 'application/json',
    accept: 'application/json',
    body: JSON.stringify(prompt),
  });

  try {
    const response = await bedrockClient.send(command);
    const responseBody = JSON.parse(new TextDecoder().decode(response.body));
    
    console.log('Bedrock response:', JSON.stringify(responseBody, null, 2));
    
    // Extract SPARQL from Nova response format
    let sparqlQuery = responseBody.output?.message?.content?.[0]?.text || responseBody.results?.[0]?.outputText || '';
    sparqlQuery = sparqlQuery.trim();
    
    // Remove markdown code blocks if present
    sparqlQuery = sparqlQuery.replace(/```sparql\n?/g, '').replace(/```\n?/g, '').trim();
    
    // Ensure PREFIX is present - add if missing
    if (!sparqlQuery.toLowerCase().includes('prefix env:')) {
      sparqlQuery = 'PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>\n\n' + sparqlQuery;
    }
    
    console.log('Generated SPARQL:', sparqlQuery);
    
    return sparqlQuery;
  } catch (error: any) {
    console.error('Bedrock invocation error:', error);
    throw new Error(`Failed to generate SPARQL: ${error.message}`);
  }
}

/**
 * All ScienceLogic property names (meta + stats) for detection
 */
const STAT_PROPERTIES = [
  // Meta
  'deviceName', 'deviceDescription',
  'ipAddress', 'deviceClass', 'organization', 'collectionMode',
  'deviceHostname', 'managedType', 'category', 'subClass',
  'uptime', 'collectionTime', 'collectorGroup',
  'sourceId', 'sourceSystem', 'lastSyncedAt',
  // Stats
  'availability', 'latency', 'cpu', 'memory', 'swap', 'currentState',
  // Derived/Internal
  'storage', 'healthScore',
];

/**
 * Execute a direct SPARQL query to get stats/health for a specific entity
 */
async function getEntityStats(entityIdentifier: string): Promise<any> {
  // Try to find entity by name or ID
  const query = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>

    SELECT ?id ?name ?type ?status
           ?deviceName ?deviceDescription
           ?ipAddress ?deviceClass ?organization ?collectionMode
           ?deviceHostname ?managedType ?category ?subClass
           ?uptime ?collectionTime ?collectorGroup
           ?sourceId ?sourceSystem ?lastSyncedAt
           ?availability ?latency ?cpu ?memory ?swap ?currentState
           ?storage ?healthScore
    WHERE {
      ?entity env:name ?name ;
              env:id ?id ;
              env:type ?type .
      FILTER(?name = "${entityIdentifier}" || ?id = "${entityIdentifier}")
      OPTIONAL { ?entity env:status ?status }
      OPTIONAL { ?entity env:deviceName ?deviceName }
      OPTIONAL { ?entity env:deviceDescription ?deviceDescription }
      OPTIONAL { ?entity env:ipAddress ?ipAddress }
      OPTIONAL { ?entity env:deviceClass ?deviceClass }
      OPTIONAL { ?entity env:organization ?organization }
      OPTIONAL { ?entity env:collectionMode ?collectionMode }
      OPTIONAL { ?entity env:deviceHostname ?deviceHostname }
      OPTIONAL { ?entity env:managedType ?managedType }
      OPTIONAL { ?entity env:category ?category }
      OPTIONAL { ?entity env:subClass ?subClass }
      OPTIONAL { ?entity env:uptime ?uptime }
      OPTIONAL { ?entity env:collectionTime ?collectionTime }
      OPTIONAL { ?entity env:collectorGroup ?collectorGroup }
      OPTIONAL { ?entity env:sourceId ?sourceId }
      OPTIONAL { ?entity env:sourceSystem ?sourceSystem }
      OPTIONAL { ?entity env:lastSyncedAt ?lastSyncedAt }
      OPTIONAL { ?entity env:availability ?availability }
      OPTIONAL { ?entity env:latency ?latency }
      OPTIONAL { ?entity env:cpu ?cpu }
      OPTIONAL { ?entity env:memory ?memory }
      OPTIONAL { ?entity env:swap ?swap }
      OPTIONAL { ?entity env:currentState ?currentState }
      OPTIONAL { ?entity env:storage ?storage }
      OPTIONAL { ?entity env:healthScore ?healthScore }
    }
    LIMIT 1
  `;

  return executeSparqlQuery(query);
}

/**
 * Execute a direct SPARQL query to get health dashboard (all entities with stats)
 */
async function getHealthDashboard(entityType?: string): Promise<any> {
  const typeFilter = entityType
    ? `FILTER(?type = "${entityType}")`
    : 'FILTER(?type IN ("Environment", "Application", "Integration"))';

  const query = `
    PREFIX env: <http://neptune.aws.com/envmgmt/ontology/>
    PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>

    SELECT ?id ?name ?type ?status
           ?deviceName ?deviceDescription
           ?currentState ?availability ?latency ?cpu ?memory ?swap
           ?ipAddress ?deviceClass ?organization ?category
           ?uptime ?collectorGroup ?sourceSystem ?lastSyncedAt
           ?storage ?healthScore
    WHERE {
      ?entity env:name ?name ;
              env:id ?id ;
              env:type ?type .
      ${typeFilter}
      OPTIONAL { ?entity env:status ?status }
      OPTIONAL { ?entity env:deviceName ?deviceName }
      OPTIONAL { ?entity env:deviceDescription ?deviceDescription }
      OPTIONAL { ?entity env:currentState ?currentState }
      OPTIONAL { ?entity env:availability ?availability }
      OPTIONAL { ?entity env:latency ?latency }
      OPTIONAL { ?entity env:cpu ?cpu }
      OPTIONAL { ?entity env:memory ?memory }
      OPTIONAL { ?entity env:swap ?swap }
      OPTIONAL { ?entity env:ipAddress ?ipAddress }
      OPTIONAL { ?entity env:deviceClass ?deviceClass }
      OPTIONAL { ?entity env:organization ?organization }
      OPTIONAL { ?entity env:category ?category }
      OPTIONAL { ?entity env:uptime ?uptime }
      OPTIONAL { ?entity env:collectorGroup ?collectorGroup }
      OPTIONAL { ?entity env:sourceSystem ?sourceSystem }
      OPTIONAL { ?entity env:lastSyncedAt ?lastSyncedAt }
      OPTIONAL { ?entity env:storage ?storage }
      OPTIONAL { ?entity env:healthScore ?healthScore }
    }
    ORDER BY DESC(?healthScore)
    LIMIT 200
  `;

  return executeSparqlQuery(query);
}

/**
 * Parse stats from a SPARQL result binding into a structured stats object
 */
function parseStatsFromBinding(binding: any): Record<string, string> {
  const stats: Record<string, string> = {};
  for (const prop of STAT_PROPERTIES) {
    if (binding[prop]?.value) {
      stats[prop] = binding[prop].value;
    }
  }
  return stats;
}

/**
 * Format entity stats into a human-readable summary
 */
function formatEntityStats(binding: any): string {
  const name = binding.name?.value || 'Unknown';
  const type = binding.type?.value || 'Unknown';
  const status = binding.status?.value || 'unknown';
  const stats = parseStatsFromBinding(binding);

  let formatted = `Entity: ${name} (${type}) [${status}]\n`;

  if (Object.keys(stats).length === 0) {
    formatted += '  No ScienceLogic data available.\n';
    return formatted;
  }

  // Current state / health
  if (stats.currentState) formatted += `  Current State: ${stats.currentState}\n`;
  if (stats.healthScore) formatted += `  Health Score: ${stats.healthScore}\n`;

  // Performance stats
  if (stats.availability) formatted += `  Availability: ${stats.availability}%\n`;
  if (stats.latency) formatted += `  Latency: ${stats.latency}ms\n`;
  if (stats.cpu) formatted += `  CPU: ${stats.cpu}%\n`;
  if (stats.memory) formatted += `  Memory: ${stats.memory}%\n`;
  if (stats.swap) formatted += `  Swap: ${stats.swap}%\n`;
  if (stats.storage) formatted += `  Storage: ${stats.storage}%\n`;

  // Device meta
  if (stats.deviceName) formatted += `  Device Name: ${stats.deviceName}\n`;
  if (stats.deviceDescription) formatted += `  Description: ${stats.deviceDescription}\n`;
  if (stats.ipAddress) formatted += `  IP Address: ${stats.ipAddress}\n`;
  if (stats.deviceHostname) formatted += `  Hostname: ${stats.deviceHostname}\n`;
  if (stats.deviceClass) formatted += `  Device Class: ${stats.deviceClass}\n`;
  if (stats.subClass) formatted += `  Sub-Class: ${stats.subClass}\n`;
  if (stats.category) formatted += `  Category: ${stats.category}\n`;
  if (stats.organization) formatted += `  Organization: ${stats.organization}\n`;
  if (stats.managedType) formatted += `  Managed Type: ${stats.managedType}\n`;
  if (stats.collectionMode) formatted += `  Collection Mode: ${stats.collectionMode}\n`;
  if (stats.uptime) formatted += `  Uptime: ${stats.uptime}\n`;
  if (stats.collectionTime) formatted += `  Collection Time: ${stats.collectionTime}\n`;
  if (stats.collectorGroup) formatted += `  Collector Group: ${stats.collectorGroup}\n`;
  if (stats.sourceSystem) formatted += `  Source System: ${stats.sourceSystem}\n`;
  if (stats.lastSyncedAt) formatted += `  Last Synced: ${stats.lastSyncedAt}\n`;

  return formatted;
}

/**
 * Format Neptune results into human-readable response
 */
function formatResults(results: any, userQuery: string): string {
  if (!results.results?.bindings?.length) {
    return 'No results found.';
  }

  const bindings = results.results.bindings;
  const count = bindings.length;

  // For count queries
  if (bindings[0].count) {
    return `Found ${bindings[0].count.value} results.`;
  }

  // Detect if this is a stats/health query by checking for stats fields
  const hasStatsFields = bindings.some((b: any) =>
    STAT_PROPERTIES.some(prop => b[prop]?.value)
  );

  if (hasStatsFields) {
    let formatted = `Health/Stats Report (${count} entit${count > 1 ? 'ies' : 'y'}):\n\n`;
    bindings.slice(0, 30).forEach((binding: any) => {
      formatted += formatEntityStats(binding) + '\n';
    });
    if (count > 30) {
      formatted += `\n... and ${count - 30} more entities.`;
    }
    return formatted.trim();
  }

  // For entity lists
  let formatted = `Found ${count} result${count > 1 ? 's' : ''}:\n\n`;
  
  bindings.slice(0, 20).forEach((binding: any, index: number) => {
    formatted += `${index + 1}. `;
    
    // Extract key fields
    const fields: string[] = [];
    if (binding.name) fields.push(binding.name.value);
    if (binding.type) fields.push(`(${binding.type.value})`);
    if (binding.status) fields.push(`[${binding.status.value}]`);
    if (binding.owner) fields.push(`Owner: ${binding.owner.value}`);
    if (binding.description) fields.push(binding.description.value);
    
    // For relationship queries
    if (binding.source && binding.target) {
      fields.push(`${binding.source.value} → ${binding.relType?.value || 'relates to'} → ${binding.target.value}`);
    }
    
    // For config queries
    if (binding.key && binding.value) {
      fields.push(`${binding.key.value}: ${binding.value.value}`);
    }
    
    formatted += fields.join(' | ') + '\n';
  });

  if (count > 20) {
    formatted += `\n... and ${count - 20} more results.`;
  }

  return formatted.trim();
}

/**
 * Main Lambda handler
 */
export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  };

  try {
    // Handle CORS preflight
    if (event.httpMethod === 'OPTIONS') {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ message: 'CORS preflight successful' }),
      };
    }

    // Parse request body
    let body: any = {};
    if (event.body) {
      body = JSON.parse(event.body);
    }

    // Determine the operation type from path or body/query params
    const path = event.path || event.resource || '';
    let operation: string;
    if (path.includes('/stats')) {
      operation = 'entity-stats';
    } else if (path.includes('/health-dashboard')) {
      operation = 'health-dashboard';
    } else {
      operation = body.operation || event.queryStringParameters?.operation || 'query';
    }
    const userQuery = body.query || event.queryStringParameters?.query;
    const entityId = body.entityId || event.queryStringParameters?.entityId;
    const entityName = body.entityName || event.queryStringParameters?.entityName;
    const entityType = body.entityType || event.queryStringParameters?.entityType;

    console.log(`Operation: ${operation}`);

    // Handle different operations
    switch (operation.toLowerCase()) {
      // --- Direct entity stats/health endpoint ---
      case 'entity-stats': {
        const identifier = entityName || entityId;
        if (!identifier) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({
              error: 'Missing required parameter: entityName or entityId',
              example: { operation: 'entity-stats', entityName: 'CAS_QA' },
            }),
          };
        }

        console.log(`Fetching stats for entity: ${identifier}`);
        const statsResults = await getEntityStats(identifier);
        const bindings = statsResults.results?.bindings || [];

        if (bindings.length === 0) {
          return {
            statusCode: 404,
            headers,
            body: JSON.stringify({
              success: false,
              error: `Entity not found: ${identifier}`,
            }),
          };
        }

        const binding = bindings[0];
        const stats = parseStatsFromBinding(binding);

        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            success: true,
            operation: 'entity-stats',
            entity: {
              id: binding.id?.value,
              name: binding.name?.value,
              type: binding.type?.value,
              status: binding.status?.value,
            },
            stats,
            hasStats: Object.keys(stats).length > 0,
            formatted: formatEntityStats(binding),
            timestamp: new Date().toISOString(),
          }),
        };
      }

      // --- Health dashboard endpoint ---
      case 'health-dashboard': {
        console.log(`Fetching health dashboard${entityType ? ` for type: ${entityType}` : ''}`);
        const dashResults = await getHealthDashboard(entityType);
        const dashBindings = dashResults.results?.bindings || [];

        const entities = dashBindings.map((binding: any) => ({
          id: binding.id?.value,
          name: binding.name?.value,
          type: binding.type?.value,
          status: binding.status?.value,
          stats: parseStatsFromBinding(binding),
        }));

        const withStats = entities.filter((e: any) => Object.keys(e.stats).length > 0);
        const unhealthy = entities.filter((e: any) => {
          const score = parseFloat(e.stats.healthScore);
          return !isNaN(score) && score < 80;
        });

        // Compute aggregate summary
        const avgHealthScore = withStats.length > 0
          ? withStats.reduce((sum: number, e: any) => {
              const score = parseFloat(e.stats.healthScore);
              return sum + (isNaN(score) ? 0 : score);
            }, 0) / withStats.filter((e: any) => e.stats.healthScore).length || 0
          : null;

        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            success: true,
            operation: 'health-dashboard',
            summary: {
              totalEntities: entities.length,
              entitiesWithStats: withStats.length,
              unhealthyEntities: unhealthy.length,
              averageHealthScore: avgHealthScore ? Math.round(avgHealthScore * 100) / 100 : null,
            },
            entities,
            unhealthy,
            timestamp: new Date().toISOString(),
          }),
        };
      }

      // --- Default: natural language query via Bedrock ---
      case 'query':
      default: {
        if (!userQuery) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({
              error: 'Missing required parameter: query',
              availableOperations: [
                { operation: 'query', description: 'Natural language query via Bedrock AI', params: ['query'] },
                { operation: 'entity-stats', description: 'Get stats/health for a specific entity', params: ['entityName or entityId'] },
                { operation: 'health-dashboard', description: 'Get health overview of all entities', params: ['entityType (optional)'] },
              ],
              example: { query: 'Show all active environments' },
            }),
          };
        }

        console.log(`User query: ${userQuery}`);

        // Step 1: Generate SPARQL using Bedrock
        const sparqlQuery = await generateSparqlWithBedrock(userQuery);

        // Step 2: Execute SPARQL on Neptune
        const results = await executeSparqlQuery(sparqlQuery);

        // Step 3: Format results
        const formattedResponse = formatResults(results, userQuery);

        // Return response
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            success: true,
            operation: 'query',
            query: userQuery,
            sparql: sparqlQuery,
            resultCount: results.results?.bindings?.length || 0,
            results: results.results?.bindings || [],
            formatted: formattedResponse,
            timestamp: new Date().toISOString(),
          }),
        };
      }
    }

  } catch (error: any) {
    console.error('Handler error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      }),
    };
  }
};
