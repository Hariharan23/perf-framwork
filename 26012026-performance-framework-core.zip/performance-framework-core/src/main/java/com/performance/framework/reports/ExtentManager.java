package com.performance.framework.reports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.performance.framework.config.ConfigManager;
import com.performance.framework.config.ReportingConfig;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

// Manages ExtentReports - single consolidated report for all tests
@Slf4j
public class ExtentManager {

    private static ExtentReports extent;
    private static final ThreadLocal<ExtentTest> testThreadLocal = new ThreadLocal<>();
    private static String reportPath;

    private ExtentManager() {
    }

    public static synchronized ExtentReports getInstance() {
        if (extent == null) {
            createInstance();
        }
        return extent;
    }

    private static void createInstance() {
        ReportingConfig config = ConfigManager.getInstance().getReportingConfig();

        log.info("Creating consolidated test report");

        String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
        String reportFileName = String.format("TestReport_%s.html", timestamp);
        reportPath = config.getReportPath() + "/" + reportFileName;

        File reportDir = new File(config.getReportPath());
        if (!reportDir.exists()) {
            reportDir.mkdirs();
        }

        ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
        sparkReporter.config().setDocumentTitle(config.getDocumentTitle());
        sparkReporter.config().setReportName(config.getReportName());
        sparkReporter.config().setTheme("DARK".equalsIgnoreCase(config.getTheme()) ? Theme.DARK : Theme.STANDARD);
        sparkReporter.config().setEncoding("UTF-8");
        sparkReporter.config().setTimeStampFormat("yyyy-MM-dd HH:mm:ss");
        sparkReporter.config().setCss(getCustomCss());
        sparkReporter.config().setJs(getCustomJs());

        extent = new ExtentReports();
        extent.attachReporter(sparkReporter);
        setSystemInfo();

        log.info("Report initialized at: {}", reportPath);
    }

    private static void setSystemInfo() {
        ConfigManager configManager = ConfigManager.getInstance();

        extent.setSystemInfo("Framework", "Selenium Performance Framework v1.0");
        extent.setSystemInfo("Environment", configManager.getEnvironmentConfig(null).getName());
        extent.setSystemInfo("Browser", configManager.getBrowserConfig().getType());
        extent.setSystemInfo("Grid URL", getGridInfo());
        extent.setSystemInfo("OS", System.getProperty("os.name"));
        extent.setSystemInfo("Java Version", System.getProperty("java.version"));
        extent.setSystemInfo("User", System.getProperty("user.name"));
    }

    /**
     * Get Selenium Grid information if available.
     */
    private static String getGridInfo() {
        ConfigManager configManager = ConfigManager.getInstance();
        if (configManager.getBrowserConfig().isUseGrid()) {
            return configManager.getBrowserConfig().getGridUrl();
        }
        return "Local Execution";
    }

    public static ExtentTest createTest(String testName) {
        ExtentTest test = getInstance().createTest(testName);
        testThreadLocal.set(test);
        log.debug("Created test in report: {}", testName);
        return test;
    }

    public static ExtentTest createTest(String testName, String description) {
        ExtentTest test = getInstance().createTest(testName, description);
        testThreadLocal.set(test);
        log.debug("Created test in report: {} - {}", testName, description);
        return test;
    }

    public static ExtentTest getTest() {
        return testThreadLocal.get();
    }

    public static void logInfo(String message) {
        ExtentTest test = getTest();
        if (test != null) {
            test.log(Status.INFO, message);
        }
    }

    public static void logPass(String message) {
        ExtentTest test = getTest();
        if (test != null) {
            test.log(Status.PASS, message);
        }
    }

    public static void logFail(String message) {
        ExtentTest test = getTest();
        if (test != null) {
            test.log(Status.FAIL, message);
        }
    }

    public static void logWarning(String message) {
        ExtentTest test = getTest();
        if (test != null) {
            test.log(Status.WARNING, message);
        }
    }

    public static void logSkip(String message) {
        ExtentTest test = getTest();
        if (test != null) {
            test.log(Status.SKIP, message);
        }
    }

    public static void attachScreenshot(String base64Screenshot, String title) {
        ExtentTest test = getTest();
        if (test != null && base64Screenshot != null) {
            test.addScreenCaptureFromBase64String(base64Screenshot, title);
        }
    }

    public static void flush() {
        if (extent != null) {
            extent.flush();
            log.info("Extent report flushed to: {}", reportPath);
        }
    }

    public static void removeTest() {
        testThreadLocal.remove();
    }

    public static String getReportPath() {
        return reportPath;
    }

    private static String getCustomCss() {
        return ".performance-table { " +
                "width: 100%; " +
                "border-collapse: collapse; " +
                "margin: 15px 0; " +
                "font-size: 14px; " +
                "} " +
                ".performance-table th, .performance-table td { " +
                "padding: 10px; " +
                "text-align: left; " +
                "border-bottom: 1px solid #ddd; " +
                "} " +
                ".performance-table th { " +
                "background-color: #2c3e50; " +
                "color: white; " +
                "} " +
                ".performance-table tr:hover { " +
                "background-color: rgba(255,255,255,0.1); " +
                "} " +
                ".metric-pass { " +
                "color: #28a745; " +
                "font-weight: bold; " +
                "} " +
                ".metric-warn { " +
                "color: #ffc107; " +
                "font-weight: bold; " +
                "} " +
                ".metric-fail { " +
                "color: #dc3545; " +
                "font-weight: bold; " +
                "} " +
                ".metric-unknown { " +
                "color: #6c757d; " +
                "} " +
                ".performance-summary { " +
                "padding: 15px; " +
                "border-radius: 5px; " +
                "margin: 10px 0; " +
                "} " +
                ".summary-pass { " +
                "background-color: rgba(40, 167, 69, 0.2); " +
                "border-left: 4px solid #28a745; " +
                "} " +
                ".summary-warn { " +
                "background-color: rgba(255, 193, 7, 0.2); " +
                "border-left: 4px solid #ffc107; " +
                "} " +
                ".summary-fail { " +
                "background-color: rgba(220, 53, 69, 0.2); " +
                "border-left: 4px solid #dc3545; " +
                "} " +
                ".execution-context { " +
                "background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); " +
                "padding: 10px 15px; " +
                "border-radius: 6px; " +
                "margin: 8px 0; " +
                "color: #fff; " +
                "font-size: 13px; " +
                "display: inline-block; " +
                "box-shadow: 0 2px 4px rgba(0,0,0,0.2); " +
                "} " +
                ".execution-context b { " +
                "color: #90caf9; " +
                "}";
    }

    private static String getCustomJs() {
        return "document.addEventListener('DOMContentLoaded', function() { " +
                "var failedTests = document.querySelectorAll('.test-status.fail'); " +
                "failedTests.forEach(function(test) { " +
                "var parent = test.closest('.test-content'); " +
                "if (parent) { " +
                "parent.classList.add('expanded'); " +
                "} " +
                "}); " +
                "});";
    }
}
