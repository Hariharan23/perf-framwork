package com.performance.framework.driver;

import com.performance.framework.config.BrowserConfig;
import com.performance.framework.config.ConfigManager;
import com.performance.framework.config.NetworkConfig;
import io.github.bonigarcia.wdm.WebDriverManager;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.MutableCapabilities;

import java.net.MalformedURLException;
import java.net.URI;
import java.time.Duration;

// WebDriver factory with version-agnostic CDP support (works with any Chrome version)
@Slf4j
public class DriverFactory {

    private static final ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();

    private DriverFactory() {
    }

    public static WebDriver initDriver() {
        BrowserConfig browserConfig = ConfigManager.getInstance().getBrowserConfig();

        // Jenkins/CLI overrides
        String browserType = System.getProperty("browser.type",
                System.getProperty("browser", browserConfig.getType()));
        boolean useGrid = Boolean.parseBoolean(
                System.getProperty("browser.useGrid", String.valueOf(browserConfig.isUseGrid())));
        String gridUrl = System.getProperty("browser.gridUrl",
                System.getProperty("gridUrl", browserConfig.getGridUrl()));

        log.info("Initializing {} browser, useGrid={}, gridUrl={}", browserType, useGrid, gridUrl);

        WebDriver driver;

        if (useGrid && gridUrl != null && !gridUrl.isEmpty()) {
            driver = initRemoteDriver(browserConfig, browserType, gridUrl);
        } else {
            driver = initLocalDriver(browserConfig, browserType);
        }

        configureDriver(driver, browserConfig);
        driverThreadLocal.set(driver);
        log.info("WebDriver initialized successfully");
        return driver;
    }

    private static WebDriver initLocalDriver(BrowserConfig browserConfig, String browserType) {
        switch (browserType.toLowerCase()) {
            case "chrome":
                return initChromeDriver(browserConfig);
            case "firefox":
                return initFirefoxDriver(browserConfig);
            case "edge":
                return initEdgeDriver(browserConfig);
            default:
                log.warn("Unknown browser type: {}, defaulting to Chrome", browserType);
                return initChromeDriver(browserConfig);
        }
    }

    private static WebDriver initRemoteDriver(BrowserConfig config, String browserType, String gridUrl) {
        try {
            URI remoteUri = URI.create(gridUrl);
            log.info("Connecting to Selenium Grid at: {}", gridUrl);

            // Get network type from ThreadLocal (set by TestNG parameter)
            String networkType = getRequestedNetworkType();
            log.info("Requesting Grid node with networkType capability: {}", networkType);

            RemoteWebDriver driver;
            switch (browserType.toLowerCase()) {
                case "chrome": {
                    ChromeOptions options = createChromeOptions(config);
                    configureGridCapabilities(options, config, networkType);
                    driver = new RemoteWebDriver(remoteUri.toURL(), options);
                    break;
                }
                case "firefox": {
                    FirefoxOptions options = createFirefoxOptions(config);
                    configureGridCapabilities(options, config, networkType);
                    driver = new RemoteWebDriver(remoteUri.toURL(), options);
                    break;
                }
                case "edge": {
                    EdgeOptions options = createEdgeOptions(config);
                    configureGridCapabilities(options, config, networkType);
                    driver = new RemoteWebDriver(remoteUri.toURL(), options);
                    break;
                }
                default: {
                    log.warn("Unknown browser type: {}, defaulting to Chrome for Grid", browserType);
                    ChromeOptions defaultOptions = createChromeOptions(config);
                    configureGridCapabilities(defaultOptions, config, networkType);
                    driver = new RemoteWebDriver(remoteUri.toURL(), defaultOptions);
                }
            }

            // Store the actual network type from the matched node
            storeNodeNetworkType(driver);
            return driver;
        } catch (MalformedURLException e) {
            log.error("Invalid Grid URL: {}", gridUrl, e);
            throw new RuntimeException("Failed to connect to Selenium Grid: " + gridUrl, e);
        }
    }

    /**
     * Get the requested network type from ThreadLocal or system property.
     */
    private static String getRequestedNetworkType() {
        NetworkConfig.NetworkType threadType = NetworkConfig.getCurrentNetworkType();
        if (threadType != null && threadType != NetworkConfig.NetworkType.UNKNOWN) {
            return threadType.name().toLowerCase().replace("_", "-");
        }
        return null;
    }

    /**
     * Store the network type and machine ID from the Grid node capabilities.
     */
    private static void storeNodeNetworkType(RemoteWebDriver driver) {
        try {
            // Get networkType from Grid node
            Object networkType = driver.getCapabilities().getCapability("networkType");
            if (networkType != null) {
                String nodeNetworkType = networkType.toString();
                log.info("Grid node networkType capability: {}", nodeNetworkType);
                NetworkConfig.setThreadNetworkType(nodeNetworkType);
            } else {
                log.warn("Grid node does not have networkType capability set");
            }
            
            // Get machineId from Grid node (node hostname or configured ID)
            Object machineId = driver.getCapabilities().getCapability("machineId");
            if (machineId != null) {
                String nodeMachineId = machineId.toString();
                log.info("Grid node machineId capability: {}", nodeMachineId);
                NetworkConfig.setGridMachineId(nodeMachineId);
            } else {
                // Fallback: try to get node info from session
                String sessionHost = getGridNodeHost(driver);
                if (sessionHost != null) {
                    log.info("Grid node host from session: {}", sessionHost);
                    NetworkConfig.setGridMachineId(sessionHost);
                } else {
                    log.warn("Grid node does not have machineId capability - using local hostname");
                }
            }
            
            // Store Grid node info for debugging
            String gridInfo = String.format("Session: %s", driver.getSessionId());
            NetworkConfig.setGridNodeInfo(gridInfo);
            
        } catch (Exception e) {
            log.warn("Failed to read capabilities from Grid node: {}", e.getMessage());
        }
    }
    
    /**
     * Try to extract Grid node host from WebDriver session.
     */
    private static String getGridNodeHost(RemoteWebDriver driver) {
        try {
            // Try to get from se:cdp or other capabilities
            Object cdpUrl = driver.getCapabilities().getCapability("se:cdp");
            if (cdpUrl != null) {
                String url = cdpUrl.toString();
                // Extract host from URL like ws://hostname:port/...
                if (url.contains("://")) {
                    String hostPart = url.split("://")[1].split(":")[0].split("/")[0];
                    return hostPart;
                }
            }
        } catch (Exception e) {
            log.debug("Could not extract Grid node host: {}", e.getMessage());
        }
        return null;
    }

    /**
     * Configure Grid capabilities including networkType for node selection.
     * networkType is used to route tests to Netskope or Non-Netskope nodes.
     */
    private static void configureGridCapabilities(MutableCapabilities options, BrowserConfig config, String networkType) {
        if (config.getPlatformName() != null && !config.getPlatformName().isEmpty()) {
            options.setCapability("platformName", config.getPlatformName());
        }
        if (config.getBrowserVersion() != null && !config.getBrowserVersion().isEmpty()) {
            options.setCapability("browserVersion", config.getBrowserVersion());
        }
        // Add networkType capability for Grid node selection
        // This matches nodes configured with: --selenium-manager-option "networkType=netskope"
        if (networkType != null && !networkType.isEmpty()) {
            options.setCapability("networkType", networkType);
            log.info("Added networkType capability: {} for Grid node matching", networkType);
        }
    }

    private static ChromeOptions createChromeOptions(BrowserConfig config) {
        ChromeOptions options = new ChromeOptions();

        if (config.isHeadless()) {
            options.addArguments("--headless=new");
        }

        options.addArguments("--disable-gpu");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--disable-extensions");
        options.addArguments("--disable-popup-blocking");
        options.addArguments("--disable-infobars");
        options.addArguments("--enable-automation");
        options.addArguments("--enable-precise-memory-info");
        options.addArguments("--disable-default-apps");
        options.addArguments("--remote-allow-origins=*");
        options.setExperimentalOption("excludeSwitches", new String[] { "enable-logging" });

        log.debug("Chrome options configured: headless={}", config.isHeadless());
        return options;
    }

    private static FirefoxOptions createFirefoxOptions(BrowserConfig config) {
        FirefoxOptions options = new FirefoxOptions();

        if (config.isHeadless()) {
            options.addArguments("-headless");
        }

        log.debug("Firefox options configured: headless={}", config.isHeadless());
        return options;
    }

    private static EdgeOptions createEdgeOptions(BrowserConfig config) {
        EdgeOptions options = new EdgeOptions();

        if (config.isHeadless()) {
            options.addArguments("--headless=new");
        }

        options.addArguments("--disable-gpu");
        options.addArguments("--no-sandbox");
        options.addArguments("--remote-allow-origins=*");

        log.debug("Edge options configured: headless={}", config.isHeadless());
        return options;
    }

    private static WebDriver initChromeDriver(BrowserConfig config) {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = createChromeOptions(config);
        return new ChromeDriver(options);
    }

    private static WebDriver initFirefoxDriver(BrowserConfig config) {
        WebDriverManager.firefoxdriver().setup();
        FirefoxOptions options = createFirefoxOptions(config);
        return new FirefoxDriver(options);
    }

    private static WebDriver initEdgeDriver(BrowserConfig config) {
        WebDriverManager.edgedriver().setup();
        EdgeOptions options = createEdgeOptions(config);
        return new EdgeDriver(options);
    }

    private static void configureDriver(WebDriver driver, BrowserConfig config) {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(config.getImplicitWait()));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(config.getPageLoadTimeout()));
        driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(config.getScriptTimeout()));

        if (config.isMaximizeWindow()) {
            driver.manage().window().maximize();
        }

        log.debug("Driver configured with implicitWait={}, pageLoadTimeout={}, scriptTimeout={}",
                config.getImplicitWait(), config.getPageLoadTimeout(), config.getScriptTimeout());
    }

    public static WebDriver getDriver() {
        WebDriver driver = driverThreadLocal.get();
        if (driver == null) {
            throw new IllegalStateException("WebDriver not initialized. Call initDriver() first.");
        }
        return driver;
    }

    /**
     * Check if the current driver supports CDP (is a Chromium-based browser).
     * Use CDPManager for version-agnostic CDP operations.
     */
    public static boolean supportsCDP() {
        WebDriver driver = driverThreadLocal.get();
        return driver instanceof org.openqa.selenium.chromium.ChromiumDriver;
    }

    public static boolean isRunningOnGrid() {
        WebDriver driver = driverThreadLocal.get();
        return driver instanceof RemoteWebDriver && !(driver instanceof ChromeDriver)
                && !(driver instanceof FirefoxDriver) && !(driver instanceof EdgeDriver);
    }

    public static void quitDriver() {
        WebDriver driver = driverThreadLocal.get();
        if (driver != null) {
            try {
                driver.quit();
                log.info("WebDriver quit successfully");
            } catch (Exception e) {
                log.warn("Error quitting WebDriver", e);
            }
            driverThreadLocal.remove();
        }
    }

    public static void closeCurrentWindow() {
        WebDriver driver = driverThreadLocal.get();
        if (driver != null) {
            driver.close();
            log.debug("Current browser window closed");
        }
    }
}
