package com.performance.framework.config;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Environment configuration POJO
 */
@Data
@AllArgsConstructor
public class EnvironmentConfig {
    private String key;
    private String name;
    private String baseUrl;
}
