package com.performance.framework.opensearch;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.performance.framework.config.ConfigManager;
import com.performance.framework.config.OpenSearchConfig;
import com.performance.framework.performance.BenchmarkValidator;
import com.performance.framework.performance.PerformanceMetrics;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * OpenSearch client manager that aggregates Netskope and Non-Netskope metrics
 * into a single document for easy comparison analysis.
 */
@Slf4j
public class OpenSearchClientManager {

    private static OpenSearchClientManager instance;
    private CloseableHttpClient httpClient;
    private final OpenSearchConfig config;
    private final ObjectMapper objectMapper;
    private final BenchmarkValidator benchmarkValidator;
    private boolean initialized = false;
    private String baseUrl;

    // Store metrics by test key for aggregation (thread-safe)
    private final Map<String, PerformanceMetrics> netskopeMetrics = new ConcurrentHashMap<>();
    private final Map<String, PerformanceMetrics> nonNetskopeMetrics = new ConcurrentHashMap<>();

    private OpenSearchClientManager() {
        this.config = ConfigManager.getInstance().getOpenSearchConfig();
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
        this.benchmarkValidator = new BenchmarkValidator();
    }

    public static synchronized OpenSearchClientManager getInstance() {
        if (instance == null) {
            instance = new OpenSearchClientManager();
        }
        return instance;
    }

    public void initialize() {
        if (!config.isEnabled()) {
            log.info("OpenSearch integration is disabled");
            return;
        }

        if (initialized) {
            log.debug("OpenSearch client already initialized");
            return;
        }

        try {
            this.baseUrl = config.getConnectionUrl();

            HttpClientBuilder builder = HttpClients.custom();

            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(config.getConnectTimeout())
                    .setSocketTimeout(config.getSocketTimeout())
                    .setConnectionRequestTimeout(config.getConnectTimeout())
                    .build();
            builder.setDefaultRequestConfig(requestConfig);

            if (config.hasCredentials()) {
                CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
                credentialsProvider.setCredentials(
                        AuthScope.ANY,
                        new UsernamePasswordCredentials(config.getUsername(), config.getPassword()));
                builder.setDefaultCredentialsProvider(credentialsProvider);
            }

            httpClient = builder.build();
            initialized = true;

            ensureIndexExists();

            log.info("OpenSearch client initialized successfully: {}", baseUrl);
        } catch (Exception e) {
            log.error("Failed to initialize OpenSearch client", e);
            initialized = false;
        }
    }

    private void ensureIndexExists() {
        try {
            String indexUrl = baseUrl + "/" + config.getIndexName();
            HttpHead headRequest = new HttpHead(indexUrl);
            HttpResponse response = httpClient.execute(headRequest);
            int statusCode = response.getStatusLine().getStatusCode();
            EntityUtils.consumeQuietly(response.getEntity());

            if (statusCode == 404) {
                createIndex();
            } else if (statusCode == 200) {
                log.debug("Index {} already exists", config.getIndexName());
            }
        } catch (IOException e) {
            log.error("Failed to check index existence", e);
        }
    }

    private void createIndex() {
        try {
            String indexUrl = baseUrl + "/" + config.getIndexName();
            HttpPut putRequest = new HttpPut(indexUrl);

            Map<String, Object> indexBody = new HashMap<>();

            Map<String, Object> settings = new HashMap<>();
            settings.put("number_of_shards", 1);
            settings.put("number_of_replicas", 1);
            indexBody.put("settings", settings);

            Map<String, Object> mappings = new HashMap<>();
            mappings.put("properties", createMappingProperties());
            indexBody.put("mappings", mappings);

            String jsonBody = objectMapper.writeValueAsString(indexBody);
            putRequest.setEntity(new StringEntity(jsonBody, ContentType.APPLICATION_JSON));

            HttpResponse response = httpClient.execute(putRequest);
            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = EntityUtils.toString(response.getEntity());

            if (statusCode == 200 || statusCode == 201) {
                log.info("Created OpenSearch index: {}", config.getIndexName());
            } else {
                log.warn("Failed to create index, status: {}, response: {}", statusCode, responseBody);
            }
        } catch (IOException e) {
            log.error("Failed to create index", e);
        }
    }

    private Map<String, Object> createMappingProperties() {
        Map<String, Object> properties = new HashMap<>();

        // Common fields
        addFieldMapping(properties, "testName", "keyword");
        addFieldMapping(properties, "pageName", "keyword");
        addFieldMapping(properties, "url", "text");
        addFieldMapping(properties, "environment", "keyword");
        addFieldMapping(properties, "browser", "keyword");
        addFieldMapping(properties, "application", "keyword");
        addFieldMapping(properties, "timestamp", "date");

        // Netskope metrics
        addFieldMapping(properties, "netskope_pageLoadTime", "long");
        addFieldMapping(properties, "netskope_domContentLoaded", "long");
        addFieldMapping(properties, "netskope_domInteractive", "long");
        addFieldMapping(properties, "netskope_domComplete", "long");
        addFieldMapping(properties, "netskope_firstContentfulPaint", "long");
        addFieldMapping(properties, "netskope_largestContentfulPaint", "long");
        addFieldMapping(properties, "netskope_timeToInteractive", "long");
        addFieldMapping(properties, "netskope_firstInputDelay", "long");
        addFieldMapping(properties, "netskope_totalBlockingTime", "long");
        addFieldMapping(properties, "netskope_timeToFirstByte", "long");
        addFieldMapping(properties, "netskope_dnsLookupTime", "long");
        addFieldMapping(properties, "netskope_connectionTime", "long");
        addFieldMapping(properties, "netskope_tlsTime", "long");
        addFieldMapping(properties, "netskope_requestTime", "long");
        addFieldMapping(properties, "netskope_responseTime", "long");
        addFieldMapping(properties, "netskope_resourceCount", "integer");
        addFieldMapping(properties, "netskope_totalResourceSize", "long");
        addFieldMapping(properties, "netskope_totalTransferSize", "long");
        addFieldMapping(properties, "netskope_jsHeapUsedSize", "long");
        addFieldMapping(properties, "netskope_cumulativeLayoutShift", "double");
        addFieldMapping(properties, "netskope_status", "keyword");
        addFieldMapping(properties, "netskope_machineId", "keyword");

        // Non-Netskope metrics
        addFieldMapping(properties, "nonNetskope_pageLoadTime", "long");
        addFieldMapping(properties, "nonNetskope_domContentLoaded", "long");
        addFieldMapping(properties, "nonNetskope_domInteractive", "long");
        addFieldMapping(properties, "nonNetskope_domComplete", "long");
        addFieldMapping(properties, "nonNetskope_firstContentfulPaint", "long");
        addFieldMapping(properties, "nonNetskope_largestContentfulPaint", "long");
        addFieldMapping(properties, "nonNetskope_timeToInteractive", "long");
        addFieldMapping(properties, "nonNetskope_firstInputDelay", "long");
        addFieldMapping(properties, "nonNetskope_totalBlockingTime", "long");
        addFieldMapping(properties, "nonNetskope_timeToFirstByte", "long");
        addFieldMapping(properties, "nonNetskope_dnsLookupTime", "long");
        addFieldMapping(properties, "nonNetskope_connectionTime", "long");
        addFieldMapping(properties, "nonNetskope_tlsTime", "long");
        addFieldMapping(properties, "nonNetskope_requestTime", "long");
        addFieldMapping(properties, "nonNetskope_responseTime", "long");
        addFieldMapping(properties, "nonNetskope_resourceCount", "integer");
        addFieldMapping(properties, "nonNetskope_totalResourceSize", "long");
        addFieldMapping(properties, "nonNetskope_totalTransferSize", "long");
        addFieldMapping(properties, "nonNetskope_jsHeapUsedSize", "long");
        addFieldMapping(properties, "nonNetskope_cumulativeLayoutShift", "double");
        addFieldMapping(properties, "nonNetskope_status", "keyword");
        addFieldMapping(properties, "nonNetskope_machineId", "keyword");

        // Difference metrics (Netskope - NonNetskope, positive = Netskope slower)
        addFieldMapping(properties, "diff_pageLoadTime", "long");
        addFieldMapping(properties, "diff_domContentLoaded", "long");
        addFieldMapping(properties, "diff_firstContentfulPaint", "long");
        addFieldMapping(properties, "diff_largestContentfulPaint", "long");
        addFieldMapping(properties, "diff_timeToInteractive", "long");
        addFieldMapping(properties, "diff_timeToFirstByte", "long");
        addFieldMapping(properties, "diff_totalBlockingTime", "long");
        addFieldMapping(properties, "diff_dnsLookupTime", "long");
        addFieldMapping(properties, "diff_connectionTime", "long");
        addFieldMapping(properties, "diff_tlsTime", "long");

        // Percentage overhead (how much slower/faster is Netskope)
        addFieldMapping(properties, "overhead_pageLoadTime_percent", "double");
        addFieldMapping(properties, "overhead_firstContentfulPaint_percent", "double");
        addFieldMapping(properties, "overhead_largestContentfulPaint_percent", "double");
        addFieldMapping(properties, "overhead_timeToFirstByte_percent", "double");
        addFieldMapping(properties, "overhead_timeToInteractive_percent", "double");

        // Threshold values
        addFieldMapping(properties, "threshold_pageLoad", "long");
        addFieldMapping(properties, "threshold_pageLoad_warn", "long");
        addFieldMapping(properties, "threshold_firstContentfulPaint", "long");
        addFieldMapping(properties, "threshold_firstContentfulPaint_warn", "long");
        addFieldMapping(properties, "threshold_largestContentfulPaint", "long");
        addFieldMapping(properties, "threshold_largestContentfulPaint_warn", "long");
        addFieldMapping(properties, "threshold_timeToInteractive", "long");
        addFieldMapping(properties, "threshold_timeToInteractive_warn", "long");
        addFieldMapping(properties, "threshold_timeToFirstByte", "long");
        addFieldMapping(properties, "threshold_timeToFirstByte_warn", "long");
        addFieldMapping(properties, "threshold_firstInputDelay", "long");
        addFieldMapping(properties, "threshold_firstInputDelay_warn", "long");
        addFieldMapping(properties, "threshold_totalBlockingTime", "long");
        addFieldMapping(properties, "threshold_totalBlockingTime_warn", "long");

        // Overall comparison result
        addFieldMapping(properties, "comparisonStatus", "keyword");
        addFieldMapping(properties, "hasBothNetworks", "boolean");

        return properties;
    }

    private void addFieldMapping(Map<String, Object> properties, String fieldName, String fieldType) {
        Map<String, Object> field = new HashMap<>();
        field.put("type", fieldType);
        properties.put(fieldName, field);
    }

    /**
     * Store metrics for later aggregation. When both Netskope and Non-Netskope
     * metrics for the same test are available, they are combined and pushed.
     */
    public void storeMetrics(PerformanceMetrics metrics) {
        String key = generateTestKey(metrics);
        String networkType = metrics.getNetworkType() != null ? metrics.getNetworkType().toLowerCase() : "unknown";

        if (networkType.contains("netskope") && !networkType.contains("non")) {
            netskopeMetrics.put(key, metrics);
            log.debug("Stored Netskope metrics for: {}", key);
        } else if (networkType.contains("non")) {
            nonNetskopeMetrics.put(key, metrics);
            log.debug("Stored Non-Netskope metrics for: {}", key);
        } else {
            log.warn("Unknown network type '{}' for metrics: {}", networkType, key);
            return;
        }

        // Check if we have both and push combined document
        if (netskopeMetrics.containsKey(key) && nonNetskopeMetrics.containsKey(key)) {
            pushCombinedMetrics(key);
        }
    }

    /**
     * Generate consistent key for matching Netskope and Non-Netskope tests.
     */
    private String generateTestKey(PerformanceMetrics metrics) {
        return String.format("%s_%s_%s",
                metrics.getTestName(),
                metrics.getPageName(),
                metrics.getEnvironment());
    }

    /**
     * Push combined document with both network types.
     */
    private void pushCombinedMetrics(String testKey) {
        if (!config.isEnabled() || !initialized) {
            return;
        }

        PerformanceMetrics netskope = netskopeMetrics.get(testKey);
        PerformanceMetrics nonNetskope = nonNetskopeMetrics.get(testKey);

        if (netskope == null || nonNetskope == null) {
            log.warn("Missing metrics for combined push: {}", testKey);
            return;
        }

        try {
            Map<String, Object> document = createCombinedDocument(netskope, nonNetskope);
            String documentId = testKey.replaceAll("[^a-zA-Z0-9_]", "_") + "_"
                    + UUID.randomUUID().toString().substring(0, 8);

            String indexUrl = baseUrl + "/" + config.getIndexName() + "/_doc/" + documentId;
            HttpPut putRequest = new HttpPut(indexUrl);

            String jsonBody = objectMapper.writeValueAsString(document);
            putRequest.setEntity(new StringEntity(jsonBody, ContentType.APPLICATION_JSON));

            HttpResponse response = httpClient.execute(putRequest);
            int statusCode = response.getStatusLine().getStatusCode();
            EntityUtils.consumeQuietly(response.getEntity());

            if (statusCode == 200 || statusCode == 201) {
                log.info("Pushed combined Netskope/Non-Netskope metrics to OpenSearch: {}", testKey);
                // Clear stored metrics after successful push
                netskopeMetrics.remove(testKey);
                nonNetskopeMetrics.remove(testKey);
            } else {
                log.warn("Failed to push combined metrics, status: {}", statusCode);
            }
        } catch (Exception e) {
            log.error("Failed to push combined metrics", e);
        }
    }

    /**
     * Create document with both Netskope and Non-Netskope metrics for comparison.
     */
    private Map<String, Object> createCombinedDocument(PerformanceMetrics netskope, PerformanceMetrics nonNetskope) {
        Map<String, Object> doc = new HashMap<>();

        // Common fields (from either, they should be same)
        doc.put("testName", netskope.getTestName());
        doc.put("pageName", netskope.getPageName());
        doc.put("url", netskope.getUrl());
        doc.put("environment", netskope.getEnvironment());
        doc.put("browser", netskope.getBrowser());
        doc.put("application", netskope.getApplication());
        doc.put("timestamp", Instant.now().toString());
        doc.put("hasBothNetworks", true);

        // Netskope metrics
        doc.put("netskope_pageLoadTime", netskope.getPageLoadTime());
        doc.put("netskope_domContentLoaded", netskope.getDomContentLoaded());
        doc.put("netskope_domInteractive", netskope.getDomInteractive());
        doc.put("netskope_domComplete", netskope.getDomComplete());
        doc.put("netskope_firstContentfulPaint", netskope.getFirstContentfulPaint());
        doc.put("netskope_largestContentfulPaint", netskope.getLargestContentfulPaint());
        doc.put("netskope_timeToInteractive", netskope.getTimeToInteractive());
        doc.put("netskope_firstInputDelay", netskope.getFirstInputDelay());
        doc.put("netskope_totalBlockingTime", netskope.getTotalBlockingTime());
        doc.put("netskope_timeToFirstByte", netskope.getTimeToFirstByte());
        doc.put("netskope_dnsLookupTime", netskope.getDnsLookupTime());
        doc.put("netskope_connectionTime", netskope.getConnectionTime());
        doc.put("netskope_tlsTime", netskope.getTlsTime());
        doc.put("netskope_requestTime", netskope.getRequestTime());
        doc.put("netskope_responseTime", netskope.getResponseTime());
        doc.put("netskope_resourceCount", netskope.getResourceCount());
        doc.put("netskope_totalResourceSize", netskope.getTotalResourceSize());
        doc.put("netskope_totalTransferSize", netskope.getTotalTransferSize());
        doc.put("netskope_jsHeapUsedSize", netskope.getJsHeapUsedSize());
        doc.put("netskope_cumulativeLayoutShift", netskope.getCumulativeLayoutShift());
        doc.put("netskope_status", netskope.getOverallStatus().name());
        doc.put("netskope_machineId", netskope.getMachineId());

        // Non-Netskope metrics
        doc.put("nonNetskope_pageLoadTime", nonNetskope.getPageLoadTime());
        doc.put("nonNetskope_domContentLoaded", nonNetskope.getDomContentLoaded());
        doc.put("nonNetskope_domInteractive", nonNetskope.getDomInteractive());
        doc.put("nonNetskope_domComplete", nonNetskope.getDomComplete());
        doc.put("nonNetskope_firstContentfulPaint", nonNetskope.getFirstContentfulPaint());
        doc.put("nonNetskope_largestContentfulPaint", nonNetskope.getLargestContentfulPaint());
        doc.put("nonNetskope_timeToInteractive", nonNetskope.getTimeToInteractive());
        doc.put("nonNetskope_firstInputDelay", nonNetskope.getFirstInputDelay());
        doc.put("nonNetskope_totalBlockingTime", nonNetskope.getTotalBlockingTime());
        doc.put("nonNetskope_timeToFirstByte", nonNetskope.getTimeToFirstByte());
        doc.put("nonNetskope_dnsLookupTime", nonNetskope.getDnsLookupTime());
        doc.put("nonNetskope_connectionTime", nonNetskope.getConnectionTime());
        doc.put("nonNetskope_tlsTime", nonNetskope.getTlsTime());
        doc.put("nonNetskope_requestTime", nonNetskope.getRequestTime());
        doc.put("nonNetskope_responseTime", nonNetskope.getResponseTime());
        doc.put("nonNetskope_resourceCount", nonNetskope.getResourceCount());
        doc.put("nonNetskope_totalResourceSize", nonNetskope.getTotalResourceSize());
        doc.put("nonNetskope_totalTransferSize", nonNetskope.getTotalTransferSize());
        doc.put("nonNetskope_jsHeapUsedSize", nonNetskope.getJsHeapUsedSize());
        doc.put("nonNetskope_cumulativeLayoutShift", nonNetskope.getCumulativeLayoutShift());
        doc.put("nonNetskope_status", nonNetskope.getOverallStatus().name());
        doc.put("nonNetskope_machineId", nonNetskope.getMachineId());

        // Calculate differences (Netskope - NonNetskope, positive = Netskope slower)
        doc.put("diff_pageLoadTime", netskope.getPageLoadTime() - nonNetskope.getPageLoadTime());
        doc.put("diff_domContentLoaded", netskope.getDomContentLoaded() - nonNetskope.getDomContentLoaded());
        doc.put("diff_firstContentfulPaint",
                netskope.getFirstContentfulPaint() - nonNetskope.getFirstContentfulPaint());
        doc.put("diff_largestContentfulPaint",
                netskope.getLargestContentfulPaint() - nonNetskope.getLargestContentfulPaint());
        doc.put("diff_timeToInteractive", netskope.getTimeToInteractive() - nonNetskope.getTimeToInteractive());
        doc.put("diff_timeToFirstByte", netskope.getTimeToFirstByte() - nonNetskope.getTimeToFirstByte());
        doc.put("diff_totalBlockingTime", netskope.getTotalBlockingTime() - nonNetskope.getTotalBlockingTime());
        doc.put("diff_dnsLookupTime", netskope.getDnsLookupTime() - nonNetskope.getDnsLookupTime());
        doc.put("diff_connectionTime", netskope.getConnectionTime() - nonNetskope.getConnectionTime());
        doc.put("diff_tlsTime", netskope.getTlsTime() - nonNetskope.getTlsTime());

        // Calculate percentage overhead
        doc.put("overhead_pageLoadTime_percent",
                calculateOverhead(netskope.getPageLoadTime(), nonNetskope.getPageLoadTime()));
        doc.put("overhead_firstContentfulPaint_percent",
                calculateOverhead(netskope.getFirstContentfulPaint(), nonNetskope.getFirstContentfulPaint()));
        doc.put("overhead_largestContentfulPaint_percent",
                calculateOverhead(netskope.getLargestContentfulPaint(), nonNetskope.getLargestContentfulPaint()));
        doc.put("overhead_timeToFirstByte_percent",
                calculateOverhead(netskope.getTimeToFirstByte(), nonNetskope.getTimeToFirstByte()));
        doc.put("overhead_timeToInteractive_percent",
                calculateOverhead(netskope.getTimeToInteractive(), nonNetskope.getTimeToInteractive()));

        // Thresholds
        addThresholdValues(doc);

        // Overall comparison status
        doc.put("comparisonStatus", determineComparisonStatus(netskope, nonNetskope));

        return doc;
    }

    /**
     * Calculate percentage overhead (how much slower/faster Netskope is vs
     * Non-Netskope).
     * Positive = Netskope slower, Negative = Netskope faster
     */
    private double calculateOverhead(long netskopeValue, long nonNetskopeValue) {
        if (nonNetskopeValue == 0)
            return 0.0;
        return Math.round(((double) (netskopeValue - nonNetskopeValue) / nonNetskopeValue) * 10000) / 100.0;
    }

    /**
     * Determine overall comparison status based on overhead percentage.
     */
    private String determineComparisonStatus(PerformanceMetrics netskope, PerformanceMetrics nonNetskope) {
        double overheadPercent = calculateOverhead(netskope.getPageLoadTime(), nonNetskope.getPageLoadTime());

        if (overheadPercent > 50)
            return "CRITICAL_OVERHEAD";
        if (overheadPercent > 25)
            return "HIGH_OVERHEAD";
        if (overheadPercent > 10)
            return "MODERATE_OVERHEAD";
        if (overheadPercent > 0)
            return "LOW_OVERHEAD";
        if (overheadPercent < -10)
            return "NETSKOPE_FASTER";
        return "SIMILAR";
    }

    /**
     * Add threshold values from benchmark configuration to the document.
     */
    private void addThresholdValues(Map<String, Object> document) {
        BenchmarkValidator.BenchmarkThreshold pageLoad = benchmarkValidator.getThreshold("pageLoad");
        document.put("threshold_pageLoad", pageLoad.getMaxThreshold());
        document.put("threshold_pageLoad_warn", pageLoad.getWarnThreshold());

        BenchmarkValidator.BenchmarkThreshold fcp = benchmarkValidator.getThreshold("firstContentfulPaint");
        document.put("threshold_firstContentfulPaint", fcp.getMaxThreshold());
        document.put("threshold_firstContentfulPaint_warn", fcp.getWarnThreshold());

        BenchmarkValidator.BenchmarkThreshold lcp = benchmarkValidator.getThreshold("largestContentfulPaint");
        document.put("threshold_largestContentfulPaint", lcp.getMaxThreshold());
        document.put("threshold_largestContentfulPaint_warn", lcp.getWarnThreshold());

        BenchmarkValidator.BenchmarkThreshold tti = benchmarkValidator.getThreshold("timeToInteractive");
        document.put("threshold_timeToInteractive", tti.getMaxThreshold());
        document.put("threshold_timeToInteractive_warn", tti.getWarnThreshold());

        BenchmarkValidator.BenchmarkThreshold ttfb = benchmarkValidator.getThreshold("firstByte");
        document.put("threshold_timeToFirstByte", ttfb.getMaxThreshold());
        document.put("threshold_timeToFirstByte_warn", ttfb.getWarnThreshold());

        BenchmarkValidator.BenchmarkThreshold fid = benchmarkValidator.getThreshold("firstInputDelay");
        document.put("threshold_firstInputDelay", fid.getMaxThreshold());
        document.put("threshold_firstInputDelay_warn", fid.getWarnThreshold());

        BenchmarkValidator.BenchmarkThreshold tbt = benchmarkValidator.getThreshold("totalBlockingTime");
        document.put("threshold_totalBlockingTime", tbt.getMaxThreshold());
        document.put("threshold_totalBlockingTime_warn", tbt.getWarnThreshold());
    }

    /**
     * Push any remaining unpaired metrics at end of test suite.
     * Called automatically when close() is invoked.
     */
    public void flushRemainingMetrics() {
        if (!config.isEnabled() || !initialized) {
            return;
        }

        log.info("Flushing remaining unpaired metrics...");

        // Push unpaired Netskope metrics
        for (Map.Entry<String, PerformanceMetrics> entry : netskopeMetrics.entrySet()) {
            pushSingleNetworkMetrics(entry.getValue(), "netskope");
        }

        // Push unpaired Non-Netskope metrics
        for (Map.Entry<String, PerformanceMetrics> entry : nonNetskopeMetrics.entrySet()) {
            pushSingleNetworkMetrics(entry.getValue(), "non-netskope");
        }

        int netskopeCount = netskopeMetrics.size();
        int nonNetskopeCount = nonNetskopeMetrics.size();

        netskopeMetrics.clear();
        nonNetskopeMetrics.clear();

        if (netskopeCount > 0 || nonNetskopeCount > 0) {
            log.info("Flushed {} Netskope and {} Non-Netskope unpaired metrics", netskopeCount, nonNetskopeCount);
        }
    }

    /**
     * Push single network metrics when pair is not available.
     */
    private void pushSingleNetworkMetrics(PerformanceMetrics metrics, String networkType) {
        try {
            Map<String, Object> doc = new HashMap<>();

            doc.put("testName", metrics.getTestName());
            doc.put("pageName", metrics.getPageName());
            doc.put("url", metrics.getUrl());
            doc.put("environment", metrics.getEnvironment());
            doc.put("browser", metrics.getBrowser());
            doc.put("application", metrics.getApplication());
            doc.put("timestamp", Instant.now().toString());
            doc.put("hasBothNetworks", false);

            String prefix = "netskope".equals(networkType) ? "netskope_" : "nonNetskope_";

            doc.put(prefix + "pageLoadTime", metrics.getPageLoadTime());
            doc.put(prefix + "domContentLoaded", metrics.getDomContentLoaded());
            doc.put(prefix + "domInteractive", metrics.getDomInteractive());
            doc.put(prefix + "domComplete", metrics.getDomComplete());
            doc.put(prefix + "firstContentfulPaint", metrics.getFirstContentfulPaint());
            doc.put(prefix + "largestContentfulPaint", metrics.getLargestContentfulPaint());
            doc.put(prefix + "timeToInteractive", metrics.getTimeToInteractive());
            doc.put(prefix + "firstInputDelay", metrics.getFirstInputDelay());
            doc.put(prefix + "totalBlockingTime", metrics.getTotalBlockingTime());
            doc.put(prefix + "timeToFirstByte", metrics.getTimeToFirstByte());
            doc.put(prefix + "dnsLookupTime", metrics.getDnsLookupTime());
            doc.put(prefix + "connectionTime", metrics.getConnectionTime());
            doc.put(prefix + "tlsTime", metrics.getTlsTime());
            doc.put(prefix + "requestTime", metrics.getRequestTime());
            doc.put(prefix + "responseTime", metrics.getResponseTime());
            doc.put(prefix + "resourceCount", metrics.getResourceCount());
            doc.put(prefix + "totalResourceSize", metrics.getTotalResourceSize());
            doc.put(prefix + "cumulativeLayoutShift", metrics.getCumulativeLayoutShift());
            doc.put(prefix + "status", metrics.getOverallStatus().name());
            doc.put(prefix + "machineId", metrics.getMachineId());

            addThresholdValues(doc);
            doc.put("comparisonStatus", "SINGLE_NETWORK_ONLY");

            String testKey = generateTestKey(metrics);
            String documentId = testKey.replaceAll("[^a-zA-Z0-9_]", "_") + "_" + networkType + "_"
                    + UUID.randomUUID().toString().substring(0, 8);
            String indexUrl = baseUrl + "/" + config.getIndexName() + "/_doc/" + documentId;
            HttpPut putRequest = new HttpPut(indexUrl);

            String jsonBody = objectMapper.writeValueAsString(doc);
            putRequest.setEntity(new StringEntity(jsonBody, ContentType.APPLICATION_JSON));

            HttpResponse response = httpClient.execute(putRequest);
            int statusCode = response.getStatusLine().getStatusCode();
            EntityUtils.consumeQuietly(response.getEntity());

            if (statusCode == 200 || statusCode == 201) {
                log.info("Pushed single network metrics: {} ({})", testKey, networkType);
            }
        } catch (Exception e) {
            log.error("Failed to push single network metrics", e);
        }
    }

    /**
     * Main entry point for pushing metrics. Stores metrics and automatically
     * combines with matching network type when available.
     */
    public boolean pushMetrics(PerformanceMetrics metrics) {
        if (!config.isEnabled() || !initialized) {
            log.debug("OpenSearch is disabled or not initialized");
            return false;
        }

        storeMetrics(metrics);
        return true;
    }

    /**
     * Push metrics with additional metadata.
     */
    public boolean pushMetricsWithMetadata(PerformanceMetrics metrics, Map<String, Object> additionalData) {
        if (!config.isEnabled() || !initialized) {
            return false;
        }

        // For now, just store metrics normally - additional data can be added later
        storeMetrics(metrics);
        return true;
    }

    /**
     * Check if OpenSearch is connected and available.
     */
    public boolean isAvailable() {
        if (!config.isEnabled() || !initialized || httpClient == null) {
            return false;
        }

        try {
            HttpGet getRequest = new HttpGet(baseUrl);
            HttpResponse response = httpClient.execute(getRequest);
            int statusCode = response.getStatusLine().getStatusCode();
            EntityUtils.consumeQuietly(response.getEntity());
            return statusCode == 200;
        } catch (IOException e) {
            log.warn("OpenSearch ping failed", e);
            return false;
        }
    }

    /**
     * Close the OpenSearch client connection.
     * Automatically flushes any remaining unpaired metrics before closing.
     */
    public void close() {
        // Flush remaining unpaired metrics before closing
        flushRemainingMetrics();

        if (httpClient != null) {
            try {
                httpClient.close();
                log.info("OpenSearch client closed");
            } catch (IOException e) {
                log.error("Error closing OpenSearch client", e);
            }
        }
        initialized = false;
    }

    /**
     * Get the index name.
     */
    public String getIndexName() {
        return config.getIndexName();
    }

    /**
     * Get count of pending Netskope metrics waiting for pairing.
     */
    public int getPendingNetskopeCount() {
        return netskopeMetrics.size();
    }

    /**
     * Get count of pending Non-Netskope metrics waiting for pairing.
     */
    public int getPendingNonNetskopeCount() {
        return nonNetskopeMetrics.size();
    }
}
