package com.performance.framework.config;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * Network config for Netskope vs Non-Netskope comparison testing.
 * 
 * Priority order for network type resolution:
 * 1. ThreadLocal (set from Grid node capability or TestNG parameter)
 * 2. System property: -Dnetwork.type=netskope
 * 3. Environment variable: NETWORK_TYPE
 * 4. Config file: application.yaml
 * 
 * For Selenium Grid, nodes should be configured with networkType capability:
 * java -jar selenium-server.jar node --selenium-manager-option "networkType=netskope"
 */
@Data
@Slf4j
public class NetworkConfig {

    // InheritableThreadLocal for parallel test execution - inherited by child threads
    private static final InheritableThreadLocal<NetworkType> threadNetworkType = new InheritableThreadLocal<>();

    // Store Grid node info when available
    private static final InheritableThreadLocal<String> gridNodeInfo = new InheritableThreadLocal<>();
    
    // Store Grid node machine ID (from Grid node capability)
    private static final InheritableThreadLocal<String> gridMachineId = new InheritableThreadLocal<>();

    public enum NetworkType {
        NETSKOPE("Netskope", "Traffic via Netskope proxy"),
        NON_NETSKOPE("Non-Netskope", "Direct network access"),
        UNKNOWN("Unknown", "Not specified");

        private final String displayName;
        private final String description;

        NetworkType(String displayName, String description) {
            this.displayName = displayName;
            this.description = description;
        }

        public String getDisplayName() {
            return displayName;
        }

        public String getDescription() {
            return description;
        }

        public static NetworkType fromString(String value) {
            if (value == null || value.trim().isEmpty()) {
                return UNKNOWN;
            }

            String normalized = value.trim().toLowerCase().replace("-", "").replace("_", "");

            if (normalized.contains("netskope") && !normalized.contains("non")) {
                return NETSKOPE;
            } else if (normalized.contains("non") || normalized.contains("direct")) {
                return NON_NETSKOPE;
            }

            // Try exact match
            for (NetworkType type : values()) {
                if (type.name().equalsIgnoreCase(value.trim())) {
                    return type;
                }
            }

            return UNKNOWN;
        }
    }

    private NetworkType type = NetworkType.UNKNOWN;
    private String description;
    private String machineName;
    private String machineId;

    // Priority: ThreadLocal (parallel) > system property > env var > config file
    public static NetworkType getCurrentNetworkType() {
        // Check ThreadLocal first (for parallel execution)
        NetworkType threadType = threadNetworkType.get();
        if (threadType != null) {
            return threadType;
        }

        String sysProp = System.getProperty("network.type");
        if (sysProp != null && !sysProp.isEmpty()) {
            NetworkType type = NetworkType.fromString(sysProp);
            log.debug("Network type from system property: {}", type);
            return type;
        }

        String envVar = System.getenv("NETWORK_TYPE");
        if (envVar != null && !envVar.isEmpty()) {
            NetworkType type = NetworkType.fromString(envVar);
            log.debug("Network type from environment variable: {}", type);
            return type;
        }

        try {
            String configType = ConfigManager.getInstance().getNetworkType();
            if (configType != null && !configType.isEmpty()) {
                NetworkType type = NetworkType.fromString(configType);
                log.debug("Network type from config file: {}", type);
                return type;
            }
        } catch (Exception e) {
            log.warn("Failed to get network type from config: {}", e.getMessage());
        }

        return NetworkType.UNKNOWN;
    }

    /**
     * Get machine identifier with priority:
     * 1. Grid node machineId capability (set by Grid)
     * 2. System property: -Dmachine.id=xxx
     * 3. Environment variable: MACHINE_ID
     * 4. Local hostname
     */
    public static String getMachineIdentifier() {
        // Check Grid machine ID first (for remote Grid execution)
        String gridMachine = gridMachineId.get();
        if (gridMachine != null && !gridMachine.isEmpty()) {
            return gridMachine;
        }
        
        String machineId = System.getProperty("machine.id");
        if (machineId != null && !machineId.isEmpty())
            return machineId;

        machineId = System.getenv("MACHINE_ID");
        if (machineId != null && !machineId.isEmpty())
            return machineId;

        try {
            return java.net.InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            return "unknown-machine";
        }
    }
    
    /**
     * Set Grid node machine ID (called by DriverFactory after connecting to Grid)
     */
    public static void setGridMachineId(String machineId) {
        gridMachineId.set(machineId);
        log.info("Thread [{}] Grid machine ID set to: {}", Thread.currentThread().getName(), machineId);
    }
    
    /**
     * Get Grid node machine ID if available
     */
    public static String getGridMachineId() {
        return gridMachineId.get();
    }

    public static boolean isNetskope() {
        return getCurrentNetworkType() == NetworkType.NETSKOPE;
    }

    public static boolean isNonNetskope() {
        return getCurrentNetworkType() == NetworkType.NON_NETSKOPE;
    }

    public static String getNetworkTypeForReport() {
        NetworkType type = getCurrentNetworkType();
        String machineId = getMachineIdentifier();
        return String.format("%s (%s)", type.getDisplayName(), machineId);
    }

    /**
     * Set network type for parallel execution (from Grid node capability or TestNG parameter)
     */
    public static void setThreadNetworkType(NetworkType type) {
        threadNetworkType.set(type);
        log.info("Thread [{}] network type set to: {}", Thread.currentThread().getName(), type);
    }

    public static void setThreadNetworkType(String type) {
        setThreadNetworkType(NetworkType.fromString(type));
    }

    /**
     * Store Grid node information for debugging and reporting
     */
    public static void setGridNodeInfo(String nodeInfo) {
        gridNodeInfo.set(nodeInfo);
        log.debug("Grid node info stored: {}", nodeInfo);
    }

    public static String getGridNodeInfo() {
        return gridNodeInfo.get();
    }

    public static void clearThreadNetworkType() {
        threadNetworkType.remove();
        gridNodeInfo.remove();
        gridMachineId.remove();
        log.debug("Thread network type, Grid info, and machine ID cleared");
    }
    
    /**
     * Get full execution context for reporting (networkType + machineId)
     */
    public static String getExecutionContext() {
        NetworkType type = getCurrentNetworkType();
        String machineId = getMachineIdentifier();
        String gridInfo = getGridNodeInfo();
        
        if (gridInfo != null && !gridInfo.isEmpty()) {
            return String.format("%s | Machine: %s | Grid: %s", type.getDisplayName(), machineId, gridInfo);
        }
        return String.format("%s | Machine: %s", type.getDisplayName(), machineId);
    }

    /**
     * Check if network type was explicitly set (vs defaulted)
     */
    public static boolean isNetworkTypeExplicitlySet() {
        return threadNetworkType.get() != null ||
                System.getProperty("network.type") != null ||
                System.getenv("NETWORK_TYPE") != null;
    }
}
