package com.performance.framework.comparison;

import com.performance.framework.config.NetworkConfig;
import com.performance.framework.config.NetworkConfig.NetworkType;
import com.performance.framework.performance.PerformanceMetrics;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

// Stores and compares metrics from Netskope vs Non-Netskope test runs
@SuppressWarnings("unused")
@Slf4j
public class NetworkPerformanceComparator {

    private static final NetworkPerformanceComparator INSTANCE = new NetworkPerformanceComparator();

    // Key: testName+pageName, Value: List of metrics from different runs
    private final Map<String, List<PerformanceMetrics>> metricsStore = new ConcurrentHashMap<>();

    private NetworkPerformanceComparator() {
    }

    public static NetworkPerformanceComparator getInstance() {
        return INSTANCE;
    }

    public void storeMetrics(PerformanceMetrics metrics) {
        String key = generateKey(metrics.getTestName(), metrics.getPageName());
        metricsStore.computeIfAbsent(key, k -> Collections.synchronizedList(new ArrayList<>())).add(metrics);
        log.debug("Stored metrics for {} (Network: {})", key, metrics.getNetworkType());
    }

    public Optional<NetworkComparisonResult> compareResults(String testName, String pageName) {
        String key = generateKey(testName, pageName);
        List<PerformanceMetrics> allMetrics = metricsStore.get(key);

        if (allMetrics == null || allMetrics.isEmpty()) {
            log.warn("No metrics found for comparison: {}", key);
            return Optional.empty();
        }

        // Find Netskope and Non-Netskope metrics
        PerformanceMetrics netskopeMetrics = findMetricsByNetworkType(allMetrics, NetworkType.NETSKOPE);
        PerformanceMetrics nonNetskopeMetrics = findMetricsByNetworkType(allMetrics, NetworkType.NON_NETSKOPE);

        if (netskopeMetrics == null || nonNetskopeMetrics == null) {
            log.warn("Incomplete comparison for {}: Netskope={}, Non-Netskope={}",
                    key, netskopeMetrics != null, nonNetskopeMetrics != null);
            return Optional.empty();
        }

        NetworkComparisonResult result = NetworkComparisonResult.builder()
                .testName(testName)
                .pageName(pageName)
                .netskopeMetrics(netskopeMetrics)
                .netskopeMachineId(netskopeMetrics.getMachineId())
                .nonNetskopeMetrics(nonNetskopeMetrics)
                .nonNetskopeMachineId(nonNetskopeMetrics.getMachineId())
                .build();

        result.calculateDifferences();
        return Optional.of(result);
    }

    public List<NetworkComparisonResult> compareAllResults() {
        List<NetworkComparisonResult> results = new ArrayList<>();

        for (String key : metricsStore.keySet()) {
            String[] parts = key.split("\\|");
            if (parts.length == 2) {
                compareResults(parts[0], parts[1]).ifPresent(results::add);
            }
        }

        return results;
    }

    /**
     * Get the latest metrics for a specific network type.
     */
    public Optional<PerformanceMetrics> getLatestMetrics(String testName, String pageName, NetworkType networkType) {
        String key = generateKey(testName, pageName);
        List<PerformanceMetrics> allMetrics = metricsStore.get(key);

        if (allMetrics == null) {
            return Optional.empty();
        }

        return allMetrics.stream()
                .filter(m -> isMatchingNetworkType(m.getNetworkType(), networkType))
                .max(Comparator.comparing(PerformanceMetrics::getTimestamp));
    }

    /**
     * Get all metrics for a specific network type.
     */
    public List<PerformanceMetrics> getMetricsByNetworkType(NetworkType networkType) {
        return metricsStore.values().stream()
                .flatMap(List::stream)
                .filter(m -> isMatchingNetworkType(m.getNetworkType(), networkType))
                .collect(Collectors.toList());
    }

    /**
     * Generate a summary report of all comparisons.
     */
    public String generateComparisonReport() {
        List<NetworkComparisonResult> comparisons = compareAllResults();

        if (comparisons.isEmpty()) {
            return "No complete Netskope vs Non-Netskope comparisons available.\n" +
                    "Ensure tests are run on both network types with proper configuration.";
        }

        StringBuilder report = new StringBuilder();
        report.append("\n╔══════════════════════════════════════════════════════════════════════════════╗\n");
        report.append("║             NETSKOPE vs NON-NETSKOPE COMPARISON SUMMARY REPORT               ║\n");
        report.append("╠══════════════════════════════════════════════════════════════════════════════╣\n");
        report.append(String.format("║  Total Comparisons: %-56d║\n", comparisons.size()));
        report.append("╚══════════════════════════════════════════════════════════════════════════════╝\n");

        for (NetworkComparisonResult comparison : comparisons) {
            report.append(comparison.getSummary());
            report.append("\n");
        }

        // Add overall summary
        report.append("╔══════════════════════════════════════════════════════════════════════════════╗\n");
        report.append("║                              OVERALL ANALYSIS                                ║\n");
        report.append("╠══════════════════════════════════════════════════════════════════════════════╣\n");

        // Calculate average differences
        long avgPageLoadDiff = 0;
        long avgTtfbDiff = 0;
        int count = 0;

        for (NetworkComparisonResult comp : comparisons) {
            if (comp.getPageLoadDiff() != null) {
                avgPageLoadDiff += comp.getPageLoadDiff().getAbsoluteDifference();
                count++;
            }
            if (comp.getTtfbDiff() != null) {
                avgTtfbDiff += comp.getTtfbDiff().getAbsoluteDifference();
            }
        }

        if (count > 0) {
            avgPageLoadDiff /= count;
            avgTtfbDiff /= count;
        }

        report.append(String.format("║  Average Page Load Difference: %+dms%45s║\n", avgPageLoadDiff, ""));
        report.append(String.format("║  Average TTFB Difference:      %+dms%45s║\n", avgTtfbDiff, ""));

        String impact = avgPageLoadDiff > 100 ? "Netskope adds noticeable latency"
                : avgPageLoadDiff < -100 ? "Netskope performs better (verify)" : "Network impact is minimal";
        report.append(String.format("║  Overall Assessment: %-55s║\n", impact));
        report.append("╚══════════════════════════════════════════════════════════════════════════════╝\n");

        return report.toString();
    }

    /**
     * Clear all stored metrics.
     */
    public void clearMetrics() {
        metricsStore.clear();
        log.info("All stored metrics cleared");
    }

    /**
     * Clear metrics older than specified hours.
     */
    public void clearOldMetrics(int hoursOld) {
        long cutoffTime = System.currentTimeMillis() - (hoursOld * 60 * 60 * 1000L);

        metricsStore.forEach((key, metricsList) -> {
            metricsList.removeIf(m -> m.getTimestamp().toEpochMilli() < cutoffTime);
        });

        // Remove empty entries
        metricsStore.entrySet().removeIf(entry -> entry.getValue().isEmpty());

        log.info("Cleared metrics older than {} hours", hoursOld);
    }

    private String generateKey(String testName, String pageName) {
        return testName + "|" + pageName;
    }

    private PerformanceMetrics findMetricsByNetworkType(List<PerformanceMetrics> metrics, NetworkType networkType) {
        return metrics.stream()
                .filter(m -> isMatchingNetworkType(m.getNetworkType(), networkType))
                .max(Comparator.comparing(PerformanceMetrics::getTimestamp))
                .orElse(null);
    }

    private boolean isMatchingNetworkType(String metricsNetworkType, NetworkType targetType) {
        if (metricsNetworkType == null)
            return false;

        String lowerType = metricsNetworkType.toLowerCase();
        switch (targetType) {
            case NETSKOPE:
                return lowerType.contains("netskope") && !lowerType.contains("non");
            case NON_NETSKOPE:
                return lowerType.contains("non") || lowerType.contains("direct");
            default:
                return false;
        }
    }
}
